package com.jh.insurance.policy.endpoint;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ws.context.MessageContext;
import org.springframework.ws.server.endpoint.annotation.Endpoint;
import org.springframework.ws.server.endpoint.annotation.PayloadRoot;
import org.springframework.ws.server.endpoint.annotation.RequestPayload;
import org.springframework.ws.server.endpoint.annotation.ResponsePayload;
import org.springframework.ws.soap.SoapHeaderElement;
import org.springframework.ws.soap.server.endpoint.annotation.SoapHeader;

import com.jh.insurance.policy.model.GetPolicyDetailsResponseWrapper;
import com.jh.insurance.policy.service.PolicyService;
import com.jh.insurance.policy.utils.HeaderKey;
import com.jh.insurance.policy.utils.JHHeaderJaxbUtils;
import com.manulife.esb.xsd.common.jh.header.JHHeader;
import com.manulife.esb.xsd.insurance.jh.policy.GetPolicyDetailsRequest;
import com.manulife.esb.xsd.insurance.jh.policy.GetPolicyDetailsResponse;

/**
 * Exposes Policy Operations via SOAP.
 *
 */
@Endpoint
public class PolicyEndpoint {
	private static final String NAMESPACE_URI = "http://www.esb.manulife.com/xsd/Insurance/jh/Policy";

	private static final String JH_HEADER_NS = "http://www.esb.manulife.com/xsd/common/jh/header";

	private static final Logger logger = LoggerFactory.getLogger(PolicyEndpoint.class);
	
	private final PolicyService policyService;
	
	private final JHHeaderJaxbUtils jhHeaderJaxbUtils;

	@Autowired
	public PolicyEndpoint(final PolicyService policyService, final JHHeaderJaxbUtils jhHeaderJaxbUtils) {
		this.policyService = policyService;
		this.jhHeaderJaxbUtils = jhHeaderJaxbUtils;
	}


	@PayloadRoot(namespace = NAMESPACE_URI, localPart = "GetPolicyDetails_request")
	@ResponsePayload
	public GetPolicyDetailsResponse getPolicyDetails(final @RequestPayload GetPolicyDetailsRequest request,
			final @SoapHeader("{" + JH_HEADER_NS + "}JHHeader")  SoapHeaderElement jhHeaderElement,
			MessageContext messageContext) {

		// parse JH Header if present
		JHHeader header = null;
		if (null != jhHeaderElement) {
			header = jhHeaderJaxbUtils.unmarshallJHHeader(jhHeaderElement);
			if (logger.isDebugEnabled()) {
			    logger.debug("JHHeader parsed with MessageUID of  [" + header.getMessageUID() + "]");
			}
		}
		GetPolicyDetailsResponseWrapper responseWrapper = policyService.getPolicyDetails(request, header);
		
	    // add response header as a property to be used by EndpointInterceptor
	    if (null != responseWrapper.getResponseHeader()) {
	    	messageContext.setProperty(HeaderKey.JH_HEADER_KEY.getValue(), responseWrapper.getResponseHeader());
	    }
        
		return policyService.getPolicyDetails(request, header).getResponse();
	}



}
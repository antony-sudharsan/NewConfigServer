package com.jh.insurance.policy.service;

import org.springframework.stereotype.Service;

import com.jh.insurance.policy.exception.PolicyException;
import com.jh.insurance.policy.model.GetPolicyDetailsResponseWrapper;
import com.jh.insurance.policy.utils.SampleDataUtils;
import com.manulife.esb.xsd.common.jh.commonmessage.FaultType;
import com.manulife.esb.xsd.common.jh.header.JHHeader;
import com.manulife.esb.xsd.insurance.jh.policy.GetPolicyDetailsFault;
import com.manulife.esb.xsd.insurance.jh.policy.GetPolicyDetailsRequest;
import com.manulife.esb.xsd.insurance.jh.policy.GetPolicyDetailsResponse;

/**
* Simulate common service to handle various endpoints. Currently just returns a sample response.
*/
@Service
public class PolicyService {
	
	// Need a valid example
	private static final String SAMPLE_ERROR_CODE = "TCH-ESB-E6000";
	private static final String SAMPLE_ERROR_DESCRIPTION = "Internal Exception";
	private final SampleDataUtils sampleDataUtils;
	
	public PolicyService( ) {
		this.sampleDataUtils = new SampleDataUtils();
	}

	// Decide if service should accept same Pojos as exposed API or transform to new types.
	public GetPolicyDetailsResponseWrapper getPolicyDetails(final GetPolicyDetailsRequest request, final JHHeader jhHeader) {
		
		// Return sample response for POC.
		if (request.getSubDivisionId() == null) {
			// just a test
			throwPolicyException();
		}
		GetPolicyDetailsResponse response = sampleDataUtils.createSampleGetPolicyDetailsResponse();
		JHHeader responseHeader = sampleDataUtils.createSampleGetPolicyDetailsResponseHeader();
		return new GetPolicyDetailsResponseWrapper(response, responseHeader);
		
	}
	
	private void throwPolicyException() {
		GetPolicyDetailsFault fault = new GetPolicyDetailsFault();
		FaultType sampleFault = new FaultType();		
		fault.setFault(sampleFault);
		sampleFault.setErrorCode(SAMPLE_ERROR_CODE);
		sampleFault.setErrorDescription(SAMPLE_ERROR_DESCRIPTION);
		
		throw new PolicyException(fault);
	}
}

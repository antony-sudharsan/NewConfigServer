package com.jh.insurance.policy.model;

import com.manulife.esb.xsd.common.jh.header.JHHeader;
import com.manulife.esb.xsd.insurance.jh.policy.GetPolicyDetailsRequest;

public class GetPolicyDetailsRequestWrapper {
	private GetPolicyDetailsRequest request;
	private JHHeader requestHeader;

	public GetPolicyDetailsRequestWrapper() {
		
	}
	
	public GetPolicyDetailsRequestWrapper(final GetPolicyDetailsRequest request, final JHHeader requestHeader) {
		this.request = request;
		this.requestHeader = requestHeader;
	}
	
	public GetPolicyDetailsRequest getRequest() {
		return request;
	}
	
	public void setRequest(GetPolicyDetailsRequest request) {
		this.request = request;
	}

	public JHHeader getRequestHeader() {
		return requestHeader;
	}
	
	public void setRequestHeader(JHHeader requestHeader) {
		this.requestHeader = requestHeader;
	}

}

package com.jh.insurance.policy.model;

import com.manulife.esb.xsd.common.jh.header.JHHeader;
import com.manulife.esb.xsd.insurance.jh.policy.GetPolicyDetailsResponse;

/**
 * Wrapper to hold both GetPolicyDetailsResponse and response JHHeader to send on the response.
 */
public class GetPolicyDetailsResponseWrapper {

	private JHHeader responseHeader;
	private GetPolicyDetailsResponse response;

	public GetPolicyDetailsResponseWrapper() {
		
	}
	
	public GetPolicyDetailsResponseWrapper(final GetPolicyDetailsResponse response, final JHHeader responseHeader) {
		this.response = response;
		this.responseHeader = responseHeader;
	}

	public JHHeader getResponseHeader() {
		return responseHeader;
	}
		
	public void setResponseHeader(JHHeader responseHeader) {
		this.responseHeader = responseHeader;
	}

	public GetPolicyDetailsResponse getResponse() {
		return response;
	}

	public void setResponse(GetPolicyDetailsResponse response) {
		this.response = response;
	}
	

}

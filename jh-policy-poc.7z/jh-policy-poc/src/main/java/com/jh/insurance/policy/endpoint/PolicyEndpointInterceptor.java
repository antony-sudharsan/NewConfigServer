package com.jh.insurance.policy.endpoint;

import org.springframework.ws.context.MessageContext;
import org.springframework.ws.server.EndpointInterceptor;
import org.springframework.ws.soap.SoapHeader;
import org.springframework.ws.soap.SoapMessage;

import com.jh.insurance.policy.utils.HeaderKey;
import com.jh.insurance.policy.utils.JHHeaderJaxbUtils;
import com.manulife.esb.xsd.common.jh.header.JHHeader;

/**
 * Interceptor for PolicyEndpoint.
 *
 */
public class PolicyEndpointInterceptor implements EndpointInterceptor {

	private final JHHeaderJaxbUtils jhHeaderJaxbUtils;
	
	public PolicyEndpointInterceptor(final JHHeaderJaxbUtils jhHeaderJaxbUtils) {
		this.jhHeaderJaxbUtils = jhHeaderJaxbUtils;
	}
	
	@Override
	public boolean handleRequest(MessageContext messageContext, Object endpoint) throws Exception {
		return true;
	}

	/**
	 * Adds SoapHeader for JHHeader if represent in the MessageContext.
	 * 
	 * @see org.springframework.ws.server.EndpointInterceptor#handleResponse(org.springframework.ws.context.MessageContext, java.lang.Object)
	 */
	@Override
	public boolean handleResponse(MessageContext messageContext, Object endpoint) throws Exception {

		// if the header property is present then add a SoapHeader
		if (messageContext.containsProperty(HeaderKey.JH_HEADER_KEY.getValue())) {
			JHHeader jhHeader = (JHHeader)messageContext.getProperty(HeaderKey.JH_HEADER_KEY.getValue());
			SoapMessage soapMessage = (SoapMessage) messageContext.getResponse();
			SoapHeader soapHeader = soapMessage.getSoapHeader();
			jhHeaderJaxbUtils.marshallJHHeaderToResult(jhHeader, soapHeader.getResult());		
		}
		return true;
	}

	@Override
	public boolean handleFault(MessageContext messageContext, Object endpoint) throws Exception {
		return true;
	}

	@Override
	public void afterCompletion(MessageContext messageContext, Object endpoint, Exception ex) throws Exception {
	}

}

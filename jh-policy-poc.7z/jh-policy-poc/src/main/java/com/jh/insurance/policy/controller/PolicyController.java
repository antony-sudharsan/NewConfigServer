package com.jh.insurance.policy.controller;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.jh.insurance.policy.model.GetPolicyDetailsRequestWrapper;
import com.jh.insurance.policy.model.GetPolicyDetailsResponseWrapper;
import com.jh.insurance.policy.service.PolicyService;
import com.jh.insurance.policy.utils.HeaderKey;
import com.jh.insurance.policy.utils.JHHeaderJaxbUtils;
import com.manulife.esb.xsd.common.jh.header.JHHeader;
import com.manulife.esb.xsd.insurance.jh.policy.GetPolicyDetailsRequest;
import com.manulife.esb.xsd.insurance.jh.policy.GetPolicyDetailsResponse;

/**
 * Handles REST requests for both application/json and application/xml payloads.
 *
 */
@RestController
@RequestMapping("/policy")
public class PolicyController {

	private static final Logger logger = LoggerFactory.getLogger(PolicyController.class);
	
	private static final String JH_HEADER_KEY = "X-JH-Header";
    
	private final PolicyService policyService;
	
	private final JHHeaderJaxbUtils jhHeaderJaxbUtils;
	
	// Used to 
	private static ObjectMapper jsonMapper;
	
	static {
		jsonMapper = new ObjectMapper();
		jsonMapper.registerModule(new JavaTimeModule());
        jsonMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        jsonMapper.configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false);
        jsonMapper.setSerializationInclusion(Include.NON_NULL);
	}
	
	// Proxy to actual request
	@Autowired
	HttpServletRequest httpServletRequest;
    
	@Autowired
	public PolicyController(final PolicyService policyService, final JHHeaderJaxbUtils jhHeaderJaxbUtils) {
		this.policyService = policyService;
		this.jhHeaderJaxbUtils = jhHeaderJaxbUtils;
	}
	
	@RequestMapping(value = "/getPolicyDetails", method = RequestMethod.POST,
			produces={"application/json","application/xml"}, consumes={"application/json", "application/xml"})
	public ResponseEntity<GetPolicyDetailsResponse> getPolicyDetails(final @RequestBody GetPolicyDetailsRequest request, 
			@RequestHeader(value = JH_HEADER_KEY, required=false) String jhHeaderStr) {
		
		//parse request header if present
		JHHeader header = null;
		if (StringUtils.isNotEmpty(jhHeaderStr)) {
			header = unmarshallRequestHeader(jhHeaderStr);
		}				
		
		GetPolicyDetailsResponseWrapper responseWrapper = policyService.getPolicyDetails(request, header);
	    HttpHeaders responseHeaders = new HttpHeaders();
	    // add response header if available
	    if (null != responseWrapper.getResponseHeader()) {
	    	marshallResponseHeader(responseHeaders, responseWrapper.getResponseHeader());
	    }
	    
		return new ResponseEntity<>(responseWrapper.getResponse(), responseHeaders, HttpStatus.OK);
	}
	
	@RequestMapping(value = "/getPolicyDetailsOption2", method = RequestMethod.POST,
			produces={"application/json"}, consumes={"application/json"})
	public ResponseEntity<GetPolicyDetailsResponseWrapper> getPolicyDetailsOption2(final @RequestBody GetPolicyDetailsRequestWrapper request) {
				
		GetPolicyDetailsResponseWrapper responseWrapper = 
				policyService.getPolicyDetails(request.getRequest(), request.getRequestHeader());

	    
		return new ResponseEntity<>(responseWrapper, HttpStatus.OK);
	}
	
	private JHHeader unmarshallRequestHeader(final String jhHeaderStr) {
		JHHeader header = null;
		try {
			// Based on content type of request, unmarshall from json or xml
	        if (httpServletRequest.getContentType().contains(MediaType.APPLICATION_JSON_VALUE)) {
	        	header = jsonMapper.readValue(jhHeaderStr, JHHeader.class);
	        }
	        else {
	        	header = jhHeaderJaxbUtils.unmarshallJHHeader(jhHeaderStr);
	        }
		}
	    catch(Exception e) {
        	logger.error("Failed unmarshalling JHHeader, will return no header ", e);
	    }
		
		return header;
	}
	
	private void marshallResponseHeader(HttpHeaders responseHeaders, final JHHeader jhHeader) {
		try {
			// Based on content type of request, format as json or xml
	        if (httpServletRequest.getContentType().contains(MediaType.APPLICATION_JSON_VALUE)) {
	        	responseHeaders.add(HeaderKey.JH_HEADER_KEY.getValue(), jsonMapper.writeValueAsString(jhHeader));
	        }
	        else {
		        responseHeaders.add(HeaderKey.JH_HEADER_KEY.getValue(), 
		        		jhHeaderJaxbUtils.marshallJHHeader(jhHeader));
	        }
		}
	    catch(Exception e) {
        	logger.error("Failed marshalling JHHeader, will return no header ", e);
	    }
	}
	
}

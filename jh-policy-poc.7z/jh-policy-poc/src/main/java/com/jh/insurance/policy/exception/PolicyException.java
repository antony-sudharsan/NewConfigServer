package com.jh.insurance.policy.exception;


/**
 * Sample Exception class used to demonstrate returning a SOAP Fault.
 *
 */
public class PolicyException extends RuntimeException {

	private static final long serialVersionUID = -1751487605566600981L;
	public static final String DEFAULT_STRING = "Internal Error";
	public static final String DEFAULT_FAULT_ACTOR = "PROVIDER";
	
	// should be one of the Faults defined in the schema
	private Object faultDetail;
	
	private String faultActor = DEFAULT_FAULT_ACTOR;
	
	
	public PolicyException(Object faultDetail) {
		super(DEFAULT_STRING);
		this.faultDetail = faultDetail;
	}
	
	public PolicyException(Object faultDetail, String faultString) {
		// Will override soap fault string
		super(faultString);
		this.faultDetail = faultDetail;
	}
	
	public PolicyException(Object faultDetail, String faultString, String faultActor) {
		// Will override soap fault string
		super(faultString);
		this.faultDetail = faultDetail;
		this.faultActor = faultActor;
	}

	public String getFaultActor() {
		return this.faultActor;
	}

	public Object getFaultDetail() {
		return faultDetail;
	}
	
	
	
	
	
}

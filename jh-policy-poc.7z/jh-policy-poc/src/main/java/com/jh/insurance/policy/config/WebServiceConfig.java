package com.jh.insurance.policy.config;
import java.util.List;
import java.util.Properties;

import org.springframework.boot.web.servlet.ServletRegistrationBean;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;
import org.springframework.ws.config.annotation.EnableWs;
import org.springframework.ws.config.annotation.WsConfigurerAdapter;
import org.springframework.ws.server.EndpointInterceptor;
import org.springframework.ws.soap.server.endpoint.SoapFaultDefinition;
import org.springframework.ws.soap.server.endpoint.SoapFaultMappingExceptionResolver;
import org.springframework.ws.transport.http.MessageDispatcherServlet;
import org.springframework.ws.wsdl.wsdl11.DefaultWsdl11Definition;
import org.springframework.xml.xsd.SimpleXsdSchema;
import org.springframework.xml.xsd.XsdSchema;

import com.jh.insurance.policy.endpoint.PolicyEndpointInterceptor;
import com.jh.insurance.policy.exception.DetailSoapFaultDefinitionExceptionResolver;
import com.jh.insurance.policy.exception.PolicyException;
import com.jh.insurance.policy.utils.JHHeaderJaxbUtils;

/**
 * Configures Web Service Endpoint for Policy Operations.
 *
 */
@EnableWs
@Configuration
public class WebServiceConfig extends WsConfigurerAdapter {
	
    @Bean
    public ServletRegistrationBean messageDispatcherServlet(final ApplicationContext applicationContext) {
        final MessageDispatcherServlet servlet = new MessageDispatcherServlet();
        servlet.setApplicationContext(applicationContext);
        servlet.setTransformWsdlLocations(true);
        return new ServletRegistrationBean(servlet, "/Insurance/*");
    }

    // Bean name is so wsdl form is more standard (e.g. http://localhost:8080//Insurance/Policy_1.0.wsdl)
    @Bean(name = "Policy_1.0")
    public DefaultWsdl11Definition defaultWsdl11Definition(final XsdSchema schema) {
        final DefaultWsdl11Definition wsdl11Definition = new DefaultWsdl11Definition();
        wsdl11Definition.setPortTypeName("PolicyPort");
        wsdl11Definition.setLocationUri("/Insurance/Policy_1.0");
        wsdl11Definition.setTargetNamespace("http://www.esb.manulife.com/xsd/Insurance/jh/Policy");
        wsdl11Definition.setSchema(schema);
        return wsdl11Definition;
    }

    @Bean
    public XsdSchema policySchema() {
        return new SimpleXsdSchema(new ClassPathResource("Policy_v5.3.3.xsd"));
    }
    
    @Bean public JHHeaderJaxbUtils  jhHeaderJaxbUtils() {
    	return new JHHeaderJaxbUtils();
    }
 
    @Bean
    public SoapFaultMappingExceptionResolver exceptionResolver(){
        SoapFaultMappingExceptionResolver exceptionResolver = new DetailSoapFaultDefinitionExceptionResolver(); 

        SoapFaultDefinition faultDefinition = new SoapFaultDefinition();
        faultDefinition.setFaultCode(SoapFaultDefinition.SERVER);
        faultDefinition.setFaultStringOrReason("Internal Error");
        exceptionResolver.setDefaultFault(faultDefinition);

        Properties errorMappings = new Properties();
        errorMappings.setProperty(Exception.class.getName(), SoapFaultDefinition.SERVER.toString());
        errorMappings.setProperty(PolicyException.class.getName(), SoapFaultDefinition.SERVER.toString());
        exceptionResolver.setExceptionMappings(errorMappings);
        exceptionResolver.setOrder(1);
        return exceptionResolver;
    }
    
    @Override
    public void addInterceptors(List<EndpointInterceptor> interceptors) {
      // will handle adding soap response header
      interceptors.add(new PolicyEndpointInterceptor(jhHeaderJaxbUtils()));
    }
    
    
}
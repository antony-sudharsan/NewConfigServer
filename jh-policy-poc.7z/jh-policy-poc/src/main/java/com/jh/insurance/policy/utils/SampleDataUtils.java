package com.jh.insurance.policy.utils;

import java.io.File;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.io.ClassPathResource;

import com.manulife.esb.xsd.common.jh.header.JHHeader;
import com.manulife.esb.xsd.insurance.jh.policy.GetPolicyDetailsResponse;

public final class SampleDataUtils {

	private static final Logger logger = LoggerFactory.getLogger(SampleDataUtils.class);
	//Note has a lot of empty elements
	private static final String SAMPLE_GET_POLICY_DETAILS_RESPONSE_FILE_NAME = "sample-data\\sampleGetPolicyDetailsResponse.xml";
	private static final String SAMPLE_JH_HEADER_RESPONSE_FILE_NAME = "sample-data\\SampleJhResponseHeader.xml";
	
	private final JAXBContext getPolicyDetailsResponseJaxBContext;
	
	private final JAXBContext jHHeaderJaxBContext;
	
	public SampleDataUtils() {	
		try {
			// JAXBContext is thread safe so for performance reasons create once.
			jHHeaderJaxBContext = JAXBContext.newInstance(JHHeader.class);
			getPolicyDetailsResponseJaxBContext = JAXBContext.newInstance(GetPolicyDetailsResponse.class);
	    } catch (final JAXBException e) {
	    	logger.error("Failed Creating JAXBContext", e);
	    	throw new RuntimeException(e);
	    }
	}
	
	public GetPolicyDetailsResponse createSampleGetPolicyDetailsResponse() {
		GetPolicyDetailsResponse response = null;
		try {
	        File file = new ClassPathResource(SAMPLE_GET_POLICY_DETAILS_RESPONSE_FILE_NAME).getFile();
	        Unmarshaller unmarshaller = getPolicyDetailsResponseJaxBContext.createUnmarshaller();
	        response = (GetPolicyDetailsResponse) unmarshaller.unmarshal(file);
		}
		catch (Exception e) {
			logger.error("Failed unmarshalling sample data file for GetPolicyDetailsResponse", e);
		}

        return response;
	}
	
	public JHHeader createSampleGetPolicyDetailsResponseHeader() {
		JHHeader jhHeader = null;
		try {
	        File file = new ClassPathResource(SAMPLE_JH_HEADER_RESPONSE_FILE_NAME).getFile();
	        Unmarshaller unmarshaller = jHHeaderJaxBContext.createUnmarshaller();
	        jhHeader = (JHHeader) unmarshaller.unmarshal(file);
		}
		catch (Exception e) {
			logger.error("Failed unmarshalling sample data file for JHHeader", e);
		}

        return jhHeader;
	}
}

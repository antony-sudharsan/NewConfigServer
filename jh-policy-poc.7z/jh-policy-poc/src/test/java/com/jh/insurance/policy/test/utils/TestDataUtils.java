package com.jh.insurance.policy.test.utils;

import com.jh.insurance.policy.model.GetPolicyDetailsRequestWrapper;
import com.jh.insurance.policy.model.GetPolicyDetailsResponseWrapper;
import com.jh.insurance.policy.utils.JHHeaderJaxbUtils;
import com.jh.insurance.policy.utils.SampleDataUtils;
import com.manulife.esb.xsd.common.jh.header.JHHeader;
import com.manulife.esb.xsd.insurance.jh.policy.GetPolicyDetailsRequest;
import com.manulife.esb.xsd.insurance.jh.policy.GetPolicyDetailsResponse;
import com.manulife.esb.xsd.insurance.jh.policy.SubDivisionIdType;
import com.manulife.esb.xsd.insurance.jh.policy.SubDivisionQualifierTypeType;
import com.manulife.esb.xsd.insurance.jh.policy.SubDivisionQualifiersType;

public final class TestDataUtils {	
	
    private static JHHeaderJaxbUtils jaxbUtils = new JHHeaderJaxbUtils();
    
    private static SampleDataUtils sampleDataUtils = new SampleDataUtils();

	private static final String SAMPLE_JSON_GET_POLICY_DETAILS_REQUEST = "{\n" + 
			"	\"polNumber\":\"000000049\",\n" + 
			"	\"subDivisionId\":\"LIFE\",\n" + 
			"	\"subDivisionQualifiers\":[ {\n" + 
			"		\"subDivisionQualifierType\": \"PLC\",\n" + 
			"		\"subDivisionQualifier\": 3\n" + 
			"	 }],\n" + 
			"	\"carrierAdminSystem\":\"VL\"\n" + 
			"}";
	
	private static final String SAMPLE_XML_GET_POLICY_DETAILS_REQUEST = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" + 
			"<GetPolicyDetails_request xmlns=\"http://www.esb.manulife.com/xsd/Insurance/jh/Policy\">\n" + 
			" <PolNumber>000000049</PolNumber>\n" + 
			" <SubDivisionId>LIFE</SubDivisionId>\n" + 
			" <!--Zero or more repetitions:-->\n" + 
			" <SubDivisionQualifiers>\n" + 
			"    <SubDivisionQualifierType>PLC</SubDivisionQualifierType>\n" + 
			"    <SubDivisionQualifier>3</SubDivisionQualifier>\n" + 
			" </SubDivisionQualifiers>\n" + 
			" <CarrierAdminSystem>VL</CarrierAdminSystem>\n" + 
			"</GetPolicyDetails_request>";
	
	private static final String SAMPLE_COMBINED_GET_POLICY_DETAILS_REQUEST = "{  \n" + 
			"	\"requestHeader\":{  \n" + 
			"      \"version\":\"1.0\",\n" + 
			"      \"conversationUID\":\"1\",\n" + 
			"      \"messageUID\":\"1009501245\",\n" + 
			"      \"relatesTo\":\"GetPolicyDetails\",\n" + 
			"      \"messageType\":\"Request\",\n" + 
			"      \"originalMessageDateTime\":\"1999-05-31T18:20:00.000+0000\",\n" + 
			"      \"currentMessageDateTime\":\"2014-02-17T18:04:00.000+0000\",\n" + 
			"      \"messageSource\":{  \n" + 
			"         \"applicationName\":\"Captivate\",\n" + 
			"         \"hostName\":\"local\",\n" + 
			"         \"applicationUserID\":\"Ez\",\n" + 
			"         \"userID\":\"patelal\",\n" + 
			"         \"processID\":\"123456\"\n" + 
			"      },\n" + 
			"      \"serviceInfo\":{  \n" + 
			"         \"serviceName\":\"Policy\",\n" + 
			"         \"serviceVersion\":\"1.0\",\n" + 
			"         \"serviceOperation\":\"GetPolicyDetails\"\n" + 
			"      },\n" + 
			"      \"environmentID\":\"1\",\n" + 
			"      \"requestTimeOut\":1\n" + 
			"   },\n" + 
			"   \"request\":{  \n" + 
			"      \"polNumber\":\"000000049\",\n" + 
			"      \"subDivisionId\":\"LIFE\",\n" + 
			"      \"subDivisionQualifiers\":[  \n" + 
			"         {  \n" + 
			"            \"subDivisionQualifierType\":\"PLC\",\n" + 
			"            \"subDivisionQualifier\":\"3\"\n" + 
			"         }\n" + 
			"      ],\n" + 
			"      \"carrierAdminSystem\":\"VL\"\n" + 
			"   }\n" + 
			"   \n" + 
			"}";
	
	private static final String SAMPLE_GET_POLICY_DETAILS_REQUEST_HEADER_XML = "<JHHeader xmlns=\"http://www.esb.manulife.com/xsd/common/jh/header\"><Version>1.0</Version><ConversationUID>1</ConversationUID><!--MessageUID field should be unique--><MessageUID>1009501245</MessageUID><RelatesTo>GetPolicyDetails</RelatesTo><MessageType>Request</MessageType><OriginalMessageDateTime>1999-05-31T13:20:00-05:00</OriginalMessageDateTime><CurrentMessageDateTime>2014-02-17T13:04:00-05:00</CurrentMessageDateTime><MessageSource><ApplicationName>Captivate</ApplicationName><HostName>local</HostName><ApplicationUserID>Ez</ApplicationUserID><UserID>patelal</UserID><ProcessID>123456</ProcessID></MessageSource><ServiceInfo><ServiceName>Policy</ServiceName><ServiceVersion>1.0</ServiceVersion><ServiceOperation>GetPolicyDetails</ServiceOperation></ServiceInfo><EnvironmentID>1</EnvironmentID><RequestTimeOut>1</RequestTimeOut></JHHeader>";
	
	private static final String SAMPLE_GET_POLICY_DETAILS_REQUEST_HEADER_JSON = "{\"version\":\"1.0\",\"conversationUID\":\"1\",\"messageUID\":\"1009501245\",\"relatesTo\":\"GetPolicyDetails\",\"messageType\":\"Request\",\"originalMessageDateTime\":\"1999-05-31T18:20:00.000+0000\",\"currentMessageDateTime\":\"2014-02-17T18:04:00.000+0000\",\"messageSource\":{\"applicationName\":\"Captivate\",\"hostName\":\"local\",\"applicationUserID\":\"Ez\",\"userID\":\"patelal\",\"processID\":\"123456\"},\"serviceInfo\":{\"serviceName\":\"Policy\",\"serviceVersion\":\"1.0\",\"serviceOperation\":\"GetPolicyDetails\"},\"environmentID\":\"1\",\"requestTimeOut\":1}";

	
	
	private TestDataUtils() {
	}
	
	public static GetPolicyDetailsRequest createSampleGetPolicyDetailsRequest() {
		GetPolicyDetailsRequest request = new GetPolicyDetailsRequest();
		request.setPolNumber("000000049");
		request.setSubDivisionId(SubDivisionIdType.LIFE);
		request.setCarrierAdminSystem("VL");
		
		SubDivisionQualifiersType subDivisionQualifiersType = new SubDivisionQualifiersType();
		subDivisionQualifiersType.setSubDivisionQualifierType(SubDivisionQualifierTypeType.PLC); 
		subDivisionQualifiersType.setSubDivisionQualifier("3");
		request.getSubDivisionQualifiers().add(subDivisionQualifiersType);
		
		return request;
	}
	
	public static String createSampleGetPolicyDetailsRequestHeaderAsXmlString() {		
		return SAMPLE_GET_POLICY_DETAILS_REQUEST_HEADER_XML;
	}
	
	public static String createSampleGetPolicyDetailsRequestHeaderAsJsonString() {	
		return SAMPLE_GET_POLICY_DETAILS_REQUEST_HEADER_JSON;
	}
	
	public static String createSampleJsonGetPolicyDetailsRequest() {
		return SAMPLE_JSON_GET_POLICY_DETAILS_REQUEST;
	}
	
	public static String createSampleXmlGetPolicyDetailsRequest() {
		return SAMPLE_XML_GET_POLICY_DETAILS_REQUEST;
	}
	
	public static String createSampleJsonGetPolicyDetailsRequestWrapper() {
		return SAMPLE_COMBINED_GET_POLICY_DETAILS_REQUEST;
	}
	
	public static JHHeader unmarshallXmlJHHeader(String xmlHeaderStr) {
		return jaxbUtils.unmarshallJHHeader(xmlHeaderStr);
	}
	
    public static GetPolicyDetailsRequestWrapper  createSampleGetPolicyDetailsRequestWrapper() {
    	GetPolicyDetailsRequestWrapper requestWrapper = new GetPolicyDetailsRequestWrapper();
    	requestWrapper.setRequest(createSampleGetPolicyDetailsRequest());
    	requestWrapper.setRequestHeader(unmarshallXmlJHHeader(SAMPLE_GET_POLICY_DETAILS_REQUEST_HEADER_XML));
    	return requestWrapper;
    }
    
    public static GetPolicyDetailsResponse createSampleGetPolicyDetailsResponse() {
    	return sampleDataUtils.createSampleGetPolicyDetailsResponse();
    }
    
    public static JHHeader createSampleGetPolicyDetailsResponseHeader() {
    	return sampleDataUtils.createSampleGetPolicyDetailsResponseHeader();
    }
    
    public static GetPolicyDetailsResponseWrapper createSampleGetPolicyDetailsResponseWrapper() {
    	GetPolicyDetailsResponseWrapper wrapper = new GetPolicyDetailsResponseWrapper(sampleDataUtils.createSampleGetPolicyDetailsResponse(), sampleDataUtils.createSampleGetPolicyDetailsResponseHeader());
    	
    	return wrapper;
    }
	
}

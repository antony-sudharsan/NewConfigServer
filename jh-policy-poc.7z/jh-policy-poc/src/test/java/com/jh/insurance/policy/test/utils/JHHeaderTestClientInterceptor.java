package com.jh.insurance.policy.test.utils;

import org.springframework.ws.client.WebServiceClientException;
import org.springframework.ws.client.support.interceptor.ClientInterceptor;
import org.springframework.ws.context.MessageContext;
import org.springframework.ws.soap.SoapHeader;
import org.springframework.ws.soap.SoapMessage;

import com.jh.insurance.policy.utils.JHHeaderJaxbUtils;
import com.manulife.esb.xsd.common.jh.header.JHHeader;

public class JHHeaderTestClientInterceptor implements ClientInterceptor {

	private final JHHeaderJaxbUtils jhHeaderJaxbUtils;
	
	public JHHeaderTestClientInterceptor() {
		this.jhHeaderJaxbUtils = new JHHeaderJaxbUtils();;
	}	
	
	@Override
	public boolean handleRequest(MessageContext messageContext) throws WebServiceClientException {
		SoapMessage soapMessage = (SoapMessage) messageContext.getRequest();
		SoapHeader soapHeader = soapMessage.getSoapHeader();
		JHHeader jhHeader = jhHeaderJaxbUtils.unmarshallJHHeader(TestDataUtils.createSampleGetPolicyDetailsRequestHeaderAsXmlString());
		jhHeaderJaxbUtils.marshallJHHeaderToResult(jhHeader, soapHeader.getResult());	
		return true;
	}

	@Override
	public boolean handleResponse(MessageContext messageContext) throws WebServiceClientException {
		return true;
	}

	@Override
	public boolean handleFault(MessageContext messageContext) throws WebServiceClientException {
		return true;
	}

	@Override
	public void afterCompletion(MessageContext messageContext, Exception ex) throws WebServiceClientException {

	}

}

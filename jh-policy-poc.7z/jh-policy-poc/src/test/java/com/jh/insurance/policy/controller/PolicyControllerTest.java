package com.jh.insurance.policy.controller;

import static org.assertj.core.api.Assertions.assertThat;
import static org.hamcrest.CoreMatchers.anything;
import static org.hamcrest.CoreMatchers.containsString;
import static org.mockito.Mockito.any;
import static org.mockito.Mockito.anyString;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.header;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;

import com.jh.insurance.policy.controller.PolicyController;
import com.jh.insurance.policy.model.GetPolicyDetailsResponseWrapper;
import com.jh.insurance.policy.service.PolicyService;
import com.jh.insurance.policy.test.utils.TestDataUtils;
import com.jh.insurance.policy.utils.HeaderKey;
import com.jh.insurance.policy.utils.JHHeaderJaxbUtils;
import com.manulife.esb.xsd.common.jh.header.JHHeader;
import com.manulife.esb.xsd.insurance.jh.policy.GetPolicyDetailsRequest;
import com.manulife.esb.xsd.insurance.jh.policy.GetPolicyDetailsResponse;
import com.manulife.esb.xsd.insurance.jh.policy.PolicyDetailsType;

@RunWith(SpringRunner.class)
@AutoConfigureMockMvc(secure=false)
@WebMvcTest(PolicyController.class)
public class PolicyControllerTest {

	private static final String TEST_POL_NUM = "012345";
	private static final String TEST_MESSAGE_UID = "1009501245";
	
    @Autowired
    private MockMvc mockMvc;
    
    @MockBean 
    private PolicyService policyService;
    
    @MockBean
    private JHHeaderJaxbUtils jhHeaderJaxbUtils;
    
	@Captor
	ArgumentCaptor<GetPolicyDetailsRequest> getPolicyDetailsRequestCaptor;
	
	@Captor
	ArgumentCaptor<JHHeader> getJHHeaderCaptor;	
    
    
    @Test
    public void shouldAcceptAndReturnJsonNoHeaderPassed() throws Exception {
    	
    	when(policyService.getPolicyDetails(any(), any())).thenReturn(createTestServiceResponse());
        
        this.mockMvc.perform(post("/policy/getPolicyDetails")
        		.contentType(MediaType.APPLICATION_JSON)
        		.content(TestDataUtils.createSampleJsonGetPolicyDetailsRequest())).andExpect(status().isOk())
                .andExpect(content().string(containsString(TEST_POL_NUM)))
                .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE));
        
		verify(policyService, times(1)).getPolicyDetails(getPolicyDetailsRequestCaptor.capture(), getJHHeaderCaptor.capture());
		verify(jhHeaderJaxbUtils, times(0)).unmarshallJHHeader(anyString());
		verify(jhHeaderJaxbUtils, times(0)).marshallJHHeader(any());
		assertThat(getJHHeaderCaptor.getValue()).isNull();
		assertThat(getPolicyDetailsRequestCaptor.getValue()).isNotNull();
    }

    
    @Test
    public void shouldAcceptAndReturnJsonAndHandleHeaderPassed() throws Exception {
    	
    	when(policyService.getPolicyDetails(any(), any())).thenReturn(createTestServiceResponse());
        
        this.mockMvc.perform(post("/policy/getPolicyDetails")
        		.contentType(MediaType.APPLICATION_JSON)
        		.header(HeaderKey.JH_HEADER_KEY.getValue(), TestDataUtils.createSampleGetPolicyDetailsRequestHeaderAsJsonString())
        		.content(TestDataUtils.createSampleJsonGetPolicyDetailsRequest())).andExpect(status().isOk())
                .andExpect(content().string(containsString(TEST_POL_NUM)))
                .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE));
        
		verify(policyService, times(1)).getPolicyDetails(getPolicyDetailsRequestCaptor.capture(), getJHHeaderCaptor.capture());
		verify(jhHeaderJaxbUtils, times(0)).unmarshallJHHeader(anyString());
		verify(jhHeaderJaxbUtils, times(0)).marshallJHHeader(any());
		assertThat(getJHHeaderCaptor.getValue()).isNotNull();
		assertThat(getPolicyDetailsRequestCaptor.getValue()).isNotNull();
    }
    
    @Test
    public void whenJsonRequestShouldReturnExpectedResponseWithHeader() throws Exception{
    	when(policyService.getPolicyDetails(any(), any())).thenReturn(createTestServiceResponse());
        
        this.mockMvc.perform(post("/policy/getPolicyDetails")
        		.contentType(MediaType.APPLICATION_JSON)
        		.header(HeaderKey.JH_HEADER_KEY.getValue(), TestDataUtils.createSampleGetPolicyDetailsRequestHeaderAsJsonString())
        		.content(TestDataUtils.createSampleJsonGetPolicyDetailsRequest())).andExpect(status().isOk())
                .andExpect(content().string(containsString(TEST_POL_NUM)))
                .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
                .andExpect(header().string(HeaderKey.JH_HEADER_KEY.getValue(), anything()));        
    }
    
    @Test
    public void shouldAcceptAndReturnXmlAndHandleNoHeaderPassed() throws Exception {
    	
    	when(policyService.getPolicyDetails(any(), any())).thenReturn(createTestServiceResponse());
        when(jhHeaderJaxbUtils.marshallJHHeader(any())).thenReturn(TestDataUtils.createSampleGetPolicyDetailsRequestHeaderAsXmlString());
        
        this.mockMvc.perform(post("/policy/getPolicyDetails")
        		.contentType(MediaType.APPLICATION_XML_VALUE)
        		.accept(MediaType.APPLICATION_XML_VALUE)
        		.content(TestDataUtils.createSampleXmlGetPolicyDetailsRequest())).andExpect(status().isOk())
                .andExpect(content().string(containsString(TEST_POL_NUM)))
                .andExpect(content().contentType(MediaType.APPLICATION_XML_VALUE));
        
		verify(policyService, times(1)).getPolicyDetails(getPolicyDetailsRequestCaptor.capture(), getJHHeaderCaptor.capture());
		verify(jhHeaderJaxbUtils, times(0)).unmarshallJHHeader(anyString());
		verify(jhHeaderJaxbUtils, times(1)).marshallJHHeader(any());
		assertThat(getJHHeaderCaptor.getValue()).isNull();
		assertThat(getPolicyDetailsRequestCaptor.getValue()).isNotNull();
    }
    
    @Test
    public void shouldAcceptAndReturnXmlAndHandleHeaderPassed() throws Exception {
    	
    	when(policyService.getPolicyDetails(any(), any())).thenReturn(createTestServiceResponse());
        when(jhHeaderJaxbUtils.marshallJHHeader(any())).thenReturn(TestDataUtils.createSampleGetPolicyDetailsRequestHeaderAsXmlString());
        when(jhHeaderJaxbUtils.unmarshallJHHeader(TestDataUtils.createSampleGetPolicyDetailsRequestHeaderAsXmlString())).thenReturn(new JHHeader());
        
        this.mockMvc.perform(post("/policy/getPolicyDetails")
        		.contentType(MediaType.APPLICATION_XML_VALUE)
        		.accept(MediaType.APPLICATION_XML_VALUE)
        		.header(HeaderKey.JH_HEADER_KEY.getValue(),TestDataUtils.createSampleGetPolicyDetailsRequestHeaderAsXmlString())
        		.content(TestDataUtils.createSampleXmlGetPolicyDetailsRequest())).andExpect(status().isOk())
                .andExpect(content().string(containsString(TEST_POL_NUM)))
                .andExpect(content().contentType(MediaType.APPLICATION_XML_VALUE));
        
		verify(policyService, times(1)).getPolicyDetails(getPolicyDetailsRequestCaptor.capture(), getJHHeaderCaptor.capture());
		verify(jhHeaderJaxbUtils, times(1)).unmarshallJHHeader(anyString());
		verify(jhHeaderJaxbUtils, times(1)).marshallJHHeader(any());
		assertThat(getJHHeaderCaptor.getValue()).isNotNull();
		assertThat(getPolicyDetailsRequestCaptor.getValue()).isNotNull();
    }
    
    @Test
    public void whenXmlRequestShouldReturnExpectedResponseWithHeader() throws Exception{
    	when(policyService.getPolicyDetails(any(), any())).thenReturn(createTestServiceResponse());
        when(jhHeaderJaxbUtils.marshallJHHeader(any())).thenReturn(TestDataUtils.createSampleGetPolicyDetailsRequestHeaderAsXmlString());
        when(jhHeaderJaxbUtils.unmarshallJHHeader(TestDataUtils.createSampleGetPolicyDetailsRequestHeaderAsXmlString())).thenReturn(new JHHeader());
        
        this.mockMvc.perform(post("/policy/getPolicyDetails")
        		.contentType(MediaType.APPLICATION_XML_VALUE)
        		.accept(MediaType.APPLICATION_XML_VALUE)
        		.header(HeaderKey.JH_HEADER_KEY.getValue(), TestDataUtils.createSampleGetPolicyDetailsRequestHeaderAsXmlString())
        		.content(TestDataUtils.createSampleXmlGetPolicyDetailsRequest())).andExpect(status().isOk())
                .andExpect(content().string(containsString(TEST_POL_NUM)))
                .andExpect(content().contentType(MediaType.APPLICATION_XML_VALUE))
                .andExpect(header().string(HeaderKey.JH_HEADER_KEY.getValue(), anything()));        
    }
    
    @Test
    public void whenGetPolicyOption2RequestShouldReturnExpectedWrapper() throws Exception{
    	when(policyService.getPolicyDetails(any(), any())).thenReturn(createTestServiceResponse());
        
        this.mockMvc.perform(post("/policy/getPolicyDetailsOption2")
        		.contentType(MediaType.APPLICATION_JSON)
        		.content(TestDataUtils.createSampleJsonGetPolicyDetailsRequestWrapper())).andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
                .andExpect(content().string(containsString(TEST_POL_NUM)))
                .andExpect(content().string(containsString(TEST_MESSAGE_UID)));        
    }
    

    
    private GetPolicyDetailsResponseWrapper createTestServiceResponse() {
    	GetPolicyDetailsResponse getPolicyDetailsResponse = new GetPolicyDetailsResponse();
    	PolicyDetailsType policyDetailsType = new PolicyDetailsType();
    	policyDetailsType.setPolNumber(TEST_POL_NUM);
    	getPolicyDetailsResponse.setPolicyDetails(policyDetailsType);
    	
    	JHHeader jhHeader = new JHHeader();
    	jhHeader.setMessageUID(TEST_MESSAGE_UID);

    	
    	GetPolicyDetailsResponseWrapper wrapper = new GetPolicyDetailsResponseWrapper(getPolicyDetailsResponse, jhHeader);
    	
    	return wrapper;
    }
    
}

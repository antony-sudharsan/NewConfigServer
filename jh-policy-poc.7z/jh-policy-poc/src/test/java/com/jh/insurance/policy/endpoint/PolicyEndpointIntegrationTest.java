package com.jh.insurance.policy.endpoint;

import static org.assertj.core.api.Assertions.assertThat;

import java.io.IOException;
import java.util.Iterator;

import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.context.embedded.LocalServerPort;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.util.ClassUtils;
import org.springframework.ws.WebServiceMessage;
import org.springframework.ws.client.core.WebServiceMessageCallback;
import org.springframework.ws.client.core.WebServiceMessageExtractor;
import org.springframework.ws.client.core.WebServiceTemplate;
import org.springframework.ws.client.support.interceptor.ClientInterceptor;
import org.springframework.ws.soap.SoapHeader;
import org.springframework.ws.soap.SoapHeaderElement;
import org.springframework.ws.soap.SoapMessage;
import org.springframework.ws.soap.client.SoapFaultClientException;
import org.springframework.ws.support.MarshallingUtils;

import com.jh.insurance.policy.model.GetPolicyDetailsResponseWrapper;
import com.jh.insurance.policy.test.utils.JHHeaderTestClientInterceptor;
import com.jh.insurance.policy.test.utils.TestDataUtils;
import com.manulife.esb.xsd.common.jh.header.JHHeader;
import com.manulife.esb.xsd.insurance.jh.policy.GetPolicyDetailsRequest;
import com.manulife.esb.xsd.insurance.jh.policy.GetPolicyDetailsResponse;


@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT)
public class PolicyEndpointIntegrationTest {
    private Jaxb2Marshaller marshaller = new Jaxb2Marshaller();

    @LocalServerPort
    private int port = 0;
    
	@Rule
	public ExpectedException exception = ExpectedException.none();

    @Before
    public void init() throws Exception {
        marshaller.setPackagesToScan(ClassUtils.getPackageName(GetPolicyDetailsRequest.class), ClassUtils.getPackageName(JHHeader.class));
        marshaller.afterPropertiesSet();
    }

    @Test
    public void testSendAndReceive() {
        WebServiceTemplate ws = new WebServiceTemplate(marshaller);
 
        assertThat(ws.marshalSendAndReceive("http://localhost:"
                + port + "/Insurance/Policy_1.0", TestDataUtils.createSampleGetPolicyDetailsRequest())).isNotNull();
    }
    
    @Test
    public void testSendAndReceiveWithSoapHeader() {
    	
        WebServiceTemplate ws = new WebServiceTemplate(marshaller);
        // client interceptor will set the sample request JH Header
        ws.setInterceptors(new ClientInterceptor[] {new JHHeaderTestClientInterceptor()});
        
        assertThat(ws.marshalSendAndReceive("http://localhost:"
                + port + "/Insurance/Policy_1.0", TestDataUtils.createSampleGetPolicyDetailsRequest())).isNotNull();
    }
    
    @Test
    public void testResponseAndResponseHeaderMatchExpected() {
    	
        WebServiceTemplate ws = new WebServiceTemplate(marshaller);
        ws.setDefaultUri("http://localhost:" + port + "/Insurance/Policy_1.0");
        // client interceptor will set the sample request JH Header
        ws.setInterceptors(new ClientInterceptor[] {new JHHeaderTestClientInterceptor()});
        
        GetPolicyDetailsRequest request = TestDataUtils.createSampleGetPolicyDetailsRequest();
        
        // Use WebServiceMessageExtractor to get Body and Header
        GetPolicyDetailsResponseWrapper responseAndHeader = ws.sendAndReceive(
        	    new WebServiceMessageCallback() {
        	      public void doWithMessage(WebServiceMessage message) throws IOException {
        	        MarshallingUtils.marshal(marshaller, request, message);
        	      }
        	    },
        	    new WebServiceMessageExtractor<GetPolicyDetailsResponseWrapper>() {
        	      public GetPolicyDetailsResponseWrapper extractData(WebServiceMessage message) throws IOException {
        	        SoapHeader header = ((SoapMessage)message).getSoapHeader();
        	        JHHeader responseJhHeader = null;
        	        // should be at most one header returned
        	        Iterator<SoapHeaderElement> it = header.examineAllHeaderElements();
        	        if (it.hasNext()) {
        	        	responseJhHeader = (JHHeader)marshaller.unmarshal(it.next().getSource());
        	        }
        	        GetPolicyDetailsResponse responseBody = (GetPolicyDetailsResponse)MarshallingUtils.unmarshal(marshaller, message);
        	        return new GetPolicyDetailsResponseWrapper(responseBody, responseJhHeader);
        	      }
        	    });
        
        assertThat(responseAndHeader).isNotNull();
        assertThat(responseAndHeader.getResponse()).isNotNull();
        assertThat(responseAndHeader.getResponseHeader()).isNotNull();   
        assertThat(responseAndHeader.getResponse()).isEqualToComparingFieldByFieldRecursively(TestDataUtils.createSampleGetPolicyDetailsResponse());
        assertThat(responseAndHeader.getResponseHeader()).isEqualToComparingFieldByFieldRecursively(TestDataUtils.createSampleGetPolicyDetailsResponseHeader());
    }
    
    @Test
    public void testSoapFaultReturned() {
    	
        WebServiceTemplate ws = new WebServiceTemplate(marshaller);
        ws.setDefaultUri("http://localhost:" + port + "/Insurance/Policy_1.0");
        // client interceptor will set the sample request JH Header
        ws.setInterceptors(new ClientInterceptor[] {new JHHeaderTestClientInterceptor()});
        
        GetPolicyDetailsRequest request = TestDataUtils.createSampleGetPolicyDetailsRequest();
        // sample service throws a fault if no SubDivisionId
        request.setSubDivisionId(null);
        
		exception.expect(SoapFaultClientException.class);
        ws.marshalSendAndReceive("http://localhost:" + port + "/Insurance/Policy_1.0", request);
    }
}

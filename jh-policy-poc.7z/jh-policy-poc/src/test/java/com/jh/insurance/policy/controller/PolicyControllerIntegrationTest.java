package com.jh.insurance.policy.controller;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.context.embedded.LocalServerPort;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;

import com.jh.insurance.policy.Application;
import com.jh.insurance.policy.model.GetPolicyDetailsRequestWrapper;
import com.jh.insurance.policy.model.GetPolicyDetailsResponseWrapper;
import com.jh.insurance.policy.test.utils.TestDataUtils;
import com.jh.insurance.policy.utils.HeaderKey;
import com.manulife.esb.xsd.insurance.jh.policy.GetPolicyDetailsRequest;
import com.manulife.esb.xsd.insurance.jh.policy.GetPolicyDetailsResponse;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = Application.class, webEnvironment=WebEnvironment.RANDOM_PORT)
public class PolicyControllerIntegrationTest {

	@LocalServerPort
    private int port;

    @Autowired
    private TestRestTemplate restTemplate;

    private final HttpHeaders headers = new HttpHeaders();

    @Test
    public void shouldAcceptAndReturnJson() throws Exception {
        headers.setContentType(MediaType.APPLICATION_JSON);

        final HttpEntity<GetPolicyDetailsRequest> entity = 
        		new HttpEntity<GetPolicyDetailsRequest>(TestDataUtils.createSampleGetPolicyDetailsRequest(), headers);

        final ResponseEntity<GetPolicyDetailsResponse> response =
                restTemplate.exchange(createURLWithPort("/policy/getPolicyDetails"),
                        HttpMethod.POST, entity, GetPolicyDetailsResponse.class);

        assertThat(response).isNotNull();
        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
        assertThat(response.getHeaders().getContentType().toString()).isEqualTo(MediaType.APPLICATION_JSON_UTF8_VALUE);
        assertThat(response.getBody()).isNotNull();
    }
    
    @Test
    public void givenJsonRequestShouldAcceptJsonHeader() throws Exception {
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.set(HeaderKey.JH_HEADER_KEY.getValue(), TestDataUtils.createSampleGetPolicyDetailsRequestHeaderAsJsonString()); 

        final HttpEntity<GetPolicyDetailsRequest> entity = 
        		new HttpEntity<GetPolicyDetailsRequest>(TestDataUtils.createSampleGetPolicyDetailsRequest(), headers);

        final ResponseEntity<GetPolicyDetailsResponse> response =
                restTemplate.exchange(createURLWithPort("/policy/getPolicyDetails"),
                        HttpMethod.POST, entity, GetPolicyDetailsResponse.class);

        assertThat(response).isNotNull();
        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
        assertThat(response.getHeaders().getContentType().toString()).isEqualTo(MediaType.APPLICATION_JSON_UTF8_VALUE);
        assertThat(response.getBody()).isNotNull();
    }

    @Test
    public void shouldAcceptAndReturnXml() throws Exception {
        headers.setContentType(MediaType.APPLICATION_XML);
        headers.set(HttpHeaders.ACCEPT, MediaType.APPLICATION_XML_VALUE);

        final HttpEntity<GetPolicyDetailsRequest> entity = 
        		new HttpEntity<GetPolicyDetailsRequest>(TestDataUtils.createSampleGetPolicyDetailsRequest(), headers);

        final ResponseEntity<GetPolicyDetailsResponse> response =
                restTemplate.exchange(createURLWithPort("/policy/getPolicyDetails"),
                        HttpMethod.POST, entity, GetPolicyDetailsResponse.class);

        assertThat(response).isNotNull();
        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
        assertThat(response.getHeaders().getContentType().toString()).isEqualTo(MediaType.APPLICATION_XML_VALUE);
        assertThat(response.getBody()).isNotNull();
    }
    
    @Test
    public void givenXmlRequestShouldAcceptXmlJHHeader() throws Exception {
        headers.setContentType(MediaType.APPLICATION_XML);
        headers.set(HttpHeaders.ACCEPT, MediaType.APPLICATION_XML_VALUE);
        headers.set(HeaderKey.JH_HEADER_KEY.getValue(), TestDataUtils.createSampleGetPolicyDetailsRequestHeaderAsXmlString()); 

        final HttpEntity<GetPolicyDetailsRequest> entity = 
        		new HttpEntity<GetPolicyDetailsRequest>(TestDataUtils.createSampleGetPolicyDetailsRequest(), headers);

        final ResponseEntity<GetPolicyDetailsResponse> response =
                restTemplate.exchange(createURLWithPort("/policy/getPolicyDetails"),
                        HttpMethod.POST, entity, GetPolicyDetailsResponse.class);

        assertThat(response).isNotNull();
        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
        assertThat(response.getHeaders().getContentType().toString()).isEqualTo(MediaType.APPLICATION_XML_VALUE);
        assertThat(response.getBody()).isNotNull();
    }
    
    @Test
    public void givenXmlRequestShouldReturnExpectedResponseWithHeader() throws Exception {
        headers.setContentType(MediaType.APPLICATION_XML);
        headers.set(HttpHeaders.ACCEPT, MediaType.APPLICATION_XML_VALUE);
        headers.set(HeaderKey.JH_HEADER_KEY.getValue(), TestDataUtils.createSampleGetPolicyDetailsRequestHeaderAsXmlString()); 

        final HttpEntity<GetPolicyDetailsRequest> entity = 
        		new HttpEntity<GetPolicyDetailsRequest>(TestDataUtils.createSampleGetPolicyDetailsRequest(), headers);

        final ResponseEntity<GetPolicyDetailsResponse> response =
                restTemplate.exchange(createURLWithPort("/policy/getPolicyDetails"),
                        HttpMethod.POST, entity, GetPolicyDetailsResponse.class);
        
        assertThat(response).isNotNull();
        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
        assertThat(response.getHeaders().getContentType().toString()).isEqualTo(MediaType.APPLICATION_XML_VALUE);
        assertThat(response.getHeaders().containsKey(HeaderKey.JH_HEADER_KEY.getValue())).isTrue();
        assertThat(response.getBody()).isNotNull();
        assertThat(response.getBody()).isEqualToComparingFieldByFieldRecursively(TestDataUtils.createSampleGetPolicyDetailsResponse());
        
        String jhHeaderStr = response.getHeaders().get(HeaderKey.JH_HEADER_KEY.getValue()).get(0);

        assertThat(TestDataUtils.unmarshallXmlJHHeader(jhHeaderStr)).isEqualToComparingFieldByFieldRecursively(TestDataUtils.createSampleGetPolicyDetailsResponseHeader());
    }
    
    // test for getPolicyOption2
    @Test
    public void whenGetPolicyOption2ShouldReturnExpectedResponseWithHeader() throws Exception {
        headers.setContentType(MediaType.APPLICATION_JSON);

        final HttpEntity<GetPolicyDetailsRequestWrapper> entity = 
        		new HttpEntity<GetPolicyDetailsRequestWrapper>(TestDataUtils.createSampleGetPolicyDetailsRequestWrapper(), headers);

        final ResponseEntity<GetPolicyDetailsResponseWrapper> response =
                restTemplate.exchange(createURLWithPort("/policy/getPolicyDetailsOption2"),
                        HttpMethod.POST, entity, GetPolicyDetailsResponseWrapper.class);
        
        assertThat(response).isNotNull();
        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
        assertThat(response.getHeaders().getContentType().toString()).isEqualTo(MediaType.APPLICATION_JSON_UTF8_VALUE);
        assertThat(response.getBody()).isNotNull();
        assertThat(response.getBody().getResponse()).isNotNull();
        assertThat(response.getBody().getResponseHeader()).isNotNull();
        assertThat(response.getBody().getResponse()).isEqualToComparingFieldByFieldRecursively(TestDataUtils.createSampleGetPolicyDetailsResponse());
        assertThat(response.getBody().getResponseHeader()).isEqualToComparingFieldByFieldRecursively(TestDataUtils.createSampleGetPolicyDetailsResponseHeader());        
    }
    

    // helper method to build uri
    private String createURLWithPort(String uri) {
        final String url = "http://localhost:" + port + uri;
        System.out.println(" url - " + url);
        return url;
    }
    
    
}

# JH SOAP POC

## POC Highlights

- Generating POJOS from xsds, and adding a web service endpoint and configuration. 
	- There is an Endpoint interceptor which demonstrates adding a SoapHeader for the JHHeader on the response.
	- The Policy_v5.3.3.xsd was used for this POC and the GetPolicyDetails operations was used to demonstrate various ways of exposing the operation.

- For the same business operation, there are examples of different potential ways to expose the operation. All operations share a common underlying business service. This business service is currently returning a sample response but this is where logic for the operation would reside. 

#### POC shows:

0. Exposing a SOAP endpoint which can be used when being called from Apigee (Assumes Apigee will strip the security header)
0. Exposing a REST endpoint where the JH Header and operation request are sent as part of the body. This would be the ideal interface if called from another microservice.
0. Another alternative for a exposing REST endpoint is included that can accept either application/json or application/xml with the JH Header passed as a HTTP Header. This is doable but requires more work in the controller.

#### POC handling a soap fault.

There are integration/unit tests in spring to call the various versions.
There are postman scripts checked in that can be run from the command line using newman.

To generate POJOs from xsds, run ./gradelw generateSources

#### Notes:

 - Sample data response has a lot of empty elements within QuarterlyValuesType's attributes. The strings were not null but empty. 
      - Configured jackson to return empty but not null to more closely match sample.

 - Left xs:datetime as XMLGregorianCalendar since time zone could be a factor for timestamps. xs:date is being converted to java.time.LocalDate using an XmlAdapter.

 - Returning HttpStatus code of 200 for regular JSON/XML responses since operations are not set up as a REST Resource where POST would be creating the resource and returning 201 or 202.

 - Provided a simple SOAP Exception Resolver to demonstrate an example of a fault being returned. Currently it is returned when a SubDivisionId is not sent on the request. This is for demonstration purposes.

 - Run postman collection tests using **newman** (npm install -g newman). 
 
 	```
    newman run src/test/resources/postman/jh-policy-poc-collection.json --environment src/test/resources/postman/local.postman_environment.json 
   ```


## Additional functionality

 - May want to switch to use org.springframework.oxm.jaxb.Jaxb2Marshaller instead of custom JhHeaderJaxbUtils class.
 - Could Add ControlAdvice for REST error handling but skipped for now since that is known and not needed for the POC.
 

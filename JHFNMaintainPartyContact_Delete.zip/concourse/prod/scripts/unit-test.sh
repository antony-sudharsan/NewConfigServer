#!/bin/bash
set -o errexit
set -o xtrace

cd gitfolder

gradle integTest
#APP_ENV=CI mvn test









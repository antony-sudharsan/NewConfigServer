#!/bin/bash
set -o errexit
set -o   xtrace

TARGET_DIR=$PWD/target
mkdir -p $TARGET_DIR

cd gitfolder
chmod +x gradlew
APP_ENV=CI ./gradlew clean build -x integTest -x test

ls
ls -lrt build/libs/
cp -R build/libs $TARGET_DIR/

cp manifest-dev.yml $TARGET_DIR/
cp manifest-test.yml $TARGET_DIR/
#cp manifest-uat.yml $TARGET_DIR/
#cp manifest-prod.yml $TARGET_DIR/



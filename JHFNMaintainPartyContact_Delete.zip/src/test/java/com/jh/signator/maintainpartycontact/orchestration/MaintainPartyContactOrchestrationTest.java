package com.jh.signator.maintainpartycontact.orchestration;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

public class MaintainPartyContactOrchestrationTest {

    @Before
    public void setUp() throws Exception {
    }

    @After
    public void tearDown() throws Exception {
    }



    @Test
    public void getPartyContacts() {
    }

    @Test
    public void searchPartyContact() {
    }

    @Test
    public void createPartyContact() {
    }

    @Test
    public void deletePartyContact() {
    }

    @Test
    public void updatePartyContact() {
    }
}
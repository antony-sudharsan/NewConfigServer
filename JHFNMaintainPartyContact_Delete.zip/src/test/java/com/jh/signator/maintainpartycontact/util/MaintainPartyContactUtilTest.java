package com.jh.signator.maintainpartycontact.util;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.junit4.SpringRunner;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.GregorianCalendar;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

@RunWith(SpringRunner.class)
public class MaintainPartyContactUtilTest {

    MaintainPartyContactUtil maintainPartyContactUtil = new MaintainPartyContactUtil();

    Date oldDate;
    long longValue = 12345678910L;

    XMLGregorianCalendar xmlGregCal;

    @Before
    public void setUp() throws Exception {
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        oldDate = sdf.parse("21/12/2012");
        DateFormat format = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
        GregorianCalendar cal = new GregorianCalendar();
        cal.setTime(oldDate);
        xmlGregCal = DatatypeFactory.newInstance().newXMLGregorianCalendar(cal);

    }

    @Test
    public void testConvertUtilDateToGregoerianCalendar() throws ParseException, DatatypeConfigurationException {
        assertEquals(xmlGregCal, maintainPartyContactUtil.convertUtilDateToGregoerianCalendar(oldDate));
    }


    @Test
    public void testConvertUtilDateToGregoerianCalendarNotNull() throws ParseException, DatatypeConfigurationException {
        assertNotNull(maintainPartyContactUtil.convertUtilDateToGregoerianCalendar(oldDate));
    }

    @Test
    public void testConvertLongToString() {
        assertEquals("12345678910", maintainPartyContactUtil.convertLongToString(longValue));
    }

    @After
    public void tearDown() throws Exception {
        maintainPartyContactUtil = null;
    }

    @Test
    public void getPhoneAreaCode() {
    }

    @Test
    public void getIntlPhoneAccessCode() {
    }

    @Test
    public void getPhoneExtCode() {
    }

    @Test
    public void getPhone() {
    }

    @Test
    public void getTelcmPerferredCode() {
    }

    @Test
    public void getTelcmPerferredCode1() {
    }

    @Test
    public void getPhoneAreaCode1() {
    }

    @Test
    public void getPhone1() {
    }

    @Test
    public void getPhoneExtCode1() {
    }

    @Test
    public void getIntlPhoneAccessCode1() {
    }
}

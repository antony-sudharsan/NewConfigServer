package com.jh.signator.maintainpartycontact.controller;

import com.jh.signator.maintainpartycontact.model.ContactResult;
import com.jh.signator.maintainpartycontact.model.ReadContactReply;
import com.jh.signator.maintainpartycontact.model.ReadContactRequest;
import com.jh.signator.maintainpartycontact.orchestration.MaintainPartyContactOrchestration;
import com.jh.signator.maintainpartycontact.util.MaintainPartyContactUtil;
import org.codehaus.jackson.map.ObjectMapper;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.result.MockMvcResultHandlers;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.hamcrest.CoreMatchers.is;

import java.util.ArrayList;
import java.util.List;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

/**
 * @WebMvcTest.
 * It will auto-configure the Spring MVC infrastructure for our unit tests.
 * Setting up WebMvc Context for the Controller which is under test("MaintainPartyContactController")
 */
@RunWith(SpringRunner.class)
@WebMvcTest(MaintainPartyContactController.class)
public class MaintainPartyContactControllerTest {

    /**
     * Initializing MockMvc
     */
    @Autowired
    private MockMvc mvc;

    ReadContactReply readContactReply;
    ReadContactRequest readContactRequest;

    @MockBean
    private MaintainPartyContactOrchestration maintainPartyContactOrchestration;

    @MockBean
    private MaintainPartyContactUtil maintainPartyContactUtil ;



    /*
     * converts a Java object into JSON representation
     */
    public static String asJsonString(final Object obj) {
        System.out.println("Inside the JSON String");
        try {
            String returnStr = new ObjectMapper().writeValueAsString(obj);
            System.out.println("@@@@@@@@@@@@@@@@@@@@2returnStr @@@@@@@@@@@@@@2>" + returnStr);
            return returnStr;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * @Before Method will be called before each test case execution
     */

    @Before
    public void setup() throws Exception {
        readContactRequest = new ReadContactRequest();
        readContactRequest.setCDCIDNo("");
        readContactRequest.setCDCIDNoBizFunc("");
        readContactRequest.setContactIDNo("");
        readContactRequest.setID("");
        readContactRequest.setIDRefType("");
        ReadContactRequest.KeyedValue keyedValue = new ReadContactRequest.KeyedValue();
        List<String> keyedListValue = new ArrayList<String>();
        keyedListValue.add("we");
        keyedValue.setKeyName("sds");
        keyedValue.setVendorCode("sds");
        keyedValue.setKeyValue(keyedListValue);
        readContactRequest.setKeyedValue(keyedValue);
//-------------------Request Completed-----------------//
        readContactReply = new ReadContactReply();
        readContactReply.setID("123456");
        readContactReply.setIDRefType("123456");
        List<ContactResult> result = new ArrayList<ContactResult>();
        ContactResult contactResult = new ContactResult();
        contactResult.setUpdatedByNm("");
        contactResult.setPartyOfficeInd("");
        contactResult.setContactPrefCd("");
        contactResult.setContactInfoTypCd("");
        contactResult.setCDCIDNo("");
        contactResult.setCDCIDNoBizFunc("");
        contactResult.setContactIDNo("");
        contactResult.setContactEffDt(null);
        contactResult.setContactEndDt(null);
        contactResult.setCreatedDate(null);
        contactResult.setUpdatedDate(null);
        contactResult.setCreatedByNm(null);
        contactResult.setUpdatedByNm("");
        List<ContactResult.KeyedValue> keyedListRetValueList = new ArrayList<ContactResult.KeyedValue>();
        ContactResult.KeyedValue retkeyedValue = new ContactResult.KeyedValue();
        retkeyedValue.setKeyName("");
        retkeyedValue.setVendorCode("");
        retkeyedValue.setKeyValue("");
        keyedListRetValueList.add(retkeyedValue);
        contactResult.setKeyedValue(keyedListRetValueList);

        result.add(contactResult);
        readContactReply.setResult(result);
    }

    @Test
    public void getPartyContactTest() throws Exception {

        when(maintainPartyContactOrchestration.getPartyContacts("1234", "FNA", readContactRequest)).thenReturn(readContactReply);
        mvc.perform(
            post("/jh/signator/partycontacts")
                    .content(asJsonString(readContactReply))
                .accept(MediaType.APPLICATION_JSON_VALUE)
                .contentType(MediaType.APPLICATION_JSON_VALUE)
                .header("MessageUUID", "1234")
                .header("SourceSystemName", "FNA")
        )
        .andDo(MockMvcResultHandlers.print())
        .andExpect(status().isOk())
        .andExpect(jsonPath("$.idRefType", is(readContactReply.getIDRefType())));
       // .andExpect(jsonPath("idrefType").value("123456"));
      //  verify(maintainPartyContactOrchestration, times(1)).getPartyContacts("1234", "FNA", readContactRequest);
        //verifyNoMoreInteractions(readContactReply);
    }

/*

    @Test
    public void searchPartyContact() {
    }

    @Test
    public void createPartyContact() {
    }

    @Test
    public void updatePartyContact() {
    }

    @Test
    public void deletePartyContact() {
    }
        //NO DATA FOUND
    @Test
    public void policyNotFoundTest() throws Exception {
        mvc.perform(get("/jh/wealth/ann/awdindex/policy?policyNo=1111").header("MessageUUID", "1234").header("SourceSystemName", "1234")).andExpect(status().isNotFound());
    }

    //BAD REQUEST
    @Test
    public void policyBadRequest() throws Exception {
        mvc.perform(get("/jh/wealth/ann/awdindex/policy?policyNo=11").header("MessageUUID", "1234").header("SourceSystemName", "1234")).andExpect(status().isBadRequest());
    }


*/

    @After
    public void teardown() {
        maintainPartyContactOrchestration = null;
    }
}
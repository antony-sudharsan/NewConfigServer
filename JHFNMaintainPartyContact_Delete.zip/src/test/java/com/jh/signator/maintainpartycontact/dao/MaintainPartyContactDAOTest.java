package com.jh.signator.maintainpartycontact.dao;

import org.junit.Test;

import static org.junit.Assert.*;

public class MaintainPartyContactDAOTest {

    @Test
    public void getTTelcmAddr() {
    }

    @Test
    public void getTelectronicAddr() {
    }

    @Test
    public void createPartyTTELCM_ADDRContact() {
    }

    @Test
    public void createPartyTELECTRONIC_ADDRContact() {
    }

    @Test
    public void updatePartyContact() {
    }

    @Test
    public void searchPartyContact() {
    }

    @Test
    public void deletePartyTTELCM_ADDRContact() {
    }

    @Test
    public void deletePartyTELECTRONIC_ADDRContact() {
    }

    @Test
    public void verifyTELECTRONIC_ADDRInsert() {
    }

    @Test
    public void verifyTTELCM_ADDRInsert() {
    }

    @Test
    public void verifyTTELCM_ADDRDelete() {
    }

    @Test
    public void verifyTELECTRONIC_ADDRDelete() {
    }

    @Test
    public void updatePartyTTELCM_ADDRContact() {
    }

    @Test
    public void updatePartyTELECTRONIC_ADDRContact() {
    }

    @Test
    public void verifyTTELCM_ADDRUpdate() {
    }

    @Test
    public void verifyTELECTRONIC_ADDRUpdate() {
    }

    @Test
    public void selectTTELCM_ADDRUpdate() {
    }

    @Test
    public void selectTELECTRONIC_ADDRUpdate() {
    }
}
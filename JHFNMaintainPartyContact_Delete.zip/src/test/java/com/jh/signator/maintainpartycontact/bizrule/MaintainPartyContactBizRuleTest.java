package com.jh.signator.maintainpartycontact.bizrule;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

public class MaintainPartyContactBizRuleTest {

    @Before
    public void setUp() throws Exception {
    }

    @After
    public void tearDown() throws Exception {
    }

    @Test
    public void businessConditionTTELCMADDR() {
    }

    @Test
    public void businessConditionTELECTRONIC_ADDR() {
    }

    @Test
    public void businessConditionDeleteTTELCMADDR() {
    }

    @Test
    public void businessConditionDeleteTELECTRONIC() {
    }

    @Test
    public void businessConditionUpdateTTELCMADDR() {
    }

    @Test
    public void businessConditionUpdateTELECTRONIC() {
    }
}
package com.jh.signator;

import com.jh.common.logging.LoggerHandler;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;

@Component
public class LogInitializer {

    @Autowired
    private Environment env;

    @PostConstruct
    public void LoggerInstance() {
        try {
            LoggerHandler.getInstance(env.getProperty("log.appID"), env.getProperty("log.svcName"), env.getProperty("log.componentName"), env.getProperty("log.svcVersion"));
        } catch (Exception e) {
            System.out.println("Error in Log Initialization in Maintain Party Contact" + e.getStackTrace());
        }

    }

}


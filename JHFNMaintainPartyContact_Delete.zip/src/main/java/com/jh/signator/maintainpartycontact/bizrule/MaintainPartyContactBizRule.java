package com.jh.signator.maintainpartycontact.bizrule;

import com.jh.signator.maintainpartycontact.constants.MaintainPartyConstants;
import com.jh.signator.maintainpartycontact.model.CreateContactRequest;
import com.jh.signator.maintainpartycontact.model.DeleteContactRequest;
import com.jh.signator.maintainpartycontact.model.ReadContactRequest;
import com.jh.signator.maintainpartycontact.model.UpdateContactRequest;
import org.springframework.stereotype.Component;

import java.util.Arrays;
import java.util.List;

@Component
public class MaintainPartyContactBizRule {

    /**
     * Business rules to identify the insertion into the TTELCM_ADDR table
     *
     * @param createContactRequest
     * @return
     */
    public boolean businessConditionTTELCMADDR(CreateContactRequest createContactRequest) {

        List<String> telectronicAddrCCIDNoBixFuncList = Arrays.asList(MaintainPartyConstants.CREATE_TTELCM_ADDR_CCID_NO_BIX_FUNC.split("\\s*,\\s*"));
        List<String> telectronicFaxAddrCCIDNoBixFuncList = Arrays.asList(MaintainPartyConstants.CREATE_FAX_TTELCM_ADDR_CCID_NO_BIX_FUNC.split("\\s*,\\s*"));

        boolean returnFlag = false;

        if (createContactRequest.getIDRefType().equals("8000") && createContactRequest.getContactInfoTypCd().equals("PHONE")
                && createContactRequest.getCDCIDNo().equals("42") && telectronicAddrCCIDNoBixFuncList.contains(createContactRequest.getCDCIDNoBizFunc())) {
            returnFlag = true;
        } else if (createContactRequest.getIDRefType().equals("8000") && createContactRequest.getContactInfoTypCd().equals("FAX")
                && createContactRequest.getCDCIDNo().equals("70") && telectronicFaxAddrCCIDNoBixFuncList.contains(createContactRequest.getCDCIDNoBizFunc())) {
            returnFlag = true;
        }
        return returnFlag;
    }


    /**
     * Business rules to identify the insertion into the TELECTRONIC_ADDR table
     *
     * @param createContactRequest
     * @return
     */
    public boolean businessConditionTELECTRONIC_ADDR(CreateContactRequest createContactRequest) {
        boolean returnFlag = false;
        List<String> telectronicEmailCCIDNoBixFuncList = Arrays.asList(MaintainPartyConstants.CREATE_TELECTRONIC_EMAIL_CCID_NO_BIX_FUNC.split("\\s*,\\s*"));
        List<String> telectronicFaxCCIDNoBixFuncList = Arrays.asList(MaintainPartyConstants.CREATE_TELECTRONIC_URL_CCID_NO_BIX_FUNC.split("\\s*,\\s*"));
        List<String> telectronicImCCIDNoBixFuncList = Arrays.asList(MaintainPartyConstants.CREATE_TELECTRONIC_IM_CCID_NO_BIX_FUNC.split("\\s*,\\s*"));
        List<String> telectronicHandlCCIDNoBixFuncList = Arrays.asList(MaintainPartyConstants.CREATE_TELECTRONIC_HANDL_CCID_NO_BIX_FUNC.split("\\s*,\\s*"));

        if (createContactRequest.getIDRefType().equals("8000") && createContactRequest.getContactInfoTypCd().equals("EMAIL")
                && createContactRequest.getCDCIDNo().equals("41") && telectronicEmailCCIDNoBixFuncList.contains(createContactRequest.getCDCIDNoBizFunc())) {
            returnFlag = true;
        } else if (createContactRequest.getIDRefType().equals("8000") && createContactRequest.getContactInfoTypCd().equals("URL")
                && createContactRequest.getCDCIDNo().equals("72") && telectronicFaxCCIDNoBixFuncList.contains(createContactRequest.getCDCIDNoBizFunc())) {
            returnFlag = true;
        } else if (createContactRequest.getIDRefType().equals("8000") && createContactRequest.getContactInfoTypCd().equals("HANDL")
                && createContactRequest.getCDCIDNo().equals("161") && telectronicHandlCCIDNoBixFuncList.contains(createContactRequest.getCDCIDNoBizFunc())) {
            returnFlag = true;
        } else if (createContactRequest.getIDRefType().equals("8000") && createContactRequest.getContactInfoTypCd().equals("IM")
                && createContactRequest.getCDCIDNo().equals("160") && telectronicImCCIDNoBixFuncList.contains(createContactRequest.getCDCIDNoBizFunc())) {
            returnFlag = true;
        }

        return returnFlag;
    }

    /**
     * @param deleteContactRequest
     * @return
     */
    public boolean businessConditionDeleteTTELCMADDR(DeleteContactRequest deleteContactRequest) {

        List<String> ttelAddrDelCCIDNoBixFuncList = Arrays.asList(MaintainPartyConstants.DELETE_TTELCM_CCID_NO_BIX_FUNC.split("\\s*,\\s*"));

        boolean returnFlag = false;

        if (deleteContactRequest.getIDRefType().equals("8000") && (deleteContactRequest.getCDCIDNo().equals("42")
                || deleteContactRequest.getCDCIDNo().equals("70")) && ttelAddrDelCCIDNoBixFuncList.contains(deleteContactRequest.getCDCIDNoBizFunc())) {
            returnFlag = true;
        }
        return returnFlag;
    }

    /**
     * @param deleteContactRequest
     * @return
     */
    public boolean businessConditionDeleteTELECTRONIC(DeleteContactRequest deleteContactRequest) {

        List<String> telectronicAddrCCIDNoList = Arrays.asList(MaintainPartyConstants.DELETE_TELECTRONIC_CCID_NO.split("\\s*,\\s*"));
        List<String> telectronicAddrCCIDNoBixFuncList = Arrays.asList(MaintainPartyConstants.DELETE_TELECTRONIC_CCID_NO_BIX_FUNC.split("\\s*,\\s*"));

        boolean returnFlag = false;

        if (deleteContactRequest.getIDRefType().equals("8000") && telectronicAddrCCIDNoList.contains(deleteContactRequest.getCDCIDNo())
                && telectronicAddrCCIDNoBixFuncList.contains(deleteContactRequest.getCDCIDNoBizFunc())) {
            returnFlag = true;
        }
        return returnFlag;
    }


    /**
     * Business rules to identify the Update into the TELECTRONIC_ADDR table
     *
     * @param updateContactRequest
     * @return
     */
    public boolean businessConditionUpdateTELECTRONIC(UpdateContactRequest updateContactRequest) {
        boolean returnFlag = false;
        List<String> telectronicEmailCCIDNoBixFuncList = Arrays.asList(MaintainPartyConstants.UPDATE_TELECTRONIC_EMAIL_CCID_NO_BIX_FUNC.split("\\s*,\\s*"));
        List<String> telectronicFaxCCIDNoBixFuncList = Arrays.asList(MaintainPartyConstants.UPDATE_TELECTRONIC_URL_CCID_NO_BIX_FUNC.split("\\s*,\\s*"));
        List<String> telectronicImCCIDNoBixFuncList = Arrays.asList(MaintainPartyConstants.UPDATE_TELECTRONIC_IM_CCID_NO_BIX_FUNC.split("\\s*,\\s*"));
        List<String> telectronicHandlCCIDNoBixFuncList = Arrays.asList(MaintainPartyConstants.UPDATE_TELECTRONIC_HANDL_CCID_NO_BIX_FUNC.split("\\s*,\\s*"));

        if (updateContactRequest.getIDRefType().equals("8000") && updateContactRequest.getContactInfoTypCd().equals("EMAIL")
                && updateContactRequest.getCDCIDNo().equals("41") && telectronicEmailCCIDNoBixFuncList.contains(updateContactRequest.getCDCIDNoBizFunc())) {
            returnFlag = true;
        } else if (updateContactRequest.getIDRefType().equals("8000") && updateContactRequest.getContactInfoTypCd().equals("URL")
                && updateContactRequest.getCDCIDNo().equals("72") && telectronicFaxCCIDNoBixFuncList.contains(updateContactRequest.getCDCIDNoBizFunc())) {
            returnFlag = true;
        } else if (updateContactRequest.getIDRefType().equals("8000") && updateContactRequest.getContactInfoTypCd().equals("HANDL")
                && updateContactRequest.getCDCIDNo().equals("161") && telectronicHandlCCIDNoBixFuncList.contains(updateContactRequest.getCDCIDNoBizFunc())) {
            returnFlag = true;
        } else if (updateContactRequest.getIDRefType().equals("8000") && updateContactRequest.getContactInfoTypCd().equals("IM")
                && updateContactRequest.getCDCIDNo().equals("160") && telectronicImCCIDNoBixFuncList.contains(updateContactRequest.getCDCIDNoBizFunc())) {
            returnFlag = true;
        }

        return returnFlag;
    }
    /**
     * Business Rules to Identify the Update into the TTELCM table
     *
     * @param updateContactRequest
     * @return
     */
    public boolean businessConditionUpdateTTELCMADDR(UpdateContactRequest updateContactRequest) {

        List<String> ttelcmAddrCCIDNoBixFuncList = Arrays.asList(MaintainPartyConstants.UPDATE_TTELCM_ADDR_CCID_NO_BIX_FUNC.split("\\s*,\\s*"));
        List<String> telectronicFaxAddrCCIDNoBixFuncList = Arrays.asList(MaintainPartyConstants.UPDATE_FAX_TTELCM_ADDR_CCID_NO_BIX_FUNC.split("\\s*,\\s*"));

        boolean returnFlag = false;
        String contactInfo = updateContactRequest.getContactInfo();

        if (updateContactRequest.getIDRefType().equals("8000") && (updateContactRequest.getContactInfoTypCd().equals("PHONE") || updateContactRequest.getContactInfoTypCd() == null || updateContactRequest.getContactInfoTypCd().equals(""))
                && updateContactRequest.getCDCIDNo().equals("42") && ttelcmAddrCCIDNoBixFuncList.contains(updateContactRequest.getCDCIDNoBizFunc())
                && (contactInfo == "" || contactInfo.isEmpty())) {
            returnFlag = true;
        } else if (updateContactRequest.getIDRefType().equals("8000") && updateContactRequest.getContactInfoTypCd().equals("FAX")
                && updateContactRequest.getCDCIDNo().equals("70") && telectronicFaxAddrCCIDNoBixFuncList.contains(updateContactRequest.getCDCIDNoBizFunc())) {
            returnFlag = true;
        }
        return returnFlag;
    }

    /**
     *
     * @param readContactRequest
     * @return
     */
    public boolean businessConditionReadTTELCMADDR(ReadContactRequest readContactRequest) {

        List<String> ttelcmAddrCCIDNoList = Arrays.asList(MaintainPartyConstants.TTELCM_ADDR_CCID_NO.split("\\s*,\\s*"));
        List<String> ttelcmAddrCCIDNoBixFuncList = Arrays.asList(MaintainPartyConstants.TTELCM_ADDR_CCID_NO_BIX_FUNC.split("\\s*,\\s*"));

        boolean returnFlag = false;

        if (readContactRequest.getIDRefType().equals(MaintainPartyConstants.ID_REF_TYPE) && ttelcmAddrCCIDNoList.contains(readContactRequest.getCDCIDNo()) && ttelcmAddrCCIDNoBixFuncList.contains(readContactRequest.getCDCIDNoBizFunc())) {
            returnFlag = true;
        }

        return returnFlag;
    }


    /**
     * @param readContactRequest
     * @return
     */
    public boolean businessConditionReadTELECTRONIC(ReadContactRequest readContactRequest) {
        boolean returnFlag = false;

        List<String> telectronicAddrCCIDNoList = Arrays.asList(MaintainPartyConstants.TELECTRONIC_ADDR_CCID_NO.split("\\s*,\\s*"));
        List<String> telectronicAddrCCIDNoBixFuncList = Arrays.asList(MaintainPartyConstants.TELECTRONIC_ADDR_NO_BIX_FUNC.split("\\s*,\\s*"));

        if (readContactRequest.getIDRefType().equals(MaintainPartyConstants.ID_REF_TYPE) && telectronicAddrCCIDNoList.contains(readContactRequest.getCDCIDNo())
                && telectronicAddrCCIDNoBixFuncList.contains(readContactRequest.getCDCIDNoBizFunc())) {
            returnFlag = true;
        }

        return returnFlag;
    }
}

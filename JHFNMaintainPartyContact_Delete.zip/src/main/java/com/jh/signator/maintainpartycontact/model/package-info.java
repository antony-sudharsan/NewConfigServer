@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.esb.manulife.com/xsd/distribution/jhfn/maintainpartycontact", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.jh.signator.maintainpartycontact.model;


package com.jh.signator.maintainpartycontact.model;

import javax.xml.bind.annotation.*;
import java.util.ArrayList;
import java.util.List;


/**
 * <p>Java class for anonymous complex type.
 *
 * <p>The following schema fragment specifies the expected content contained within this class.
 *
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="ID" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="IDRefType" type="{http://www.esb.manulife.com/xsd/distribution/jhfn/maintainpartycontact}OLI_LU_IDREFTYPE"/>
 *         &lt;element name="Result" type="{http://www.esb.manulife.com/xsd/distribution/jhfn/maintainpartycontact}ContactResult" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
        "id",
        "idRefType",
        "result"
})
@XmlRootElement(name = "CreateContact_reply")
public class CreateContactReply {

    @XmlElement(name = "ID", required = true)
    protected String id;
    @XmlElement(name = "IDRefType", required = true)
    protected String idRefType;
    @XmlElement(name = "Result")
    protected List<ContactResult> result;

    /**
     * Gets the value of the id property.
     *
     * @return possible object is
     * {@link String }
     */
    public String getID() {
        return id;
    }

    /**
     * Sets the value of the id property.
     *
     * @param value allowed object is
     *              {@link String }
     */
    public void setID(String value) {
        this.id = value;
    }

    /**
     * Gets the value of the idRefType property.
     *
     * @return possible object is
     * {@link String }
     */
    public String getIDRefType() {
        return idRefType;
    }

    /**
     * Sets the value of the idRefType property.
     *
     * @param value allowed object is
     *              {@link String }
     */
    public void setIDRefType(String value) {
        this.idRefType = value;
    }

    /**
     * Gets the value of the result property.
     * <p>
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the result property.
     * <p>
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getResult().add(newItem);
     * </pre>
     * <p>
     * <p>
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ContactResult }
     */
    public List<ContactResult> getResult() {
        if (result == null) {
            result = new ArrayList<ContactResult>();
        }
        return this.result;
    }

    public void setResult(List<ContactResult> result) {
        this.result = result;
    }

}

package com.jh.signator.maintainpartycontact.validation;
/**
 * Copyright (c) 2018, John Hancock and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 * <p>
 * Please contact John Hancock, 200 Berkley, Boston, MA 02116 USA
 * or visit https://www.johnhancock.com/legal.html if you need additional information or have any
 * questions.
 */


import org.springframework.stereotype.Component;

/**
 * This class consists exclusively methods to expose the methods as RestFull webservices
 *
 *
 * @author Antony Sudharsan Gnanaraj
 * @version     %I%, %G%
 * @since 1.0
 */
@Component
public class MaitainPartyContactValidation {

    public boolean validateAWDIndexPolicy(String policyNumber) {

        return false;
    }
}

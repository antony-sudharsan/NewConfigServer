package com.jh.signator.maintainpartycontact.constants;

public final class MaintainPartyConstants {

    //##READ OPERATION QUERY fILTERS##
    public static String ID_REF_TYPE = "8000";
    public static String TTELCM_ADDR_CCID_NO = "42,70";
    public static String TTELCM_ADDR_CCID_NO_BIX_FUNC = "190,191,192,193,194,195";
    public static String TELECTRONIC_ADDR_CCID_NO = "41,72,160,161";
    public static String TELECTRONIC_ADDR_NO_BIX_FUNC = "170,171,172,173,174,175,176,177,178,179,180,181,182";
    // ###### CREATE OPERATION FILTERS#####
    public static String CREATE_TTELCM_ADDR_CCID_NO_BIX_FUNC = "190,191,192,193,194";
    public static String CREATE_FAX_TTELCM_ADDR_CCID_NO_BIX_FUNC = "190,195";
    public static String CREATE_TELECTRONIC_EMAIL_CCID_NO_BIX_FUNC = "170,171,172,173,174";
    public static String CREATE_TELECTRONIC_URL_CCID_NO_BIX_FUNC = "170,175,176,177,178";
    public static String CREATE_TELECTRONIC_IM_CCID_NO_BIX_FUNC = "170,179,180,181";
    public static String CREATE_TELECTRONIC_HANDL_CCID_NO_BIX_FUNC = "170,182";
    // ###### DELETE OPERATION FILTERS#####
    public static String DELETE_TTELCM_CCID_NO_BIX_FUNC = "190,191,192,193,194,195";
    public static String DELETE_TELECTRONIC_CCID_NO = "41,72,160,161";
    public static String DELETE_TELECTRONIC_CCID_NO_BIX_FUNC = "170,171,172,173,174,175,176,177,178,179,180,181,182";
    // ###### UPDATE OPERATION FILTERS#####
    public static String UPDATE_TTELCM_ADDR_CCID_NO_BIX_FUNC = "190,191,192,193,194";
    public static String UPDATE_FAX_TTELCM_ADDR_CCID_NO_BIX_FUNC = "190,195";
    public static String UPDATE_TELECTRONIC_EMAIL_CCID_NO_BIX_FUNC = "170,171,172,173,174";
    public static String UPDATE_TELECTRONIC_URL_CCID_NO_BIX_FUNC = "170,175,176,177,178";
    public static String UPDATE_TELECTRONIC_IM_CCID_NO_BIX_FUNC = "170,179,180,181";
    public static String UPDATE_TELECTRONIC_HANDL_CCID_NO_BIX_FUNC = "170,182";


    // ####### Error Messages #####################

    public static String NO_CONTENT_FOUND = "No Content Found";
    public static String SQL_TIME_OUT = "SQL Server back end timed out";
    public static String NO_DATA_FOUND = "No Data Found";
    public static String INVALID_REQUEST = "Invalid Request";
    public static String VALIDATION_FAILED = "Validation Failed";

    private MaintainPartyConstants() {
    }

}

package com.jh.signator.maintainpartycontact.util;

import com.jh.signator.maintainpartycontact.model.CreateContactRequest;
import com.jh.signator.maintainpartycontact.model.UpdateContactRequest;
import org.springframework.stereotype.Component;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;
import java.util.Date;
import java.util.GregorianCalendar;

@Component
public class MaintainPartyContactUtil {

    /**
     * Method to convert Long Data type to String
     *
     * @param longValue
     * @return
     */
    public String convertLongToString(Long longValue) {

        return longValue.toString();
    }

    /**
     * Method to oncer the Date input to XML Gregorian Calendar
     *
     * @param inputDate
     * @return
     */
    public XMLGregorianCalendar convertUtilDateToGregoerianCalendar(Date inputDate) {
        GregorianCalendar gregorianCalContactEffDate = new GregorianCalendar();
        gregorianCalContactEffDate.setTime(inputDate);
        XMLGregorianCalendar date2 = null;
        try {
            date2 = DatatypeFactory.newInstance().newXMLGregorianCalendar(gregorianCalContactEffDate);
        } catch (DatatypeConfigurationException e) {
            e.printStackTrace();
        }
        return date2;
    }

    /**
     * @param createContactRequest
     * @return
     */
    public String getPhoneAreaCode(CreateContactRequest createContactRequest) {
        String retString = "";
        if (createContactRequest.getContactInfoTypCd() != null && (createContactRequest.getContactInfoTypCd().equals("PHONE") || createContactRequest.getContactInfoTypCd().equals("FAX"))) {
            String contactInfo = createContactRequest.getContactInfo();
            if (contactInfo.substring(1, 1).equals("1")) {
                retString = contactInfo.substring(2, (2 + 3 - 1));
            }
        }
        return retString;
    }

    /**
     * @param createContactRequest
     * @return
     */
    public String getIntlPhoneAccessCode(CreateContactRequest createContactRequest) {
        String retString = "";
        if (createContactRequest.getContactInfoTypCd() != null && (createContactRequest.getContactInfoTypCd().equals("PHONE") || createContactRequest.getContactInfoTypCd().equals("FAX"))) {
            String contactInfo = createContactRequest.getContactInfo();
            if (contactInfo.substring(1, 1).equals("0")) {
                retString = contactInfo.substring(4, (4 + 12 - 1));
            }
        }
        return retString;
    }

    /**
     * @param createContactRequest
     * @return
     */
    public String getPhoneExtCode(CreateContactRequest createContactRequest) {
        String retString = "";
        if (createContactRequest.getContactInfoTypCd() != null && createContactRequest.getContactInfoTypCd().equals("PHONE")) {
            String contactInfo = createContactRequest.getContactInfo();
            if (contactInfo.substring(1, 1).equals("1")) {
                retString = contactInfo.substring(12, (8 + 12 - 1));
            } else if (contactInfo.substring(1, 1).equals("0")) {
                retString = contactInfo.substring(16, (8 + 16 - 1));
            }
        }
        return retString;
    }

    /**
     * @param createContactRequest
     * @return
     */
    public String getPhone(CreateContactRequest createContactRequest) {
        String retString = "";
        if (createContactRequest.getContactInfoTypCd() != null && (createContactRequest.getContactInfoTypCd().equals("PHONE") || createContactRequest.getContactInfoTypCd().equals("FAX"))) {
            String contactInfo = createContactRequest.getContactInfo();
            if (contactInfo.substring(1, 1).equals("1")) {
                retString = contactInfo.substring(5, (7 + 5 - 1));
            }
        }
        return retString;
    }

    /**
     * @param createContactRequest
     * @return
     */
    public String getTelcmPerferredCode(CreateContactRequest createContactRequest) {
        String retString = "";
        String contactPrefCd = createContactRequest.getContactPrefCd();

        if (contactPrefCd == null && contactPrefCd.isEmpty()) {
            retString = "150";
        } else {
            retString = contactPrefCd;
        }
        return retString;
    }

    public String getTelcmPerferredCode(UpdateContactRequest updateContactRequest) {
        String retString = "";
        String contactPrefCd = updateContactRequest.getContactPrefCd();

        if (contactPrefCd == null && contactPrefCd.isEmpty()) {
            retString = "150";
        } else {
            retString = contactPrefCd;
        }
        return retString;
    }

    public String getPhoneAreaCode(UpdateContactRequest updateContactRequest) {
        String retString = "";
        if (updateContactRequest.getContactInfoTypCd() != null && (updateContactRequest.getContactInfoTypCd().equals("PHONE") || updateContactRequest.getContactInfoTypCd().equals("FAX"))) {
            String contactInfo = updateContactRequest.getContactInfo();
            if (contactInfo.substring(1, 1).equals("1")) {
                retString = contactInfo.substring(2, (2 + 3 - 1));
            }
        }
        return retString;
    }

    public String getPhone(UpdateContactRequest updateContactRequest) {
        String retString = "";
        if (updateContactRequest.getContactInfoTypCd() != null && (updateContactRequest.getContactInfoTypCd().equals("PHONE") || updateContactRequest.getContactInfoTypCd().equals("FAX"))) {
            String contactInfo = updateContactRequest.getContactInfo();
            if (contactInfo.substring(1, 1).equals("1")) {
                retString = contactInfo.substring(5, (7 + 5 - 1));
            }
        }
        return retString;
    }

    public String getPhoneExtCode(UpdateContactRequest updateContactRequest) {
        String retString = "";
        if (updateContactRequest.getContactInfoTypCd() != null && updateContactRequest.getContactInfoTypCd().equals("PHONE")) {
            String contactInfo = updateContactRequest.getContactInfo();
            if (contactInfo.substring(1, 1).equals("1")) {
                retString = contactInfo.substring(12, (8 + 12 - 1));
            } else if (contactInfo.substring(1, 1).equals("0")) {
                retString = contactInfo.substring(16, (8 + 16 - 1));
            }
        }
        return retString;
    }

    public String getIntlPhoneAccessCode(UpdateContactRequest updateContactRequest) {
        String retString = "";
        if (updateContactRequest.getContactInfoTypCd() != null && (updateContactRequest.getContactInfoTypCd().equals("PHONE") || updateContactRequest.getContactInfoTypCd().equals("FAX"))) {
            String contactInfo = updateContactRequest.getContactInfo();
            if (contactInfo.substring(1, 1).equals("0")) {
                retString = contactInfo.substring(4, (4 + 12 - 1));
            }
        }
        return retString;
    }
}

package com.jh.signator.maintainpartycontact.mapper;

import com.jh.signator.maintainpartycontact.model.ContactResult;
import com.jh.signator.maintainpartycontact.util.MaintainPartyContactUtil;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * @author deepain
 */
public class ContactResultTTelCMMapper implements RowMapper {

    MaintainPartyContactUtil maintainPartyContactUtil = new MaintainPartyContactUtil();

    @Override
    public Object mapRow(ResultSet rsRepData, int rowNum) throws SQLException {

        ContactResult contactResult = new ContactResult();
        contactResult.setPartyOfficeInd("0");
        contactResult.setCDCIDNo(rsRepData.getString("CDC_ID_NO_PHNE_TYP"));
        contactResult.setCDCIDNoBizFunc(rsRepData.getString("CDC_ID_NO_BIZ_FUNC"));
        contactResult.setContactIDNo(rsRepData.getString("TELCM_ADDR_ID_NO"));
        if (rsRepData.getString("PHNE_AREA_CD") != null && rsRepData.getString("PHNE_AREA_CD").length() > 0) {
            String contactInfo = "1" + rsRepData.getString("PHNE_AREA_CD") + rsRepData.getString("PHNE_NO") + rsRepData.getString("PHNE_EXT_NO");
            contactResult.setContactInfo(contactInfo);
        } else if (rsRepData.getString("INTL_PHNE_ACES_CD") != null && rsRepData.getString("INTL_PHNE_ACES_CD").length() > 0) {
            String contactInfo = "011" + rsRepData.getString("INTL_PHNE_ACES_CD") + rsRepData.getString("PHNE_EXT_NO");
            contactResult.setContactInfo(contactInfo);
        } else {
            contactResult.setContactInfo("");
        }
        contactResult.setContactInfoTypCd(rsRepData.getString("TELCM_TYP_CD"));
        contactResult.setContactPrefCd(rsRepData.getString("TELCM_PREF_CD"));
        if (rsRepData.getDate("TELCM_ADDR_EFF_DT") != null)
            contactResult.setContactEffDt(maintainPartyContactUtil.convertUtilDateToGregoerianCalendar(rsRepData.getDate("TELCM_ADDR_EFF_DT")));
        if (rsRepData.getDate("TELCM_ADDR_END_DT") != null)
            contactResult.setContactEndDt(maintainPartyContactUtil.convertUtilDateToGregoerianCalendar(rsRepData.getDate("TELCM_ADDR_END_DT")));
        if (rsRepData.getDate("CREAT_DTM") != null)
            contactResult.setCreatedDate(maintainPartyContactUtil.convertUtilDateToGregoerianCalendar(rsRepData.getDate("CREAT_DTM")));
        contactResult.setCreatedByNm(rsRepData.getString("CREAT_BY_NM"));
        if (rsRepData.getDate("LAST_UPD_DTM") != null)
            contactResult.setUpdatedDate(maintainPartyContactUtil.convertUtilDateToGregoerianCalendar(rsRepData.getDate("LAST_UPD_DTM")));
        contactResult.setUpdatedByNm(rsRepData.getString("LAST_UPD_BY_NM"));

        return contactResult;
    }
}


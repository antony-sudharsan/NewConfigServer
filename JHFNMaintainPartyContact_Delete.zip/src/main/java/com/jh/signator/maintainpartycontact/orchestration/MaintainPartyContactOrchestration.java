package com.jh.signator.maintainpartycontact.orchestration;

import com.jh.common.logging.LoggerHandler;
import com.jh.signator.maintainpartycontact.bizrule.MaintainPartyContactBizRule;
import com.jh.signator.maintainpartycontact.dao.MaintainPartyContactDAO;
import com.jh.signator.maintainpartycontact.model.*;
import com.jh.signator.maintainpartycontact.util.MaintainPartyContactUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;


/**
 * Copyright (c) 2018, John Hancock and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 * <p>
 * Please contact John Hancock, 200 Berkley, Boston, MA 02116 USA
 * or visit https://www.johnhancock.com/legal.html if you need additional information or have any
 * questions.
 */


/**
 * This class consists exclusively methods to expose the methods as RestFull
 * webservices
 *
 * @author Antony Sudharsan Gnanaraj
 * @version %I%, %G%
 * @since 1.0
 */
@Component
public class MaintainPartyContactOrchestration {


    @Autowired
    private MaintainPartyContactUtil investmentRepUtil;

    @Autowired
    private MaintainPartyContactBizRule maintainPartyContactBizRule;

    @Autowired
    private MaintainPartyContactDAO maintainPartyContactDAO;

    /**
     * Method to get all the Party Contacts
     *
     * @param transactionId
     * @param sourceSystemName
     * @param readContactRequest
     * @return
     */
    public ReadContactReply getPartyContacts(String transactionId, String sourceSystemName, ReadContactRequest readContactRequest) {

        LoggerHandler.LogOut("INFO", "2", transactionId, sourceSystemName, this.getClass().getName(), readContactRequest.getCDCIDNo());

        ReadContactReply readContactReply = new ReadContactReply();
        List<ContactResult> contactResultList = null;

        if (maintainPartyContactBizRule.businessConditionReadTTELCMADDR(readContactRequest)) {
            LoggerHandler.LogOut("INFO", "2", transactionId, sourceSystemName, this.getClass().getName(), "Inside the first If loop");
            //  Invoke the getTTelcmAddr to get the Party Contact details
            contactResultList = (List<ContactResult>) maintainPartyContactDAO.getTTelcmAddr(transactionId, sourceSystemName, readContactRequest);
            LoggerHandler.LogOut("INFO", "2", transactionId, sourceSystemName, this.getClass().getName(), "Contact result size >>" + contactResultList.size());

        }

        if (maintainPartyContactBizRule.businessConditionReadTELECTRONIC(readContactRequest)) {
            //  Invoke the getTelectronicAddr to get the Party Contact details
            LoggerHandler.LogOut("INFO", "2", transactionId, sourceSystemName, this.getClass().getName(), "Inside the second If loop");
            contactResultList = (List<ContactResult>) maintainPartyContactDAO.getTelectronicAddr(transactionId, sourceSystemName, readContactRequest);
            LoggerHandler.LogOut("INFO", "2", transactionId, sourceSystemName, this.getClass().getName(), "contactResultList >>" + contactResultList.size());
        }

        readContactReply.setID(readContactRequest.getID());
        readContactReply.setIDRefType(readContactRequest.getIDRefType());

        readContactReply.setResult(contactResultList);

        LoggerHandler.LogOut("INFO", "4", transactionId, sourceSystemName, this.getClass().getName(), readContactReply.getResult().size() + "");
        return readContactReply;
    }

    /**
     * Method to search for the Party contacts
     *
     * @param transactionId
     * @param sourceSystemName
     * @param searchContactRequest
     * @return
     */

    public SearchContactReply searchPartyContact(String transactionId, String sourceSystemName, SearchContactRequest searchContactRequest) {

        SearchContactReply searchContactReply = new SearchContactReply();
        List<ContactResult> contactResultList = null;
        contactResultList = (List<ContactResult>) maintainPartyContactDAO.searchPartyContact(transactionId, sourceSystemName, searchContactRequest);
        searchContactReply.setResult(contactResultList);
        return searchContactReply;
    }

    /**
     * Method to create a Party Contact
     * @param applicationUserId
     * @param transactionId
     * @param sourceSystemName
     * @param createContactRequest
     * @return
     */
    public CreateContactReply createPartyContact(String applicationUserId, String transactionId, String sourceSystemName, CreateContactRequest createContactRequest) {

        CreateContactReply createContactReply = new CreateContactReply();
        List<ContactResult> contactResultList = null;

        int rowsUpdated = 0;

        if (maintainPartyContactBizRule.businessConditionTTELCMADDR(createContactRequest)) {
            // Insert into the TTELCM_ADDR table
            rowsUpdated = maintainPartyContactDAO.createPartyTTELCM_ADDRContact(applicationUserId, transactionId, sourceSystemName, createContactRequest);
            if (rowsUpdated > 0) {
                contactResultList = (List<ContactResult>) maintainPartyContactDAO.verifyTTELCM_ADDRInsert(transactionId, sourceSystemName, createContactRequest);
            }

        } else if (maintainPartyContactBizRule.businessConditionTELECTRONIC_ADDR(createContactRequest)) {
            // Insert into the TELECTRONIC_ADDR table
            rowsUpdated = maintainPartyContactDAO.createPartyTELECTRONIC_ADDRContact(applicationUserId, transactionId, sourceSystemName, createContactRequest);
            if (rowsUpdated > 0) {
                contactResultList = (List<ContactResult>) maintainPartyContactDAO.verifyTELECTRONIC_ADDRInsert(transactionId, sourceSystemName, createContactRequest);
            }
        }

        createContactReply.setResult(contactResultList);
        return createContactReply;
    }

    /**
     * Method to delete a Party Contact
     *
     * @param transactionId
     * @param sourceSystemName
     * @param deleteContactRequest
     * @return
     */
    public DeleteContactReply deletePartyContact(String applicationUserId, String transactionId, String sourceSystemName, DeleteContactRequest deleteContactRequest) {

        DeleteContactReply deleteContactReply = new DeleteContactReply();
        List<ContactResult> contactResultList = null;

        int rowsUpdated = 0;

        if (maintainPartyContactBizRule.businessConditionDeleteTTELCMADDR(deleteContactRequest)) {
            rowsUpdated = maintainPartyContactDAO.deletePartyTTELCM_ADDRContact(applicationUserId, transactionId, sourceSystemName, deleteContactRequest);
            if (rowsUpdated > 0) {
                contactResultList = (List<ContactResult>) maintainPartyContactDAO.verifyTTELCM_ADDRDelete(transactionId, sourceSystemName, deleteContactRequest);
            }
        } else if (maintainPartyContactBizRule.businessConditionDeleteTELECTRONIC(deleteContactRequest)) {
            rowsUpdated = maintainPartyContactDAO.deletePartyTELECTRONIC_ADDRContact(applicationUserId, transactionId, sourceSystemName, deleteContactRequest);
            if (rowsUpdated > 0) {
                contactResultList = (List<ContactResult>) maintainPartyContactDAO.verifyTELECTRONIC_ADDRDelete(transactionId, sourceSystemName, deleteContactRequest);
            }
        }

        deleteContactReply.setResult(contactResultList);
        return deleteContactReply;
    }


    /**
     * Method to update a Party Contact
     *
     * @param transactionId
     * @param sourceSystemName
     * @param updateContactRequest
     * @return
     */

    public UpdateContactReply updatePartyContact(String applicationUserId, String transactionId, String sourceSystemName, UpdateContactRequest updateContactRequest) {

        UpdateContactReply updateContactReply = new UpdateContactReply();
        List<ContactResult> contactResultList = null;
        int rowsUpdated = 0;

        if (maintainPartyContactBizRule.businessConditionUpdateTTELCMADDR(updateContactRequest)) {
            // Do the select

            contactResultList = (List<ContactResult>) maintainPartyContactDAO.selectTTELCM_ADDRUpdate(transactionId, sourceSystemName, updateContactRequest);
            // Invoke the Update
            rowsUpdated = maintainPartyContactDAO.updatePartyTTELCM_ADDRContact(applicationUserId, transactionId, sourceSystemName, updateContactRequest);
            // Do the select
            if (rowsUpdated > 0) {
                contactResultList = (List<ContactResult>) maintainPartyContactDAO.verifyTTELCM_ADDRUpdate(transactionId, sourceSystemName, updateContactRequest);
            }

        } else if (maintainPartyContactBizRule.businessConditionUpdateTELECTRONIC(updateContactRequest)) {
            // Do the select
            contactResultList = (List<ContactResult>) maintainPartyContactDAO.selectTELECTRONIC_ADDRUpdate(transactionId, sourceSystemName, updateContactRequest);

            // Invoke the Update
            rowsUpdated = maintainPartyContactDAO.updatePartyTELECTRONIC_ADDRContact(applicationUserId, transactionId, sourceSystemName, updateContactRequest);

            // Do the select
            if (rowsUpdated > 0) {
                contactResultList = (List<ContactResult>) maintainPartyContactDAO.verifyTELECTRONIC_ADDRUpdate(transactionId, sourceSystemName, updateContactRequest);
            }
        }
        contactResultList = (List<ContactResult>) maintainPartyContactDAO.updatePartyContact(transactionId, sourceSystemName, updateContactRequest);
        updateContactReply.setResult(contactResultList);
        return updateContactReply;
    }


}

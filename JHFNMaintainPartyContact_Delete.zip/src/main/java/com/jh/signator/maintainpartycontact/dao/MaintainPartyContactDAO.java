package com.jh.signator.maintainpartycontact.dao;

import com.jh.common.logging.LoggerHandler;
import com.jh.signator.maintainpartycontact.constants.MaintainPartyQueryConstants;
import com.jh.signator.maintainpartycontact.mapper.ContactResultTTelCMMapper;
import com.jh.signator.maintainpartycontact.mapper.ContactResultTelectronicAddrMapper;
import com.jh.signator.maintainpartycontact.model.*;
import com.jh.signator.maintainpartycontact.util.MaintainPartyContactUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.util.List;


/**
 * Copyright (c) 2018, John Hancock and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 * <p>
 * Please contact John Hancock, 200 Berkley, Boston, MA 02116 USA
 * or visit https://www.johnhancock.com/legal.html if you need additional information or have any
 * questions.
 */


/**
 * This class consists exclusively methods to expose the methods as RestFull
 * webservices
 *
 * @author Antony Sudharsan Gnanaraj
 * @version %I%, %G%
 * @since 1.0
 */
@Service
public class MaintainPartyContactDAO {

    @Autowired
    private JdbcTemplate jdbctemplate;
    @Value("${RequestTimeoutLimit}")
    private long RequestTimeoutLimit;
    @Autowired
    private MaintainPartyContactUtil contactUtil;

    /**
     * To retrive the Party Contact  from the TTELCM_ADDR table
     * @param transactionId
     * @param sourceSystemName
     * @param readContactRequest
     * @return
     */
    @SuppressWarnings("unchecked")
    public List<ContactResult> getTTelcmAddr(String transactionId, String sourceSystemName, ReadContactRequest readContactRequest) {
        List<ContactResult> contactResultList = null;


        LoggerHandler.LogOut("INFO", "3", transactionId, sourceSystemName, this.getClass().getName(), "  parameters: getContactIDNo >>" + readContactRequest.getContactIDNo() + "<<getID>>" + readContactRequest.getID());

        jdbctemplate.setQueryTimeout(1000);
        contactResultList = (List<ContactResult>) jdbctemplate.query(MaintainPartyQueryConstants.GET_TTELCM_ADDR, new Object[]{readContactRequest.getContactIDNo(), readContactRequest.getID()}, new ContactResultTTelCMMapper());

        LoggerHandler.LogOut("INFO", "4", transactionId, sourceSystemName, this.getClass().getName(), contactResultList.size() + "");
        return contactResultList;
    }

    /**
     * To retrive the Party Contact from the TELECTRONIC_ADDR table
     * @param transactionId
     * @param sourceSystemName
     * @param readContactRequest
     * @return
     */
    @SuppressWarnings("unchecked")
    public List<ContactResult> getTelectronicAddr(String transactionId, String sourceSystemName, ReadContactRequest readContactRequest) {
        List<ContactResult> contactResultList = null;

        jdbctemplate.setQueryTimeout(1000);
        LoggerHandler.LogOut("INFO", "3", transactionId, sourceSystemName, this.getClass().getName(), "parameters: getContactIDNo>" + readContactRequest.getContactIDNo() + "<getID>" + readContactRequest.getID() + "<getCDCIDNo>" + readContactRequest.getCDCIDNo());

        contactResultList = (List<ContactResult>) jdbctemplate.query(MaintainPartyQueryConstants.GET_TELECTRONIC_ADDR, new Object[]{readContactRequest.getContactIDNo(), readContactRequest.getID(), readContactRequest.getCDCIDNo()}, new ContactResultTelectronicAddrMapper());

        LoggerHandler.LogOut("INFO", "4", transactionId, sourceSystemName, this.getClass().getName(), contactResultList.size() + "");
        return contactResultList;
    }

    /**
     *  Method to create the Party contact
     * @param transactionId
     * @param sourceSystemName
     * @param createContactRequest
     * @return
     */
    public int createPartyTTELCM_ADDRContact(String applicationUserId, String transactionId, String sourceSystemName, CreateContactRequest createContactRequest) {
        int rowUpdated = 0;

        jdbctemplate.setQueryTimeout(1000);
        LoggerHandler.LogOut("INFO", "2", transactionId, sourceSystemName, this.getClass().getName(), "Representative Record, parameters" + createContactRequest.getCDCIDNo());

        rowUpdated = jdbctemplate.update(MaintainPartyQueryConstants.CREATE_TTELCM_ADDR,
                new Object[]{createContactRequest.getID(), createContactRequest.getContactEffDt(), createContactRequest.getContactEndDt(),
                        createContactRequest.getContactInfoTypCd(), contactUtil.getPhoneAreaCode(createContactRequest), contactUtil.getIntlPhoneAccessCode(createContactRequest), contactUtil.getPhoneExtCode(createContactRequest), contactUtil.getPhone(createContactRequest),
                        createContactRequest.getCDCIDNo(), applicationUserId, applicationUserId, contactUtil.getTelcmPerferredCode(createContactRequest), createContactRequest.getCDCIDNoBizFunc()
                });

        LoggerHandler.LogOut("INFO", "3", transactionId, sourceSystemName, this.getClass().getName(), "");
        return rowUpdated;
    }

    /**
     * @param applicationUserId
     * @param transactionId
     * @param sourceSystemName
     * @param createContactRequest
     * @return
     */
    public int createPartyTELECTRONIC_ADDRContact(String applicationUserId, String transactionId, String sourceSystemName, CreateContactRequest createContactRequest) {
        int rowUpdated = 0;
        jdbctemplate.setQueryTimeout(1000);
        LoggerHandler.LogOut("INFO", "2", transactionId, sourceSystemName, this.getClass().getName(), "Representative Record, parameters" + createContactRequest.getCDCIDNo());

        rowUpdated = jdbctemplate.update(MaintainPartyQueryConstants.CREATE_TELECTRONIC_ADDR,
                new Object[]{createContactRequest.getID(), createContactRequest.getContactInfoTypCd(),
                        createContactRequest.getContactInfo(), createContactRequest.getContactEffDt(), createContactRequest.getContactEndDt(),
                        createContactRequest.getCDCIDNo(), applicationUserId, applicationUserId, contactUtil.getTelcmPerferredCode(createContactRequest),
                        createContactRequest.getCDCIDNoBizFunc()
                });

        LoggerHandler.LogOut("INFO", "3", transactionId, sourceSystemName, this.getClass().getName(), "");
        return rowUpdated;
    }


    /**
     * Method to update the Party Contact
     * @param transactionId
     * @param sourceSystemName
     * @param updateContactRequest
     * @return
     */
    public List<ContactResult> updatePartyContact(String transactionId, String sourceSystemName, UpdateContactRequest updateContactRequest) {
        List<ContactResult> contactResultList = null;

        jdbctemplate.setQueryTimeout(1000);
        LoggerHandler.LogOut("INFO", "2", transactionId, sourceSystemName, this.getClass().getName(), "Representative Record, parameters" + updateContactRequest.getCDCIDNo());

        contactResultList = (List<ContactResult>) jdbctemplate.query("SELECT * FROM V_JHI_COM   WHERE REP_ID=? ",
                new Object[]{updateContactRequest.getCDCIDNo()}, new ContactResultTTelCMMapper());

        LoggerHandler.LogOut("INFO", "3", transactionId, sourceSystemName, this.getClass().getName(), "");
        return contactResultList;
    }

    /**
     * Method to search for an contanct from the database
     * @param transactionId
     * @param sourceSystemName
     * @param searchContactRequest
     * @return
     */
    public List<ContactResult> searchPartyContact(String transactionId, String sourceSystemName, SearchContactRequest searchContactRequest) {
        List<ContactResult> contactResultList = null;

        jdbctemplate.setQueryTimeout(1000);
        LoggerHandler.LogOut("INFO", "2", transactionId, sourceSystemName, this.getClass().getName(), "Representative Record, parameters" + searchContactRequest.getCDCIDNo());

        contactResultList = (List<ContactResult>) jdbctemplate.query("SELECT * FROM V_JHI_COM   WHERE REP_ID=? ",
                new Object[]{searchContactRequest.getCDCIDNo()}, new ContactResultTTelCMMapper());

        LoggerHandler.LogOut("INFO", "3", transactionId, sourceSystemName, this.getClass().getName(), "");
        return contactResultList;
    }


    /**
     * Method to delete the TTELCM contact
     * @param applicationUserId
     * @param transactionId
     * @param sourceSystemName
     * @param deleteContactRequest
     * @return
     */
    public int deletePartyTTELCM_ADDRContact(String applicationUserId, String transactionId, String sourceSystemName, DeleteContactRequest deleteContactRequest) {
        int rowUpdated = 0;
        jdbctemplate.setQueryTimeout(1000);
        LoggerHandler.LogOut("INFO", "2", transactionId, sourceSystemName, this.getClass().getName(), "parameters<TELCM_ADDR_END_DT>" + deleteContactRequest.getContactEndDt() + "<LAST_UPD_BY_NM>" + applicationUserId + "<TELCM_ADDR_ID_NO>" + deleteContactRequest.getContactIDNo() + "<PARTY_ID_NO>" + deleteContactRequest.getID());

        rowUpdated = jdbctemplate.update(MaintainPartyQueryConstants.DELETE_TTELCM_ADDR,
                new Object[]{deleteContactRequest.getContactEndDt(), applicationUserId, deleteContactRequest.getContactIDNo(), deleteContactRequest.getID()
                });

        LoggerHandler.LogOut("INFO", "3", transactionId, sourceSystemName, this.getClass().getName(), "");
        return rowUpdated;
    }

    /**
     * Method to delete the TELEECTRONIC Contact
     * @param applicationUserId
     * @param transactionId
     * @param sourceSystemName
     * @param deleteContactRequest
     * @return
     */
    public int deletePartyTELECTRONIC_ADDRContact(String applicationUserId, String transactionId, String sourceSystemName, DeleteContactRequest deleteContactRequest) {
        int rowUpdated = 0;
        jdbctemplate.setQueryTimeout(1000);

        LoggerHandler.LogOut("INFO", "2", transactionId, sourceSystemName, this.getClass().getName(), "parameters<ELCTR_ADDR_END_DT>" + deleteContactRequest.getContactEndDt() + "<LAST_UPD_BY_NM>" + applicationUserId + "<ELCTR_ADDR_ID_NO>" + deleteContactRequest.getContactIDNo() + "<PARTY_ID_NO>" + deleteContactRequest.getID());

        rowUpdated = jdbctemplate.update(MaintainPartyQueryConstants.DELETE_TELECTRONIC_ADDR,
                new Object[]{deleteContactRequest.getContactEndDt(), applicationUserId, deleteContactRequest.getContactIDNo(), deleteContactRequest.getID()
                });

        LoggerHandler.LogOut("INFO", "3", transactionId, sourceSystemName, this.getClass().getName(), "");
        return rowUpdated;
    }

    /**
     * @param transactionId
     * @param sourceSystemName
     * @param createContactRequest
     * @return
     */
    public List<ContactResult> verifyTELECTRONIC_ADDRInsert(String transactionId, String sourceSystemName, CreateContactRequest createContactRequest) {
        List<ContactResult> contactResultList = null;

        jdbctemplate.setQueryTimeout(1000);
        LoggerHandler.LogOut("INFO", "3", transactionId, sourceSystemName, this.getClass().getName(), "parameters: PARTY_ID_NO>" + createContactRequest.getID() + "<ELCTR_ADDR_NM>" + createContactRequest.getContactInfo() + "<TELCM_ADDR_EFF_DT>" + createContactRequest.getContactEffDt() + "<TELCM_TYP_CD>" + createContactRequest.getContactInfoTypCd() + "<CDC_ID_NO_PHNE_TYP>" + createContactRequest.getCDCIDNo() + "<CDC_ID_NO_BIZ_FUNC>" + createContactRequest.getCDCIDNoBizFunc());

        contactResultList = (List<ContactResult>) jdbctemplate.query(MaintainPartyQueryConstants.READ_TELECTRONIC_ADDR_INSERT, new Object[]{createContactRequest.getID(), createContactRequest.getContactInfo(), createContactRequest.getContactEffDt(), createContactRequest.getContactInfoTypCd(), createContactRequest.getCDCIDNo(), createContactRequest.getCDCIDNoBizFunc()}, new ContactResultTelectronicAddrMapper());

        LoggerHandler.LogOut("INFO", "4", transactionId, sourceSystemName, this.getClass().getName(), contactResultList.size() + "");
        return contactResultList;
    }

    /**
     * @param transactionId
     * @param sourceSystemName
     * @param createContactRequest
     * @return
     */
    public List<ContactResult> verifyTTELCM_ADDRInsert(String transactionId, String sourceSystemName, CreateContactRequest createContactRequest) {
        List<ContactResult> contactResultList = null;

        jdbctemplate.setQueryTimeout(1000);
        LoggerHandler.LogOut("INFO", "3", transactionId, sourceSystemName, this.getClass().getName(), "parameters: PARTY_ID_NO>" + createContactRequest.getID() + "<TELCM_ADDR_EFF_DT>" + createContactRequest.getContactEffDt() + "<TELCM_TYP_CD>" + createContactRequest.getContactInfoTypCd() + "<CDC_ID_NO_PHNE_TYP>" + createContactRequest.getCDCIDNo() + "<CDC_ID_NO_BIZ_FUNC>" + createContactRequest.getCDCIDNoBizFunc());

        contactResultList = (List<ContactResult>) jdbctemplate.query(MaintainPartyQueryConstants.READ_TTELCM_ADDR_INSERT, new Object[]{createContactRequest.getID(), createContactRequest.getContactEffDt(), createContactRequest.getContactInfoTypCd(), createContactRequest.getCDCIDNo(), createContactRequest.getCDCIDNoBizFunc()}, new ContactResultTelectronicAddrMapper());

        LoggerHandler.LogOut("INFO", "4", transactionId, sourceSystemName, this.getClass().getName(), contactResultList.size() + "");
        return contactResultList;
    }

    /**
     * Method to get the update value from TTELCM table
     *
     * @param transactionId
     * @param sourceSystemName
     * @param deleteContactRequest
     * @return
     */
    public List<ContactResult> verifyTTELCM_ADDRDelete(String transactionId, String sourceSystemName, DeleteContactRequest deleteContactRequest) {
        List<ContactResult> contactResultList = null;

        jdbctemplate.setQueryTimeout(1000);
        LoggerHandler.LogOut("INFO", "3", transactionId, sourceSystemName, this.getClass().getName(), "parameters: TELCM_ADDR_ID_NO>" + deleteContactRequest.getContactIDNo() + "<PARTY_ID_NO>" + deleteContactRequest.getID() + "<CDC_ID_NO_PHNE_TYP>" + deleteContactRequest.getCDCIDNo() + "<TELCM_ADDR_END_DT>" + deleteContactRequest.getContactEndDt());

        contactResultList = (List<ContactResult>) jdbctemplate.query(MaintainPartyQueryConstants.READ_TTELCM_ADDR_DELETE, new Object[]{deleteContactRequest.getContactIDNo(), deleteContactRequest.getID(), deleteContactRequest.getCDCIDNo(), deleteContactRequest.getContactEndDt()}, new ContactResultTelectronicAddrMapper());

        LoggerHandler.LogOut("INFO", "4", transactionId, sourceSystemName, this.getClass().getName(), contactResultList.size() + "");
        return contactResultList;
    }

    /**
     * Method to get the updated value from the TELECTRONIC table
     *
     * @param transactionId
     * @param sourceSystemName
     * @param deleteContactRequest
     * @return
     */
    public List<ContactResult> verifyTELECTRONIC_ADDRDelete(String transactionId, String sourceSystemName, DeleteContactRequest deleteContactRequest) {
        List<ContactResult> contactResultList = null;

        jdbctemplate.setQueryTimeout(1000);
        LoggerHandler.LogOut("INFO", "3", transactionId, sourceSystemName, this.getClass().getName(), "parameters: ELCTR_ADDR_ID_NO>" + deleteContactRequest.getContactIDNo() + "<PARTY_ID_NO>" + deleteContactRequest.getID() + "<CDC_ID_NO_ELCTR_TYP>" + deleteContactRequest.getCDCIDNo() + "<ELCTR_ADDR_END_DT>" + deleteContactRequest.getContactEndDt());

        contactResultList = (List<ContactResult>) jdbctemplate.query(MaintainPartyQueryConstants.READ_TELECTRONIC_ADDR_DELETE, new Object[]{deleteContactRequest.getContactIDNo(), deleteContactRequest.getID(), deleteContactRequest.getCDCIDNo(), deleteContactRequest.getContactEndDt()}, new ContactResultTelectronicAddrMapper());

        LoggerHandler.LogOut("INFO", "4", transactionId, sourceSystemName, this.getClass().getName(), contactResultList.size() + "");
        return contactResultList;
    }

    /**
     * Method to Update the Party contact
     *
     * @param transactionId
     * @param sourceSystemName
     * @param updateContactRequest
     * @return
     */
    public int updatePartyTTELCM_ADDRContact(String applicationUserId, String transactionId, String sourceSystemName, UpdateContactRequest updateContactRequest) {
        int rowUpdated = 0;

        jdbctemplate.setQueryTimeout(1000);
        LoggerHandler.LogOut("INFO", "2", transactionId, sourceSystemName, this.getClass().getName(), "Representative Record, parameters" + updateContactRequest.getCDCIDNo());

        rowUpdated = jdbctemplate.update(MaintainPartyQueryConstants.UPDATE_TTELCM,
                new Object[]{updateContactRequest.getContactEndDt(), updateContactRequest.getContactInfoTypCd(), updateContactRequest.getContactEffDt(),
                        updateContactRequest.getCDCIDNo(), contactUtil.getTelcmPerferredCode(updateContactRequest), contactUtil.getPhoneAreaCode(updateContactRequest), contactUtil.getPhone(updateContactRequest), contactUtil.getPhoneExtCode(updateContactRequest), contactUtil.getIntlPhoneAccessCode(updateContactRequest),
                        applicationUserId, updateContactRequest.getCDCIDNoBizFunc(), updateContactRequest.getContactIDNo(), updateContactRequest.getID()
                });

        LoggerHandler.LogOut("INFO", "3", transactionId, sourceSystemName, this.getClass().getName(), "");
        return rowUpdated;
    }

    /**
     * Method to update the Party Contact
     *
     * @param applicationUserId
     * @param transactionId
     * @param sourceSystemName
     * @param updateContactRequest
     * @return
     */
    public int updatePartyTELECTRONIC_ADDRContact(String applicationUserId, String transactionId, String sourceSystemName, UpdateContactRequest updateContactRequest) {
        int rowUpdated = 0;
        jdbctemplate.setQueryTimeout(1000);
        LoggerHandler.LogOut("INFO", "2", transactionId, sourceSystemName, this.getClass().getName(), "Representative Record, parameters" + updateContactRequest.getCDCIDNo());

        rowUpdated = jdbctemplate.update(MaintainPartyQueryConstants.UPDATE_TELECTRONIC,
                new Object[]{updateContactRequest.getContactEndDt(), updateContactRequest.getContactInfoTypCd(), updateContactRequest.getContactEffDt(), updateContactRequest.getContactPrefCd(), applicationUserId,
                        updateContactRequest.getCDCIDNoBizFunc(), updateContactRequest.getContactIDNo(), updateContactRequest.getID()
                });

        LoggerHandler.LogOut("INFO", "3", transactionId, sourceSystemName, this.getClass().getName(), "");
        return rowUpdated;
    }


    /**
     * @param transactionId
     * @param sourceSystemName
     * @param updateContactRequest
     * @return
     */
    public List<ContactResult> verifyTTELCM_ADDRUpdate(String transactionId, String sourceSystemName, UpdateContactRequest updateContactRequest) {
        List<ContactResult> contactResultList = null;

        jdbctemplate.setQueryTimeout(1000);
        LoggerHandler.LogOut("INFO", "3", transactionId, sourceSystemName, this.getClass().getName(), "parameters: ELCTR_ADDR_ID_NO>" + updateContactRequest.getContactIDNo() + "<PARTY_ID_NO>" + updateContactRequest.getID() + "<CDC_ID_NO_ELCTR_TYP>" + updateContactRequest.getCDCIDNo() + "<CDC_ID_NO_BIZ_FUNC>" + updateContactRequest.getCDCIDNoBizFunc());

        contactResultList = (List<ContactResult>) jdbctemplate.query(MaintainPartyQueryConstants.UPDATE_SELECT_TTELCM_2, new Object[]{updateContactRequest.getContactIDNo(), updateContactRequest.getID(), updateContactRequest.getCDCIDNo(), updateContactRequest.getCDCIDNoBizFunc()}, new ContactResultTelectronicAddrMapper());

        LoggerHandler.LogOut("INFO", "4", transactionId, sourceSystemName, this.getClass().getName(), contactResultList.size() + "");
        return contactResultList;
    }


    /**
     * @param transactionId
     * @param sourceSystemName
     * @param updateContactRequest
     * @return
     */
    public List<ContactResult> verifyTELECTRONIC_ADDRUpdate(String transactionId, String sourceSystemName, UpdateContactRequest updateContactRequest) {
        List<ContactResult> contactResultList = null;

        jdbctemplate.setQueryTimeout(1000);
        LoggerHandler.LogOut("INFO", "3", transactionId, sourceSystemName, this.getClass().getName(), "parameters: ELCTR_ADDR_ID_NO>" + updateContactRequest.getContactIDNo() + "<PARTY_ID_NO>" + updateContactRequest.getID() + "<CDC_ID_NO_ELCTR_TYP>" + updateContactRequest.getCDCIDNo() + "<CDC_ID_NO_BIZ_FUNC>" + updateContactRequest.getCDCIDNoBizFunc());

        contactResultList = (List<ContactResult>) jdbctemplate.query(MaintainPartyQueryConstants.UPDATE_SELECT_TELECTRONIC_2, new Object[]{updateContactRequest.getContactIDNo(), updateContactRequest.getID(), updateContactRequest.getCDCIDNo(), updateContactRequest.getCDCIDNoBizFunc()}, new ContactResultTelectronicAddrMapper());

        LoggerHandler.LogOut("INFO", "4", transactionId, sourceSystemName, this.getClass().getName(), contactResultList.size() + "");
        return contactResultList;
    }

    /**
     * @param transactionId
     * @param sourceSystemName
     * @param updateContactRequest
     * @return
     */
    public List<ContactResult> selectTTELCM_ADDRUpdate(String transactionId, String sourceSystemName, UpdateContactRequest updateContactRequest) {
        List<ContactResult> contactResultList = null;

        jdbctemplate.setQueryTimeout(1000);
        LoggerHandler.LogOut("INFO", "3", transactionId, sourceSystemName, this.getClass().getName(), "parameters: ELCTR_ADDR_ID_NO>" + updateContactRequest.getContactIDNo() + "<PARTY_ID_NO>" + updateContactRequest.getID());

        contactResultList = (List<ContactResult>) jdbctemplate.query(MaintainPartyQueryConstants.UPDATE_SELECT_TTELCM, new Object[]{updateContactRequest.getContactIDNo(), updateContactRequest.getID()}, new ContactResultTelectronicAddrMapper());

        LoggerHandler.LogOut("INFO", "4", transactionId, sourceSystemName, this.getClass().getName(), contactResultList.size() + "");
        return contactResultList;
    }


    /**
     * @param transactionId
     * @param sourceSystemName
     * @param updateContactRequest
     * @return
     */
    public List<ContactResult> selectTELECTRONIC_ADDRUpdate(String transactionId, String sourceSystemName, UpdateContactRequest updateContactRequest) {
        List<ContactResult> contactResultList = null;

        jdbctemplate.setQueryTimeout(1000);
        LoggerHandler.LogOut("INFO", "3", transactionId, sourceSystemName, this.getClass().getName(), "parameters: ELCTR_ADDR_ID_NO>" + updateContactRequest.getContactIDNo() + "<PARTY_ID_NO>" + updateContactRequest.getID());

        contactResultList = (List<ContactResult>) jdbctemplate.query(MaintainPartyQueryConstants.UPDATE_SELECT_TELECTRONIC, new Object[]{updateContactRequest.getContactIDNo(), updateContactRequest.getID()}, new ContactResultTelectronicAddrMapper());

        LoggerHandler.LogOut("INFO", "4", transactionId, sourceSystemName, this.getClass().getName(), contactResultList.size() + "");
        return contactResultList;
    }


}

package com.jh.signator.maintainpartycontact.controller;

import com.jh.signator.maintainpartycontact.constants.MaintainPartyConstants;
import com.jh.signator.maintainpartycontact.loggingexception.*;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

@ControllerAdvice
public class MaintainPartyContactException extends ResponseEntityExceptionHandler {

    @ExceptionHandler(NoContentException.class)
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public final ResponseEntity<Object> handleAllExceptions(Exception ex, WebRequest request) {
        ExceptionResponse exceptionResponse = new ExceptionResponse("204", MaintainPartyConstants.NO_CONTENT_FOUND, ex.getMessage());
        return new ResponseEntity(exceptionResponse, HttpStatus.NO_CONTENT);

    }

    // 408
    @ExceptionHandler(RequestTimeoutException.class)
    public final ResponseEntity<ExceptionResponse> handleException(RequestTimeoutException ex, WebRequest request) {

        ExceptionResponse exceptionResponse = new ExceptionResponse("408", MaintainPartyConstants.SQL_TIME_OUT, ex.getMessage());
        return new ResponseEntity(exceptionResponse, HttpStatus.REQUEST_TIMEOUT);
    }

    @ExceptionHandler(NotFoundException.class)
    @ResponseStatus(HttpStatus.NOT_FOUND)
    @ResponseBody
    public final ResponseEntity<Object> handleNotFoundException(NotFoundException ex, WebRequest request) {
        ExceptionResponse exceptionResponse = new ExceptionResponse("404", MaintainPartyConstants.NO_DATA_FOUND, ex.getMessage());
        return new ResponseEntity(exceptionResponse, HttpStatus.NOT_FOUND);
    }

    @ExceptionHandler(InvalidRequestException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ResponseBody
    public final ResponseEntity<Object> handleNotFoundException(InvalidRequestException ex, WebRequest request) {
        ExceptionResponse exceptionResponse = new ExceptionResponse("400", MaintainPartyConstants.INVALID_REQUEST, ex.getMessage());
        return new ResponseEntity(exceptionResponse, HttpStatus.BAD_REQUEST);
    }

    // 500
    @ExceptionHandler(SQLServerErrorException.class)
    public final ResponseEntity<Object> handleException(SQLServerErrorException ex, WebRequest request) {

        ExceptionResponse exceptionResponse = new ExceptionResponse("500", ex.getMessage(), ex.getDetails());
        return new ResponseEntity(exceptionResponse, HttpStatus.INTERNAL_SERVER_ERROR);
    }

    @Override
    protected ResponseEntity<Object> handleMethodArgumentNotValid(MethodArgumentNotValidException ex, HttpHeaders headers, HttpStatus status,
                                                                  WebRequest request) {
        ExceptionResponse exceptionResponse = new ExceptionResponse("400", MaintainPartyConstants.VALIDATION_FAILED, ex.getBindingResult().toString());
        return new ResponseEntity(exceptionResponse, HttpStatus.BAD_REQUEST);
    }

}

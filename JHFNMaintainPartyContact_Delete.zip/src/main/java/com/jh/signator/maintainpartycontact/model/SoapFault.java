
package com.jh.signator.maintainpartycontact.model;

import javax.xml.bind.annotation.*;


/**
 * <p>Java class for anonymous complex type.
 *
 * <p>The following schema fragment specifies the expected content contained within this class.
 *
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="Code" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="Reason" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="Detail" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
        "code",
        "reason",
        "detail"
})
@XmlRootElement(name = "SoapFault", namespace = "http://www.esb.manulife.com/JHFN/SoapFault.xsd")
public class SoapFault {

    @XmlElement(name = "Code", namespace = "http://www.esb.manulife.com/JHFN/SoapFault.xsd", required = true)
    protected String code;
    @XmlElement(name = "Reason", namespace = "http://www.esb.manulife.com/JHFN/SoapFault.xsd", required = true)
    protected String reason;
    @XmlElement(name = "Detail", namespace = "http://www.esb.manulife.com/JHFN/SoapFault.xsd", required = true)
    protected String detail;

    public SoapFault() {
    }

    public SoapFault(String code, String reason, String detail) {
        this.code = code;
        this.reason = reason;
        this.detail = detail;
    }

    /**
     * Gets the value of the code property.
     *
     * @return possible object is
     * {@link String }
     */
    public String getCode() {
        return code;
    }

    /**
     * Sets the value of the code property.
     *
     * @param value allowed object is
     *              {@link String }
     */
    public void setCode(String value) {
        this.code = value;
    }

    /**
     * Gets the value of the reason property.
     *
     * @return possible object is
     * {@link String }
     */
    public String getReason() {
        return reason;
    }

    /**
     * Sets the value of the reason property.
     *
     * @param value allowed object is
     *              {@link String }
     */
    public void setReason(String value) {
        this.reason = value;
    }

    /**
     * Gets the value of the detail property.
     *
     * @return possible object is
     * {@link String }
     */
    public String getDetail() {
        return detail;
    }

    /**
     * Sets the value of the detail property.
     *
     * @param value allowed object is
     *              {@link String }
     */
    public void setDetail(String value) {
        this.detail = value;
    }

}

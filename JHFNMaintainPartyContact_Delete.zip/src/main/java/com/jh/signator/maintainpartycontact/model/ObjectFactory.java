
package com.jh.signator.maintainpartycontact.model;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.datatype.XMLGregorianCalendar;
import javax.xml.namespace.QName;
import java.math.BigDecimal;


/**
 * This object contains factory methods for each
 * Java content interface and Java element interface
 * generated in the com.jh.signator.maintainpartycontact.model package.
 * <p>An ObjectFactory allows you to programatically
 * construct new instances of the Java representation
 * for XML content. The Java representation of XML
 * content can consist of schema derived interfaces
 * and classes representing the binding of schema
 * type definitions, element declarations and model
 * groups.  Factory methods for each of these are
 * provided in this class.
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _StatusCode_QNAME = new QName("http://www.esb.manulife.com/xsd/common/jh/header", "StatusCode");
    private final static QName _OriginalMessageDateTime_QNAME = new QName("http://www.esb.manulife.com/xsd/common/jh/header", "OriginalMessageDateTime");
    private final static QName _RelatesTo_QNAME = new QName("http://www.esb.manulife.com/xsd/common/jh/header", "RelatesTo");
    private final static QName _MessageSource_QNAME = new QName("http://www.esb.manulife.com/xsd/common/jh/header", "MessageSource");
    private final static QName _ServiceOperation_QNAME = new QName("http://www.esb.manulife.com/xsd/common/jh/header", "ServiceOperation");
    private final static QName _ApplicationUserID_QNAME = new QName("http://www.esb.manulife.com/xsd/common/jh/header", "ApplicationUserID");
    private final static QName _CurrentMessageDateTime_QNAME = new QName("http://www.esb.manulife.com/xsd/common/jh/header", "CurrentMessageDateTime");
    private final static QName _RequestTimeOut_QNAME = new QName("http://www.esb.manulife.com/xsd/common/jh/header", "RequestTimeOut");
    private final static QName _Status_QNAME = new QName("http://www.esb.manulife.com/xsd/common/jh/header", "Status");
    private final static QName _ApplicationName_QNAME = new QName("http://www.esb.manulife.com/xsd/common/jh/header", "ApplicationName");
    private final static QName _MessageUID_QNAME = new QName("http://www.esb.manulife.com/xsd/common/jh/header", "MessageUID");
    private final static QName _MessageType_QNAME = new QName("http://www.esb.manulife.com/xsd/common/jh/header", "MessageType");
    private final static QName _HostName_QNAME = new QName("http://www.esb.manulife.com/xsd/common/jh/header", "HostName");
    private final static QName _ConversationUID_QNAME = new QName("http://www.esb.manulife.com/xsd/common/jh/header", "ConversationUID");
    private final static QName _ServiceVersion_QNAME = new QName("http://www.esb.manulife.com/xsd/common/jh/header", "ServiceVersion");
    private final static QName _ProcessID_QNAME = new QName("http://www.esb.manulife.com/xsd/common/jh/header", "ProcessID");
    private final static QName _ServiceName_QNAME = new QName("http://www.esb.manulife.com/xsd/common/jh/header", "ServiceName");
    private final static QName _Version_QNAME = new QName("http://www.esb.manulife.com/xsd/common/jh/header", "Version");
    private final static QName _StatusDescription_QNAME = new QName("http://www.esb.manulife.com/xsd/common/jh/header", "StatusDescription");
    private final static QName _UserID_QNAME = new QName("http://www.esb.manulife.com/xsd/common/jh/header", "UserID");
    private final static QName _ServiceInfo_QNAME = new QName("http://www.esb.manulife.com/xsd/common/jh/header", "ServiceInfo");
    private final static QName _EnvironmentID_QNAME = new QName("http://www.esb.manulife.com/xsd/common/jh/header", "EnvironmentID");
    private final static QName _CreateContactRequestValidated_QNAME = new QName("http://www.esb.manulife.com/xsd/distribution/jhfn/maintainpartycontact", "Validated");
    private final static QName _CreateContactRequestContactEndDt_QNAME = new QName("http://www.esb.manulife.com/xsd/distribution/jhfn/maintainpartycontact", "ContactEndDt");
    private final static QName _UpdateContactRequestContactEffDt_QNAME = new QName("http://www.esb.manulife.com/xsd/distribution/jhfn/maintainpartycontact", "ContactEffDt");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.jh.signator.maintainpartycontact.model
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link ReadContactRequest }
     */
    public ReadContactRequest createReadContactRequest() {
        return new ReadContactRequest();
    }

    /**
     * Create an instance of {@link CreateContactRequest }
     */
    public CreateContactRequest createCreateContactRequest() {
        return new CreateContactRequest();
    }

    /**
     * Create an instance of {@link DeleteContactRequest }
     */
    public DeleteContactRequest createDeleteContactRequest() {
        return new DeleteContactRequest();
    }

    /**
     * Create an instance of {@link SearchContactRequest }
     */
    public SearchContactRequest createSearchContactRequest() {
        return new SearchContactRequest();
    }

    /**
     * Create an instance of {@link UpdateContactRequest }
     */
    public UpdateContactRequest createUpdateContactRequest() {
        return new UpdateContactRequest();
    }

    /**
     * Create an instance of {@link ContactResult }
     */
    public ContactResult createContactResult() {
        return new ContactResult();
    }

    /**
     * Create an instance of {@link ReadContactRequest.KeyedValue }
     */
    public ReadContactRequest.KeyedValue createReadContactRequestKeyedValue() {
        return new ReadContactRequest.KeyedValue();
    }

    /**
     * Create an instance of {@link CreateContactRequest.KeyedValue }
     */
    public CreateContactRequest.KeyedValue createCreateContactRequestKeyedValue() {
        return new CreateContactRequest.KeyedValue();
    }

    /**
     * Create an instance of {@link DeleteContactRequest.KeyedValue }
     */
    public DeleteContactRequest.KeyedValue createDeleteContactRequestKeyedValue() {
        return new DeleteContactRequest.KeyedValue();
    }

    /**
     * Create an instance of {@link SearchContactReply }
     */
    public SearchContactReply createSearchContactReply() {
        return new SearchContactReply();
    }

    /**
     * Create an instance of {@link SearchContactRequest.KeyedValue }
     */
    public SearchContactRequest.KeyedValue createSearchContactRequestKeyedValue() {
        return new SearchContactRequest.KeyedValue();
    }

    /**
     * Create an instance of {@link UpdateContactRequest.KeyedValue }
     */
    public UpdateContactRequest.KeyedValue createUpdateContactRequestKeyedValue() {
        return new UpdateContactRequest.KeyedValue();
    }

    /**
     * Create an instance of {@link ReadContactReply }
     */
    public ReadContactReply createReadContactReply() {
        return new ReadContactReply();
    }

    /**
     * Create an instance of {@link UpdateContactReply }
     */
    public UpdateContactReply createUpdateContactReply() {
        return new UpdateContactReply();
    }

    /**
     * Create an instance of {@link CreateContactReply }
     */
    public CreateContactReply createCreateContactReply() {
        return new CreateContactReply();
    }

    /**
     * Create an instance of {@link DeleteContactReply }
     */
    public DeleteContactReply createDeleteContactReply() {
        return new DeleteContactReply();
    }

    /**
     * Create an instance of {@link Status }
     */
    public Status createStatus() {
        return new Status();
    }

    /**
     * Create an instance of {@link MessageSource }
     */
    public MessageSource createMessageSource() {
        return new MessageSource();
    }

    /**
     * Create an instance of {@link ServiceInfo }
     */
    public ServiceInfo createServiceInfo() {
        return new ServiceInfo();
    }

    /**
     * Create an instance of {@link JHHeader }
     */
    public JHHeader createJHHeader() {
        return new JHHeader();
    }

    /**
     * Create an instance of {@link SoapFault }
     */
    public SoapFault createSoapFault() {
        return new SoapFault();
    }

    /**
     * Create an instance of {@link ContactResult.KeyedValue }
     */
    public ContactResult.KeyedValue createContactResultKeyedValue() {
        return new ContactResult.KeyedValue();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Long }{@code >}}
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/common/jh/header", name = "StatusCode")
    public JAXBElement<Long> createStatusCode(Long value) {
        return new JAXBElement<Long>(_StatusCode_QNAME, Long.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}}
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/common/jh/header", name = "OriginalMessageDateTime")
    public JAXBElement<XMLGregorianCalendar> createOriginalMessageDateTime(XMLGregorianCalendar value) {
        return new JAXBElement<XMLGregorianCalendar>(_OriginalMessageDateTime_QNAME, XMLGregorianCalendar.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/common/jh/header", name = "RelatesTo")
    public JAXBElement<String> createRelatesTo(String value) {
        return new JAXBElement<String>(_RelatesTo_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MessageSource }{@code >}}
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/common/jh/header", name = "MessageSource")
    public JAXBElement<MessageSource> createMessageSource(MessageSource value) {
        return new JAXBElement<MessageSource>(_MessageSource_QNAME, MessageSource.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/common/jh/header", name = "ServiceOperation")
    public JAXBElement<String> createServiceOperation(String value) {
        return new JAXBElement<String>(_ServiceOperation_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/common/jh/header", name = "ApplicationUserID")
    public JAXBElement<String> createApplicationUserID(String value) {
        return new JAXBElement<String>(_ApplicationUserID_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}}
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/common/jh/header", name = "CurrentMessageDateTime")
    public JAXBElement<XMLGregorianCalendar> createCurrentMessageDateTime(XMLGregorianCalendar value) {
        return new JAXBElement<XMLGregorianCalendar>(_CurrentMessageDateTime_QNAME, XMLGregorianCalendar.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}}
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/common/jh/header", name = "RequestTimeOut")
    public JAXBElement<BigDecimal> createRequestTimeOut(BigDecimal value) {
        return new JAXBElement<BigDecimal>(_RequestTimeOut_QNAME, BigDecimal.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Status }{@code >}}
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/common/jh/header", name = "Status")
    public JAXBElement<Status> createStatus(Status value) {
        return new JAXBElement<Status>(_Status_QNAME, Status.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/common/jh/header", name = "ApplicationName")
    public JAXBElement<String> createApplicationName(String value) {
        return new JAXBElement<String>(_ApplicationName_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/common/jh/header", name = "MessageUID")
    public JAXBElement<String> createMessageUID(String value) {
        return new JAXBElement<String>(_MessageUID_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/common/jh/header", name = "MessageType")
    public JAXBElement<String> createMessageType(String value) {
        return new JAXBElement<String>(_MessageType_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/common/jh/header", name = "HostName")
    public JAXBElement<String> createHostName(String value) {
        return new JAXBElement<String>(_HostName_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/common/jh/header", name = "ConversationUID")
    public JAXBElement<String> createConversationUID(String value) {
        return new JAXBElement<String>(_ConversationUID_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/common/jh/header", name = "ServiceVersion")
    public JAXBElement<String> createServiceVersion(String value) {
        return new JAXBElement<String>(_ServiceVersion_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/common/jh/header", name = "ProcessID")
    public JAXBElement<String> createProcessID(String value) {
        return new JAXBElement<String>(_ProcessID_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/common/jh/header", name = "ServiceName")
    public JAXBElement<String> createServiceName(String value) {
        return new JAXBElement<String>(_ServiceName_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/common/jh/header", name = "Version")
    public JAXBElement<String> createVersion(String value) {
        return new JAXBElement<String>(_Version_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/common/jh/header", name = "StatusDescription")
    public JAXBElement<String> createStatusDescription(String value) {
        return new JAXBElement<String>(_StatusDescription_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/common/jh/header", name = "UserID")
    public JAXBElement<String> createUserID(String value) {
        return new JAXBElement<String>(_UserID_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ServiceInfo }{@code >}}
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/common/jh/header", name = "ServiceInfo")
    public JAXBElement<ServiceInfo> createServiceInfo(ServiceInfo value) {
        return new JAXBElement<ServiceInfo>(_ServiceInfo_QNAME, ServiceInfo.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/common/jh/header", name = "EnvironmentID")
    public JAXBElement<String> createEnvironmentID(String value) {
        return new JAXBElement<String>(_EnvironmentID_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/distribution/jhfn/maintainpartycontact", name = "Validated", scope = CreateContactRequest.class)
    public JAXBElement<String> createCreateContactRequestValidated(String value) {
        return new JAXBElement<String>(_CreateContactRequestValidated_QNAME, String.class, CreateContactRequest.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}}
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/distribution/jhfn/maintainpartycontact", name = "ContactEndDt", scope = CreateContactRequest.class)
    public JAXBElement<XMLGregorianCalendar> createCreateContactRequestContactEndDt(XMLGregorianCalendar value) {
        return new JAXBElement<XMLGregorianCalendar>(_CreateContactRequestContactEndDt_QNAME, XMLGregorianCalendar.class, CreateContactRequest.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/distribution/jhfn/maintainpartycontact", name = "Validated", scope = UpdateContactRequest.class)
    public JAXBElement<String> createUpdateContactRequestValidated(String value) {
        return new JAXBElement<String>(_CreateContactRequestValidated_QNAME, String.class, UpdateContactRequest.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}}
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/distribution/jhfn/maintainpartycontact", name = "ContactEffDt", scope = UpdateContactRequest.class)
    public JAXBElement<XMLGregorianCalendar> createUpdateContactRequestContactEffDt(XMLGregorianCalendar value) {
        return new JAXBElement<XMLGregorianCalendar>(_UpdateContactRequestContactEffDt_QNAME, XMLGregorianCalendar.class, UpdateContactRequest.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}}
     */
    @XmlElementDecl(namespace = "http://www.esb.manulife.com/xsd/distribution/jhfn/maintainpartycontact", name = "ContactEndDt", scope = UpdateContactRequest.class)
    public JAXBElement<XMLGregorianCalendar> createUpdateContactRequestContactEndDt(XMLGregorianCalendar value) {
        return new JAXBElement<XMLGregorianCalendar>(_CreateContactRequestContactEndDt_QNAME, XMLGregorianCalendar.class, UpdateContactRequest.class, value);
    }

}

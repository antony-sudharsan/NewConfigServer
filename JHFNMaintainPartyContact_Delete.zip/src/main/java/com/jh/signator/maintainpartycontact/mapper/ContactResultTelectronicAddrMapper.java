package com.jh.signator.maintainpartycontact.mapper;

import com.jh.signator.maintainpartycontact.model.ContactResult;
import com.jh.signator.maintainpartycontact.util.MaintainPartyContactUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * @author deepain
 */
public class ContactResultTelectronicAddrMapper implements RowMapper {

    @Autowired
    MaintainPartyContactUtil maintainPartyContactUtil;

    @Override
    public Object mapRow(ResultSet rsRepData, int rowNum) throws SQLException {

        ContactResult contactResult = new ContactResult();
        contactResult.setCDCIDNo(rsRepData.getString(""));
        contactResult.setCDCIDNoBizFunc(rsRepData.getString(""));

        contactResult.setContactEffDt(maintainPartyContactUtil.convertUtilDateToGregoerianCalendar(rsRepData.getDate("")));

        contactResult.setContactEndDt(null);

        contactResult.setContactIDNo(rsRepData.getString(""));
        contactResult.setContactInfoTypCd(rsRepData.getString(""));
        contactResult.setCreatedByNm(rsRepData.getString(""));
        contactResult.setCreatedDate(null);
        contactResult.setContactInfo(rsRepData.getString(""));
        contactResult.setContactPrefCd(rsRepData.getString(""));
        contactResult.setUpdatedDate(null);
        contactResult.setPartyOfficeInd(rsRepData.getString(""));
        contactResult.setUpdatedByNm(rsRepData.getString(""));

        return contactResult;
    }


}


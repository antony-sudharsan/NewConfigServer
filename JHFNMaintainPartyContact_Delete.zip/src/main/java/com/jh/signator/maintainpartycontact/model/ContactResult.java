
package com.jh.signator.maintainpartycontact.model;

import javax.xml.bind.annotation.*;
import javax.xml.datatype.XMLGregorianCalendar;
import java.util.ArrayList;
import java.util.List;


/**
 * <p>Java class for ContactResult complex type.
 *
 * <p>The following schema fragment specifies the expected content contained within this class.
 *
 * <pre>
 * &lt;complexType name="ContactResult">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="PartyOfficeInd" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="CDCIDNo" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="CDCIDNoBizFunc" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="ContactIDNo" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="ContactInfo" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="ContactInfoTypCd" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="ContactPrefCd" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="ContactEffDt" type="{http://www.w3.org/2001/XMLSchema}dateTime"/>
 *         &lt;element name="ContactEndDt" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *         &lt;element name="KeyedValue" maxOccurs="unbounded" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="KeyName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                   &lt;element name="VendorCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                   &lt;element name="KeyValue" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="CreatedDate" type="{http://www.w3.org/2001/XMLSchema}dateTime"/>
 *         &lt;element name="CreatedByNm" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="UpdatedDate" type="{http://www.w3.org/2001/XMLSchema}dateTime"/>
 *         &lt;element name="UpdatedByNm" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ContactResult", propOrder = {
        "partyOfficeInd",
        "cdcidNo",
        "cdcidNoBizFunc",
        "contactIDNo",
        "contactInfo",
        "contactInfoTypCd",
        "contactPrefCd",
        "contactEffDt",
        "contactEndDt",
        "keyedValue",
        "createdDate",
        "createdByNm",
        "updatedDate",
        "updatedByNm"
})
public class ContactResult {

    @XmlElement(name = "PartyOfficeInd", required = true)
    protected String partyOfficeInd;
    @XmlElement(name = "CDCIDNo", required = true)
    protected String cdcidNo;
    @XmlElement(name = "CDCIDNoBizFunc", required = true)
    protected String cdcidNoBizFunc;
    @XmlElement(name = "ContactIDNo", required = true)
    protected String contactIDNo;
    @XmlElement(name = "ContactInfo", required = true)
    protected String contactInfo;
    @XmlElement(name = "ContactInfoTypCd", required = true)
    protected String contactInfoTypCd;
    @XmlElement(name = "ContactPrefCd", required = true)
    protected String contactPrefCd;
    @XmlElement(name = "ContactEffDt", required = true)
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar contactEffDt;
    @XmlElement(name = "ContactEndDt")
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar contactEndDt;
    @XmlElement(name = "KeyedValue")
    protected List<KeyedValue> keyedValue;
    @XmlElement(name = "CreatedDate", required = true)
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar createdDate;
    @XmlElement(name = "CreatedByNm", required = true)
    protected String createdByNm;
    @XmlElement(name = "UpdatedDate", required = true)
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar updatedDate;
    @XmlElement(name = "UpdatedByNm", required = true)
    protected String updatedByNm;

    /**
     * Gets the value of the partyOfficeInd property.
     *
     * @return possible object is
     * {@link String }
     */
    public String getPartyOfficeInd() {
        return partyOfficeInd;
    }

    /**
     * Sets the value of the partyOfficeInd property.
     *
     * @param value allowed object is
     *              {@link String }
     */
    public void setPartyOfficeInd(String value) {
        this.partyOfficeInd = value;
    }

    /**
     * Gets the value of the cdcidNo property.
     *
     * @return possible object is
     * {@link String }
     */
    public String getCDCIDNo() {
        return cdcidNo;
    }

    /**
     * Sets the value of the cdcidNo property.
     *
     * @param value allowed object is
     *              {@link String }
     */
    public void setCDCIDNo(String value) {
        this.cdcidNo = value;
    }

    /**
     * Gets the value of the cdcidNoBizFunc property.
     *
     * @return possible object is
     * {@link String }
     */
    public String getCDCIDNoBizFunc() {
        return cdcidNoBizFunc;
    }

    /**
     * Sets the value of the cdcidNoBizFunc property.
     *
     * @param value allowed object is
     *              {@link String }
     */
    public void setCDCIDNoBizFunc(String value) {
        this.cdcidNoBizFunc = value;
    }

    /**
     * Gets the value of the contactIDNo property.
     *
     * @return possible object is
     * {@link String }
     */
    public String getContactIDNo() {
        return contactIDNo;
    }

    /**
     * Sets the value of the contactIDNo property.
     *
     * @param value allowed object is
     *              {@link String }
     */
    public void setContactIDNo(String value) {
        this.contactIDNo = value;
    }

    /**
     * Gets the value of the contactInfo property.
     *
     * @return possible object is
     * {@link String }
     */
    public String getContactInfo() {
        return contactInfo;
    }

    /**
     * Sets the value of the contactInfo property.
     *
     * @param value allowed object is
     *              {@link String }
     */
    public void setContactInfo(String value) {
        this.contactInfo = value;
    }

    /**
     * Gets the value of the contactInfoTypCd property.
     *
     * @return possible object is
     * {@link String }
     */
    public String getContactInfoTypCd() {
        return contactInfoTypCd;
    }

    /**
     * Sets the value of the contactInfoTypCd property.
     *
     * @param value allowed object is
     *              {@link String }
     */
    public void setContactInfoTypCd(String value) {
        this.contactInfoTypCd = value;
    }

    /**
     * Gets the value of the contactPrefCd property.
     *
     * @return possible object is
     * {@link String }
     */
    public String getContactPrefCd() {
        return contactPrefCd;
    }

    /**
     * Sets the value of the contactPrefCd property.
     *
     * @param value allowed object is
     *              {@link String }
     */
    public void setContactPrefCd(String value) {
        this.contactPrefCd = value;
    }

    /**
     * Gets the value of the contactEffDt property.
     *
     * @return possible object is
     * {@link XMLGregorianCalendar }
     */
    public XMLGregorianCalendar getContactEffDt() {
        return contactEffDt;
    }

    /**
     * Sets the value of the contactEffDt property.
     *
     * @param value allowed object is
     *              {@link XMLGregorianCalendar }
     */
    public void setContactEffDt(XMLGregorianCalendar value) {
        this.contactEffDt = value;
    }

    /**
     * Gets the value of the contactEndDt property.
     *
     * @return possible object is
     * {@link XMLGregorianCalendar }
     */
    public XMLGregorianCalendar getContactEndDt() {
        return contactEndDt;
    }

    /**
     * Sets the value of the contactEndDt property.
     *
     * @param value allowed object is
     *              {@link XMLGregorianCalendar }
     */
    public void setContactEndDt(XMLGregorianCalendar value) {
        this.contactEndDt = value;
    }

    /**
     * Gets the value of the keyedValue property.
     * <p>
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the keyedValue property.
     * <p>
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getKeyedValue().add(newItem);
     * </pre>
     * <p>
     * <p>
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link KeyedValue }
     */
    public List<KeyedValue> getKeyedValue() {
        if (keyedValue == null) {
            keyedValue = new ArrayList<KeyedValue>();
        }
        return this.keyedValue;
    }

    public void setKeyedValue(List<KeyedValue> keyedValue) {
        this.keyedValue = keyedValue;
    }

    /**
     * Gets the value of the createdDate property.
     *
     * @return possible object is
     * {@link XMLGregorianCalendar }
     */
    public XMLGregorianCalendar getCreatedDate() {
        return createdDate;
    }

    /**
     * Sets the value of the createdDate property.
     *
     * @param value allowed object is
     *              {@link XMLGregorianCalendar }
     */
    public void setCreatedDate(XMLGregorianCalendar value) {
        this.createdDate = value;
    }

    /**
     * Gets the value of the createdByNm property.
     *
     * @return possible object is
     * {@link String }
     */
    public String getCreatedByNm() {
        return createdByNm;
    }

    /**
     * Sets the value of the createdByNm property.
     *
     * @param value allowed object is
     *              {@link String }
     */
    public void setCreatedByNm(String value) {
        this.createdByNm = value;
    }

    /**
     * Gets the value of the updatedDate property.
     *
     * @return possible object is
     * {@link XMLGregorianCalendar }
     */
    public XMLGregorianCalendar getUpdatedDate() {
        return updatedDate;
    }

    /**
     * Sets the value of the updatedDate property.
     *
     * @param value allowed object is
     *              {@link XMLGregorianCalendar }
     */
    public void setUpdatedDate(XMLGregorianCalendar value) {
        this.updatedDate = value;
    }

    /**
     * Gets the value of the updatedByNm property.
     *
     * @return possible object is
     * {@link String }
     */
    public String getUpdatedByNm() {
        return updatedByNm;
    }

    /**
     * Sets the value of the updatedByNm property.
     *
     * @param value allowed object is
     *              {@link String }
     */
    public void setUpdatedByNm(String value) {
        this.updatedByNm = value;
    }


    /**
     * <p>Java class for anonymous complex type.
     *
     * <p>The following schema fragment specifies the expected content contained within this class.
     *
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="KeyName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
     *         &lt;element name="VendorCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
     *         &lt;element name="KeyValue" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
            "keyName",
            "vendorCode",
            "keyValue"
    })
    public static class KeyedValue {

        @XmlElement(name = "KeyName")
        protected String keyName;
        @XmlElement(name = "VendorCode")
        protected String vendorCode;
        @XmlElement(name = "KeyValue")
        protected String keyValue;

        /**
         * Gets the value of the keyName property.
         *
         * @return possible object is
         * {@link String }
         */
        public String getKeyName() {
            return keyName;
        }

        /**
         * Sets the value of the keyName property.
         *
         * @param value allowed object is
         *              {@link String }
         */
        public void setKeyName(String value) {
            this.keyName = value;
        }

        /**
         * Gets the value of the vendorCode property.
         *
         * @return possible object is
         * {@link String }
         */
        public String getVendorCode() {
            return vendorCode;
        }

        /**
         * Sets the value of the vendorCode property.
         *
         * @param value allowed object is
         *              {@link String }
         */
        public void setVendorCode(String value) {
            this.vendorCode = value;
        }

        /**
         * Gets the value of the keyValue property.
         *
         * @return possible object is
         * {@link String }
         */
        public String getKeyValue() {
            return keyValue;
        }

        /**
         * Sets the value of the keyValue property.
         *
         * @param value allowed object is
         *              {@link String }
         */
        public void setKeyValue(String value) {
            this.keyValue = value;
        }

    }

}

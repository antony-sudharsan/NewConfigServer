
package com.jh.signator.maintainpartycontact.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for Status complex type.
 *
 * <p>The following schema fragment specifies the expected content contained within this class.
 *
 * <pre>
 * &lt;complexType name="Status">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/common/jh/header}StatusCode"/>
 *         &lt;element ref="{http://www.esb.manulife.com/xsd/common/jh/header}StatusDescription"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Status", namespace = "http://www.esb.manulife.com/xsd/common/jh/header", propOrder = {
        "statusCode",
        "statusDescription"
})
public class Status {

    @XmlElement(name = "StatusCode")
    protected long statusCode;
    @XmlElement(name = "StatusDescription", required = true)
    protected String statusDescription;

    /**
     * Indicates the status of the  request.
     */
    public long getStatusCode() {
        return statusCode;
    }

    /**
     * Sets the value of the statusCode property.
     */
    public void setStatusCode(long value) {
        this.statusCode = value;
    }

    /**
     * This element would carry meaningful description in case of partial and error status. The complete trace and info messages should be part of SOAPFAULT or application message payload with in SOAPBody.
     *
     * @return possible object is
     * {@link String }
     */
    public String getStatusDescription() {
        return statusDescription;
    }

    /**
     * Sets the value of the statusDescription property.
     *
     * @param value allowed object is
     *              {@link String }
     */
    public void setStatusDescription(String value) {
        this.statusDescription = value;
    }

}

package com.jh.signator.maintainpartycontact.controller;

import com.jh.common.logging.LoggerHandler;
import com.jh.signator.maintainpartycontact.model.*;
import com.jh.signator.maintainpartycontact.orchestration.MaintainPartyContactOrchestration;
import com.jh.signator.maintainpartycontact.util.MaintainPartyContactUtil;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

/**
 * This class consists exclusively methods to expose the methods as RestFull
 * webservices
 *
 * @author Antony Sudharsan Gnanaraj
 * @version %I%, %G%
 * @since 1.0
 */

@RestController
@EnableSwagger2
public class MaintainPartyContactController {

    HttpHeaders responseHeaders = new HttpHeaders();
    @Autowired
    private MaintainPartyContactOrchestration maintainPartyContactService;
    @Autowired
    private MaintainPartyContactUtil investmentRepUtil;

    @ApiOperation(httpMethod = "POST", value = "List Party Contact Details", notes = "Service is designed to retrieve Party Contact details", response = ReadContactReply.class)
    @ApiResponses(value = {@ApiResponse(code = 200, message = "Successfully retrieved list"),
            @ApiResponse(code = 401, message = "You are not authorized to view the resource"),
            @ApiResponse(code = 403, message = "Accessing the resource you were trying to reach is forbidden"),
            @ApiResponse(code = 404, message = "The resource you were trying to reach is not found")})

    @RequestMapping(path = "/jh/signator/partycontacts", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<ReadContactReply> getPartyContacts(@RequestHeader("MessageUUID") String transactionId,
                                                             @RequestHeader("SourceSystemName") String sourceSystemName, @RequestBody ReadContactRequest readContactRequest) throws ReadContactFault {
        ReadContactReply readContactReply = new ReadContactReply();

        LoggerHandler.LogOut("INFO", "1", transactionId, sourceSystemName, this.getClass().getName(), readContactRequest.getCDCIDNo());

        try {
            readContactReply = maintainPartyContactService.getPartyContacts(transactionId, sourceSystemName, readContactRequest);

        } catch (Exception e) {

            ReadContactFault readContactFault = new ReadContactFault("", new SoapFault("", "", ""), e);
            LoggerHandler.ErrorOut(e, transactionId, sourceSystemName, this.getClass().getName(), readContactRequest.getCDCIDNo());
            throw readContactFault;
        }
        LoggerHandler.LogOut("INFO", "5", transactionId, sourceSystemName, this.getClass().getName(), readContactRequest.getCDCIDNo());
        return ResponseEntity.ok().headers(responseHeaders).body(readContactReply);
    }


    @ApiOperation(httpMethod = "POST", value = "Search Party Contact", notes = "Service is designed to search for an contact", response = SearchContactReply.class)
    @ApiResponses(value = {@ApiResponse(code = 200, message = "Successfully retrieved list"),
            @ApiResponse(code = 401, message = "You are not authorized to view the resource"),
            @ApiResponse(code = 403, message = "Accessing the resource you were trying to reach is forbidden"),
            @ApiResponse(code = 404, message = "The resource you were trying to reach is not found")})

    @RequestMapping(path = "/jh/signator/searchpartycontacts", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<SearchContactReply> searchPartyContact(@RequestHeader("MessageUUID") String transactionId,
                                                                 @RequestHeader("SourceSystemName") String sourceSystemName, @RequestBody SearchContactRequest searchContactRequest) throws Exception {
        SearchContactReply searchContactReply = new SearchContactReply();

        LoggerHandler.LogOut("INFO", "1", transactionId, sourceSystemName, this.getClass().getName(), searchContactRequest.getCDCIDNo());

        try {
            searchContactReply = maintainPartyContactService.searchPartyContact(transactionId, sourceSystemName, searchContactRequest);

        } catch (Exception e) {
            LoggerHandler.ErrorOut(e, transactionId, sourceSystemName, this.getClass().getName(), searchContactRequest.getCDCIDNo());
            throw e;
        }

        return ResponseEntity.ok().headers(responseHeaders).body(searchContactReply);
    }

    @ApiOperation(httpMethod = "POST", value = "Create Party Contact", notes = "Service is designed to create a party contact", response = CreateContactReply.class)
    @ApiResponses(value = {@ApiResponse(code = 200, message = "Successfully retrieved list"),
            @ApiResponse(code = 401, message = "You are not authorized to view the resource"),
            @ApiResponse(code = 403, message = "Accessing the resource you were trying to reach is forbidden"),
            @ApiResponse(code = 404, message = "The resource you were trying to reach is not found")})

    @RequestMapping(path = "/jh/signator/createpartycontact", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<CreateContactReply> createPartyContact(@RequestHeader("ApplicationUserId") String applicationUserId, @RequestHeader("MessageUUID") String transactionId,
                                                                 @RequestHeader("SourceSystemName") String sourceSystemName, @RequestBody CreateContactRequest createContactRequest) throws Exception {
        CreateContactReply createContactReply = new CreateContactReply();

        LoggerHandler.LogOut("INFO", "1", transactionId, sourceSystemName, this.getClass().getName(), createContactRequest.getCDCIDNo());

        try {
            createContactReply = maintainPartyContactService.createPartyContact(applicationUserId, transactionId, sourceSystemName, createContactRequest);

        } catch (Exception e) {
            LoggerHandler.ErrorOut(e, transactionId, sourceSystemName, this.getClass().getName(), createContactRequest.getCDCIDNo());
            throw e;
        }
        return ResponseEntity.ok().headers(responseHeaders).body(createContactReply);
    }

    @ApiOperation(httpMethod = "POST", value = "Update Party Contact", notes = "Service is designed to update an party contact", response = UpdateContactReply.class)
    @ApiResponses(value = {@ApiResponse(code = 200, message = "Successfully retrieved list"),
            @ApiResponse(code = 401, message = "You are not authorized to view the resource"),
            @ApiResponse(code = 403, message = "Accessing the resource you were trying to reach is forbidden"),
            @ApiResponse(code = 404, message = "The resource you were trying to reach is not found")})

    @RequestMapping(path = "/jh/signator/updatepartycontact", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<UpdateContactReply> updatePartyContact(@RequestHeader("ApplicationUserId") String applicationUserId, @RequestHeader("MessageUUID") String transactionId,
                                                                 @RequestHeader("SourceSystemName") String sourceSystemName, @RequestBody UpdateContactRequest updateContactRequest) throws Exception {
        UpdateContactReply updateContactReply = new UpdateContactReply();

        LoggerHandler.LogOut("INFO", "1", transactionId, sourceSystemName, this.getClass().getName(), updateContactRequest.getCDCIDNo());

        try {
            updateContactReply = maintainPartyContactService.updatePartyContact(applicationUserId, transactionId, sourceSystemName, updateContactRequest);

        } catch (Exception e) {
            LoggerHandler.ErrorOut(e, transactionId, sourceSystemName, this.getClass().getName(), updateContactRequest.getCDCIDNo());
            throw e;
        }
        return ResponseEntity.ok().headers(responseHeaders).body(updateContactReply);
    }


    @ApiOperation(httpMethod = "POST", value = "Delete Party Contact", notes = "Service is designed to delete a party contact", response = DeleteContactReply.class)
    @ApiResponses(value = {@ApiResponse(code = 200, message = "Successfully retrieved list"),
            @ApiResponse(code = 401, message = "You are not authorized to view the resource"),
            @ApiResponse(code = 403, message = "Accessing the resource you were trying to reach is forbidden"),
            @ApiResponse(code = 404, message = "The resource you were trying to reach is not found")})

    @RequestMapping(path = "/jh/signator/deletepartycontact", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<DeleteContactReply> deletePartyContact(@RequestHeader("ApplicationUserId") String applicationUserId, @RequestHeader("MessageUUID") String transactionId,
                                                                 @RequestHeader("SourceSystemName") String sourceSystemName, @RequestBody DeleteContactRequest deleteContactRequest) throws Exception {
        DeleteContactReply deleteContactReply = new DeleteContactReply();

        LoggerHandler.LogOut("INFO", "1", transactionId, sourceSystemName, this.getClass().getName(), deleteContactRequest.getCDCIDNo());

        try {
            deleteContactReply = maintainPartyContactService.deletePartyContact(applicationUserId, transactionId, sourceSystemName, deleteContactRequest);

        } catch (Exception e) {
            LoggerHandler.ErrorOut(e, transactionId, sourceSystemName, this.getClass().getName(), deleteContactRequest.getCDCIDNo());
            throw e;
        }

        return ResponseEntity.ok().headers(responseHeaders).body(deleteContactReply);
    }

}

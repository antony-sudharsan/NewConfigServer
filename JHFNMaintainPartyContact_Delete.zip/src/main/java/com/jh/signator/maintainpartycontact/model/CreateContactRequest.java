
package com.jh.signator.maintainpartycontact.model;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.*;
import javax.xml.datatype.XMLGregorianCalendar;
import java.util.ArrayList;
import java.util.List;


/**
 * <p>Java class for anonymous complex type.
 *
 * <p>The following schema fragment specifies the expected content contained within this class.
 *
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="ID" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="IDRefType" type="{http://www.esb.manulife.com/xsd/distribution/jhfn/maintainpartycontact}OLI_LU_IDREFTYPE"/>
 *         &lt;element name="PartyOfficeInd" type="{http://www.esb.manulife.com/xsd/distribution/jhfn/maintainpartycontact}PARTY_OFFICE_IND" minOccurs="0"/>
 *         &lt;element name="CDCIDNo" type="{http://www.esb.manulife.com/xsd/distribution/jhfn/maintainpartycontact}ASSIGNMENT_CODE"/>
 *         &lt;element name="CDCIDNoBizFunc" type="{http://www.esb.manulife.com/xsd/distribution/jhfn/maintainpartycontact}BIZ_FUNC_CODE"/>
 *         &lt;element name="ContactInfo" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="ContactInfoTypCd" type="{http://www.esb.manulife.com/xsd/distribution/jhfn/maintainpartycontact}CONTACT_INFO_CODE"/>
 *         &lt;element name="ContactPrefCd" type="{http://www.esb.manulife.com/xsd/distribution/jhfn/maintainpartycontact}CONTACT_PREF_CODE" minOccurs="0"/>
 *         &lt;element name="ContactEffDt" type="{http://www.w3.org/2001/XMLSchema}dateTime"/>
 *         &lt;element name="ContactEndDt" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *         &lt;element name="Validated" type="{http://www.esb.manulife.com/xsd/distribution/jhfn/maintainpartycontact}OLI_LU_BOOLEAN" minOccurs="0"/>
 *         &lt;element name="KeyedValue" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="KeyName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                   &lt;element name="VendorCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                   &lt;element name="KeyValue" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0"/>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
        "id",
        "idRefType",
        "partyOfficeInd",
        "cdcidNo",
        "cdcidNoBizFunc",
        "contactInfo",
        "contactInfoTypCd",
        "contactPrefCd",
        "contactEffDt",
        "contactEndDt",
        "validated",
        "keyedValue"
})
@XmlRootElement(name = "CreateContact_request")
public class CreateContactRequest {

    @XmlElement(name = "ID", required = true)
    protected String id;
    @XmlElement(name = "IDRefType", required = true)
    protected String idRefType;
    @XmlElement(name = "PartyOfficeInd")
    protected String partyOfficeInd;
    @XmlElement(name = "CDCIDNo", required = true)
    protected String cdcidNo;
    @XmlElement(name = "CDCIDNoBizFunc", required = true)
    protected String cdcidNoBizFunc;
    @XmlElement(name = "ContactInfo", required = true)
    protected String contactInfo;
    @XmlElement(name = "ContactInfoTypCd", required = true)
    @XmlSchemaType(name = "string")
    protected CONTACTINFOCODE contactInfoTypCd;
    @XmlElement(name = "ContactPrefCd")
    protected String contactPrefCd;
    @XmlElement(name = "ContactEffDt", required = true)
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar contactEffDt;
    @XmlElementRef(name = "ContactEndDt", namespace = "http://www.esb.manulife.com/xsd/distribution/jhfn/maintainpartycontact", type = JAXBElement.class, required = false)
    protected JAXBElement<XMLGregorianCalendar> contactEndDt;
    @XmlElementRef(name = "Validated", namespace = "http://www.esb.manulife.com/xsd/distribution/jhfn/maintainpartycontact", type = JAXBElement.class, required = false)
    protected JAXBElement<String> validated;
    @XmlElement(name = "KeyedValue")
    protected KeyedValue keyedValue;

    /**
     * Gets the value of the id property.
     *
     * @return possible object is
     * {@link String }
     */
    public String getID() {
        return id;
    }

    /**
     * Sets the value of the id property.
     *
     * @param value allowed object is
     *              {@link String }
     */
    public void setID(String value) {
        this.id = value;
    }

    /**
     * Gets the value of the idRefType property.
     *
     * @return possible object is
     * {@link String }
     */
    public String getIDRefType() {
        return idRefType;
    }

    /**
     * Sets the value of the idRefType property.
     *
     * @param value allowed object is
     *              {@link String }
     */
    public void setIDRefType(String value) {
        this.idRefType = value;
    }

    /**
     * Gets the value of the partyOfficeInd property.
     *
     * @return possible object is
     * {@link String }
     */
    public String getPartyOfficeInd() {
        return partyOfficeInd;
    }

    /**
     * Sets the value of the partyOfficeInd property.
     *
     * @param value allowed object is
     *              {@link String }
     */
    public void setPartyOfficeInd(String value) {
        this.partyOfficeInd = value;
    }

    /**
     * Gets the value of the cdcidNo property.
     *
     * @return possible object is
     * {@link String }
     */
    public String getCDCIDNo() {
        return cdcidNo;
    }

    /**
     * Sets the value of the cdcidNo property.
     *
     * @param value allowed object is
     *              {@link String }
     */
    public void setCDCIDNo(String value) {
        this.cdcidNo = value;
    }

    /**
     * Gets the value of the cdcidNoBizFunc property.
     *
     * @return possible object is
     * {@link String }
     */
    public String getCDCIDNoBizFunc() {
        return cdcidNoBizFunc;
    }

    /**
     * Sets the value of the cdcidNoBizFunc property.
     *
     * @param value allowed object is
     *              {@link String }
     */
    public void setCDCIDNoBizFunc(String value) {
        this.cdcidNoBizFunc = value;
    }

    /**
     * Gets the value of the contactInfo property.
     *
     * @return possible object is
     * {@link String }
     */
    public String getContactInfo() {
        return contactInfo;
    }

    /**
     * Sets the value of the contactInfo property.
     *
     * @param value allowed object is
     *              {@link String }
     */
    public void setContactInfo(String value) {
        this.contactInfo = value;
    }

    /**
     * Gets the value of the contactInfoTypCd property.
     *
     * @return possible object is
     * {@link CONTACTINFOCODE }
     */
    public CONTACTINFOCODE getContactInfoTypCd() {
        return contactInfoTypCd;
    }

    /**
     * Sets the value of the contactInfoTypCd property.
     *
     * @param value allowed object is
     *              {@link CONTACTINFOCODE }
     */
    public void setContactInfoTypCd(CONTACTINFOCODE value) {
        this.contactInfoTypCd = value;
    }

    /**
     * Gets the value of the contactPrefCd property.
     *
     * @return possible object is
     * {@link String }
     */
    public String getContactPrefCd() {
        return contactPrefCd;
    }

    /**
     * Sets the value of the contactPrefCd property.
     *
     * @param value allowed object is
     *              {@link String }
     */
    public void setContactPrefCd(String value) {
        this.contactPrefCd = value;
    }

    /**
     * Gets the value of the contactEffDt property.
     *
     * @return possible object is
     * {@link XMLGregorianCalendar }
     */
    public XMLGregorianCalendar getContactEffDt() {
        return contactEffDt;
    }

    /**
     * Sets the value of the contactEffDt property.
     *
     * @param value allowed object is
     *              {@link XMLGregorianCalendar }
     */
    public void setContactEffDt(XMLGregorianCalendar value) {
        this.contactEffDt = value;
    }

    /**
     * Gets the value of the contactEndDt property.
     *
     * @return possible object is
     * {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}
     */
    public JAXBElement<XMLGregorianCalendar> getContactEndDt() {
        return contactEndDt;
    }

    /**
     * Sets the value of the contactEndDt property.
     *
     * @param value allowed object is
     *              {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}
     */
    public void setContactEndDt(JAXBElement<XMLGregorianCalendar> value) {
        this.contactEndDt = value;
    }

    /**
     * Gets the value of the validated property.
     *
     * @return possible object is
     * {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    public JAXBElement<String> getValidated() {
        return validated;
    }

    /**
     * Sets the value of the validated property.
     *
     * @param value allowed object is
     *              {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    public void setValidated(JAXBElement<String> value) {
        this.validated = value;
    }

    /**
     * Gets the value of the keyedValue property.
     *
     * @return possible object is
     * {@link KeyedValue }
     */
    public KeyedValue getKeyedValue() {
        return keyedValue;
    }

    /**
     * Sets the value of the keyedValue property.
     *
     * @param value allowed object is
     *              {@link KeyedValue }
     */
    public void setKeyedValue(KeyedValue value) {
        this.keyedValue = value;
    }


    /**
     * <p>Java class for anonymous complex type.
     *
     * <p>The following schema fragment specifies the expected content contained within this class.
     *
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="KeyName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
     *         &lt;element name="VendorCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
     *         &lt;element name="KeyValue" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0"/>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
            "keyName",
            "vendorCode",
            "keyValue"
    })
    public static class KeyedValue {

        @XmlElement(name = "KeyName")
        protected String keyName;
        @XmlElement(name = "VendorCode")
        protected String vendorCode;
        @XmlElement(name = "KeyValue")
        protected List<String> keyValue;

        /**
         * Gets the value of the keyName property.
         *
         * @return possible object is
         * {@link String }
         */
        public String getKeyName() {
            return keyName;
        }

        /**
         * Sets the value of the keyName property.
         *
         * @param value allowed object is
         *              {@link String }
         */
        public void setKeyName(String value) {
            this.keyName = value;
        }

        /**
         * Gets the value of the vendorCode property.
         *
         * @return possible object is
         * {@link String }
         */
        public String getVendorCode() {
            return vendorCode;
        }

        /**
         * Sets the value of the vendorCode property.
         *
         * @param value allowed object is
         *              {@link String }
         */
        public void setVendorCode(String value) {
            this.vendorCode = value;
        }

        /**
         * Gets the value of the keyValue property.
         * <p>
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the keyValue property.
         * <p>
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getKeyValue().add(newItem);
         * </pre>
         * <p>
         * <p>
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link String }
         */
        public List<String> getKeyValue() {
            if (keyValue == null) {
                keyValue = new ArrayList<String>();
            }
            return this.keyValue;
        }

    }

}

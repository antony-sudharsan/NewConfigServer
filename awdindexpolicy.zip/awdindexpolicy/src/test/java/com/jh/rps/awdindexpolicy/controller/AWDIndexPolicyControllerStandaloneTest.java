package com.jh.rps.awdindexpolicy.controller;

import com.jh.rps.awdindexpolicy.exception.GlobalExceptionHandler;
import com.jh.rps.awdindexpolicy.model.PolicyData;
import com.jh.rps.awdindexpolicy.service.AWDIndexPolicyService;
import com.jh.rps.awdindexpolicy.utils.LogUtils;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.result.MockMvcResultHandlers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import java.util.ArrayList;
import java.util.List;

import static org.hamcrest.CoreMatchers.is;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@RunWith(SpringRunner.class)
/**
 * @WebMvcTest.
 * It will auto-configure the Spring MVC infrastructure for our unit tests.
 * Setting up WebMvc Context for the Controller which is under test("AWDIndexPolicyController")
 */
public class AWDIndexPolicyControllerStandaloneTest {

    /**
     * Initializing MockMvc
     */
    private MockMvc mvc;

    @Mock
    private AWDIndexPolicyService policyService;

    @Mock
    private LogUtils logUtils;

    @InjectMocks
    private AWDIndexPolicyController controller;

    private List<PolicyData> policyDataList = new ArrayList<PolicyData>();
    /**
     * @Before
     * Method will be called before each test case execution
     */
    @Before
    public void setup(){
        // MockMvc standalone approach
        mvc = MockMvcBuilders.standaloneSetup(controller)
                .setControllerAdvice(new GlobalExceptionHandler())
                .build();
        policyDataList = new ArrayList<PolicyData>();
        PolicyData policyData = new PolicyData();
        policyData.setAgentBrokerDealerId("121");
        policyData.setAgentBrokerDealerName("Asd");
        policyData.setAgentCustomBrokerCode(true);
        policyData.setAgentFirstName("ANBC");
        policyData.setAgentLastName("LASTNAME");
        policyDataList.add(policyData);
    }

    @Test
    public void getAWDIndexPolicyTestUsingJSONPath() throws Exception{
        when(policyService.getAWDIndexPolicy("1234")).thenReturn(policyDataList);
        mvc.perform(get("/jh/wealth/ann/awdindex/policy?policyNo=1234"))
                .andDo(MockMvcResultHandlers.print())
        		.andExpect(status().isOk())
                .andExpect(jsonPath("$[0].agentBrokerDealerId", is("121")))
                .andExpect(jsonPath("$[0].agentBrokerDealerName", is("Asd")))
                .andExpect(jsonPath("$[0].agentCustomBrokerCode", is(true)))
                .andExpect(jsonPath("$[0].agentFirstName", is("ANBC")))
                .andExpect(jsonPath("$[0].agentLastName", is("LASTNAME")));
    }

    @Test
    public void getAWDIndexPolicyTestUsingJSONasString() throws Exception{
        when(policyService.getAWDIndexPolicy("1234")).thenReturn(policyDataList);
        mvc.perform(get("/jh/wealth/ann/awdindex/policy?policyNo=1234"))
                .andDo(MockMvcResultHandlers.print())
                .andExpect(status().isOk())
                .andExpect(content().json("[{\"lob\":null,\"fixedVarCode\":null,\"reInstrtyInd\":null,\"ownerCompanyIndivCode\":null,\"ownerFirstName\":null,\"ownerLastName\":null,\"ownerCompanyname\":null,\"ownerSSN\":null,\"annuitantFirstName\":null,\"annuitantLastName\":null,\"annuitantSSN\":null,\"brokerCount\":null,\"agentId\":null,\"agentBrokerDealerId\":\"121\",\"agentBrokerDealerName\":\"Asd\",\"agentCustomBrokerCode\":true,\"agentFirstName\":\"ANBC\",\"agentLastName\":\"LASTNAME\",\"agentTaxId\":null,\"agentPhoneNo\":null,\"repAgentid\":null,\"repBrokerDealerId\":null,\"repBrokerdealerName\":null,\"repCustombrokerCode\":false,\"repAgentFirstName\":null,\"repAgentLastName\":null,\"repAgentTaxId\":null,\"repAgentPhoneNo\":null}]"));
    }

    @Test
    public void policyNotFoundTest() throws Exception {
        mvc.perform(get("/jh/wealth/ann/awdindex/policy?policyNo=1111"))
                .andDo(MockMvcResultHandlers.print())
                .andExpect(status().isNotFound());
    }

    @After
    public void teardown(){
        policyDataList = new ArrayList<PolicyData>();
    }

}
package com.jh.rps.awdindexpolicy.controller;

import com.jh.rps.awdindexpolicy.model.PolicyData;
import com.jh.rps.awdindexpolicy.service.AWDIndexPolicyService;
import com.jh.rps.awdindexpolicy.utils.LogUtils;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;

import java.util.ArrayList;
import java.util.List;

import static org.hamcrest.CoreMatchers.is;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@RunWith(SpringRunner.class)
/**
 * @WebMvcTest.
 * It will auto-configure the Spring MVC infrastructure for our unit tests.
 * Setting up WebMvc Context for the Controller which is under test("AWDIndexPolicyController")
 */
@WebMvcTest(AWDIndexPolicyController.class)
public class AWDIndexPolicyControllerTest {

    /**
     * Initializing MockMvc
     */
    @Autowired
    private MockMvc mvc;

    @MockBean
    private LogUtils log;

    /**
     * @MockBean
     * The class is included in the spring-boot-test library.
     * It allows to add Mockito mocks in a Spring ApplicationContext.
     * If a bean, compatible with the declared class exists in the context, it replaces it by the mock.
     * If it is not the case, it adds the mock in the context as a bean.
     */
    @MockBean
    private AWDIndexPolicyService policyService;

    private List<PolicyData> policyDataList = new ArrayList<PolicyData>();
    /**
     * @Before
     * Method will be called before each test case execution
     */
    @Before
    public void setup(){
        policyDataList = new ArrayList<PolicyData>();
        PolicyData policyData = new PolicyData();
        policyData.setAgentBrokerDealerId("121");
        policyData.setAgentBrokerDealerName("Asd");
        policyData.setAgentCustomBrokerCode(true);
        policyData.setAgentFirstName("ANBC");
        policyData.setAgentLastName("LASTNAME");
        policyDataList.add(policyData);
    }

    @Test
    public void getAWDIndexPolicyTest() throws Exception{
        when(policyService.getAWDIndexPolicy("1234")).thenReturn(policyDataList);
        mvc.perform(get("/jh/wealth/ann/awdindex/policy?policyNo=1234"))
        		.andExpect(status().isOk())
                .andExpect(jsonPath("$[0].agentBrokerDealerId", is("121")))
                .andExpect(jsonPath("$[0].agentBrokerDealerName", is("Asd")))
                .andExpect(jsonPath("$[0].agentCustomBrokerCode", is(true)))
                .andExpect(jsonPath("$[0].agentFirstName", is("ANBC")))
                .andExpect(jsonPath("$[0].agentLastName", is("LASTNAME")));
    }

    @Test
    public void policyNotFoundTest() throws Exception {
        mvc.perform(get("/jh/wealth/ann/awdindex/policy?policyNo=1111")).andExpect(status().isNotFound());
    }

    @After
    public void teardown(){
        policyDataList = new ArrayList<PolicyData>();
    }

}
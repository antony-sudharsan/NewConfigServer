package com.jh.rps.awdindexpolicy.repository;

/**
 *  Copyright (c) 2018, John Hancock and/or its affiliates. All rights reserved.
 *  DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 *  Please contact John Hancock, 200 Berkley, Boston, MA 02116 USA
 *  or visit https://www.johnhancock.com/legal.html if you need additional information or have any
 *  questions.
 */


import com.jh.rps.awdindexpolicy.model.PolicyData;
import org.springframework.stereotype.Service;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.StoredProcedureQuery;
import java.util.ArrayList;
import java.util.List;

/**
 * This class consists exclusively methods to expose the methods as RestFull webservices
 *
 *
 * @author      Antony Sudharsan Gnanaraj
 * @version     %I%, %G%
 * @since       1.0
 */
@Service
public class AWDIndexPolicyService {

    @PersistenceContext
    EntityManager entityManager;
    StoredProcedureQuery awdIndexPolicyProcedure;

    public List<PolicyData> getAWDIndexPolicy(String policyNo) {

/*        awdIndexPolicyProcedure = entityManager.createStoredProcedureQuery("GET_POLICY_DATA");
       List<PolicyData> policyDataList = ((List<PolicyData>) awdIndexPolicyProcedure.getResultList());*/

        return populateDummyData();
    }

    /**
     * Dummy method to populate the Test Data
     *
     * @return
     */
    private List<PolicyData> populateDummyData() {
        List<PolicyData> policyDataList = new ArrayList<PolicyData>();

        PolicyData policyData = new PolicyData();
        policyData.setAgentBrokerDealerId("121");
        policyData.setAgentBrokerDealerName("Asd");
        policyData.setAgentCustomBrokerCode(true);
        policyData.setAgentFirstName("ANBC");
        policyData.setAgentLastName("LASTNAME");

        policyDataList.add(policyData);
        return policyDataList;
    }
}

package com.jh.rps.awdindexpolicy.utils;

import org.slf4j.Logger;
import org.springframework.stereotype.Component;

@Component
public class LogUtils {
    public LogUtils() {}

    /**
     *
     * @param logger
     * @param methodName
     * @param logMsg
     */
    public void debug(Logger logger, String methodName, String logMsg)
    {
        if (logger.isDebugEnabled()) {
            logger.debug(frameLogMessage(logger.getName(),methodName,logMsg));
        }
    }

    /**
     *
     * @param logger
     * @param methodName
     * @param logMsg
     */
    public void warn(Logger logger, String methodName, String logMsg)
    {
        if (logger.isDebugEnabled()) {
            logger.warn(frameLogMessage(logger.getName(),methodName,logMsg));
        }
    }

    /**
     *
     * @param logger
     * @param methodName
     * @param logMsg
     */
    public void trace(Logger logger, String methodName, String logMsg)
    {
        if (logger.isDebugEnabled()) {
            logger.trace(frameLogMessage(logger.getName(),methodName,logMsg));
        }
    }

    /**
     *
     * @param logger
     * @param methodName
     * @param logMsg
     */
    public void info(Logger logger, String methodName, String logMsg)
    {
        if (logger.isDebugEnabled()) {
            logger.info(frameLogMessage(logger.getName(),methodName,logMsg));
        }
    }

    /**
     *
     * @param logger
     * @param methodName
     * @param logMsg
     */
    public void error(Logger logger, String methodName, String logMsg)
    {
            logger.error(frameLogMessage(logger.getName(),methodName,logMsg));
    }


    /**
     *
     * @param className
     * @param methodName
     * @param msg
     * @return
     */
    private String frameLogMessage(String className, String methodName, String msg){
        StringBuffer localStringBuffer = new StringBuffer();
        localStringBuffer.append(className);
        localStringBuffer.append(".");
        localStringBuffer.append(methodName);
        localStringBuffer.append("() - ");
        localStringBuffer.append(msg);
        return localStringBuffer.toString();
    }
}

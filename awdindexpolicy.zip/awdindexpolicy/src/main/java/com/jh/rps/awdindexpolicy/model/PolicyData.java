package com.jh.rps.awdindexpolicy.model;

/**
 *  Copyright (c) 2018, John Hancock and/or its affiliates. All rights reserved.
 *  DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 *  Please contact John Hancock, 200 Berkley, Boston, MA 02116 USA
 *  or visit https://www.johnhancock.com/legal.html if you need additional information or have any
 *  questions.
 */


import io.swagger.annotations.ApiModelProperty;

/**
 * This class consists exclusively methods to expose the methods as RestFull webservices
 *
 *
 * @author      Antony Sudharsan Gnanaraj
 * @version     %I%, %G%
 * @since       1.0
 */
public class PolicyData {

    @ApiModelProperty(notes = "Line of Business")
    private String lob;
    @ApiModelProperty(notes = "Fixed Variable Code")
    private String fixedVarCode;
    @ApiModelProperty(notes = "ReIndustry Indicator")
    private String reInstrtyInd;
    private String ownerCompanyIndivCode;
    private String ownerFirstName;
    private String ownerLastName;
    private String ownerCompanyname;
    private String ownerSSN;
    private String annuitantFirstName;
    private String annuitantLastName;
    private String annuitantSSN;
    private String brokerCount;
    private String agentId;
    private String agentBrokerDealerId;
    private String agentBrokerDealerName;
    private boolean agentCustomBrokerCode;
    private String agentFirstName;
    private String agentLastName;
    private String agentTaxId;
    private String agentPhoneNo;
    private String repAgentid;
    private String repBrokerDealerId;
    private String repBrokerdealerName;
    private boolean repCustombrokerCode;
    private String repAgentFirstName;
    private String repAgentLastName;
    private String repAgentTaxId;
    private String repAgentPhoneNo;

    public String getLob() {
        return lob;
    }

    public void setLob(String lob) {
        this.lob = lob;
    }

    public String getFixedVarCode() {
        return fixedVarCode;
    }

    public void setFixedVarCode(String fixedVarCode) {
        this.fixedVarCode = fixedVarCode;
    }

    public String getReInstrtyInd() {
        return reInstrtyInd;
    }

    public void setReInstrtyInd(String reInstrtyInd) {
        this.reInstrtyInd = reInstrtyInd;
    }

    public String getOwnerCompanyIndivCode() {
        return ownerCompanyIndivCode;
    }

    public void setOwnerCompanyIndivCode(String ownerCompanyIndivCode) {
        this.ownerCompanyIndivCode = ownerCompanyIndivCode;
    }

    public String getOwnerFirstName() {
        return ownerFirstName;
    }

    public void setOwnerFirstName(String ownerFirstName) {
        this.ownerFirstName = ownerFirstName;
    }

    public String getOwnerLastName() {
        return ownerLastName;
    }

    public void setOwnerLastName(String ownerLastName) {
        this.ownerLastName = ownerLastName;
    }

    public String getOwnerCompanyname() {
        return ownerCompanyname;
    }

    public void setOwnerCompanyname(String ownerCompanyname) {
        this.ownerCompanyname = ownerCompanyname;
    }

    public String getOwnerSSN() {
        return ownerSSN;
    }

    public void setOwnerSSN(String ownerSSN) {
        this.ownerSSN = ownerSSN;
    }

    public String getAnnuitantFirstName() {
        return annuitantFirstName;
    }

    public void setAnnuitantFirstName(String annuitantFirstName) {
        this.annuitantFirstName = annuitantFirstName;
    }

    public String getAnnuitantLastName() {
        return annuitantLastName;
    }

    public void setAnnuitantLastName(String annuitantLastName) {
        this.annuitantLastName = annuitantLastName;
    }

    public String getAnnuitantSSN() {
        return annuitantSSN;
    }

    public void setAnnuitantSSN(String annuitantSSN) {
        this.annuitantSSN = annuitantSSN;
    }

    public String getBrokerCount() {
        return brokerCount;
    }

    public void setBrokerCount(String brokerCount) {
        this.brokerCount = brokerCount;
    }

    public String getAgentId() {
        return agentId;
    }

    public void setAgentId(String agentId) {
        this.agentId = agentId;
    }

    public String getAgentBrokerDealerId() {
        return agentBrokerDealerId;
    }

    public void setAgentBrokerDealerId(String agentBrokerDealerId) {
        this.agentBrokerDealerId = agentBrokerDealerId;
    }

    public String getAgentBrokerDealerName() {
        return agentBrokerDealerName;
    }

    public void setAgentBrokerDealerName(String agentBrokerDealerName) {
        this.agentBrokerDealerName = agentBrokerDealerName;
    }

    public boolean isAgentCustomBrokerCode() {
        return agentCustomBrokerCode;
    }

    public void setAgentCustomBrokerCode(boolean agentCustomBrokerCode) {
        this.agentCustomBrokerCode = agentCustomBrokerCode;
    }

    public String getAgentFirstName() {
        return agentFirstName;
    }

    public void setAgentFirstName(String agentFirstName) {
        this.agentFirstName = agentFirstName;
    }

    public String getAgentLastName() {
        return agentLastName;
    }

    public void setAgentLastName(String agentLastName) {
        this.agentLastName = agentLastName;
    }

    public String getAgentTaxId() {
        return agentTaxId;
    }

    public void setAgentTaxId(String agentTaxId) {
        this.agentTaxId = agentTaxId;
    }

    public String getAgentPhoneNo() {
        return agentPhoneNo;
    }

    public void setAgentPhoneNo(String agentPhoneNo) {
        this.agentPhoneNo = agentPhoneNo;
    }

    public String getRepAgentid() {
        return repAgentid;
    }

    public void setRepAgentid(String repAgentid) {
        this.repAgentid = repAgentid;
    }

    public String getRepBrokerDealerId() {
        return repBrokerDealerId;
    }

    public void setRepBrokerDealerId(String repBrokerDealerId) {
        this.repBrokerDealerId = repBrokerDealerId;
    }

    public String getRepBrokerdealerName() {
        return repBrokerdealerName;
    }

    public void setRepBrokerdealerName(String repBrokerdealerName) {
        this.repBrokerdealerName = repBrokerdealerName;
    }

    public boolean isRepCustombrokerCode() {
        return repCustombrokerCode;
    }

    public void setRepCustombrokerCode(boolean repCustombrokerCode) {
        this.repCustombrokerCode = repCustombrokerCode;
    }

    public String getRepAgentFirstName() {
        return repAgentFirstName;
    }

    public void setRepAgentFirstName(String repAgentFirstName) {
        this.repAgentFirstName = repAgentFirstName;
    }

    public String getRepAgentLastName() {
        return repAgentLastName;
    }

    public void setRepAgentLastName(String repAgentLastName) {
        this.repAgentLastName = repAgentLastName;
    }

    public String getRepAgentTaxId() {
        return repAgentTaxId;
    }

    public void setRepAgentTaxId(String repAgentTaxId) {
        this.repAgentTaxId = repAgentTaxId;
    }

    public String getRepAgentPhoneNo() {
        return repAgentPhoneNo;
    }

    public void setRepAgentPhoneNo(String repAgentPhoneNo) {
        this.repAgentPhoneNo = repAgentPhoneNo;
    }
}

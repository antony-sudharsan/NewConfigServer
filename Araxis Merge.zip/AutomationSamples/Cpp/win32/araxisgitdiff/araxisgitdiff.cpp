//------------------------------------------------------------------------------
//
// DESCRIPTION
//
// Araxis Merge v7.0 Subversion Integration (araxisgitdiff)
//
// This file is part of the Araxis Merge product and associated documentation. 
// Please see www.araxis.com for further information. Email comments and
// suggestions to support@araxis.com.
//
//
// COPYRIGHT
//
// Copyright � 1999-2001 Araxis Ltd. All rights reserved except as expressly
// granted below.
//
// You are hereby granted a limited licence to use and modify this source code
// solely for the purposes of:
//
//    i) tailoring Araxis Merge to suit your requirements;
//   ii) for enhancing your understanding of the Araxis Merge Automation API;
//  iii) enabling integration of Araxis Merge with your application(s).
//
// No other rights are granted or implied by this limited licence. Please
// email support@araxis.com if you require additional rights.
//
//------------------------------------------------------------------------------


#include "stdafx.h"

#include "compareutil.h"

// The current module.
//

CComModule _Module;

// An object map. Not used for anything significant.
//

BEGIN_OBJECT_MAP(ObjectMap)
END_OBJECT_MAP()

// Main entry point.
//
int APIENTRY _tWinMain(
  HINSTANCE hInstance,
  HINSTANCE /*hPrevInstance*/,
  LPTSTR     /*lpCmdLine*/,
  int       /*nCmdShow*/)
{
  using namespace compareutil;

  ComInit com;

  // Set up the ATL stuff.
  _Module.Init(ObjectMap, hInstance);

  // Break the command line into options and arguments.
  LPCTSTR lpszCmdLine(GetCommandLine());
  StringSet options;
  StringVector arguments;

  ParseCommandLine(lpszCmdLine, options, arguments);

  // Strip off the first program name argument.
  if (arguments.size())
    arguments.erase(arguments.begin());
  if (arguments.size() > 7)
    arguments.erase(arguments.begin() + 7, arguments.end());
  
  Merge70::IApplicationPtr pApp = createApplicationObject();
  if (pApp == 0)
    return rcFailed;

  // Examine simple command line options.
  const size_t nArguments(arguments.size());

  bool bHelp(false);

  ReturnCode nResult(rcFailed);
  if (bHelp || nArguments != 7)
    {
      DisplayInfo(
        _T("Usage:\n\n")
        _T("araxisgitdiff [/? | /h] <path> <old-file> <old-hex> <old-mode> <new-file> <new-hex> <new-mode>\n"));
      
      nResult = rcSucceeded;
    }
  else
    {
      StringVector titles;

      StringVector files;
      files.push_back(arguments[1]);
      files.push_back(arguments[4]);

      // Expand pathnames of filename arguments.
      if (!ExpandArgumentPaths(pApp, files))
        return rcFailed;

      int lineNumbers[3] = { -1, -1, -1 };

      nResult = launchComparison(
        pApp,
        files,
        true,/*two way*/
        false/*maximized*/,
        false/*wait for exit*/,
        false/*set titles*/,
        titles,
        lineNumbers,
        false/*don't merge*/,
        false/*don't test for conflicts*/,
        false/*don't mark files read-only*/);
    }  

  return int(nResult);
}

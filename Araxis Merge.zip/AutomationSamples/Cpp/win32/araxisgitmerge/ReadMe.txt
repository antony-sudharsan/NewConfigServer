DESCRIPTION

Araxis Merge v6.5 "araxisgitmerge" Utility

This file is part of the Araxis Merge product and associated documentation. 
Please see www.araxis.com for further information. Email comments and
suggestions to support@araxis.com.


COPYRIGHT

Copyright � 1999-2003 Araxis Ltd. All rights reserved except as expressly
granted below.

You are hereby granted a limited licence to use and modify this source code
solely for the purposes of:

   i) tailoring Araxis Merge to suit your requirements;
  ii) for enhancing your understanding of the Araxis Merge Automation API;
 iii) enabling integration of Araxis Merge with your application(s).

No other rights are granted or implied by this limited licence. Please
email support@araxis.com if you require additional rights.

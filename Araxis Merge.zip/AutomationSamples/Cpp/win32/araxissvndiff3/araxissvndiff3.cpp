//------------------------------------------------------------------------------
//
// DESCRIPTION
//
// Araxis Merge v7.0 Subversion Integration (araxissvndiff3)
//
// This file is part of the Araxis Merge product and associated documentation. 
// Please see www.araxis.com for further information. Email comments and
// suggestions to support@araxis.com.
//
//
// COPYRIGHT
//
// Copyright � 1999-2001 Araxis Ltd. All rights reserved except as expressly
// granted below.
//
// You are hereby granted a limited licence to use and modify this source code
// solely for the purposes of:
//
//    i) tailoring Araxis Merge to suit your requirements;
//   ii) for enhancing your understanding of the Araxis Merge Automation API;
//  iii) enabling integration of Araxis Merge with your application(s).
//
// No other rights are granted or implied by this limited licence. Please
// email support@araxis.com if you require additional rights.
//
//------------------------------------------------------------------------------


#include "stdafx.h"

#include "compareutil.h"


static std::wstring GetTemporaryFileName(const std::wstring& strPrefix)
{
  static int unique = 0;

  const size_t cchBuffer(_MAX_PATH + 1);
  const size_t cchMaxPath(_MAX_PATH);
  TCHAR szTempPath[cchBuffer] = { 0 };
  if (!GetTempPath(cchMaxPath, szTempPath))
    wcscpy(szTempPath, L".\\");

  std::wstringstream s;
  s << szTempPath << strPrefix << GetCurrentProcessId() << (++unique);
  return s.str();
}

// The current module.
//

CComModule _Module;

// An object map. Not used for anything significant.
//

BEGIN_OBJECT_MAP(ObjectMap)
END_OBJECT_MAP()

// Main entry point.
//
int APIENTRY _tWinMain(
  HINSTANCE hInstance,
  HINSTANCE /*hPrevInstance*/,
  LPTSTR     /*lpCmdLine*/,
  int       /*nCmdShow*/)
{
  using namespace compareutil;

  ComInit com;

  // Set up the ATL stuff.
  _Module.Init(ObjectMap, hInstance);

  // Break the command line into options and arguments.
  LPCWSTR lpszCmdLine(GetCommandLine());
  StringSet options;
  StringVector arguments;

  ParseCommandLine(lpszCmdLine, options, arguments);

  // Strip off the first program name argument.
  if (arguments.size())
    arguments.erase(arguments.begin());
  if (arguments.size() > 6)
    arguments.erase(arguments.begin() + 6, arguments.end());
  
  Merge70::IApplicationPtr pApp = createApplicationObject();
  if (pApp == 0)
    return rcFailed;

  // Expand pathnames of filename arguments.
  if (!ExpandArgumentPaths(pApp, arguments))
    return rcFailed;
  
  // Examine simple command line options.
  const size_t nArguments(arguments.size());

  bool bHelp(false);

  ReturnCode nResult(rcFailed);
  if (bHelp || nArguments == 0)
    {
      DisplayInfo(
        _T("Usage:\n\n")
        _T("araxissvndiff3 [/? | /h] <mineTitle> <olderTitle> <yoursTitle> <mineFile> <olderFile> <yoursFile>\n"));
      
      nResult = rcSucceeded;
    }
  else if (nArguments < 1)
    {
      DisplayError(_T("Not enough arguments for a two-way comparison."));
    }
  else
    {
      StringVector files;
      files.push_back(arguments[3]);
      files.push_back(arguments[4]);
      files.push_back(arguments[5]);
      
      StringVector titles;
      titles.push_back(arguments[0]);
      titles.push_back(arguments[1]);
      titles.push_back(arguments[2]);

      // Construct a temporary save file.
      std::wstring tempFile = GetTemporaryFileName(L"mrg");
      files.push_back(tempFile);

      int lineNumbers[3] = { -1, -1, -1 };

      nResult = launchComparison(
        pApp,
        files,
        false/*three way*/,
        false/*maximized*/,
        true/*wait for exit*/,
        true/*set titles*/,
        titles,
        lineNumbers,
        false/*don't merge*/,
        false/*don't test for conflicts*/,
        false/*don't mark files read-only*/);

      if (nResult != rcFailed)
        {
          // If the saved output file exists, spit it out.
          nResult = rcFailed;
          
          HANDLE hFile = CreateFile(tempFile.c_str(), GENERIC_READ, FILE_SHARE_READ, 0, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, 0);
          if (hFile != INVALID_HANDLE_VALUE)
            {
              HANDLE hStdOut = GetStdHandle(STD_OUTPUT_HANDLE);

              const size_t bufferSize = 1024;
              BYTE buffer[bufferSize];
              while (true)
                {
                  DWORD bytesRead = 0, bytesWritten = 0;
                  BOOL r = ReadFile(hFile, buffer, bufferSize, &bytesRead, 0);
                  if (!r)
                    {
                      DWORD error = GetLastError();
                      std::wcerr << L"Can't read from \"" << tempFile << "\". Error: 0x" << std::hex << std::setw(8) << std::setfill(L'0') << error << std::endl;
                    }
                  else if (!bytesRead)
                    {
                      nResult = rcSucceeded;
                      break;
                    }
                    
                  r = WriteFile(hStdOut, buffer, bytesRead, &bytesWritten, 0);
                  if (!r)
                    {
                      DWORD error = GetLastError();
                      std::wcerr << L"Can't write to STDOUT. Error: 0x" << std::hex << std::setw(8) << std::setfill(L'0') << error << std::endl;
                      break;
                    }
                  else if (bytesWritten != bytesRead)
                    {
                      std::wcerr << "Couldn't write all of the saved merged file to STDOUT." << std::endl;
                      break;
                    }
                }

              CloseHandle(hFile);
              
              DeleteFile(tempFile.c_str());
            }
          else
            {
              DWORD error = GetLastError();
              std::wcerr << L"Can't open \"" << tempFile << "\". Error: 0x" << std::hex << std::setw(8) << std::setfill(L'0') << error << std::endl;
            }            
        }
    }  

  return int(nResult);
}

#pragma once

namespace compareutil
{
  #define MERGE_VERSION _T("7.0")

  // Some useful typedefs.
  //

  #if defined(UNICODE) || defined(_UNICODE)
    typedef std::wstring tstring;
  #else
    typedef std::string tstring;
  #endif

  typedef std::vector<tstring> StringVector;
  typedef StringVector::const_iterator StringVectorCI;
  typedef StringVector::iterator StringVectorI;
  typedef std::set<tstring> StringSet;
  typedef StringSet::const_iterator StringSetCI;
  typedef StringSet::iterator StringSetI;

  // Exit-code values for this program.
  //

  enum ReturnCode {
    rcSucceeded,
    rcFailed
  };

  // A handle to the active file comparison.
  //

  extern Merge70::IFileComparisonPtr g_pFile;
  extern Merge70::IFolderComparisonPtr g_pFolder;

  // Function information.
  //

  extern _ATL_FUNC_INFO folder_fninfo[];
  extern _ATL_FUNC_INFO file_fninfo[];

  // A class for COM Initialization
  class ComInit
  {
  private:
    HRESULT m_hr;

  public:
    ComInit()
    {
      m_hr = CoInitialize(0);
    }

    ~ComInit()
    {
      if (SUCCEEDED(m_hr))
        CoUninitialize();
    }
  };

  // This class is used to sink events fired by the Merge Folder Comparison window.
  //

  class ATL_NO_VTABLE CFolderComparisonWaitObject :
    public CComObjectRootEx<CComMultiThreadModel>,
    public CComCoClass<CFolderComparisonWaitObject>,
    public IDispatchImpl<IDispatch, &IID_IDispatch, 0>,
    public IDispEventImpl<0, CFolderComparisonWaitObject, &__uuidof(Merge70::_FolderComparisonEvents)>
  {
  public:
    BEGIN_COM_MAP(CFolderComparisonWaitObject)
      COM_INTERFACE_ENTRY(IDispatch)
    END_COM_MAP()

  public:
    BEGIN_SINK_MAP(CFolderComparisonWaitObject)
      SINK_ENTRY_INFO(0, __uuidof(Merge70::_FolderComparisonEvents), 1, ComparisonComplete, &folder_fninfo[0])
      SINK_ENTRY_INFO(0, __uuidof(Merge70::_FolderComparisonEvents), 3, Close, &folder_fninfo[1])
    END_SINK_MAP()

    // Merge::_FolderComparisonEvents
    void __stdcall ComparisonComplete(
      Merge70::FolderComparisonResult /*result*/)
    {
    }

    void __stdcall Close()
    {
      DispEventUnadvise(g_pFolder, &__uuidof(Merge70::_FolderComparisonEvents));

      // Quit this program.
      PostQuitMessage(0);
    }
  };

  // This class is used to sink events fired by the Merge File Comparison window.
  //

  class ATL_NO_VTABLE CFileComparisonWaitObject :
    public CComObjectRootEx<CComMultiThreadModel>,
    public CComCoClass<CFileComparisonWaitObject>,
    public IDispatchImpl<IDispatch, &IID_IDispatch, 0>,
    public IDispEventImpl<0, CFileComparisonWaitObject, &__uuidof(Merge70::_FileComparisonEvents)>
  {
  public:
    BEGIN_COM_MAP(CFileComparisonWaitObject)
      COM_INTERFACE_ENTRY(IDispatch)
    END_COM_MAP()

  public:
    BEGIN_SINK_MAP(CFileComparisonWaitObject)
      SINK_ENTRY_INFO(0, __uuidof(Merge70::_FileComparisonEvents), 1, ComparisonComplete, &file_fninfo[0])
      SINK_ENTRY_INFO(0, __uuidof(Merge70::_FileComparisonEvents), 2, Close, &file_fninfo[1])
    END_SINK_MAP()

    // Merge::_FileComparisonEvents
    void __stdcall ComparisonComplete(
      Merge70::FileComparisonError /*error*/,
      Merge70::FileComparisonResult /*result*/)
    {
    }

    void __stdcall Close()
    {
      DispEventUnadvise(g_pFile, &__uuidof(Merge70::_FileComparisonEvents));

      // Quit this program.
      PostQuitMessage(0);
    }
  };

  // Output an informational message
  extern void DisplayInfo(LPCTSTR pszText);

  // Output an error message
  extern void DisplayError(LPCTSTR pszText);

  // Parses a command line into option arguments and other arguments.
  // Arguments containing white-space should be enclosed within quotes.
  //

  extern void ParseCommandLine(
    LPCTSTR lpszArgs,
    StringSet& options,
    StringVector& arguments);

  // Returns the value of a specific option. The value of an option
  // is the text (if any) after the colon following the option.
  // Thus, /optionName:<value>. The value must be enclosed in
  // single or double quotation marks if it contains spaces.
  //

  extern tstring ParseOptionValue(
    StringSet& options,
    tstring sOptionName);

  extern int ParseLineNumber(
    tstring sOptionValue);

  // Take a file specification and combine it with the
  // current directory to return a full pathname.
  //

  extern tstring ExpandPathname(
    Merge70::IUriInformationPtr pUriInfo, 
    const tstring& file);

  // Return true if the specified character is a directory path separator.
  //

  extern bool IsDirSep(TCHAR chSep);

  // Converts a potentially short-form pathname into a long-form pathname.
  // .
  // Valid components of the input pathname are expanded if possible. Invalid
  // components are left as-is.
  //
  // Example inputs/outputs:
  //
  // e:\program files\micros~4\vintde~1\Script~1 expands to e:\Program Files\Microsoft Visual Studio\VIntDev98\ScriptLibrary
  //
  //  expands to
  //
  // c expands to c
  //
  // c: expands to c:
  //
  // c:\ expands to c:\
  //
  // \ expands to \
  //
  // \\ expands to \\
  //
  // \\a expands to \\a
  //
  // \\a\ expands to \\a\
  //
  // \\a\a expands to \\a\a
  //

  extern tstring getLongPathName(
    const TCHAR* pszOriginal);

  // Expand relative paths of filename arguments to
  // absolute paths.
  //

  extern bool ExpandArgumentPaths(
    Merge70::IUriInformationPtr pUriInfo, 
    StringVector& arguments);

  // Report an automation error.
  //

  extern void ReportError(
    _com_error e, 
    LPCTSTR lpszWhileTrying);

  // Report a serious error.
  //

  extern void ReportError(LPCTSTR lpszWhileTrying);

  // Do a three-way merge on a file comparison, and return the number of conflicts (or 0 if there weren't any).
  // (Note: This is a no-op for folder comparisons)

  extern long threeWayMerge(Merge70::IFolderComparisonPtr automationObject);
  extern long threeWayMerge(Merge70::IFileComparisonPtr automationObject);

  // This happens automatically in the Compare method.
  //

  extern void setThreeWay(Merge70::IFolderComparisonPtr automationObject);

  // Force a file comparison window into three-way mode.
  //

  extern void setThreeWay(Merge70::IFileComparisonPtr automationObject);

  // Starts a file/folder comparison. The type of comparison is defined
  // by the arguments to this method. If instructed to wait for
  // the comparison to complete, this method sets up a sink for
  // events from the file comparison window. It is up to the caller
  // to set up a message pump and wait for the event sink object
  // to post a WM_QUIT message to the main message queue.
  //

  template <class WaitType, class Events, class AutomationType>
  ReturnCode DoComparison(
    Merge70::IApplicationPtr pApp,
    const bool& bTwoWay,
    const bool& bMaximize,
    const bool& bWait,
    const bool& bSetTitles,
    const StringVector& titles,
    const AutomationType automationObject,
    const bool& bMerge = false,
    const bool& bTestConflicts = false)
  {
    ReturnCode nResult(rcSucceeded);

    HRESULT hr(S_OK);
    try
      {
        try
          {
            // Make Merge visible and active.
            if (pApp->Minimized)
              pApp->Restore();
            pApp->Visible = VARIANT_TRUE;

            // Bring the window to the front (Merge can't do this itself on Win2K and higher)
            Merge70::IWindowHandlePtr pWindowHandle(pApp);
            if (pWindowHandle)
              {
                unsigned __int64 wh(pWindowHandle->WindowHandle);
                if (wh)
                  {
                    HWND hWnd(reinterpret_cast<HWND>(wh));
                    BringWindowToTop(hWnd);
                    SetForegroundWindow(hWnd);
                  }
              }

            bool bMaximizePreference =
              pApp->Preferences->Longs->Item[Merge70::clAppMax] ? true : false;

            if (bMaximize || bMaximizePreference)
              pApp->Maximized = VARIANT_TRUE;
          }
        catch (_com_error e)
          {
            ReportError(e, _T("showing the Merge application window."));
            throw;
          }
        catch (...)
          {
            ReportError(_T("showing the Merge application window."));
            throw;
          }

        try
          {
            pApp->Active = VARIANT_TRUE;
          }
        catch (_com_error e)
          {
            ReportError(e, _T("activating the Merge application window."));
            throw;
          }
        catch (...)
          {
            ReportError(_T("activating the Merge application window."));
            throw;
          }

        CComObject<WaitType>* pObject = 0;

        try
          {
            CComObject<WaitType>::CreateInstance(&pObject);
            pObject->AddRef();

            // Register an interest in events fired by the file comparison.
            pObject->DispEventAdvise(automationObject, &__uuidof(Events));
          }
        catch (_com_error e)
          {
            ReportError(e, _T("creating a comparison window."));
            throw;
          }
        catch (...)
          {
            ReportError(_T("creating a comparison window."));
            throw;
          }

        // Compare the files...
        if (bTwoWay)
          {
            try
              {
                // Set file panel titles.
                if (bSetTitles)
                  automationObject->SetPanelTitles(
                    titles[0].c_str(), 
                    titles[1].c_str());
              }
            catch (_com_error e)
              {
                ReportError(e, _T("comparing two files/folders."));
                throw;
              }
            catch (...)
              {
                ReportError(_T("comparing two files/folders."));
                throw;
              }
          }
        else
          {
            try
              {
                // Set file panel titles.
                if (bSetTitles)
                  automationObject->SetPanelTitles(
                    titles[0].c_str(),
                    titles[1].c_str(),
                    titles[2].c_str());

                // Compare three files.
                setThreeWay(automationObject);

                if (bMerge)
                  {
                    long nConflicts = threeWayMerge(automationObject);

                    if (bTestConflicts)
                      {
                        std::cout << nConflicts << " conflict(s)." << std::endl;
                        nResult = (ReturnCode)nConflicts;
                        automationObject->Close();
                      }
                    else
                      // keep comparison window open.
                      automationObject->GiveUserControl();
                  }
              }
            catch (_com_error e)
              {
                ReportError(e, _T("comparing three files/folders."));
                throw;
              }
            catch (...)
              {
                ReportError(_T("comparing three files/folders."));
                throw;
              }
          }

        try
          {
            // Hand off control to the user. This means that Merge
            // won't close until the user decides to close it.
            pApp->GiveUserControl();
            automationObject->GiveUserControl();

            // If not waiting for the file comparison to finish, shutdown the connection point.
            if (!bWait)
              pObject->Close();

            pObject->Release();
          }
        catch (_com_error e)
          {
            ReportError(e, _T("ending the conversation with Merge."));
            throw;
          }
        catch (...)
          {
            ReportError(_T("ending the conversation with Merge."));
            throw;
          }
      }
    catch (_com_error e)
      {
        hr = e.Error();
        if (!FAILED(hr))
          hr = E_FAIL;
      }
    catch (...) 
      {
        hr = E_FAIL;
      }

    if (FAILED(hr))
      {
        TCHAR szMessage[1024];
        _stprintf(szMessage, _T("Unable to communicate with Araxis Merge.\n\n%08x"), hr);
        DisplayError(szMessage);
        nResult = rcFailed;
      }

    return nResult;
  }

  // Starts a folder comparison. The type of comparison is defined
  // by the arguments to this method. If instructed to wait for
  // the comparison to complete, this method sets up a sink for
  // events from the folder comparison window. It is up to the caller
  // to set up a message pump and wait for the event sink object
  // (a CFolderComparisonWaitObject) to post a WM_QUIT message to the
  // main message queue.
  //

  extern ReturnCode DoFolderComparison(
    Merge70::IApplicationPtr pApp,
    const bool& bTwoWay,
    const bool& bMaximize,
    const bool& bWait,
    const bool& bSetTitles,
    const StringVector& titles);

  // Starts a file comparison. The type of comparison is defined
  // by the arguments to this method. If instructed to wait for
  // the comparison to complete, this method sets up a sink for
  // events from the file comparison window. It is up to the caller
  // to set up a message pump and wait for the event sink object
  // (a CFileComparisonWaitObject) to post a WM_QUIT message to the
  // main message queue.
  //

  ReturnCode DoFileComparison(
    Merge70::IApplicationPtr pApp,
    const bool& bTwoWay,
    const bool& bMaximize,
    const bool& bWait,
    const StringVector& arguments,
    const bool& bSetTitles,
    const StringVector& titles,
    const int* lineNumbers,
    const bool& bMerge,
    const bool& bTestConflicts,
    bool bReadOnly);

  extern ReturnCode launchComparison(
    Merge70::IApplicationPtr pApp,
    const StringVector& arguments,
    bool bTwoWay,
    bool bMaximized,
    bool bWait,
    bool bSetTitles,
    const StringVector& titles,
    const int* lineNumbers,
    bool bMerge,
    bool bTestConflicts,
    bool bReadOnly);

  extern Merge70::IApplicationPtr createApplicationObject();
}

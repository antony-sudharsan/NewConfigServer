#include "stdafx.h"
#include "compareutil.h"



namespace compareutil
{
  // A handle to the active file comparison.
  //

  Merge70::IFileComparisonPtr g_pFile;
  Merge70::IFolderComparisonPtr g_pFolder;


  // Function information.
  //

  _ATL_FUNC_INFO folder_fninfo[] = 
  {
    { CC_STDCALL, VT_EMPTY, 1, VT_I4 },
    { CC_STDCALL, VT_EMPTY, 0 }
  };

  _ATL_FUNC_INFO file_fninfo[] = 
  {
    { CC_STDCALL, VT_EMPTY, 2, VT_I4, VT_I4 },
    { CC_STDCALL, VT_EMPTY, 0 }
  };

  // Output an informational message
  void 
  DisplayInfo(
    LPCTSTR pszText)
  {
  #ifdef _CONSOLE
    _ftprintf(stdout, _T("Araxis Merge Command Line Compare Utility v%s\n\n%s\n"), MERGE_VERSION, pszText);
  #else
    MessageBox(0, pszText, _T("Araxis Merge Command Line Compare Utility v") MERGE_VERSION, MB_ICONINFORMATION | MB_OK);
  #endif
  }

  // Output an error message
  void 
  DisplayError(
    LPCTSTR pszText)
  {
  #ifdef _CONSOLE
    _ftprintf(stderr, _T("Araxis Merge Command Line Compare Utility v%s\n\n%s\n"), MERGE_VERSION, pszText);
  #else
    MessageBox(0, pszText, _T("Araxis Merge Command Line Compare Utility v") MERGE_VERSION, MB_ICONERROR | MB_OK);
  #endif
  }

  // Parses a command line into option arguments and other arguments.
  // Arguments containing white-space should be enclosed within quotes.
  //

  void
  ParseCommandLine(
    LPCTSTR lpszArgs,
    StringSet& options,
    StringVector& arguments)
  {
    LPCTSTR lpchA(lpszArgs);

    while (*lpchA)
      {
        while (_istspace(*lpchA))
          lpchA++;

        // allow options to start with a forward slash or a dash
        bool bIsOption(*lpchA == _T('-') || *lpchA == _T('/'));

        if (bIsOption)
          lpchA++;

        tstring strOptionOrArgument;
        bool bQuote = false;
        TCHAR tcQuoteCharacter = 0;
        while (*lpchA)
          {
            if (*lpchA == _T('\'') || *lpchA == _T('\"'))
              {
                if (bQuote && *lpchA == tcQuoteCharacter)
                  {
                    bQuote = false;
                  }
                else if (!bQuote)
                  {
                    bQuote = true;
                    tcQuoteCharacter = *lpchA;
                  }
                else
                  strOptionOrArgument += *lpchA;
              }
            else if (_istspace(*lpchA) && !bQuote)
              break;
            else
              strOptionOrArgument += *lpchA;
                
            lpchA++;
          }

        if (strOptionOrArgument.length())
          {
            if (bIsOption)
              options.insert(strOptionOrArgument);
            else
              arguments.push_back(strOptionOrArgument);
          }
      }
  }


  // Returns the value of a specific option. The value of an option
  // is the text (if any) after the colon following the option.
  // Thus, /optionName:<value>. The value must be enclosed in
  // single or double quotation marks if it contains spaces.
  //

  tstring
  ParseOptionValue(
    StringSet& options,
    tstring sOptionName)
  {
    const tstring sOptionNameWithColon(sOptionName + _T(":"));
    tstring sResult;

    StringSetI optIt = options.begin();
    while (optIt != options.end())
      {
        if (optIt->substr(0, sOptionNameWithColon.length()) == sOptionNameWithColon)
          {        
            sResult = optIt->substr(sOptionNameWithColon.length());
          }
        ++optIt;
      }

    return sResult;
  }

  extern int ParseLineNumber(
    tstring sOptionValue)
  {
    return _ttoi(sOptionValue.c_str()) - 1;
  }

  // Take a file specification and combine it with the
  // current directory to return a full pathname.
  //

  tstring ExpandPathname(Merge70::IUriInformationPtr pUriInfo, const tstring& file)
  {
    tstring result(file);
    
    // If it's not a Win32 URI, leave it alone.
    if (pUriInfo->IsWin32FileSystemUri(_bstr_t(file.c_str())) == S_OK)
      {
        TCHAR* full = _tfullpath(0, file.c_str(), 0);
        if (full)
          {
            result = full;
            free(full);
          }
      }

    return result;
  }

  // Return true if the specified character is a directory path separator.
  //

  bool IsDirSep(TCHAR chSep)
  {
    return
      chSep == _T('\\') ||
      chSep == _T('/');
  }

  // +---------------------+
  // |  GetLongPathName()  |
  // +---------------------+
  //

  //:Description
  //
  // Converts a potentially short-form pathname into a long-form pathname.
  // .
  // Valid components of the input pathname are expanded if possible. Invalid
  // components are left as-is.
  //
  // Example inputs/outputs:
  //
  // e:\program files\micros~4\vintde~1\Script~1 expands to e:\Program Files\Microsoft Visual Studio\VIntDev98\ScriptLibrary
  //
  //  expands to
  //
  // c expands to c
  //
  // c: expands to c:
  //
  // c:\ expands to c:\
  //
  // \ expands to \
  //
  // \\ expands to \\
  //
  // \\a expands to \\a
  //
  // \\a\ expands to \\a\
  //
  // \\a\a expands to \\a\a
  //

  tstring
  getLongPathName(const TCHAR* pszOriginal)             // The (short) input path name
  {
    tstring result;
    
    const TCHAR* pchScan = pszOriginal;
    
    // Do Drive Letter check...
    if (pchScan[0] && pchScan[1] == _T(':'))
      {
        // Copy drive letter and colon.
        result.push_back(*pchScan++);
        result.push_back(*pchScan++);
      }
    else if (pchScan[0] == _T('\\') && pchScan[1] == _T('\\'))
      {
        // Copy \\ and machine name.
        result.push_back(*pchScan++);
        result.push_back(*pchScan++);
        while (*pchScan && !IsDirSep(*pchScan))
          result.push_back(*pchScan++);
        // Note that the code below will fail since FindFirstFile
        // on a UNC path seems not to work on directory name searches?
      }
    
    WIN32_FIND_DATA wfd;
    if (!IsDirSep(*pchScan))
      {
        while (*pchScan)
          result.push_back(*pchScan++);
      }
    else
      // Now loop through directories and files...
      while (IsDirSep(*pchScan))
        {
          result.push_back(*pchScan++);
          size_t replacePos = result.length();
    
          const TCHAR* pchEnd = pchScan;
          while (*pchEnd && !IsDirSep(*pchEnd))
            result.push_back(*pchEnd++);
    
          if (!_tcsicmp(result.c_str() + replacePos, _T(".")) || !_tcsicmp(result.c_str() + replacePos, _T("..")))
            {
            }
          else
            {
              // Now run this through FindFirstFile...
              HANDLE hFind = FindFirstFile(result.c_str(), &wfd);
              if (hFind != INVALID_HANDLE_VALUE)
                {
                  FindClose(hFind);
                  result.replace(replacePos, result.length() - replacePos, wfd.cFileName);
                }
              else
                {
                  // Copy rest of input path & end.
                  while (*pchEnd)
                    result.push_back(*pchEnd++);
                  break;
                }
            }
          pchScan = pchEnd;
        }
    
    return result;
  }

  // Expand relative paths of filename arguments to
  // absolute paths.
  //

  bool
  ExpandArgumentPaths(Merge70::IUriInformationPtr pUriInfo, StringVector& arguments)
  {
    USES_CONVERSION;
  
    try
      {
        StringVectorI argIt = arguments.begin();
        while (argIt != arguments.end())
          {
            if (pUriInfo->IsWin32FileSystemUri(_bstr_t(argIt->c_str())) == S_OK)
              {
                *argIt = getLongPathName(ExpandPathname(pUriInfo, *argIt).c_str());
              }
            ++argIt;
          }
      }
    catch (_com_error e)
      {
        ReportError(e, _T("creating absolute paths"));
        return false;
      }
      
    return true;
  }

  // Report an automation error.
  //

  void
  ReportError(_com_error e, LPCTSTR lpszWhileTrying)
  {
    tstringstream s;

    s << _T("An error occured while ")
      << lpszWhileTrying
      << _T("\n\n")
      << e.ErrorMessage();

    DisplayError(s.str().c_str());
  }

  // Report a serious error.
  //

  void
  ReportError(LPCTSTR lpszWhileTrying)
  {
    tstringstream s;
    s << _T("An error occurred while \n");
    s << lpszWhileTrying;

    DisplayError(s.str().c_str());
  }

  // Create a new folder comparison automation object.
  //

  void getAutomationObject(Merge70::IApplicationPtr pApp, Merge70::IFolderComparisonPtr& automationObject)
  {
    automationObject = pApp->FolderComparison;
  }

  // Create a new file comparison automation object.
  //

  void getAutomationObject(Merge70::IApplicationPtr pApp, Merge70::IFileComparisonPtr& automationObject)
  {
    automationObject = pApp->TextComparison;
  }

  // Do a three-way merge on a file comparison, and return the number of conflicts (or 0 if there weren't any).
  // (Note: This is a no-op for folder comparisons)

  long threeWayMerge(Merge70::IFolderComparisonPtr automationObject)
  {
    UNREFERENCED_PARAMETER(automationObject);
    return 0;
  }

  long threeWayMerge(Merge70::IFileComparisonPtr automationObject)
  {
    return automationObject->ThreeWayMerge();
  }

  // This happens automatically in the Compare method.
  //

  void setThreeWay(Merge70::IFolderComparisonPtr automationObject)
  {
  }

  // Force a file comparison window into three-way mode.
  //

  void setThreeWay(Merge70::IFileComparisonPtr automationObject)
  {
    automationObject->put_ViewType(Merge70::fvtThreeWay);
  }

  void setLineNumber(Merge70::IFileComparisonPtr automationObject, int fileNumber, int lineNumber)
  {
    if (lineNumber != -1)
      {
        Merge70::ITextComparisonPtr textObject(automationObject);
        if (textObject)
          textObject->put_LineNumber(static_cast<short>(fileNumber), lineNumber);
      }
  }

  // Starts a folder comparison. The type of comparison is defined
  // by the arguments to this method. If instructed to wait for
  // the comparison to complete, this method sets up a sink for
  // events from the folder comparison window. It is up to the caller
  // to set up a message pump and wait for the event sink object
  // (a CFolderComparisonWaitObject) to post a WM_QUIT message to the
  // main message queue.
  //

  ReturnCode DoFolderComparison(
    Merge70::IApplicationPtr pApp,
    const bool& bTwoWay,
    const bool& bMaximize,
    const bool& bWait,
    const bool& bSetTitles,
    const StringVector& titles)
  {
    return DoComparison<
      CFolderComparisonWaitObject, 
      Merge70::_FolderComparisonEvents, 
      Merge70::IFolderComparisonPtr>(
        pApp,
        bTwoWay, bMaximize, 
        bWait, 
        bSetTitles, titles, 
        g_pFolder);
  }

  // Starts a file comparison. The type of comparison is defined
  // by the arguments to this method. If instructed to wait for
  // the comparison to complete, this method sets up a sink for
  // events from the file comparison window. It is up to the caller
  // to set up a message pump and wait for the event sink object
  // (a CFileComparisonWaitObject) to post a WM_QUIT message to the
  // main message queue.
  //

  ReturnCode DoFileComparison(
    Merge70::IApplicationPtr pApp,
    const bool& bTwoWay,
    const bool& bMaximize,
    const bool& bWait,
    const StringVector& arguments,
    const bool& bSetTitles,
    const StringVector& titles,
    const int* lineNumbers,
    const bool& bMerge,
    const bool& bTestConflicts,
    bool bReadOnly)
  {
    ReturnCode nResult = DoComparison<
          CFileComparisonWaitObject, 
          Merge70::_FileComparisonEvents, 
          Merge70::IFileComparisonPtr>(
            pApp,
            bTwoWay, bMaximize, 
            bWait, 
            bSetTitles, titles, 
            g_pFile,
            bMerge,
            bTestConflicts);
  
    if (nResult == rcSucceeded)
      {
        try
          {
            if (bTwoWay)
              {
                // Set the optional save property.
                if (arguments.size() >= 3)
                  g_pFile->SaveFileName = arguments[2].c_str();
                for (int n = 0; n < 2; ++n)
                  setLineNumber(g_pFile, n, lineNumbers[n]);
              }
            else
              {
                if (arguments.size() >= 4)
                  g_pFile->SaveFileName = arguments[3].c_str();
                for (int n = 0; n < 3; ++n)
                  setLineNumber(g_pFile, n, lineNumbers[n]);
              }
            if (bReadOnly)
              {
                g_pFile->ReadOnly[0] = VARIANT_TRUE;
                g_pFile->ReadOnly[1] = VARIANT_TRUE;
                g_pFile->ReadOnly[2] = VARIANT_TRUE;
              }
          }
        catch (_com_error e)
          {
            ReportError(e, _T("setting save filename, line numbers, and read-only states"));
            nResult = rcFailed;
          }
      }

    return nResult;
  }

  ReturnCode launchComparison(
    Merge70::IApplicationPtr pApp,
    const StringVector& arguments,
    bool bTwoWay,
    bool bMaximized,
    bool bWait,
    bool bSetTitles,
    const StringVector& titles,
    const int* lineNumbers,
    bool bMerge,
    bool bTestConflicts,
    bool bReadOnly)
  {
    ReturnCode nResult(rcFailed);

    Merge70::IComparisonPtr object;
    
    try
      {
        object = pApp->CompareItems(
          arguments[0].c_str(), 
          arguments[1].c_str(), 
          bTwoWay ? _variant_t() : arguments[2].c_str());
      }
    catch (_com_error e)
      {
        ReportError(e, _T("comparing the requested items"));
        return nResult;
      }

    g_pFile = object;
    g_pFolder = object;

    if (g_pFolder)
      nResult = DoFolderComparison(pApp, bTwoWay, bMaximized, bWait, bSetTitles, titles);
    else
      nResult = DoFileComparison(pApp, bTwoWay, bMaximized, bWait, arguments, bSetTitles, titles, lineNumbers, bMerge, bTestConflicts, bReadOnly);
  
    if (nResult == rcSucceeded)
      {
        // Pump messages until we get a WM_QUIT from the event sink object.
        MSG msg;
        while (GetMessage(&msg, 0, 0, 0))
          {
            TranslateMessage(&msg);
            DispatchMessage(&msg);
          }

        // Release the reference to the comparison window.
        if (g_pFolder)
          g_pFolder.Release();
        if (g_pFile)
          g_pFile.Release();
      }

    return nResult;
  }

  Merge70::IApplicationPtr createApplicationObject()
  {
    Merge70::IApplicationPtr pApp;

    // Create a Merge application object. This will cause Merge
    // to be started if it isn't already running.
    HRESULT hr(
      CoCreateInstance(
        __uuidof(Merge70::Application), 0, CLSCTX_SERVER,
        __uuidof(Merge70::IApplication), (void**)&pApp));

    if (!SUCCEEDED(hr))
      {
        ReportError(_com_error(hr), _T("creating a Merge application object"));
      }

    return pApp;
  }
}

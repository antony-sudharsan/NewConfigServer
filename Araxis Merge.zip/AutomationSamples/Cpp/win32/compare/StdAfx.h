#if !defined(AFX_STDAFX_H__A9DB83DB_A9FD_11D0_BFD1_444553540000__INCLUDED_)
#define AFX_STDAFX_H__A9DB83DB_A9FD_11D0_BFD1_444553540000__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define WIN32_LEAN_AND_MEAN		// Exclude rarely-used stuff from Windows headers

#pragma warning(disable: 4514 4786 4710 4310 4505 4097 4127 4711)
#pragma warning(push, 3)

#define STRICT
#include <windows.h>
#include <tchar.h>
#include <atlbase.h>

extern CComModule _Module;

#include <atlcom.h>
#include <vector>
#include <string>
#include <set>
#include <algorithm>
#include <iostream>
#include <sstream>
#include <iomanip>

#pragma warning(pop)

#include <comdef.h>
#import <merge.tlb>

#if defined(UNICODE) || defined(_UNICODE)
  typedef std::wstringstream tstringstream;
#else
  typedef std::stringstream tstringstream;
#endif

#endif // !defined(AFX_STDAFX_H__A9DB83DB_A9FD_11D0_BFD1_444553540000__INCLUDED_)

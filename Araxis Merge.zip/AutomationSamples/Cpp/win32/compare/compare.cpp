#include "stdafx.h"
#include "compareutil.h"

// The current module.
//

CComModule _Module;

// An object map. Not used for anything significant.
//

BEGIN_OBJECT_MAP(ObjectMap)
END_OBJECT_MAP()

// Main entry point.
//
#ifdef _CONSOLE
int main ()
{
#else
int APIENTRY _tWinMain(
  HINSTANCE hInstance,
  HINSTANCE /*hPrevInstance*/,
  LPTSTR     /*lpCmdLine*/,
  int       /*nCmdShow*/)
{
  // Set up the ATL stuff. 
  _Module.Init(ObjectMap, hInstance);
#endif
  using namespace compareutil;

  ComInit com;

  // Break the command line into options and arguments.
  LPCTSTR lpszCmdLine(GetCommandLine());
  StringSet options;
  StringVector arguments;

  ParseCommandLine(lpszCmdLine, options, arguments);

  // Strip off the first program name argument.
  if (arguments.size())
    arguments.erase(arguments.begin());

  Merge70::IApplicationPtr pApp = createApplicationObject();
  if (pApp == 0)
    return rcFailed;

  // Expand pathnames of filename arguments.
  if (!ExpandArgumentPaths(pApp, arguments))
    return rcFailed;
  
  // Examine simple command line options.
  const size_t nArguments(arguments.size());

  bool bHelp(false);
  bool bThreeWay(nArguments == 4);
  bool bMaximized(false);
#ifdef _CONSOLE
  bool bWait(true);
#else
  bool bWait(false);
#endif
  bool bTwoWay(false);
  bool bSwap(false);
  bool bMerge(false);
  bool bTestConflicts(false);
  bool bReadOnly(false);

  // Parse the arguments to detect any bad ones and force the help message if so.
  // Set Boolean options.
  StringSetI optIt = options.begin();
  while (optIt != options.end())
    {
      const tstring& str = *optIt;
      if (str == _T("3"))
        bThreeWay = true;
      else if (!_tcsicmp(str.c_str(), _T("max")))
        bMaximized = true;
      else if (!_tcsicmp(str.c_str(), _T("wait")))
        bWait = true;
      else if (!_tcsicmp(str.c_str(), _T("nowait")))
        bWait = false;
      else if (!_tcsicmp(str.c_str(), _T("swap")))
        bSwap = true;
      else if (!_tcsicmp(str.c_str(), _T("merge")))
        bMerge = true;
      else if (!_tcsicmp(str.c_str(), _T("testconflicts")))
        bMerge = bTestConflicts = true;
      else if (!_tcsicmp(str.c_str(), _T("readonly")))
        bReadOnly = true;
      else if (!_tcsnicmp(str.c_str(), _T("title1"), 6) || !_tcsnicmp(str.c_str(), _T("title2"), 6) || !_tcsnicmp(str.c_str(), _T("title3"), 6))
        ;
      else if (!_tcsnicmp(str.c_str(), _T("line1"), 5) || !_tcsnicmp(str.c_str(), _T("line2"), 5) || !_tcsnicmp(str.c_str(), _T("line3"), 5))
        ;
      else if (str == _T("2") || str == _T("3"))
        ;
      else if (!_tcsicmp(str.c_str(), _T("a1")) || !_tcsicmp(str.c_str(), _T("a2")) || !_tcsicmp(str.c_str(), _T("a3")))
        ;
      else
        {
          bHelp = true;
          break;
        }
      ++optIt;
    }
  bTwoWay = !bThreeWay;
    
  // Three way merge testing will close the comparison window when the number of conflicts
  // are known, therefore there's no need to wait...
  if (bTestConflicts)
    bWait = false;
    
  ReturnCode nResult(rcFailed);
  if (bHelp || 0 == nArguments)
    {
      DisplayInfo(
        _T("Usage:\n\n")
        _T("compare [/? | /h] [/[no]wait] [/merge] [/testconflicts] [/readonly] [/aN] [/swap] [/max] [[/titleN:\"<NthFileOrFolderTitle>\"]...] [[/lineN:<lineNumber>]...] [/2 | /3]\n")
        _T("        <firstFile> [<secondFile>] [<thirdFile>] [<mergedOutputFile>]\n")
        _T("  or:\n")
        _T("        <firstFolder> [<secondFolder>] [<thirdFolder>]\n\n")
        _T("/wait -- Wait for user to close the compared files/folders before exiting")
#ifdef _CONSOLE
        _T(" (default)")
#endif
        _T(".\n\n")
        _T("/nowait -- Do not wait for user to close the compared files/folders before exiting")
#ifndef _CONSOLE
        _T(" (default)")
#endif
        _T(".\n\n")
        _T("/aN -- (N is 1, 2 or 3) The Nth file/folder argument specifies a common ancestor of\n        the other two files/folders. The common ancestor is shown in the middle file/folder panel.\n\n")
        _T("/merge -- Merge two new revisions into the common ancestor (three-way comparisons only).\n\n")
        _T("/testconflicts -- Perform a merge, and return the number of conflicts (if any) as this program's\n        return code and as a message in the console.\n\n")
        _T("/readonly -- Prevents the compared files from being edited.\n\n")
        _T("/swap -- Swaps the files/folders displayed in the left and right panels.\n\n")
        _T("/max -- Maximize the Merge application window.\n\n")
        _T("/titleN:\"<NthFileOrFolderTitle>\" -- (N is 1, 2 or 3) Sets a friendly title for the file/folder panel\n        that displays the Nth file/folder specified on the command line. Single or double\n        quotes must be used to surround the title.\n\n")
        _T("/lineN:<lineNumber> -- (N is 1, 2 or 3) Ensures that a line number is visible within a file panel.\n\n")
        _T("For file comparisons:\n\n")
        _T("  /2 -- Performs a two-way comparison (default). The files <firstFile> and\n        <secondFile> are compared. If present, <mergedOutputFile> is used as\n        the default save filename for the results of any merge.\n\n")
        _T("  /3 -- Performs a three-way comparison. The files <firstFile>, <secondFile>\n        and <thirdFile> are compared. If present, <mergedOutputFile> is used\n        as the default save filename for the results of any merge.\n\n")
        _T("For folder comparisons:\n\n")
        _T("  /2 -- Performs a two-way comparison (default). The folders <firstFolder> and\n        <secondFolder> are compared.\n\n")
        _T("  /3 -- Performs a three-way comparison. The folders <firstFolder>, <secondFolder>\n        and <thirdFolder> are compared."));

      nResult = rcSucceeded;
    }
  else if (bThreeWay && nArguments < 3)
    {
      DisplayError(_T("Not enough arguments for a three-way comparison."));
    }
  else if (bTwoWay && nArguments < 1)
    {
      DisplayError(_T("Not enough arguments for a two-way comparison."));
    }
  else
    {
      // Process file panel titles.
      StringVector titles;
      titles.push_back(ParseOptionValue(options, _T("title1")));
      titles.push_back(ParseOptionValue(options, _T("title2")));
      bool bSetTitles(titles[0].length() || titles[1].length());
      if (bThreeWay)
        {
          titles.push_back(ParseOptionValue(options, _T("title3")));
          bSetTitles = bSetTitles || titles[2].length();
        }

      int lineNumbers[3] = { 
        ParseLineNumber(ParseOptionValue(options, _T("line1"))),
        ParseLineNumber(ParseOptionValue(options, _T("line2"))),
        ParseLineNumber(ParseOptionValue(options, _T("line3")))
      };
      
      // Use filenames as panel titles for titles not specified.
      // Note that this section could be removed if Merge ever
      // acquires the ability to set file panel titles individually.      
      if (!titles[0].length()) 
        titles[0] = arguments[0];
      if (!titles[1].length()) 
        titles[1] = arguments[1];
      if (bThreeWay && !titles[2].length()) 
        titles[2] = arguments[2];

      // Process common ancestor command line option.
      if (bThreeWay)
        {
          // Ensure the common ancestor argument is the middle of the
          // three input filename arguements.
          if (options.find(_T("a1")) != options.end())
            {
              std::swap(arguments[0], arguments[1]);          
              std::swap(titles[0], titles[1]);          
            }
          else if (options.find(_T("a3")) != options.end())
            {
              std::swap(arguments[2], arguments[1]);
              std::swap(titles[2], titles[1]);
            }
        }

      // Process swap command line option (this must happen 
      // after the common ancestor processing above).
      if (bSwap)
        {
          // Swap left and right files.
          std::swap(arguments[0], arguments[bTwoWay ? 1 : 2]);
          std::swap(titles[0], titles[bTwoWay ? 1 : 2]);
        }

      nResult = launchComparison(
        pApp,
        arguments,
        bTwoWay,
        bMaximized,
        bWait,
        bSetTitles,
        titles,
        lineNumbers,
        bMerge,
        bTestConflicts,
        bReadOnly);
    }  

  return int(nResult);
}

//------------------------------------------------------------------------------
//
// DESCRIPTION
//
// Araxis Merge v7.0 Perforce Integration (araxisp4diff)
//
// This file is part of the Araxis Merge product and associated documentation. 
// Please see www.araxis.com for further information. Email comments and
// suggestions to support@araxis.com.
//
//
// COPYRIGHT
//
// Copyright � 1999-2001 Araxis Ltd. All rights reserved except as expressly
// granted below.
//
// You are hereby granted a limited licence to use and modify this source code
// solely for the purposes of:
//
//    i) tailoring Araxis Merge to suit your requirements;
//   ii) for enhancing your understanding of the Araxis Merge Automation API;
//  iii) enabling integration of Araxis Merge with your application(s).
//
// No other rights are granted or implied by this limited licence. Please
// email support@araxis.com if you require additional rights.
//
//------------------------------------------------------------------------------


#include "stdafx.h"

#include "compareutil.h"

// The current module.
//

CComModule _Module;

// An object map. Not used for anything significant.
//

BEGIN_OBJECT_MAP(ObjectMap)
END_OBJECT_MAP()

// Main entry point.
//
int APIENTRY _tWinMain(
  HINSTANCE hInstance,
  HINSTANCE /*hPrevInstance*/,
  LPTSTR     /*lpCmdLine*/,
  int       /*nCmdShow*/)
{
  using namespace compareutil;

  ComInit com;

  // Set up the ATL stuff.
  _Module.Init(ObjectMap, hInstance);

  // Break the command line into options and arguments.
  LPCTSTR lpszCmdLine(GetCommandLine());
  StringSet options;
  StringVector arguments;

  ParseCommandLine(lpszCmdLine, options, arguments);

  // Strip off the first program name argument.
  if (arguments.size())
    arguments.erase(arguments.begin());
  if (arguments.size() > 3)
    arguments.erase(arguments.begin() + 3, arguments.end());
  
  Merge70::IApplicationPtr pApp = createApplicationObject();
  if (pApp == 0)
    return rcFailed;

  // Expand pathnames of filename arguments.
  if (!ExpandArgumentPaths(pApp, arguments))
    return rcFailed;
  
  // Examine simple command line options.
  const size_t nArguments(arguments.size());

  bool bHelp(false);
  bool bThreeWay(nArguments == 3);

  // Unlike compare, p4diff takes no options. If any are provided, display usage information.
  StringSetCI optIt = options.begin();
  if (optIt != options.end())
    bHelp = true;
    
  ReturnCode nResult(rcFailed);
  if (bHelp || nArguments == 0)
    {
      DisplayInfo(
        _T("Usage:\n\n")
        _T("araxisp4diff [/? | /h] <firstFile> [<secondFile>] [<thirdFile>]\n"));
      
      nResult = rcSucceeded;
    }
  else if (nArguments < 1)
    {
      DisplayError(_T("Not enough arguments for a two-way comparison."));
    }
  else
    {
      int lineNumbers[3] = { -1, -1, -1 };

      nResult = launchComparison(
        pApp,
        arguments,
        !bThreeWay,
        false/*maximized*/,
        true/*wait for exit*/,
        false/*no titles*/,
        StringVector(),
        lineNumbers,
        false/*don't merge*/,
        false/*don't test for conflicts*/,
        false/*don't mark files read-only*/);
    }  

  return int(nResult);
}

// Araxis Merge Automation API Script Example.
// Copyright (c) 2006-2009 Araxis Ltd. All rights reserved.
//
// Redistribution and use, with or without modification, are hereby permitted.
//
//
// Performs an image comparison between the two images specified as the first two 
// program arguments.
//
// Also displays the number of differences/changes between the two images. 
//
// To run from the command line as a console application:
//
//     cscript ImageComparison.js <image1> <image2>
//
// (All file paths should be fully-qualified.)


// Check the correct number of arguments were supplied.
if (WScript.Arguments.Length != 2)
{
  WScript.echo("<image1> <image2>");
  WScript.quit(1);
}

var image1 = WScript.Arguments(0);
var image2 = WScript.Arguments(1);

// Create an Application object.
var application = WScript.CreateObject("Merge70.Application");

// Make Merge active and visible.
application.Active = true;
application.Visible = true;

// Compare the images and give the user control over the image comparison window's lifetime.
var ic = application.ImageComparison;
ic.Compare(image1, image2);
ic.GiveUserControl();

// Display the number of differences between the two images.
WScript.Echo("Number of changes: " + ic.NumberOfChanges);
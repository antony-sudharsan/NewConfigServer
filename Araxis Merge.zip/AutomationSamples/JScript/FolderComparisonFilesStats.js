// Araxis Merge Automation API Script Example.
// Copyright (c) 2008-2009 Araxis Ltd. All rights reserved.
//
// Redistribution and use, with or without modification, are hereby permitted.
//
//
// Performs a folder comparison between two folder hierarchies,
// then saves an HTML report and sub-file reports for the folder comparison 
// as the third program argument. A summary of changed, inserted and removed 
// files is also output to the command line.
//
// To run from the command line as a console application:
//
//     cscript FolderComparisonFilesStats.js <folder1> <folder2> <reportFile>
//
// All file paths should be fully-qualified.


// Check the correct number of arguments were supplied.
if (WScript.Arguments.Length != 3)
  {
    WScript.echo("<folder1> <folder2> <reportpath>");
    WScript.quit(1);
  }

var folder1 = WScript.Arguments(0);
var folder2 = WScript.Arguments(1);
var reportPath = WScript.Arguments(2);

// The report type for the main report.
var folderReportType = "html";

// The report type for linked file comparison reports.
var fileReportType = "html";

// Create an Application object.
var application = WScript.CreateObject("Merge70.Application");

// Doing a full thorough comparison ensures we get full
// change statistics for changed, inserted, and removed files.
application.Preferences.Longs("ThoroughComparison") = 1; // fctAlwaysThorough

// Get a FolderComparison object via the Merge70 Application object.
var fc = application.FolderComparison;

// Start the comparison. This returns immediately, so...
fc.Compare(folder1, folder2);

// ...wait for folder comparison to complete.
while (fc.Busy)
{
	WScript.Sleep(1000);
}

// Now that the folder comparison is complete, we can generate the reports.

// Linked file comparison sub-reports use the HTML reporter.
application.Preferences.Strings("HTMLTwoWayFileReporter") = fileReportType;

// Generate linked file comparison sub-reports for changed, inserted, and
// removed files.
application.Preferences.Longs("HTMLGenerateReportsFor") = 2;

// Squish unchanged blocks of lines into just 5 lines of context.
application.Preferences.Longs("CompactUnchangedBlocks") = 1;
application.Preferences.Longs("CompactUnchangedBlocksContext") = 5;

// Generate the folder comparison report and file sub-reports.
fc.Report(folderReportType, 0, reportPath);


//----
// Display some additional statistics about the folder comparison.
//----

// Selected values from the FolderFileType enumeration.
var fftFirstFile = 0x0001; // The row contains a file in the first column.
var fftSecondFile = 0x0002; // The row contains a file in the second column.
var fftFirstFolder = 0x0010; // The row contains a folder in the first column.
var fftSecondFolder = 0x0020; // The row contains a file in the second column.
var fftFSChanged = 0x0100; // The files in the first and second columns have changed with respect to one-another.
var fftFirstFileNewer = 0x1000; // The file in the first column is newer than the other files.
var fftSecondFileNewer = 0x2000; // The file in the second column is newer than the other files.

var cChangedFiles = 0;
var cInsertedFiles = 0;
var cRemovedFiles = 0;

// Gather statistics and display them.
for (var i = 0; i < fc.NumberOfEntries; i++)
{
  var ft = fc.FileType(i);

  if (ft & fftFSChanged && ft & fftFirstFile && ft & fftSecondFile) 
  { 
    cChangedFiles++;
  }
  else if (ft & fftFirstFile && !(ft & fftSecondFile))
  {
    cRemovedFiles++;
  }
  else if (!(ft & fftFirstFile) && ft & fftSecondFile)
  {
    cInsertedFiles++;
  }
  else
  {
    WScript.echo("Ignored row with FileType " + fc.FileType(i));
  }
}

WScript.echo("\n\nBetween folders 1 and 2:")
WScript.echo(cChangedFiles + " changed files");
WScript.echo(cInsertedFiles + " inserted files");
WScript.echo(cRemovedFiles + " removed files");
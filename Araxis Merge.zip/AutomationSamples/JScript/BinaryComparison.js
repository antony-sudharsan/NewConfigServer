// Araxis Merge Automation API Script Example.
// Copyright (c) 2008-2009 Araxis Ltd. All rights reserved.
//
// Redistribution and use, with or without modification, are hereby permitted.
//
//
// Performs a binary comparison between the two files specified within the script 
// and loops through the results displaying, for both files, the recorded 
// number of changes for:
//  "Unchanged"
//  "Changed"
//  "Removed"
//  "Inserted" 
//
// To run from the command line as a console application:
//
//     cscript BinaryComparison.js
//
// All file paths should be fully-qualified.


// Create an Application object.
var application = WScript.CreateObject("Merge70.Application");

// Compare the binary files.
var comparison = application.BinaryComparison;
comparison.Compare(
  "c:\\program files\\araxis\\araxis merge\\test1.txt", 
  "c:\\program files\\araxis\\araxis merge\\test2.txt");
// Note: the files have be hard coded for display purposes. We recommended 
// that these files are passed as program arguments

// Display: 
// - the number of changes between the binary files
// - the number of bytes in the first file
// - the number of bytes in the second file

var c = comparison.NumberOfChanges(0);
WScript.echo("number of changes: " + c);
WScript.echo("number of bytes in first file:" + comparison.NumberOfBytes(0));
WScript.echo("number of bytes in second file:" + comparison.NumberOfBytes(1));

for (change = 0; change < c; ++change)
{
  var type = comparison.ChangeType(change);
  WScript.echo("change: " + change + " type: " + typeToText(type));
  var s0 = comparison.ChangeStartByte(change, 0, 0);
  var e0 = s0 + comparison.ChangeLength(change, 0, 0);
  var s1 = comparison.ChangeStartByte(change, 1, 0);
  var e1 = s1 + comparison.ChangeLength(change, 1, 0);
  WScript.echo(" range: " + s0 + "-" + e0 + ":" + s1 + "-" + e1);
}

function typeToText(type)
{
  switch (type)
  {
  case 0: return "Unchanged";
  case 1: return "Changed";
  case 2: return "Removed";
  case 3: return "Inserted";
  }
  return "<unknown>";
}
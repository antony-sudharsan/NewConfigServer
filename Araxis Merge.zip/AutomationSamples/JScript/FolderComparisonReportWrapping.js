// Araxis Merge Automation API Script Example.
// Copyright (c) 2008-2009 Araxis Ltd. All rights reserved.
//
// Redistribution and use, with or without modification, are hereby permitted.
//
//
// Performs a folder comparison between two folder hierarchies,
// then saves an HTML report for the folder comparison and the changed
// files within it to the folder specified as the third program argument.
//
// Word wrapping is turned on.
// 
// To run from the command line as a console application:
//
//     cscript FolderComparisonReportWrapping.js <folder1> <folder2> <reportFolder>
//
// (All file paths should be fully-qualified.)


// Check the correct number of arguments were supplied.
if (WScript.Arguments.Length != 3)
{  
  WScript.echo("<folder1> <folder2> <reportpath>");
  WScript.quit(1);
}

var folder1 = WScript.Arguments(0);
var folder2 = WScript.Arguments(1);
var reportPath = WScript.Arguments(2);

// The report type for the main report.
var folderReportType = "html";

// The report type for linked file comparison reports.
var fileReportType = "html";

// Create an Application object.
var application = WScript.CreateObject("Merge70.Application");

// Create a folder comparison object.
var fc = application.FolderComparison;

// Doing a full thorough comparison ensures we get full
// change statistics for changed, inserted, and removed files.
application.Preferences.Longs("ThoroughComparison") = 1; // fctAlwaysThorough

// Turn 'word' wrapping on and indicate where a line has been wrapped
application.Preferences.Longs("clFilePrintWordWrap") = 1
application.Preferences.Longs("clShowWrapIndicator") = 1

// Start the comparison. This returns immediately, so...
fc.Compare(folder1, folder2);

// ...wait for folder comparison to complete.
while (fc.Busy)
  {
    WScript.Sleep(1000);
  }

// Now that the folder comparison is complete, we can generate the reports.

// Linked file comparison sub-reports use the HTML reporter.
application.Preferences.Strings("HTMLTwoWayFileReporter") = fileReportType;

// Generate linked file comparison sub-reports for changed, inserted, and removed files.
application.Preferences.Longs("HTMLGenerateReportsFor") = 2; // gfChanged

// Squish unchanged blocks of lines into just 5 lines of context.
application.Preferences.Longs("CompactUnchangedBlocks") = 1;
application.Preferences.Longs("CompactUnchangedBlocksContext") = 5;

// Generate the folder comparison report and file sub-reports.
fc.Report(folderReportType, 0, reportPath);
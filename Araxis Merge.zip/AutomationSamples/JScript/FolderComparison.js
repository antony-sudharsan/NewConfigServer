// Araxis Merge Automation API Script Example.
// Copyright (c) 2008-2009 Araxis Ltd. All rights reserved.
//
// Redistribution and use, with or without modification, are hereby permitted.
//
//
// Performs a folder comparison between two folder hierarchies, giving the user
// control.
//
// To run from the command line as a console application:
//
//     cscript FolderComparison.js <folder1> <folder2>
//
// All file paths should be fully-qualified.


// Check the correct number of arguments were supplied.
if (WScript.Arguments.Length != 2)
{
  WScript.echo("<folder1> <folder2>");
  WScript.quit(1);
}

var folder1 = WScript.Arguments(0);
var folder2 = WScript.Arguments(1);

// Create an Application object.
var application = WScript.CreateObject("Merge70.Application");

// Make Merge active and visible.
application.Active = true;
application.Visible = true;

// Get a FolderComparison object.
var fc = application.FolderComparison;

// Start the comparison. This returns immediately.
fc.Compare(folder1, folder2);

// Give the user control of the folder comparison window's lifetime.
fc.GiveUserControl();



// Araxis Merge Automation API Script Example.
// Copyright (c) 2008-2009 Araxis Ltd. All rights reserved.
//
// Redistribution and use, with or without modification, are hereby permitted.
//
//
// Performs a file comparison between the two files specified as the first two 
// program arguments.
//
// To run from the command line as a console application:
//
//     cscript TextComparison.js <file1> <file2>
//
// All file paths should be fully-qualified.


// Check the correct number of arguments were supplied.
if (WScript.Arguments.Length != 2)
{
  WScript.echo("<file1> <file2>");
  WScript.quit(1);
}

var file1 = WScript.Arguments(0);
var file2 = WScript.Arguments(1);

// Create an Application object.
var application = WScript.CreateObject("Merge70.Application");

// Ensure Merge is visible to the user
application.Active = true;
application.Visible = true;

// Compare the files and give the user control over the text comparison
// window's lifetime.
var tc = application.TextComparison;
tc.Compare(file1, file2);
tc.GiveUserControl();
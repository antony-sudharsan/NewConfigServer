// Araxis Merge Automation API Script Example.
// Copyright (c) 2008-2009 Araxis Ltd. All rights reserved.
//
// Redistribution and use, with or without modification, are hereby permitted.
//
//
// Performs a file comparison between the two files specified as the first two 
// program arguments, and saves the comparison to a file. We recommend that you
// use the .cmp7 extension in the filename.
//
// To run from the command line as a console application:
//
//     cscript TextComparisonSavedComparison.js <file1> <file2> <savedComparisonFile>
//
// All file paths should be fully-qualified.


// Check the correct number of arguments were supplied.
if (WScript.Arguments.Length != 3)
{
  WScript.echo("<file1> <file2> <savedComparisonFile>");
  WScript.quit(1);
}

var file1 = WScript.Arguments(0);
var file2 = WScript.Arguments(1);
var savedComparisonFile = WScript.Arguments(2);

// Create an Application object.
var application = WScript.CreateObject("Merge70.Application");

// Compare the files.
var tc = application.TextComparison;
tc.Compare(file1, file2);

// Generate the saved comparison.
tc.SaveComparison(savedComparisonFile);
// Araxis Merge Automation API Script Example.
// Copyright (c) 2008 Araxis Ltd. All rights reserved.
//
// Redistribution and use, with or without modification, are hereby permitted.
//
//
// Performs a folder comparison between the two folders specified as the first two 
// program arguments (folder1 and folder2) and copies changed and inserted files into 
// the folder specified as the third program argument (folder3).
//
// To run from the command line:
//
//     cscript FolderComparisonCopyDifferences.js <folder1> <folder2> <folder3>
//
// All file paths should be fully-qualified.


// Check the correct number of arguments were supplied.
if (WScript.Arguments.Length != 3)
{
  WScript.echo("<folder1> <folder2> <folder3>");
  WScript.quit(1);
}

var folder1 = WScript.Arguments(0);
var folder2 = WScript.Arguments(1);
var folder3 = WScript.Arguments(2);

// Create an Application Object
var application = WScript.CreateObject("Merge70.Application");

// Perform thorough comparisons on files (remove if not appropriate).
application.Preferences.Longs("ThoroughComparison") = 1;

// Create a folder comparison object.
var fc = application.FolderComparison;

// Compare <folder1> and <folder2> and wait for it to complete.
fc.Compare(folder1, folder2);
while (fc.Busy)
{
  WScript.Sleep(1);
}

// Handy file type flags (copied from online help).
var fftUnknown          = 0x0000;
var fftFirstFile        = 0x0001;
var fftSecondFile       = 0x0002;
var fftThirdFile        = 0x0004;
var fftFirstFolder      = 0x0010;
var fftSecondFolder     = 0x0020;
var fftThirdFolder      = 0x0040;
var fftFSChanged        = 0x0100;
var fftSTChanged        = 0x0200;
var fftFirstFileNewer   = 0x1000;
var fftSecondFileNewer  = 0x2000;
var fftThirdFileNewer   = 0x4000;

// Create a file scripting object, used for file related actions
var fso = WScript.CreateObject("Scripting.FileSystemObject");

// Loop through the results, looking for inserted or changed files.
var rowCount = fc.NumberOfEntries;
for (row = 0; row < rowCount; ++row)
  {
    var type = fc.FileType(row);
    var isFileRow = type & (fftFirstFile | fftSecondFile);
    var isInserted = !(type & fftFirstFile) && (type & fftSecondFile);
    var isChanged = (type & fftFSChanged) && (type & fftFirstFile) && (type & fftSecondFile);

    if (isFileRow && (isInserted || isChanged))
      {
        // The source is the fully qualified path of the file in the second column.
        var sourceFile = fc.FullFilePath(row, 1);
        // The target is the same relative location, but under <folder3>.
        var targetFile = folder3 + "\\" + fc.FilePath(row, 1);
        WScript.Echo("Copying \"" + sourceFile + "\" to \"" + targetFile + "\"");
        // Ensure the target folder exists, creating it if required.
        makeFolderFor(fso, targetFile);
        // Copy the inserted or changed file.
        fso.CopyFile(sourceFile, targetFile, true);
      }
  }

WScript.Quit(0);

// Creates a folder at the given path.
function makeFolderFor(fso, path)
{
  var folder = fso.GetParentFolderName(path);
  if (folder != "")
    {
      if (!fso.FolderExists(folder))
        {
          makeFolderFor(fso, folder);
          fso.CreateFolder(folder);
        }
    }
}
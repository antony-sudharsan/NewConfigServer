// Araxis Merge Automation API Script Example.
// Copyright (c) 2008-2009 Araxis Ltd. All rights reserved.
//
// Redistribution and use, with or without modification, are hereby permitted.
//
//
// Adds two filters:
// Exclude *.obj and *.dll files
// Exclude debug and release folders
//
// To run from the command line as a console application:
//
//     cscript MiscAddFilter.js <newFilterName>


// Check the correct number of arguments were supplied.
if (WScript.Arguments.Length != 1)
{
  WScript.echo("<newFilterName>");
  WScript.quit(1);
}

// Create a WSript.Shell object. This provides functions to read system information and environment variables, work with the registry and manage shortcuts.
var shell = WScript.CreateObject("WScript.Shell");

// Create an Application object.
var app = WScript.CreateObject("Merge70.Application");
var prefs = app.Preferences;
var filters = prefs.Filters;

// Some constant values.
var pfInclude = 0;
var pfExclude = 1;
var pmFiles = 0;
var pmFolders = 1;
var pmFilesAndFolders = 2;

// Get the name for the filter from the command line.
var newFilterName = WScript.Arguments(0);

// Create a new filter.
var filter = WScript.CreateObject("Merge70.Filter");
filter.Name = newFilterName;

// Create, initialize, and add new filter patterns to the filter.
var filterPattern;

// Add a pattern to the filter.
filterPattern = WScript.CreateObject("Merge70.FilterPattern");
filterPattern.Match = pmFiles;
filterPattern.Filter = pfExclude;
filterPattern.Pattern = "*.obj;*.dll";
filter.Add(filterPattern);

// Add a pattern to the filter.
filterPattern = WScript.CreateObject("Merge70.FilterPattern");
filterPattern.Match = pmFolders;
filterPattern.Filter = pfExclude;
filterPattern.Pattern = "debug;release";
filter.Add(filterPattern);

// Add the new filter.
var filterIndex = filters.Store(filter);

// Make the new filter active (uncomment if required).
// filters.MakeActive(filterIndex);
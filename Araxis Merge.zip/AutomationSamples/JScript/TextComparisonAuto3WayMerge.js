// Araxis Merge Automation API Script Example.
// Copyright (c) 2008 Araxis Ltd. All rights reserved.
//
// Redistribution and use, with or without modification, are hereby permitted.
//
// A common task when using a source control system like Perforce is that of
// resolving conflicts at check-in time. Merge is typically used to perform the
// merging of two potentially conflicting revisions of a file into a common base
// revision. In most cases, there are no conflicts, and no manual processing is
// required. This example provides a way to perform the automatic merge while only
// presenting a merging user interface to the user when there are conflicts that
// require manual resolution
//
// Performs an automatic merge on the first three files provided on the
// command line.
//
//  - If there were no conflicts, it saves the resulting file to
//    the fourth file. 
//
//  - If there were conflicts, shows the comparison to the user and set 
//    the filename to which his/her merged work will be saved.
//
// To run from the command line as a console application:
//
//     cscript TextComparisonAuto3WayMerge.js <ancestorFile> <theirFile> <yourFile> <saveFile>
//
// (All file paths should be fully-qualified.)


// Check the correct number of arguments were supplied.
if (WScript.Arguments.Length != 4)
{
  WScript.echo("<ancestorFile> <theirFile> <yourFile> <saveFile>");
  WScript.quit(1);
}

var ancestorFile = fullyQualified(WScript.Arguments(0));
var theirFile = fullyQualified(WScript.Arguments(1));
var yourFile = fullyQualified(WScript.Arguments(2));
var saveFile = fullyQualified(WScript.Arguments(3));

// Create an Application object.
var application = WScript.CreateObject("Merge70.Application");

// Used to detect the text comparison window closing.
var waitingForClose = true;

// Compare the changes.
var tc = application.textComparison;
tc.Compare(theirFile, ancestorFile, yourFile);

// Perform an automatic merge into the ancestor file.
var conflictCount = tc.ThreeWayMerge();
if (conflictCount == 0)
  {
    // Save the merged file.
    tc.SaveFile(1, saveFile);
  }
else
  {
    // Show the text comparison window.
    application.Visible = true;
    tc.Visible = true;
    tc.SaveFileName = saveFile;
    tc.GiveUserControl();

    // NB: ConnectObject doesn't work with Merge builds earlier than #1801.
    WScript.ConnectObject(tc, "eventHandler_");

    // Wait for the text comparison to close
    while (waitingForClose)
      WScript.Sleep(500);
      
    WScript.DisconnectObject(tc);
  }

WScript.quit(0);

function eventHandler_Close()
{
  waitingForClose = false;
}

function fullyQualified(filename)
{
  var fso = WScript.CreateObject("Scripting.FileSystemObject");
  return fso.GetAbsolutePathName(filename);
}

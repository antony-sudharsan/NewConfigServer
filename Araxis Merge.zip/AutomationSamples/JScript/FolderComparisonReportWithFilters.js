// Araxis Merge Automation API Script Example.
// Copyright (c) 2008 Araxis Ltd. All rights reserved.
//
// Redistribution and use, with or without modification, are hereby permitted.
//
//
// Performs a folder comparison between two folder hierarchies,
// then saves an HTML report for the folder comparison and the changed
// files within it to the folder specified as the third program argument.
//
// To run from the command line as a console application:
//
//     cscript FolderComparisonReportWithFilters.js <folder1> <folder2> <reportFolder>
//
// All file paths should be fully-qualified.


// Check the correct number of arguments were supplied.
if (WScript.Arguments.Length != 3)
{
  WScript.echo("<folder1> <folder2> <reportpath>");
  WScript.quit(1);
}

var folder1 = WScript.Arguments(0);
var folder2 = WScript.Arguments(1);
var reportPath = WScript.Arguments(2);

// The report type for the main report.
var folderReportType = "html";

// The report type for linked file comparison reports.
var fileReportType = "html";

// Create an Application object.
var application = WScript.CreateObject("Merge70.Application");

// Create a folder comparison object.
var folderComparison = application.FolderComparison;

var shell = WScript.CreateObject("WScript.Shell");
var prefs = application.Preferences;
var filters = prefs.Filters;

// Some constant values.
var pfInclude = 0;
var pfExclude = 1;
var pmFiles = 0;
var pmFolders = 1;
var pmFilesAndFolders = 2;

// Get the name for the filter from the command line.
var newFilterName = 'SAMBA';

// Create a new filter.
var filter = WScript.CreateObject("Merge70.Filter");
filter.Name = newFilterName;

// Create, initialize, and add new filter patterns to the filter.
var filterPattern;

// Temporary pattern for Araxis testing
filterPattern = WScript.CreateObject("Merge70.FilterPattern");
filterPattern.Match = pmFilesAndFolders;
filterPattern.Filter = pfInclude;
filterPattern.Pattern = "*";
filter.Add(filterPattern);

filterPattern = WScript.CreateObject("Merge70.FilterPattern");
filterPattern.Match = pmFiles;
filterPattern.Filter = pfInclude;
filterPattern.Pattern = "*.calibration;*.simin";
filter.Add(filterPattern);
filterPattern.Match = pmFiles;
filterPattern.Filter = pfExclude;
filterPattern.Pattern = "*.bak;*.simout;*.tbl";
filter.Add(filterPattern);

// Add a pattern to the filter.
filterPattern = WScript.CreateObject("Merge70.FilterPattern");
filterPattern.Match = pmFolders;
filterPattern.Filter = pfExclude;
filterPattern.Pattern = "debug;release";
filter.Add(filterPattern);

// Add the new filter.
var filterIndex = filters.Store(filter);

// Make the new filter active (uncomment if required).
filters.MakeActive(filterIndex);

// Doing a full thorough comparison ensures we get full
// change statistics for changed, inserted, and removed files.
application.Preferences.Longs("ThoroughComparison") = 1; // fctAlwaysThorough

// Start the comparison. This returns immediately, so...
folderComparison.Compare(folder1, folder2);

// ...wait for folder comparison to complete.
while (folderComparison.Busy)
{
  WScript.Sleep(1000);
}

// Now that the folder comparison is complete, we can generate the reports.

// Linked file comparison sub-reports use the HTML reporter.
application.Preferences.Strings("HTMLTwoWayFileReporter") = fileReportType;

// Generate linked file comparison sub-reports for changed, inserted, and removed files.
application.Preferences.Longs("HTMLGenerateReportsFor") = 2; // gfChanged

// Squish unchanged blocks of lines into just 5 lines of context.
application.Preferences.Longs("CompactUnchangedBlocks") = 1;
application.Preferences.Longs("CompactUnchangedBlocksContext") = 5;

// Generate the folder comparison report and file sub-reports.
folderComparison.Report(folderReportType, 0, reportPath);
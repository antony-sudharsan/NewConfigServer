// Araxis Merge Automation API Script Example.
// Copyright (c) 2009 Araxis Ltd. All rights reserved.
//
// Redistribution and use, with or without modification, are hereby permitted.
//
// Sets up 4 regular expressions then performs a text comparison between 
// the two files specified as the first two program arguments, and saves 
// a comparison report to the name specified as the third program argument.
//
// Only one line of context is produced for blocks of unchanged text.
//
// To run from the command line as a console application:
//
//     cscript MiscTextExpressions.js <file1> <file2> <reportFile>
//
// All file paths should be fully-qualified.


// Check the correct number of arguments were supplied.
if (WScript.Arguments.Length != 3)
{
  WScript.echo("<file1> <file2> <reportFile>");
  WScript.quit(1);
}

var file1 = WScript.Arguments(0);
var file2 = WScript.Arguments(1);
var reportFile = WScript.Arguments(2);

// Create an Application object.
var application = WScript.CreateObject("Merge70.Application");

// Compare the files.
var tc = application.TextComparison;
tc.Compare(file1, file2);

// Reduce unchanged blocks of lines to just 1 line of context.
application.Preferences.Longs("CompactUnchangedBlocks") = 1;
application.Preferences.Longs("CompactUnchangedBlocksContext") = 1;

// Set up the first 4 regular expressions.
application.Preferences.Strings.Set('csRegexp0','^\d*$');
application.Preferences.Strings.Set('csRegexpDescription0', 'Description 1');
application.Preferences.Strings.Set('csRegexpSample0','1');

application.Preferences.Strings.Set('csRegexp1','<a.*">');
application.Preferences.Strings.Set('csRegexpDescription1', 'Attributes');
application.Preferences.Strings.Set('csRegexpSample1','<a name="L28-C2">');

application.Preferences.Strings.Set('csRegexp2','<FONT\s*COLOR="#\w*">');
application.Preferences.Strings.Set('csRegexpDescription2', 'Fonts');
application.Preferences.Strings.Set('csRegexpSample2','<FONT COLOR="#00647A">');

application.Preferences.Strings.Set('csRegexp3','<a \s1class="CheckInfoPointer"');
application.Preferences.Strings.Set('csRegexpDescription3', 'CheckInfoPointer');
application.Preferences.Strings.Set('csRegexpSample3','<a class="CheckInfoPointer"');

//Turn the expressions on (1 = on, 0 = off).
application.Preferences.Longs("clApplyRegexp0") = 1;
application.Preferences.Longs("clApplyRegexp1") = 1;
application.Preferences.Longs("clApplyRegexp2") = 1;
application.Preferences.Longs("clApplyRegexp3") = 1;

// You can set whether it causes the entire line to be ignored...
application.Preferences.Longs("clRegexpMatchWithinLine0") = 0;
application.Preferences.Longs("clRegexpMatchWithinLine1") = 0;

// ...or ignore just the matching characters.
application.Preferences.Longs("clRegexpMatchWithinLine2") = 1;
application.Preferences.Longs("clRegexpMatchWithinLine3") = 1;

// Available report types.
var xmlReport = "xml";
var htmlReport = "html";
var slideshowReport = "htmlslideshow";
var diffReport = "diff";


// Generate the file comparison report.
tc.Report(htmlReport, 0, reportFile);

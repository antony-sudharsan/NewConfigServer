// Araxis Merge Automation API Script Example.
// Copyright (c) 2008-2009 Araxis Ltd. All rights reserved.
//
// Redistribution and use, with or without modification, are hereby permitted.
//
//
// Performs a folder comparison between two folder hierarchies at a point in
// time (date) or at a specific changelist (changelist number) using the 
// Perforce source control system. It then generates a report for the folder
// comparison and the changed files within it.
//
// To run from the command line as a console application:
//
//     cscript FolderComparisonPerforceChangeListReport.js <depotpath> <changelist1> <changelist2> <reportpath> <folderreporttype> <filereporttype>
//
// All file paths should be fully-qualified.


// Check the correct number of arguments were supplied.
if (WScript.Arguments.Length != 6)
{
  WScript.echo("<depotpath> <changelist1> <changelist2> <reportpath> <folderreporttype> <filereporttype>");
  WScript.quit(1);
}

var depotPath = WScript.Arguments(0);
var changeList1 = WScript.Arguments(1);
var changeList2 = WScript.Arguments(2);
var reportName = WScript.Arguments(3);
var folderReportType = WScript.Arguments(4);
var fileReportType = WScript.Arguments(5);

// Create an Application object.
var application = WScript.CreateObject("Merge70.Application");

// Create a folder comparison object.
var folderComparison = application.FolderComparison;

var spec1 = depotPath + "@" + changeList1;
var spec2 = depotPath + "@" + changeList2;

// Doing a full thorough comparison ensures we get full
// change statistics for changed, inserted, and removed files.
application.Preferences.Longs("ThoroughComparison") = 1 /*fctAlwaysThorough*/;

folderComparison.Compare(spec1, spec2);

// Wait for folder comparison to complete.
while (folderComparison.Busy)
{
  WScript.Sleep(1000);
}

// File comparison sub-reports use the HTML reporter.
application.Preferences.Strings("HTMLTwoWayFileReporter") = fileReportType;

// Generate file comparison sub-reports for changed, inserted, and removed files.
application.Preferences.Longs("HTMLGenerateReportsFor") = 2/*gfChanged*/;

// Squish unchanged blocks of lines into just 5 lines of context.
application.Preferences.Longs("CompactUnchangedBlocks") = 1;
application.Preferences.Longs("CompactUnchangedBlocksContext") = 5;

// Generate the folder comparison report and file sub-reports.
folderComparison.Report(folderReportType, 0, reportName);
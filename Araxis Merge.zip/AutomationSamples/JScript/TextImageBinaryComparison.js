// Araxis Merge Automation API Script Example.
// Copyright (c) 2008 Araxis Ltd. All rights reserved.
//
// Redistribution and use, with or without modification, are hereby permitted.
//
//
// Opens the following hard coded comparisons:
//  - two text files (text1.txt and text2.txt)
//  - two image files (test1.png and test2.png)
//  - two binary files (araxisp4diff.exe and araxisp4winmrg.exe)
//
// Control of each comparison is passed to the user.
// 
// To run from the command line as a console application:
//
//     cscript TextImageBinaryComparison.js
//
// All file paths should be fully-qualified.

var shell = WScript.CreateObject("WScript.Shell");
var app = WScript.CreateObject("Merge70.Application");
app.Visible = true;

// Text file comparison.
var fc = app.CompareItems("c:\\program files\\araxis\\araxis merge\\test1.txt", "c:\\program files\\araxis\\araxis merge\\test2.txt");
fc.GiveUserControl();

// Image file comparison.
fc = app.CompareItems("c:\\program files\\araxis\\araxis merge\\test1.png", "c:\\program files\\araxis\\araxis merge\\test2.png");
fc.GiveUserControl();

// Binary file comparison.
fc = app.CompareItems("c:\\program files\\araxis\\araxis merge\\compare.exe", "c:\\program files\\araxis\\araxis merge\\consolecompare.exe");
fc.GiveUserControl();

// Araxis Merge Automation API Script Example.
// Copyright (c) 2008-2009 Araxis Ltd. All rights reserved.
//
// Redistribution and use, with or without modification, are hereby 
// permitted.
//
// Opens a 3-way comparison. places the text, "wibble" in pane 1,
// "wobble" in pane 2 and "wubble" in pane 3.
//
// Transfers control to the user, then displays the number of 
// unresolved conflicts in each file.
//
// To run from the command line as a console application:
//
//     cscript TextComparisonCountConflicts.js
//
// All file paths should be fully-qualified.


// Create an Application object and ensure Merge is visible
var application = WScript.CreateObject("Merge70.Application");
application.Visible = true;

// make a three-way text file comparison window visible.
var tc = application.TextComparison;
tc.Visible = true;
tc.ViewType = 2;

// Place text in each of the text panes.
tc.FileContent(0) = "wibble";
tc.FileContent(1) = "wobble";
tc.FileContent(2) = "wubble";

// Merge the two outer files in the three-way comparison into the
// central common ancestor file. 
tc.ThreeWayMerge();

// Give control over the lifetime of the comparison window to the
// user. Merge will not automatically close the window when outstanding
// automation references are released.
tc.GiveUserControl();

// Display conflict information.
WScript.Echo("Unresolved conflicts in file 0: " + tc.UnresolvedConflicts(0));
WScript.Echo("Unresolved conflicts in file 1: " + tc.UnresolvedConflicts(1));
WScript.Echo("Unresolved conflicts in file 2: " + tc.UnresolvedConflicts(2));
WScript.Echo("Unresolved conflicts in all files: " + tc.AllUnresolvedConflicts);
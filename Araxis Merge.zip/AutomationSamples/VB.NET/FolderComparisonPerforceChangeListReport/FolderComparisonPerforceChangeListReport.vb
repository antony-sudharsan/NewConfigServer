' Araxis Merge Automation API Script Example.
' Copyright (c) 2008-2009 Araxis Ltd. All rights reserved.
'
' Redistribution and use, with or without modification, are hereby permitted.
'
'
' Performs a folder comparison between two folder hierarchies at a point in
' time (date) or at a specific changelist (changelist number) using the 
' Perforce source control system. It then generates a report for the folder
' comparison and the changed files within it.
'
' To run from the command line as a console application:
'
'     FolderComparisonPerforceChangeListReport.js <depotpath> <changelist1> <changelist2> <reportpath> <folderreporttype> <filereporttype>
'
' All file paths should be fully-qualified.


Imports System
Imports System.Windows.Forms
Imports System.Threading

Module FolderComparisonPerforceChangeListReport

    Class FolderComparisonChangeListReport

        Public Sub Run(ByVal Args() As String)

            ' Check that the right number of arguments were supplied.
            If Args.Length <> 6 Then
                MessageBox.Show("<depotpath> <changelist1> <changelist2> <reportpath> <folderreporttype> <filereporttype>", "FolderComparisonPerforceChangeListReport")
                Return
            End If

            Dim depotPath As String = Args(0)
            Dim changeList1 As String = Args(1)
            Dim changeList2 As String = Args(2)
            Dim reportName As String = Args(3)
            Dim folderReportType As String = Args(4)
            Dim fileReportType As String = Args(5)

            ' Create an Application object.
            Dim application As New Merge70.ApplicationClass
            Dim folderComparison As Merge70.FolderComparison = application.FolderComparison

            Dim spec1 As String = depotPath + "@" + changeList1
            Dim spec2 As String = depotPath + "@" + changeList2

            ' Doing a full thorough comparison ensures we get full
            ' change statistics for changed, inserted, and removed files.
            application.Preferences.Longs("ThoroughComparison") = 1

            folderComparison.Compare(spec1, spec2, Nothing)

            ' Wait for folder comparison to complete...
            While folderComparison.Busy
                Thread.Sleep(1000)
            End While

            ' File comparison sub-reports use the HTML reporter.
            application.Preferences.Strings("HTMLTwoWayFileReporter") = fileReportType

            ' Generate file comparison sub-reports for changed, inserted, and removed files.
            application.Preferences.Longs("HTMLGenerateReportsFor") = 2 ' gfChanged

            ' Squish unchanged blocks of lines into just 5 lines of context.
            application.Preferences.Longs("CompactUnchangedBlocks") = 1
            application.Preferences.Longs("CompactUnchangedBlocksContext") = 5

            ' Generate the folder comparison report and file sub-reports.
            folderComparison.Report(folderReportType, Merge70.LineEndingStyle.lesCRLF, reportName)

        End Sub

    End Class

    Sub Main(ByVal Args() As String)
        Dim program As New FolderComparisonChangeListReport
        program.Run(Args)
    End Sub

End Module

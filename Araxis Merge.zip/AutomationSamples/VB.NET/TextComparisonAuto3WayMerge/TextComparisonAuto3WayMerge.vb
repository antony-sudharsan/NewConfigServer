' Araxis Merge Automation API Script Example.
' Copyright (c) 2008 Araxis Ltd. All rights reserved.
'
' Redistribution and use, with or without modification, are hereby permitted.
'
' A common task when using a source control system like Perforce is that of
' resolving conflicts at check-in time. Merge is typically used to perform the
' merging of two potentially conflicting revisions of a file into a common base
' revision. In most cases, there are no conflicts, and no manual processing is
' required. This example provides a way to perform the automatic merge while only
' presenting a merging user interface to the user when there are conflicts that
' require manual resolution
'
' Performs an automatic merge on the first three files provided on the
' command line.
'
'  - If there were no conflicts, it saves the resulting file to
'    the fourth file. 
'
'  - If there were conflicts, shows the comparison to the user and set 
'    the filename to which his/her merged work will be saved.
'
' To run from the command line:
'
'     TextComparisonAuto3WayMerge.js <ancestorFile> <theirFile> <yourFile> <saveFile>
'
' All file paths should be fully-qualified.

Imports System.Threading
Imports System.Windows.Forms

Module TextComparisonAuto3WayMerge

    Class TextComparisonAuto3WayMerge

        Public Sub Run(ByVal Args() As String)

            ' Check that the right number of arguments were supplied.
            If Args.Length <> 4 Then
                MessageBox.Show("<ancestorFile> <theirFile> <yourFile> <saveFile>", "TextComparisonAuto3WayMerge")
                Return
            End If

            Dim ancestorFile As String = FullyQualified(Args(0))
            Dim theirFile As String = FullyQualified(Args(1))
            Dim yourFile As String = FullyQualified(Args(2))
            Dim saveFile As String = FullyQualified(Args(3))

            ' Create an Application object.
            Dim application As New Merge70.ApplicationClass
            Dim tc As Merge70.TextComparison = application.TextComparison

            ' Compare the changes.
            tc.Compare(theirFile, ancestorFile, yourFile)

            ' Perform an automatic merge into the ancestor file.
            Dim conflictCount As Integer = tc.ThreeWayMerge()
            If conflictCount = 0 Then
                ' Save the merged file.
                tc.SaveFile(1, saveFile)
            Else
                ' Show the file comparison window.
                application.Visible = True
                application.Active = True
                tc.Visible = True
                tc.SaveFileName = saveFile
                tc.GiveUserControl()
                AddHandler tc.Closed, AddressOf fileComparison_Closed

                ' Wait for the file comparison to close
                While m_bClosed = False
                    Thread.Sleep(1000)
                End While

            End If

        End Sub

        Private Sub fileComparison_Closed()
            m_bClosed = True
        End Sub

        ''' <summary>
        ''' Returns the full path to the file.
        ''' </summary>
        ''' <param name="filename">The filename.</param>
        ''' <returns>The full path to the file.</returns>
        Private Function FullyQualified(ByVal filename As String) As String
            Try
                Dim i As New System.IO.FileInfo(filename)
                Return i.FullName
            Catch ex As Exception
                Return filename
            End Try
        End Function

        ' Used to detect the file comparison window closing.
        Dim m_bClosed As Boolean = False

    End Class

    Sub Main(ByVal Args() As String)
        Dim program As TextComparisonAuto3WayMerge = New TextComparisonAuto3WayMerge
        program.Run(Args)
    End Sub

End Module

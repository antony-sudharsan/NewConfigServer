// Araxis Merge Automation API Script Example.
// Copyright (c) 2008-2009 Araxis Ltd. All rights reserved.
//
// Redistribution and use, with or without modification, are hereby permitted.
//
//
// Performs a folder comparison between two folder hierarchies at a point in
// time (date) or at a specific changelist (changelist number) using the 
// Perforce source control system. It then generates a report for the folder
// comparison and the changed files within it.
//
// To run from the command line:
//
//     FolderComparisonPerforceChangeListReport.exe <depotpath> <changelist1> <changelist2> <reportpath> <folderreporttype> <filereporttype>
//
// All file paths should be fully-qualified.

using System;
using System.Windows.Forms;
using System.Threading;

namespace FolderComparisonPerforceChangeListReport
{
   class FolderComparisonPerforceChangeListReport
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main(string[] args)
        {
            new FolderComparisonPerforceChangeListReport().Run(args);
        }

        private void Run(string[] args)
        {
            // Performs a folder comparison between two folder hierarchies at a
            // point in time (date) or at a specific changelist (changelist number).
            // Then generates a report for the folder comparison and the changed
            // files within it.

            // Check that enough arguments were supplied.

            if (args.Length != 6)
            {
                MessageBox.Show("<depotpath> <changelist1> <changelist2> <reportpath> <folderreporttype> <filereporttype>", "FolderComparisonPerforceChangeListReport");
                return;
            }

            string depotPath = args[0];
            string changeList1 = args[1];
            string changeList2 = args[2];
            string reportName = args[3];
            string folderReportType = args[4];
            string fileReportType = args[5];

            // Create an Application object.

            Merge70.Application application = new Merge70.ApplicationClass();
            Merge70.FolderComparison folderComparison = application.FolderComparison;

            string spec1 = depotPath + "@" + changeList1;
            string spec2 = depotPath + "@" + changeList2;

            // Doing a full thorough comparison ensures we get full
            // change statistics for changed, inserted, and removed files.
            application.Preferences.Longs["ThoroughComparison"] = 1;

            folderComparison.Compare(spec1, spec2, null);

            // Wait for folder comparison to complete...
            while (folderComparison.Busy)
            {
                Thread.Sleep(1000);
            }

            // File comparison sub-reports use the HTML reporter.
            application.Preferences.Strings["HTMLTwoWayFileReporter"] = fileReportType;
            // Generate file comparison sub-reports for changed, inserted, and removed files.
            application.Preferences.Longs["HTMLGenerateReportsFor"] = 2/*gfChanged*/;

            // Squish unchanged blocks of lines into just 5 lines of context.
            application.Preferences.Longs["CompactUnchangedBlocks"] = 1;
            application.Preferences.Longs["CompactUnchangedBlocksContext"] = 5;

            // Generate the folder comparison report and file sub-reports.
            folderComparison.Report(folderReportType, Merge70.LineEndingStyle.lesCRLF, reportName);
        }
    }
}

// Araxis Merge Automation API Script Example.
// Copyright (c) 2008-2009 Araxis Ltd. All rights reserved.
//
// Redistribution and use, with or without modification, are hereby permitted.
//
//
// Performs an image comparison between the two images specified as the first two 
// program arguments.
//
// Also displays the number of differences/changes between the two images. 
//
// To run from the command line:
//
//     ImageComparison.exe <image1> <image2>
//
// All file paths should be fully-qualified.

using System;
using System.Collections;
using System.IO;
using System.Threading;
using System.Windows.Forms;

namespace ImageComparison
{
    public class ImageComparison
    {
        static void Main(string[] args)
        {
            new ImageComparison().Run(args);
        }

        private void Run(string[] args)
        {
            // Check that the correct number of arguments were supplied.
            if (args.Length != 2)
            {
                MessageBox.Show("<image1> <image2>", "ImageComparison");
                return;
            }

            string image1 = FullyQualified(args[0]);
            string image2 = FullyQualified(args[1]);

            // Create an Application object.
            Merge70.Application application = new Merge70.ApplicationClass();

            // Create the text comparison object.
            Merge70.ImageComparison ic = application.ImageComparison;

            // Ensure Merge is visible to the user.
            application.Active = true;
            application.Visible = true;

            // Compare the files and give the user control over the text comparison
            // windows' lifetime.
            ic.Compare(image1, image2, System.Reflection.Missing.Value);
            ic.GiveUserControl();

            MessageBox.Show("Number of changes: " + Convert.ToString(ic.get_NumberOfChanges(System.Reflection.Missing.Value))); 
        }

        /// <summary>
        /// Returns the full path of the directory or file.
        /// </summary>
        /// <param name="filename">The file.</param>
        /// <returns>The full path of the directory of file.</returns>
        private static string FullyQualified(string filename)
        {
            try
            {
                System.IO.FileInfo i = new System.IO.FileInfo(filename);
                return i.FullName;
            }
            catch (Exception)
            {
                return filename;
            }
        }
    }
}
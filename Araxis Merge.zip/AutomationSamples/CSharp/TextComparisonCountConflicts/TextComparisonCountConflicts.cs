// Araxis Merge Automation API Script Example.
// Copyright (c) 2008-2009 Araxis Ltd. All rights reserved.
//
// Redistribution and use, with or without modification, are hereby permitted.
//
//
// Opens a 3-way comparison. places the text, "wibble" in pane 1,
// "wobble" in pane 2 and "wubble" in pane 3.
//
// Transfers control to the user, then displays the number of 
// unresolved conflicts in each file.
//
// To run from the command line:
//
//     TextComparisonCountConflicts.exe
//
// All file paths should be fully-qualified.

using System;
using System.Collections;
using System.IO;
using System.Threading;
using System.Windows.Forms;

namespace TextComparisonCountConflicts
{
    public class TextComparisonCountConflicts
    {
        static void Main(string[] args)
        {
            new TextComparisonCountConflicts().Run(args);
        }

        private void Run(string[] args)
        {
            // Create an Application object.
            Merge70.Application application = new Merge70.ApplicationClass();

            // Create the text comparison object.
            Merge70.TextComparison tc = application.TextComparison;

            // Ensure Merge is visible to the user.
            application.Active = true;
            application.Visible = true;
            tc.ViewType = Merge70.FileViewType.fvtTwoWay;

            // Place text in each of the text panes.
            tc.set_FileContent(0,"wibble");
            tc.set_FileContent(1, "wobble");
            tc.set_FileContent(2, "wubble");

            // Merge the two outer files in the three-way comparison into the
            // central common ancestor file. 
            tc.ThreeWayMerge();

            // Give control over the lifetime of the comparison window to the
            // user. Merge will not automatically close the window when outstanding
            // automation references are released.
            tc.GiveUserControl();

            // Display conflict information.
            System.Console.WriteLine("Unresolved conflicts in file 0: " + Convert.ToString(tc.get_UnresolvedConflicts(0)));
            System.Console.WriteLine("Unresolved conflicts in file 1: " + Convert.ToString(tc.get_UnresolvedConflicts(1)));
            System.Console.WriteLine("Unresolved conflicts in file 2: " + Convert.ToString(tc.get_UnresolvedConflicts(2)));
            System.Console.WriteLine("Unresolved conflicts in all files: " + Convert.ToString(tc.AllUnresolvedConflicts));
        }
    }
}
// Araxis Merge Automation API Script Example.
// Copyright (c) 2008-2009 Araxis Ltd. All rights reserved.
//
// Redistribution and use, with or without modification, are hereby permitted.
//
//
// Performs a folder comparison between two folder hierarchies at a
// point in time (date) or at a specific changelist (changelist number).
// Then generates a report for the folder comparison and the changed
// files within it.
//
// To run from the command line:
//
//     FolderComparisonReportIfDifferences.exe <directory1> <directory2> <reportpath>
//
// All file paths should be fully-qualified.

using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.IO;

namespace FolderComparisonReportIfDifferences
{
    class FolderComparisonReportIfDifferences
    {
        static void Main(string[] args)
        {
            // Check that the correct number of arguments were supplied.
            if (args.Length != 3)
            {
                System.Console.WriteLine("<directory1> <directory2> <reportpath>", "FolderComparisonReportIfDifferences");
                return;
            }

            Merge70.Application application = new Merge70.ApplicationClass();
            Merge70.FolderComparison folderComparison = application.FolderComparison;

            string directory1 = FullyQualified(args[0]);
            string directory2 = FullyQualified(args[1]);
            string reportFile = FullyQualified(args[2]);

            application.Preferences.Longs["ThoroughComparison"] = 1;
            application.Preferences.Longs["ShowUnchanged"] = 0;

            folderComparison.Compare(directory1, directory2, null);

            // Wait for folder comparison to complete...
            while (folderComparison.Busy)
            {
                Thread.Sleep(1000);
            }

            bool hasChanges = false;
            int items = folderComparison.NumberOfEntries;

            for (int item = 0; item < items; ++item)
            {
                Merge70.FolderFileType type = folderComparison.get_FileType(item);
                bool change = 0 != (type & Merge70.FolderFileType.fftFSChanged);
                bool insertion = 0 == (type & (Merge70.FolderFileType.fftFirstFile | Merge70.FolderFileType.fftFirstFolder));
                bool removal = 0 == (type & (Merge70.FolderFileType.fftSecondFile | Merge70.FolderFileType.fftSecondFolder));
                System.Console.WriteLine("change {0} insertion {1} removal {2}", change, insertion, removal);

                if (change || insertion || removal)
                {
                    hasChanges = true;
                    break;
                }
            }

            if (hasChanges)
            {
                folderComparison.Report("html", 0, reportFile);
                SendTheReport(reportFile);
            }
            else
            {
                SendAllClearReport();
            }
        }

        /// <summary>
        /// Returns the full path of the directory or file.
        /// </summary>
        /// <param name="filename">The file.</param>
        /// <returns>The full path of the directory of file.</returns>
        private static string FullyQualified(string filename)
        {
            try
            {
                System.IO.FileInfo i = new System.IO.FileInfo(filename);
                return i.FullName;
            }
            catch (Exception)
            {
                return filename;
            }
        }

        static void SendTheReport(string reportFile)
        {
        }

        static void SendAllClearReport()
        {
        }

    }
}

// Araxis Merge Automation API Script Example.
// Copyright (c) 2008-2009 Araxis Ltd. All rights reserved.
//
// Redistribution and use, with or without modification, are hereby permitted.
//
//
// Perform an automatic merge on the first three files provided on the
// command line. If there were no conflicts, save the resulting file to
// the fourth file. If there were conflicts, show the comparison to the
// user and set the filename that his/her merged work will be saved to.
//
// To run from the command line:
//
//     TextComparisonAuto3WayMerge.exe <ancestorFile> <theirFile> <yourFile> <saveFile>
//
// All file paths should be fully-qualified.

using System;
using System.Collections;
using System.IO;
using System.Threading;
using System.Windows.Forms;

namespace TextComparisonAuto3WayMerge
{
	public class TextComparisonAuto3WayMerge
	{
		static void Main(string[] args) 
		{
		  new TextComparisonAuto3WayMerge().Run(args);
		}
		
		private void Run(string[] args)
		{
          // Check that the correct number of arguments were supplied.
		  if (args.Length != 4)
		    {
		      MessageBox.Show("<ancestorFile> <theirFile> <yourFile> <saveFile>", "TextComparisonAuto3WayMerge");
		      return;
		    }

      string ancestorFile = FullyQualified(args[0]);
      string theirFile = FullyQualified(args[1]);
      string yourFile = FullyQualified(args[2]);
      string saveFile = FullyQualified(args[3]);      
            
      // Create an Application object.
      Merge70.Application application = new Merge70.ApplicationClass();
      Merge70.TextComparison fileComparison = application.TextComparison;
      
      // Compare the changes.
      fileComparison.Compare(theirFile, ancestorFile, yourFile);
      
      // Perform an automatic merge into the ancestor file.
     int conflictCount = fileComparison.ThreeWayMerge();
      if (conflictCount == 0)
        {
          // Save the merged file.
          fileComparison.SaveFile(1, saveFile);
        }
      else
        {
          // Show the file comparison window.
          application.Visible = true;
          application.Active = true;
          fileComparison.Visible = true;
          fileComparison.SaveFileName = saveFile;
          fileComparison.GiveUserControl();
          fileComparison.Closed += new Merge70._FileComparisonEvents_ClosedEventHandler(fileComparison_Close);
     
          // Wait for the file comparison to close
          while (!m_bClosed)
            Thread.Sleep(1000);
        }      		
		}
		
		private void fileComparison_Close()
		{
		  m_bClosed = true;
		}

    /// <summary>
    /// Returns the full path of the directory or file.
    /// </summary>
    /// <param name="filename">The file.</param>
    /// <returns>The full path of the directory of file.</returns>
    private string FullyQualified(string filename)
    {
      try
        {
          System.IO.FileInfo i = new System.IO.FileInfo(filename);
          return i.FullName;
        }
      catch (Exception)
        {
          return filename;
        }
    }

    // Used to detect the file comparison window closing.
    private bool m_bClosed = false;
	}
}

// Araxis Merge Automation API Script Example.
// Copyright (c) 2008-2009 Araxis Ltd. All rights reserved.
//
// Redistribution and use, with or without modification, are hereby permitted.
//
//
// Performs a file comparison between the two files specified as the first two 
// program arguments.
//
// To run from the command line:
//
//     TextComparison.exe <file1> <file2>
//
// All file paths should be fully-qualified.

using System;
using System.Collections;
using System.IO;
using System.Threading;
using System.Windows.Forms;

namespace TextComparison
{
    public class TextComparison
    {
        static void Main(string[] args)
        {
            new TextComparison().Run(args);
        }

        private void Run(string[] args)
        {
            // Check that the correct number of arguments were supplied.
            if (args.Length != 2)
            {
                MessageBox.Show("<file1> <file2>", "TextComparison");
                return;
            }

            string file1 = FullyQualified(args[0]);
            string file2 = FullyQualified(args[1]);

            // Create an Application object.
            Merge70.Application application = new Merge70.ApplicationClass();

            // Create the text comparison object.
            Merge70.TextComparison tc = application.TextComparison;

            // Ensure Merge is visible to the user.
            application.Active = true;
            application.Visible = true;

            // Compare the files and give the user control over the text comparison
            // windows' lifetime.
            tc.Compare(file1, file2, System.Reflection.Missing.Value);
            tc.GiveUserControl();
        }

        /// <summary>
        /// Returns the full path of the directory or file.
        /// </summary>
        /// <param name="filename">The file.</param>
        /// <returns>The full path of the directory of file.</returns>
        private static string FullyQualified(string filename)
        {
            try
            {
                System.IO.FileInfo i = new System.IO.FileInfo(filename);
                return i.FullName;
            }
            catch (Exception)
            {
                return filename;
            }
        }
    }
}
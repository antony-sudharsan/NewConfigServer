// Araxis Merge Automation API Script Example.
// Copyright (c) 2008-2009 Araxis Ltd. All rights reserved.
//
// Redistribution and use, with or without modification, are hereby permitted.
//
//
// Performs a binary comparison between the two files specified within the script 
// and loops through the results displaying, for both files, the recorded 
// number of changes for:
//  "Unchanged"
//  "Changed"
//  "Removed"
//  "Inserted" 
//
// To run from the command line:
//
//     BinaryComparison.exe
//
// All file paths should be fully-qualified.

using System;
using System.Collections;
using System.IO;
using System.Threading;
using System.Windows.Forms;

namespace BinaryComparison
{
    public class BinaryComparison
    {
        static void Main(string[] args)
        {
            new BinaryComparison().Run(args);
        }

        private void Run(string[] args)
        {
            // Create an Application object.
            Merge70.Application application = new Merge70.ApplicationClass();

            // Create the text comparison object.
            Merge70.BinaryComparison bc = application.BinaryComparison;

            // The files have be hard coded for display purposes. We recommended 
            // that these files are passed as program arguments
            bc.Compare("c:\\program files\\araxis\\araxis merge\\test1.txt",
                        "c:\\program files\\araxis\\araxis merge\\test2.txt",
                        System.Reflection.Missing.Value);

            // Display: 
            // - the number of changes between the binary files
            // - the number of bytes in the first file
            // - the number of bytes in the second file

            int c = bc.get_NumberOfChanges(0);
            System.Console.WriteLine("number of changes: " + Convert.ToString(c));
            System.Console.WriteLine("number of bytes in first file: " + Convert.ToString(bc.get_NumberOfBytes(0)));
            System.Console.WriteLine("number of bytes in second file: " + Convert.ToString(bc.get_NumberOfBytes(1)));

            for (int change = 0; change < c; ++change)
            {
                Merge70.ChangeStyle type = bc.get_ChangeType(change, System.Reflection.Missing.Value);
                Console.WriteLine("change: " + Convert.ToString(change) + " type: " + typeToText(type));

                string s0 = Convert.ToString(bc.get_ChangeStartByte(change,0,0));
                string e0 = s0 + Convert.ToString(bc.get_ChangeLength(change,0,0));
                string s1 = Convert.ToString(bc.get_ChangeStartByte(change, 1, 0));
                string e1 = s1 + Convert.ToString(bc.get_ChangeLength(change, 1, 0));
                System.Console.WriteLine(" range: " + s0 + "-" + e0 + ":" + s1 + "-" + e1);
            }
     
        }

        static string typeToText(Merge70.ChangeStyle type)
        {
            switch (type)
            {
                case Merge70.ChangeStyle.cstSame: return "Unchanged";
                case Merge70.ChangeStyle.cstChange: return "Changed";
                case Merge70.ChangeStyle.cstRemove: return "Removed";
                case Merge70.ChangeStyle.cstInsert: return "Inserted";
            }
            return "<unknown>";
        }

    }
}
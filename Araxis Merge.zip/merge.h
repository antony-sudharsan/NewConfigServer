

/* this ALWAYS GENERATED file contains the definitions for the interfaces */


 /* File created by MIDL compiler version 7.00.0555 */
/* at Wed Jan 20 11:09:47 2010
 */
/* Compiler settings for .\merge.idl:
    Oicf, W1, Zp8, env=Win32 (32b run), target_arch=X86 7.00.0555 
    protocol : dce , ms_ext, c_ext
    error checks: allocation ref bounds_check enum stub_data 
    VC __declspec() decoration level: 
         __declspec(uuid()), __declspec(selectany), __declspec(novtable)
         DECLSPEC_UUID(), MIDL_INTERFACE()
*/
/* @@MIDL_FILE_HEADING(  ) */

#pragma warning( disable: 4049 )  /* more than 64k source lines */


/* verify that the <rpcndr.h> version is high enough to compile this file*/
#ifndef __REQUIRED_RPCNDR_H_VERSION__
#define __REQUIRED_RPCNDR_H_VERSION__ 440
#endif

#include "rpc.h"
#include "rpcndr.h"

#ifndef __merge_h__
#define __merge_h__

#if defined(_MSC_VER) && (_MSC_VER >= 1020)
#pragma once
#endif

/* Forward Declarations */ 

#ifndef __IPreferences_FWD_DEFINED__
#define __IPreferences_FWD_DEFINED__
typedef interface IPreferences IPreferences;
#endif 	/* __IPreferences_FWD_DEFINED__ */


#ifndef __ICommonUI_FWD_DEFINED__
#define __ICommonUI_FWD_DEFINED__
typedef interface ICommonUI ICommonUI;
#endif 	/* __ICommonUI_FWD_DEFINED__ */


#ifndef __IApplication_FWD_DEFINED__
#define __IApplication_FWD_DEFINED__
typedef interface IApplication IApplication;
#endif 	/* __IApplication_FWD_DEFINED__ */


#ifndef __IApplication2_FWD_DEFINED__
#define __IApplication2_FWD_DEFINED__
typedef interface IApplication2 IApplication2;
#endif 	/* __IApplication2_FWD_DEFINED__ */


#ifndef __IApplication3_FWD_DEFINED__
#define __IApplication3_FWD_DEFINED__
typedef interface IApplication3 IApplication3;
#endif 	/* __IApplication3_FWD_DEFINED__ */


#ifndef __IUriInformation_FWD_DEFINED__
#define __IUriInformation_FWD_DEFINED__
typedef interface IUriInformation IUriInformation;
#endif 	/* __IUriInformation_FWD_DEFINED__ */


#ifndef __IWindowHandle_FWD_DEFINED__
#define __IWindowHandle_FWD_DEFINED__
typedef interface IWindowHandle IWindowHandle;
#endif 	/* __IWindowHandle_FWD_DEFINED__ */


#ifndef __IStringPreferences_FWD_DEFINED__
#define __IStringPreferences_FWD_DEFINED__
typedef interface IStringPreferences IStringPreferences;
#endif 	/* __IStringPreferences_FWD_DEFINED__ */


#ifndef __ILongPreferences_FWD_DEFINED__
#define __ILongPreferences_FWD_DEFINED__
typedef interface ILongPreferences ILongPreferences;
#endif 	/* __ILongPreferences_FWD_DEFINED__ */


#ifndef __IDoublePreferences_FWD_DEFINED__
#define __IDoublePreferences_FWD_DEFINED__
typedef interface IDoublePreferences IDoublePreferences;
#endif 	/* __IDoublePreferences_FWD_DEFINED__ */


#ifndef __IComparison_FWD_DEFINED__
#define __IComparison_FWD_DEFINED__
typedef interface IComparison IComparison;
#endif 	/* __IComparison_FWD_DEFINED__ */


#ifndef __IFileComparison_FWD_DEFINED__
#define __IFileComparison_FWD_DEFINED__
typedef interface IFileComparison IFileComparison;
#endif 	/* __IFileComparison_FWD_DEFINED__ */


#ifndef __ITextComparison_FWD_DEFINED__
#define __ITextComparison_FWD_DEFINED__
typedef interface ITextComparison ITextComparison;
#endif 	/* __ITextComparison_FWD_DEFINED__ */


#ifndef __ITextComparison2_FWD_DEFINED__
#define __ITextComparison2_FWD_DEFINED__
typedef interface ITextComparison2 ITextComparison2;
#endif 	/* __ITextComparison2_FWD_DEFINED__ */


#ifndef __IBinaryComparison_FWD_DEFINED__
#define __IBinaryComparison_FWD_DEFINED__
typedef interface IBinaryComparison IBinaryComparison;
#endif 	/* __IBinaryComparison_FWD_DEFINED__ */


#ifndef __IImageComparison_FWD_DEFINED__
#define __IImageComparison_FWD_DEFINED__
typedef interface IImageComparison IImageComparison;
#endif 	/* __IImageComparison_FWD_DEFINED__ */


#ifndef __IFilters_FWD_DEFINED__
#define __IFilters_FWD_DEFINED__
typedef interface IFilters IFilters;
#endif 	/* __IFilters_FWD_DEFINED__ */


#ifndef __IFilter_FWD_DEFINED__
#define __IFilter_FWD_DEFINED__
typedef interface IFilter IFilter;
#endif 	/* __IFilter_FWD_DEFINED__ */


#ifndef __IFilterPattern_FWD_DEFINED__
#define __IFilterPattern_FWD_DEFINED__
typedef interface IFilterPattern IFilterPattern;
#endif 	/* __IFilterPattern_FWD_DEFINED__ */


#ifndef __IThreeWayMergeActions_FWD_DEFINED__
#define __IThreeWayMergeActions_FWD_DEFINED__
typedef interface IThreeWayMergeActions IThreeWayMergeActions;
#endif 	/* __IThreeWayMergeActions_FWD_DEFINED__ */


#ifndef __IThreeWayMergeAction_FWD_DEFINED__
#define __IThreeWayMergeAction_FWD_DEFINED__
typedef interface IThreeWayMergeAction IThreeWayMergeAction;
#endif 	/* __IThreeWayMergeAction_FWD_DEFINED__ */


#ifndef __IFileComparisonEvents_FWD_DEFINED__
#define __IFileComparisonEvents_FWD_DEFINED__
typedef interface IFileComparisonEvents IFileComparisonEvents;
#endif 	/* __IFileComparisonEvents_FWD_DEFINED__ */


#ifndef ___FileComparisonEvents_FWD_DEFINED__
#define ___FileComparisonEvents_FWD_DEFINED__
typedef interface _FileComparisonEvents _FileComparisonEvents;
#endif 	/* ___FileComparisonEvents_FWD_DEFINED__ */


#ifndef __IFolderComparisonEvents_FWD_DEFINED__
#define __IFolderComparisonEvents_FWD_DEFINED__
typedef interface IFolderComparisonEvents IFolderComparisonEvents;
#endif 	/* __IFolderComparisonEvents_FWD_DEFINED__ */


#ifndef ___FolderComparisonEvents_FWD_DEFINED__
#define ___FolderComparisonEvents_FWD_DEFINED__
typedef interface _FolderComparisonEvents _FolderComparisonEvents;
#endif 	/* ___FolderComparisonEvents_FWD_DEFINED__ */


#ifndef __IFolderComparison_FWD_DEFINED__
#define __IFolderComparison_FWD_DEFINED__
typedef interface IFolderComparison IFolderComparison;
#endif 	/* __IFolderComparison_FWD_DEFINED__ */


#ifndef __IEncoding_FWD_DEFINED__
#define __IEncoding_FWD_DEFINED__
typedef interface IEncoding IEncoding;
#endif 	/* __IEncoding_FWD_DEFINED__ */


#ifndef __IEncodings_FWD_DEFINED__
#define __IEncodings_FWD_DEFINED__
typedef interface IEncodings IEncodings;
#endif 	/* __IEncodings_FWD_DEFINED__ */


#ifndef __TextComparison_FWD_DEFINED__
#define __TextComparison_FWD_DEFINED__

#ifdef __cplusplus
typedef class TextComparison TextComparison;
#else
typedef struct TextComparison TextComparison;
#endif /* __cplusplus */

#endif 	/* __TextComparison_FWD_DEFINED__ */


#ifndef __BinaryComparison_FWD_DEFINED__
#define __BinaryComparison_FWD_DEFINED__

#ifdef __cplusplus
typedef class BinaryComparison BinaryComparison;
#else
typedef struct BinaryComparison BinaryComparison;
#endif /* __cplusplus */

#endif 	/* __BinaryComparison_FWD_DEFINED__ */


#ifndef __ImageComparison_FWD_DEFINED__
#define __ImageComparison_FWD_DEFINED__

#ifdef __cplusplus
typedef class ImageComparison ImageComparison;
#else
typedef struct ImageComparison ImageComparison;
#endif /* __cplusplus */

#endif 	/* __ImageComparison_FWD_DEFINED__ */


#ifndef __FolderComparison_FWD_DEFINED__
#define __FolderComparison_FWD_DEFINED__

#ifdef __cplusplus
typedef class FolderComparison FolderComparison;
#else
typedef struct FolderComparison FolderComparison;
#endif /* __cplusplus */

#endif 	/* __FolderComparison_FWD_DEFINED__ */


#ifndef __Preferences_FWD_DEFINED__
#define __Preferences_FWD_DEFINED__

#ifdef __cplusplus
typedef class Preferences Preferences;
#else
typedef struct Preferences Preferences;
#endif /* __cplusplus */

#endif 	/* __Preferences_FWD_DEFINED__ */


#ifndef __Filters_FWD_DEFINED__
#define __Filters_FWD_DEFINED__

#ifdef __cplusplus
typedef class Filters Filters;
#else
typedef struct Filters Filters;
#endif /* __cplusplus */

#endif 	/* __Filters_FWD_DEFINED__ */


#ifndef __ThreeWayMergeActions_FWD_DEFINED__
#define __ThreeWayMergeActions_FWD_DEFINED__

#ifdef __cplusplus
typedef class ThreeWayMergeActions ThreeWayMergeActions;
#else
typedef struct ThreeWayMergeActions ThreeWayMergeActions;
#endif /* __cplusplus */

#endif 	/* __ThreeWayMergeActions_FWD_DEFINED__ */


#ifndef __ThreeWayMergeAction_FWD_DEFINED__
#define __ThreeWayMergeAction_FWD_DEFINED__

#ifdef __cplusplus
typedef class ThreeWayMergeAction ThreeWayMergeAction;
#else
typedef struct ThreeWayMergeAction ThreeWayMergeAction;
#endif /* __cplusplus */

#endif 	/* __ThreeWayMergeAction_FWD_DEFINED__ */


#ifndef __Filter_FWD_DEFINED__
#define __Filter_FWD_DEFINED__

#ifdef __cplusplus
typedef class Filter Filter;
#else
typedef struct Filter Filter;
#endif /* __cplusplus */

#endif 	/* __Filter_FWD_DEFINED__ */


#ifndef __FilterPattern_FWD_DEFINED__
#define __FilterPattern_FWD_DEFINED__

#ifdef __cplusplus
typedef class FilterPattern FilterPattern;
#else
typedef struct FilterPattern FilterPattern;
#endif /* __cplusplus */

#endif 	/* __FilterPattern_FWD_DEFINED__ */


#ifndef __Application_FWD_DEFINED__
#define __Application_FWD_DEFINED__

#ifdef __cplusplus
typedef class Application Application;
#else
typedef struct Application Application;
#endif /* __cplusplus */

#endif 	/* __Application_FWD_DEFINED__ */


#ifndef __StringPreferences_FWD_DEFINED__
#define __StringPreferences_FWD_DEFINED__

#ifdef __cplusplus
typedef class StringPreferences StringPreferences;
#else
typedef struct StringPreferences StringPreferences;
#endif /* __cplusplus */

#endif 	/* __StringPreferences_FWD_DEFINED__ */


#ifndef __LongPreferences_FWD_DEFINED__
#define __LongPreferences_FWD_DEFINED__

#ifdef __cplusplus
typedef class LongPreferences LongPreferences;
#else
typedef struct LongPreferences LongPreferences;
#endif /* __cplusplus */

#endif 	/* __LongPreferences_FWD_DEFINED__ */


#ifndef __DoublePreferences_FWD_DEFINED__
#define __DoublePreferences_FWD_DEFINED__

#ifdef __cplusplus
typedef class DoublePreferences DoublePreferences;
#else
typedef struct DoublePreferences DoublePreferences;
#endif /* __cplusplus */

#endif 	/* __DoublePreferences_FWD_DEFINED__ */


#ifndef __Encoding_FWD_DEFINED__
#define __Encoding_FWD_DEFINED__

#ifdef __cplusplus
typedef class Encoding Encoding;
#else
typedef struct Encoding Encoding;
#endif /* __cplusplus */

#endif 	/* __Encoding_FWD_DEFINED__ */


#ifndef __Encodings_FWD_DEFINED__
#define __Encodings_FWD_DEFINED__

#ifdef __cplusplus
typedef class Encodings Encodings;
#else
typedef struct Encodings Encodings;
#endif /* __cplusplus */

#endif 	/* __Encodings_FWD_DEFINED__ */


/* header files for imported files */
#include "vfsplugin.h"

#ifdef __cplusplus
extern "C"{
#endif 


/* interface __MIDL_itf_merge_0000_0000 */
/* [local] */ 
























extern RPC_IF_HANDLE __MIDL_itf_merge_0000_0000_v0_0_c_ifspec;
extern RPC_IF_HANDLE __MIDL_itf_merge_0000_0000_v0_0_s_ifspec;


#ifndef __Merge70_LIBRARY_DEFINED__
#define __Merge70_LIBRARY_DEFINED__

/* library Merge70 */
/* [helpstring][version][uuid] */ 

typedef /* [helpstring] */ 
enum _FileType
    {	ftUnknown	= 0,
	ftFile	= ( ftUnknown + 1 ) ,
	ftFolder	= ( ftFile + 1 ) 
    } 	FileType;

typedef /* [helpstring] */ 
enum _Whitespace
    {	wsIgnoreNone	= 0,
	wsIgnoreAll	= 1,
	wsIgnoreLeading	= 2,
	wsIgnoreTrailing	= 4,
	wsIgnoreConsecutive	= 8
    } 	Whitespace;

typedef /* [helpstring] */ 
enum _ChangeStyle
    {	cstSame	= 0,
	cstInsert	= ( cstSame + 1 ) ,
	cstRemove	= ( cstInsert + 1 ) ,
	cstChange	= ( cstRemove + 1 ) 
    } 	ChangeStyle;

typedef /* [helpstring] */ 
enum _FolderComparisonThoroughness
    {	fctCheckTimestampsAndSizes	= 0,
	fctAlwaysThorough	= ( fctCheckTimestampsAndSizes + 1 ) ,
	fctThoroughOnlyIfTimestampsAndSizesDifferent	= ( fctAlwaysThorough + 1 ) 
    } 	FolderComparisonThoroughness;

typedef /* [helpstring] */ 
enum _FileViewType
    {	fvtNone	= 0,
	fvtTwoWay	= ( fvtNone + 1 ) ,
	fvtThreeWay	= ( fvtTwoWay + 1 ) 
    } 	FileViewType;

typedef /* [helpstring] */ 
enum _FileComparisonError
    {	fceNoError	= 0,
	fceOutOfMemory	= ( fceNoError + 1 ) ,
	fceFile1NotFound	= ( fceOutOfMemory + 1 ) ,
	fceFile2NotFound	= ( fceFile1NotFound + 1 ) ,
	fceCantReadFile1	= ( fceFile2NotFound + 1 ) ,
	fceCantReadFile2	= ( fceCantReadFile1 + 1 ) ,
	fceCantGetFile1Info	= ( fceCantReadFile2 + 1 ) ,
	fceCantGetFile2Info	= ( fceCantGetFile1Info + 1 ) ,
	fceInvalidSetup	= ( fceCantGetFile2Info + 1 ) ,
	fceAlreadyDiffed	= ( fceInvalidSetup + 1 ) ,
	fceChangeTableError	= ( fceAlreadyDiffed + 1 ) ,
	fceNeitherFileFound	= ( fceChangeTableError + 1 ) ,
	fceInternalError	= ( fceNeitherFileFound + 1 ) ,
	fceFile3NotFound	= ( fceInternalError + 1 ) ,
	fceCantReadFile3	= ( fceFile3NotFound + 1 ) ,
	fceCantGetFile3Info	= ( fceCantReadFile3 + 1 ) 
    } 	FileComparisonError;

typedef /* [helpstring] */ 
enum _FileComparisonResult
    {	fcrSame	= 0,
	fcrDifferent	= ( fcrSame + 1 ) ,
	fcrError	= ( fcrDifferent + 1 ) 
    } 	FileComparisonResult;

typedef /* [helpstring] */ 
enum _FolderComparisonResult
    {	flcrNoError	= 0,
	flcrError	= 0x1,
	flcrFirstFolderNotFound	= 0x2,
	flcrSecondFolderNotFound	= 0x4,
	flcrThirdFolderNotFound	= 0x8
    } 	FolderComparisonResult;

typedef /* [helpstring] */ 
enum _FolderFileType
    {	fftUnknown	= 0,
	fftFirstFile	= 0x1,
	fftSecondFile	= 0x2,
	fftThirdFile	= 0x4,
	fftFirstFolder	= 0x10,
	fftSecondFolder	= 0x20,
	fftThirdFolder	= 0x40,
	fftFSChanged	= 0x100,
	fftSTChanged	= 0x200,
	fftFirstFileNewer	= 0x1000,
	fftSecondFileNewer	= 0x2000,
	fftThirdFileNewer	= 0x4000
    } 	FolderFileType;

typedef /* [helpstring] */ 
enum _PageOrientation
    {	poPortrait	= 0,
	poLandscape	= ( poPortrait + 1 ) 
    } 	PageOrientation;

typedef /* [helpstring] */ 
enum _LineEndingStyle
    {	lesCRLF	= 0,
	lesCR	= ( lesCRLF + 1 ) ,
	lesLF	= ( lesCR + 1 ) ,
	lesPreserve	= ( lesLF + 1 ) 
    } 	LineEndingStyle;

typedef /* [helpstring] */ 
enum _ThreeWayMergeActionType
    {	twmaMergeChange	= 0,
	twmaMarkConflict	= ( twmaMergeChange + 1 ) 
    } 	ThreeWayMergeActionType;

typedef /* [helpstring] */ 
enum _FolderSortOrder
    {	fsoInvalid	= 0,
	fsoOrderShift	= 0,
	fsoTypeShift	= 2,
	fsoColumnShift	= 4,
	fsoType2Shift	= 6,
	fsoOrderMask	= ( 3 << fsoOrderShift ) ,
	fsoTypeMask	= ( 3 << fsoTypeShift ) ,
	fsoColumnMask	= ( 3 << fsoColumnShift ) ,
	fsoType2Mask	= ( 3 << fsoType2Shift ) ,
	fsoTypesMask	= ( fsoTypeMask | fsoType2Mask ) ,
	fsoAscending	= ( 1 << fsoOrderShift ) ,
	fsoDescending	= ( 2 << fsoOrderShift ) ,
	fsoByName	= ( 1 << fsoTypeShift ) ,
	fsoByTimestamp	= ( 2 << fsoTypeShift ) ,
	fsoBySize	= ( 3 << fsoTypeShift ) ,
	fsoColumn1	= ( 1 << fsoColumnShift ) ,
	fsoColumn2	= ( 2 << fsoColumnShift ) ,
	fsoColumn3	= ( 3 << fsoColumnShift ) ,
	fsoByChangeCount	= ( 1 << fsoType2Shift ) 
    } 	FolderSortOrder;

typedef /* [helpstring] */ 
enum _ConfigString
    {	csUnchangedFont	= 0,
	csChangedFont	= ( csUnchangedFont + 1 ) ,
	csInsertedFont	= ( csChangedFont + 1 ) ,
	csRemovedFont	= ( csInsertedFont + 1 ) ,
	csReserved1	= ( csRemovedFont + 1 ) ,
	csReserved2	= ( csReserved1 + 1 ) ,
	csReserved3	= ( csReserved2 + 1 ) ,
	csReserved4	= ( csReserved3 + 1 ) ,
	csReserved5	= ( csReserved4 + 1 ) ,
	csSearchText0	= ( csReserved5 + 1 ) ,
	csSearchText1	= ( csSearchText0 + 1 ) ,
	csSearchText2	= ( csSearchText1 + 1 ) ,
	csSearchText3	= ( csSearchText2 + 1 ) ,
	csSearchText4	= ( csSearchText3 + 1 ) ,
	csSearchText5	= ( csSearchText4 + 1 ) ,
	csSearchText6	= ( csSearchText5 + 1 ) ,
	csSearchText7	= ( csSearchText6 + 1 ) ,
	csSearchText8	= ( csSearchText7 + 1 ) ,
	csSearchText9	= ( csSearchText8 + 1 ) ,
	csReplaceText0	= ( csSearchText9 + 1 ) ,
	csReplaceText1	= ( csReplaceText0 + 1 ) ,
	csReplaceText2	= ( csReplaceText1 + 1 ) ,
	csReplaceText3	= ( csReplaceText2 + 1 ) ,
	csReplaceText4	= ( csReplaceText3 + 1 ) ,
	csReplaceText5	= ( csReplaceText4 + 1 ) ,
	csReplaceText6	= ( csReplaceText5 + 1 ) ,
	csReplaceText7	= ( csReplaceText6 + 1 ) ,
	csReplaceText8	= ( csReplaceText7 + 1 ) ,
	csReplaceText9	= ( csReplaceText8 + 1 ) ,
	csReserved6	= ( csReplaceText9 + 1 ) ,
	csReserved7	= ( csReserved6 + 1 ) ,
	csReserved8	= ( csReserved7 + 1 ) ,
	csReserved9	= ( csReserved8 + 1 ) ,
	csReserved10	= ( csReserved9 + 1 ) ,
	csReserved11	= ( csReserved10 + 1 ) ,
	csReserved12	= ( csReserved11 + 1 ) ,
	csReserved13	= ( csReserved12 + 1 ) ,
	csReserved14	= ( csReserved13 + 1 ) ,
	csReserved15	= ( csReserved14 + 1 ) ,
	csReserved16	= ( csReserved15 + 1 ) ,
	csReserved17	= ( csReserved16 + 1 ) ,
	csReserved18	= ( csReserved17 + 1 ) ,
	csReserved19	= ( csReserved18 + 1 ) ,
	csReserved20	= ( csReserved19 + 1 ) ,
	csReserved21	= ( csReserved20 + 1 ) ,
	csReserved22	= ( csReserved21 + 1 ) ,
	csReserved23	= ( csReserved22 + 1 ) ,
	csReserved24	= ( csReserved23 + 1 ) ,
	csReserved25	= ( csReserved24 + 1 ) ,
	csReserved26	= ( csReserved25 + 1 ) ,
	csReserved27	= ( csReserved26 + 1 ) ,
	csReserved28	= ( csReserved27 + 1 ) ,
	csReserved29	= ( csReserved28 + 1 ) ,
	csReserved30	= ( csReserved29 + 1 ) ,
	csReserved31	= ( csReserved30 + 1 ) ,
	csReserved32	= ( csReserved31 + 1 ) ,
	csReserved33	= ( csReserved32 + 1 ) ,
	csReserved34	= ( csReserved33 + 1 ) ,
	csReserved35	= ( csReserved34 + 1 ) ,
	csReserved36	= ( csReserved35 + 1 ) ,
	csReserved37	= ( csReserved36 + 1 ) ,
	csReserved38	= ( csReserved37 + 1 ) ,
	csReserved39	= ( csReserved38 + 1 ) ,
	csReserved40	= ( csReserved39 + 1 ) ,
	csReserved41	= ( csReserved40 + 1 ) ,
	csReserved42	= ( csReserved41 + 1 ) ,
	csReserved43	= ( csReserved42 + 1 ) ,
	csReserved44	= ( csReserved43 + 1 ) ,
	csReserved45	= ( csReserved44 + 1 ) ,
	csReserved46	= ( csReserved45 + 1 ) ,
	csReserved47	= ( csReserved46 + 1 ) ,
	csReserved48	= ( csReserved47 + 1 ) ,
	csReserved49	= ( csReserved48 + 1 ) ,
	csReserved50	= ( csReserved49 + 1 ) ,
	csReserved51	= ( csReserved50 + 1 ) ,
	csReserved52	= ( csReserved51 + 1 ) ,
	csReserved53	= ( csReserved52 + 1 ) ,
	csReserved54	= ( csReserved53 + 1 ) ,
	csReserved55	= ( csReserved54 + 1 ) ,
	csReserved56	= ( csReserved55 + 1 ) ,
	csReserved57	= ( csReserved56 + 1 ) ,
	csReserved58	= ( csReserved57 + 1 ) ,
	csReserved59	= ( csReserved58 + 1 ) ,
	csReserved60	= ( csReserved59 + 1 ) ,
	csReserved61	= ( csReserved60 + 1 ) ,
	csReserved62	= ( csReserved61 + 1 ) ,
	csReserved63	= ( csReserved62 + 1 ) ,
	csIgnorePatternText0	= ( csReserved63 + 1 ) ,
	csIgnorePatternText1	= ( csIgnorePatternText0 + 1 ) ,
	csIgnorePatternText2	= ( csIgnorePatternText1 + 1 ) ,
	csIgnorePatternText3	= ( csIgnorePatternText2 + 1 ) ,
	csIgnorePatternText4	= ( csIgnorePatternText3 + 1 ) ,
	csIgnorePatternText5	= ( csIgnorePatternText4 + 1 ) ,
	csIgnorePatternText6	= ( csIgnorePatternText5 + 1 ) ,
	csIgnorePatternText7	= ( csIgnorePatternText6 + 1 ) ,
	csIgnorePatternText8	= ( csIgnorePatternText7 + 1 ) ,
	csIgnorePatternText9	= ( csIgnorePatternText8 + 1 ) ,
	csIncludePatternText0	= ( csIgnorePatternText9 + 1 ) ,
	csIncludePatternText1	= ( csIncludePatternText0 + 1 ) ,
	csIncludePatternText2	= ( csIncludePatternText1 + 1 ) ,
	csIncludePatternText3	= ( csIncludePatternText2 + 1 ) ,
	csIncludePatternText4	= ( csIncludePatternText3 + 1 ) ,
	csIncludePatternText5	= ( csIncludePatternText4 + 1 ) ,
	csIncludePatternText6	= ( csIncludePatternText5 + 1 ) ,
	csIncludePatternText7	= ( csIncludePatternText6 + 1 ) ,
	csIncludePatternText8	= ( csIncludePatternText7 + 1 ) ,
	csIncludePatternText9	= ( csIncludePatternText8 + 1 ) ,
	csRegexp0	= ( csIncludePatternText9 + 1 ) ,
	csRegexp1	= ( csRegexp0 + 1 ) ,
	csRegexp2	= ( csRegexp1 + 1 ) ,
	csRegexp3	= ( csRegexp2 + 1 ) ,
	csRegexp4	= ( csRegexp3 + 1 ) ,
	csRegexp5	= ( csRegexp4 + 1 ) ,
	csRegexp6	= ( csRegexp5 + 1 ) ,
	csRegexp7	= ( csRegexp6 + 1 ) ,
	csRegexp8	= ( csRegexp7 + 1 ) ,
	csRegexp9	= ( csRegexp8 + 1 ) ,
	csRegexpDescription0	= ( csRegexp9 + 1 ) ,
	csRegexpDescription1	= ( csRegexpDescription0 + 1 ) ,
	csRegexpDescription2	= ( csRegexpDescription1 + 1 ) ,
	csRegexpDescription3	= ( csRegexpDescription2 + 1 ) ,
	csRegexpDescription4	= ( csRegexpDescription3 + 1 ) ,
	csRegexpDescription5	= ( csRegexpDescription4 + 1 ) ,
	csRegexpDescription6	= ( csRegexpDescription5 + 1 ) ,
	csRegexpDescription7	= ( csRegexpDescription6 + 1 ) ,
	csRegexpDescription8	= ( csRegexpDescription7 + 1 ) ,
	csRegexpDescription9	= ( csRegexpDescription8 + 1 ) ,
	csLastOpenFolder	= ( csRegexpDescription9 + 1 ) ,
	csReserved64	= ( csLastOpenFolder + 1 ) ,
	csReserved65	= ( csReserved64 + 1 ) ,
	csReserved66	= ( csReserved65 + 1 ) ,
	csReserved67	= ( csReserved66 + 1 ) ,
	csReserved68	= ( csReserved67 + 1 ) ,
	csReserved69	= ( csReserved68 + 1 ) ,
	csReserved70	= ( csReserved69 + 1 ) ,
	csReserved71	= ( csReserved70 + 1 ) ,
	csReserved72	= ( csReserved71 + 1 ) ,
	csReserved73	= ( csReserved72 + 1 ) ,
	csUnchangedFont2	= ( csReserved73 + 1 ) ,
	csChangedFont2	= ( csUnchangedFont2 + 1 ) ,
	csInsertedFont2	= ( csChangedFont2 + 1 ) ,
	csRemovedFont2	= ( csInsertedFont2 + 1 ) ,
	csUnchangedFont3	= ( csRemovedFont2 + 1 ) ,
	csChangedFont3	= ( csUnchangedFont3 + 1 ) ,
	csInsertedFont3	= ( csChangedFont3 + 1 ) ,
	csRemovedFont3	= ( csInsertedFont3 + 1 ) ,
	csFileComparisonHeaderRTF	= ( csRemovedFont3 + 1 ) ,
	csFileComparisonFooterRTF	= ( csFileComparisonHeaderRTF + 1 ) ,
	csFolderComparisonHeaderRTF	= ( csFileComparisonFooterRTF + 1 ) ,
	csFolderComparisonFooterRTF	= ( csFolderComparisonHeaderRTF + 1 ) ,
	csFirewallUsername	= ( csFolderComparisonFooterRTF + 1 ) ,
	csFirewallPassword	= ( csFirewallUsername + 1 ) ,
	csRegexpSample0	= ( csFirewallPassword + 1 ) ,
	csRegexpSample1	= ( csRegexpSample0 + 1 ) ,
	csRegexpSample2	= ( csRegexpSample1 + 1 ) ,
	csRegexpSample3	= ( csRegexpSample2 + 1 ) ,
	csRegexpSample4	= ( csRegexpSample3 + 1 ) ,
	csRegexpSample5	= ( csRegexpSample4 + 1 ) ,
	csRegexpSample6	= ( csRegexpSample5 + 1 ) ,
	csRegexpSample7	= ( csRegexpSample6 + 1 ) ,
	csRegexpSample8	= ( csRegexpSample7 + 1 ) ,
	csRegexpSample9	= ( csRegexpSample8 + 1 ) ,
	csRegexpFields0	= ( csRegexpSample9 + 1 ) ,
	csRegexpFields1	= ( csRegexpFields0 + 1 ) ,
	csRegexpFields2	= ( csRegexpFields1 + 1 ) ,
	csRegexpFields3	= ( csRegexpFields2 + 1 ) ,
	csRegexpFields4	= ( csRegexpFields3 + 1 ) ,
	csRegexpFields5	= ( csRegexpFields4 + 1 ) ,
	csRegexpFields6	= ( csRegexpFields5 + 1 ) ,
	csRegexpFields7	= ( csRegexpFields6 + 1 ) ,
	csRegexpFields8	= ( csRegexpFields7 + 1 ) ,
	csRegexpFields9	= ( csRegexpFields8 + 1 ) ,
	csColumnsFilteredOut	= ( csRegexpFields9 + 1 ) ,
	csFolderUnchangedFont	= ( csColumnsFilteredOut + 1 ) ,
	csFolderChangedFont	= ( csFolderUnchangedFont + 1 ) ,
	csFolderInsertedFont	= ( csFolderChangedFont + 1 ) ,
	csFolderRemovedFont	= ( csFolderInsertedFont + 1 ) ,
	csFolderUnchangedFont2	= ( csFolderRemovedFont + 1 ) ,
	csFolderChangedFont2	= ( csFolderUnchangedFont2 + 1 ) ,
	csFolderInsertedFont2	= ( csFolderChangedFont2 + 1 ) ,
	csFolderRemovedFont2	= ( csFolderInsertedFont2 + 1 ) ,
	csFolderUnchangedFont3	= ( csFolderRemovedFont2 + 1 ) ,
	csFolderChangedFont3	= ( csFolderUnchangedFont3 + 1 ) ,
	csFolderInsertedFont3	= ( csFolderChangedFont3 + 1 ) ,
	csFolderRemovedFont3	= ( csFolderInsertedFont3 + 1 ) ,
	csDefaultEncoding	= ( csFolderRemovedFont3 + 1 ) ,
	csFirewallHost	= ( csDefaultEncoding + 1 ) ,
	csReserved74	= ( csFirewallHost + 1 ) ,
	csReserved75	= ( csReserved74 + 1 ) ,
	csHTMLTwoWayFileReporter	= ( csReserved75 + 1 ) ,
	csHTMLThreeWayFileReporter	= ( csHTMLTwoWayFileReporter + 1 ) ,
	csAutoSyncSettings	= ( csHTMLThreeWayFileReporter + 1 ) ,
	csFileComparisonHistory	= ( csAutoSyncSettings + 1 ) ,
	csFolderComparisonHistory	= ( csFileComparisonHistory + 1 ) ,
	csFileDialogFileTypesFilter	= ( csFolderComparisonHistory + 1 ) 
    } 	ConfigString;

typedef /* [helpstring] */ 
enum _ConfigLong
    {	clUnchangedFgnd	= 0,
	clChangedFgnd	= ( clUnchangedFgnd + 1 ) ,
	clInsertedFgnd	= ( clChangedFgnd + 1 ) ,
	clRemovedFgnd	= ( clInsertedFgnd + 1 ) ,
	clLinesFgnd	= ( clRemovedFgnd + 1 ) ,
	clOverviewFgnd	= ( clLinesFgnd + 1 ) ,
	clUnchangedBgnd	= ( clOverviewFgnd + 1 ) ,
	clChangedBgnd	= ( clUnchangedBgnd + 1 ) ,
	clInsertedBgnd	= ( clChangedBgnd + 1 ) ,
	clRemovedBgnd	= ( clInsertedBgnd + 1 ) ,
	clExtendLines	= ( clRemovedBgnd + 1 ) ,
	clExpandTabs	= ( clExtendLines + 1 ) ,
	clTabExpandVal	= ( clExpandTabs + 1 ) ,
	clVertLink	= ( clTabExpandVal + 1 ) ,
	clHorzLink	= ( clVertLink + 1 ) ,
	clIgnWhitespace	= ( clHorzLink + 1 ) ,
	clAppMax	= ( clIgnWhitespace + 1 ) ,
	closeAfterDiff	= ( clAppMax + 1 ) ,
	clViewBgnd	= ( closeAfterDiff + 1 ) ,
	clShowLineNums	= ( clViewBgnd + 1 ) ,
	clDelayedLink	= ( clShowLineNums + 1 ) ,
	closeOnErrorOrNeitherFileFound	= ( clDelayedLink + 1 ) ,
	closeOnNoDifferences	= ( closeOnErrorOrNeitherFileFound + 1 ) ,
	clLimitViews	= ( closeOnNoDifferences + 1 ) ,
	clViewLimit	= ( clLimitViews + 1 ) ,
	clHideCRLF	= ( clViewLimit + 1 ) ,
	clShowCentrePoint	= ( clHideCRLF + 1 ) ,
	clShowOverviews	= ( clShowCentrePoint + 1 ) ,
	clMergingEnabled	= ( clShowOverviews + 1 ) ,
	clBracketChanges	= ( clMergingEnabled + 1 ) ,
	clReserved1	= ( clBracketChanges + 1 ) ,
	clThoroughComparison	= ( clReserved1 + 1 ) ,
	clTopLevelFilesOnly	= ( clThoroughComparison + 1 ) ,
	clReserved2	= ( clTopLevelFilesOnly + 1 ) ,
	clShowUnchanged	= ( clReserved2 + 1 ) ,
	clIgnoreFilter	= ( clShowUnchanged + 1 ) ,
	clShowOverview	= ( clIgnoreFilter + 1 ) ,
	clIgnoreCase	= ( clShowOverview + 1 ) ,
	clOpenInitialComparisonWindow	= ( clIgnoreCase + 1 ) ,
	clConfirmClose	= ( clOpenInitialComparisonWindow + 1 ) ,
	clFolderPrintShowLineNumbers	= ( clConfirmClose + 1 ) ,
	clFolderPrintMarginUnits	= ( clFolderPrintShowLineNumbers + 1 ) ,
	clFilePrintShowLineNumbers	= ( clFolderPrintMarginUnits + 1 ) ,
	clFilePrintMarginUnits	= ( clFilePrintShowLineNumbers + 1 ) ,
	clFolderTextScale	= ( clFilePrintMarginUnits + 1 ) ,
	clFileTextScale	= ( clFolderTextScale + 1 ) ,
	clShowFileStamps	= ( clFileTextScale + 1 ) ,
	clSearchMatchCase	= ( clShowFileStamps + 1 ) ,
	clSearchWholeWord	= ( clSearchMatchCase + 1 ) ,
	clReserved3	= ( clSearchWholeWord + 1 ) ,
	clReserved4	= ( clReserved3 + 1 ) ,
	clReserved5	= ( clReserved4 + 1 ) ,
	clReserved6	= ( clReserved5 + 1 ) ,
	clReserved7	= ( clReserved6 + 1 ) ,
	clReserved8	= ( clReserved7 + 1 ) ,
	clReserved9	= ( clReserved8 + 1 ) ,
	clReserved10	= ( clReserved9 + 1 ) ,
	clReserved11	= ( clReserved10 + 1 ) ,
	clFolderWindowWidth	= ( clReserved11 + 1 ) ,
	clFolderWindowHeight	= ( clFolderWindowWidth + 1 ) ,
	clUpgrade40	= ( clFolderWindowHeight + 1 ) ,
	clMaximizeFileComp	= ( clUpgrade40 + 1 ) ,
	clFilePrintWordWrap	= ( clMaximizeFileComp + 1 ) ,
	clOpenInitialFolderWindow	= ( clFilePrintWordWrap + 1 ) ,
	clIncludeFilterOn	= ( clOpenInitialFolderWindow + 1 ) ,
	clAutoFolderCreate	= ( clIncludeFilterOn + 1 ) ,
	clPrintPagesWithChanges	= ( clAutoFolderCreate + 1 ) ,
	clReserved12	= ( clPrintPagesWithChanges + 1 ) ,
	clReserved13	= ( clReserved12 + 1 ) ,
	clSimpleInlineChanges	= ( clReserved13 + 1 ) ,
	clReserved14	= ( clSimpleInlineChanges + 1 ) ,
	clCentralLinesWidth	= ( clReserved14 + 1 ) ,
	clShowChangesColumn	= ( clCentralLinesWidth + 1 ) ,
	clIgnoreLineEndings	= ( clShowChangesColumn + 1 ) ,
	clTabKeyEditing	= ( clIgnoreLineEndings + 1 ) ,
	clShowTutorialsAndOverviews	= ( clTabKeyEditing + 1 ) ,
	clAllowReadOnlyEdit	= ( clShowTutorialsAndOverviews + 1 ) ,
	clApplyRegexp0	= ( clAllowReadOnlyEdit + 1 ) ,
	clApplyRegexp1	= ( clApplyRegexp0 + 1 ) ,
	clApplyRegexp2	= ( clApplyRegexp1 + 1 ) ,
	clApplyRegexp3	= ( clApplyRegexp2 + 1 ) ,
	clApplyRegexp4	= ( clApplyRegexp3 + 1 ) ,
	clApplyRegexp5	= ( clApplyRegexp4 + 1 ) ,
	clApplyRegexp6	= ( clApplyRegexp5 + 1 ) ,
	clApplyRegexp7	= ( clApplyRegexp6 + 1 ) ,
	clApplyRegexp8	= ( clApplyRegexp7 + 1 ) ,
	clApplyRegexp9	= ( clApplyRegexp8 + 1 ) ,
	clQuickDiffForLargeFiles	= ( clApplyRegexp9 + 1 ) ,
	clQuickDiffLimit	= ( clQuickDiffForLargeFiles + 1 ) ,
	clLargeFileThreshold	= ( clQuickDiffLimit + 1 ) ,
	clSaveChangesWindowSize	= ( clLargeFileThreshold + 1 ) ,
	clReserved15	= ( clSaveChangesWindowSize + 1 ) ,
	clDisableMergingTips	= ( clReserved15 + 1 ) ,
	clDisableFileAndFolderPathTips	= ( clDisableMergingTips + 1 ) ,
	clAbsentFileBgnd	= ( clDisableFileAndFolderPathTips + 1 ) ,
	clThreeWayFolderComparison	= ( clAbsentFileBgnd + 1 ) ,
	clTwoWaySubColWidth00	= ( clThreeWayFolderComparison + 1 ) ,
	clTwoWaySubColWidth01	= ( clTwoWaySubColWidth00 + 1 ) ,
	clTwoWaySubColWidth10	= ( clTwoWaySubColWidth01 + 1 ) ,
	clTwoWaySubColWidth11	= ( clTwoWaySubColWidth10 + 1 ) ,
	clThreeWaySubColWidth00	= ( clTwoWaySubColWidth11 + 1 ) ,
	clThreeWaySubColWidth01	= ( clThreeWaySubColWidth00 + 1 ) ,
	clThreeWaySubColWidth10	= ( clThreeWaySubColWidth01 + 1 ) ,
	clThreeWaySubColWidth11	= ( clThreeWaySubColWidth10 + 1 ) ,
	clThreeWaySubColWidth20	= ( clThreeWaySubColWidth11 + 1 ) ,
	clThreeWaySubColWidth21	= ( clThreeWaySubColWidth20 + 1 ) ,
	clUpdateCheckPromptBeforeCheck	= ( clThreeWaySubColWidth21 + 1 ) ,
	clReserved16	= ( clUpdateCheckPromptBeforeCheck + 1 ) ,
	clUpdateCheckFrequency	= ( clReserved16 + 1 ) ,
	clUpdateCheckLastCheckHigh	= ( clUpdateCheckFrequency + 1 ) ,
	clUpdateCheckLastCheckLow	= ( clUpdateCheckLastCheckHigh + 1 ) ,
	clUnchangedFgnd2	= ( clUpdateCheckLastCheckLow + 1 ) ,
	clChangedFgnd2	= ( clUnchangedFgnd2 + 1 ) ,
	clInsertedFgnd2	= ( clChangedFgnd2 + 1 ) ,
	clRemovedFgnd2	= ( clInsertedFgnd2 + 1 ) ,
	clUnchangedFgnd3	= ( clRemovedFgnd2 + 1 ) ,
	clChangedFgnd3	= ( clUnchangedFgnd3 + 1 ) ,
	clInsertedFgnd3	= ( clChangedFgnd3 + 1 ) ,
	clRemovedFgnd3	= ( clInsertedFgnd3 + 1 ) ,
	clUnchangedBgnd2	= ( clRemovedFgnd3 + 1 ) ,
	clChangedBgnd2	= ( clUnchangedBgnd2 + 1 ) ,
	clInsertedBgnd2	= ( clChangedBgnd2 + 1 ) ,
	clRemovedBgnd2	= ( clInsertedBgnd2 + 1 ) ,
	clUnchangedBgnd3	= ( clRemovedBgnd2 + 1 ) ,
	clChangedBgnd3	= ( clUnchangedBgnd3 + 1 ) ,
	clInsertedBgnd3	= ( clChangedBgnd3 + 1 ) ,
	clRemovedBgnd3	= ( clInsertedBgnd3 + 1 ) ,
	clShowFilePrintHeader	= ( clRemovedBgnd3 + 1 ) ,
	clShowFilePrintFooter	= ( clShowFilePrintHeader + 1 ) ,
	clShowFolderPrintHeader	= ( clShowFilePrintFooter + 1 ) ,
	clShowFolderPrintFooter	= ( clShowFolderPrintHeader + 1 ) ,
	clThreeWayFileComparison	= ( clShowFolderPrintFooter + 1 ) ,
	clLayoutFileComparisonHorizontally	= ( clThreeWayFileComparison + 1 ) ,
	clBlockIndent	= ( clLayoutFileComparisonHorizontally + 1 ) ,
	clVFFirstTwoWay	= ( clBlockIndent + 1 ) ,
	clVFSecondTwoWay	= ( clVFFirstTwoWay + 1 ) ,
	clReserved17	= ( clVFSecondTwoWay + 1 ) ,
	clVFFirstThreeWay	= ( clReserved17 + 1 ) ,
	clVFSecondThreeWay	= ( clVFFirstThreeWay + 1 ) ,
	clVFThirdThreeWay	= ( clVFSecondThreeWay + 1 ) ,
	clSFFirstTwoWay	= ( clVFThirdThreeWay + 1 ) ,
	clSFSecondTwoWay	= ( clSFFirstTwoWay + 1 ) ,
	clReserved18	= ( clSFSecondTwoWay + 1 ) ,
	clSFFirstThreeWay	= ( clReserved18 + 1 ) ,
	clSFSecondThreeWay	= ( clSFFirstThreeWay + 1 ) ,
	clSFThirdThreeWay	= ( clSFSecondThreeWay + 1 ) ,
	clMainWindowLeft	= ( clSFThirdThreeWay + 1 ) ,
	clMainWindowTop	= ( clMainWindowLeft + 1 ) ,
	clMainWindowWidth	= ( clMainWindowTop + 1 ) ,
	clMainWindowHeight	= ( clMainWindowWidth + 1 ) ,
	clMainWindowShowCmd	= ( clMainWindowHeight + 1 ) ,
	clFolderWindowLeft	= ( clMainWindowShowCmd + 1 ) ,
	clFolderWindowTop	= ( clFolderWindowLeft + 1 ) ,
	clFolderWindowShowCmd	= ( clFolderWindowTop + 1 ) ,
	clIndicateConcealedChanges	= ( clFolderWindowShowCmd + 1 ) ,
	clTimestampTolerance	= ( clIndicateConcealedChanges + 1 ) ,
	clTimestampDaylightSavings	= ( clTimestampTolerance + 1 ) ,
	clCursorKeysForMerging	= ( clTimestampDaylightSavings + 1 ) ,
	clUseFontFgndPrefsInFolderComparisons	= ( clCursorKeysForMerging + 1 ) ,
	clReportDiff_IncludeContext	= ( clUseFontFgndPrefsInFolderComparisons + 1 ) ,
	clReportDiff_UnifiedFormat	= ( clReportDiff_IncludeContext + 1 ) ,
	clReportDiff_ContextLines	= ( clReportDiff_UnifiedFormat + 1 ) ,
	clReportHtmlSlideShow_SlideWidth	= ( clReportDiff_ContextLines + 1 ) ,
	clReportHtmlSlideShow_SlideHeight	= ( clReportHtmlSlideShow_SlideWidth + 1 ) ,
	clReportHtmlSlideShow_OnlyPagesWithChanges	= ( clReportHtmlSlideShow_SlideHeight + 1 ) ,
	clReportHtmlSlideShow_ShowLineNumbers	= ( clReportHtmlSlideShow_OnlyPagesWithChanges + 1 ) ,
	clReserved19	= ( clReportHtmlSlideShow_ShowLineNumbers + 1 ) ,
	clReportHtmlSlideShow_TextScale	= ( clReserved19 + 1 ) ,
	clReserved20	= ( clReportHtmlSlideShow_TextScale + 1 ) ,
	clReserved21	= ( clReserved20 + 1 ) ,
	clSaveFirewallPassword	= ( clReserved21 + 1 ) ,
	clFirewallPort	= ( clSaveFirewallPassword + 1 ) ,
	clPrinterAspect	= ( clFirewallPort + 1 ) ,
	clNumConfigLongsV6	= ( clPrinterAspect + 1 ) ,
	clRegexpMatchWithinLine0	= clNumConfigLongsV6,
	clRegexpMatchWithinLine1	= ( clRegexpMatchWithinLine0 + 1 ) ,
	clRegexpMatchWithinLine2	= ( clRegexpMatchWithinLine1 + 1 ) ,
	clRegexpMatchWithinLine3	= ( clRegexpMatchWithinLine2 + 1 ) ,
	clRegexpMatchWithinLine4	= ( clRegexpMatchWithinLine3 + 1 ) ,
	clRegexpMatchWithinLine5	= ( clRegexpMatchWithinLine4 + 1 ) ,
	clRegexpMatchWithinLine6	= ( clRegexpMatchWithinLine5 + 1 ) ,
	clRegexpMatchWithinLine7	= ( clRegexpMatchWithinLine6 + 1 ) ,
	clRegexpMatchWithinLine8	= ( clRegexpMatchWithinLine7 + 1 ) ,
	clRegexpMatchWithinLine9	= ( clRegexpMatchWithinLine8 + 1 ) ,
	clApplyColumnFilter	= ( clRegexpMatchWithinLine9 + 1 ) ,
	clFolderUnchangedFgnd	= ( clApplyColumnFilter + 1 ) ,
	clFolderUnchangedFgnd2	= ( clFolderUnchangedFgnd + 1 ) ,
	clFolderUnchangedFgnd3	= ( clFolderUnchangedFgnd2 + 1 ) ,
	clFolderChangedFgnd	= ( clFolderUnchangedFgnd3 + 1 ) ,
	clFolderChangedFgnd2	= ( clFolderChangedFgnd + 1 ) ,
	clFolderChangedFgnd3	= ( clFolderChangedFgnd2 + 1 ) ,
	clFolderInsertedFgnd	= ( clFolderChangedFgnd3 + 1 ) ,
	clFolderInsertedFgnd2	= ( clFolderInsertedFgnd + 1 ) ,
	clFolderInsertedFgnd3	= ( clFolderInsertedFgnd2 + 1 ) ,
	clFolderRemovedFgnd	= ( clFolderInsertedFgnd3 + 1 ) ,
	clFolderRemovedFgnd2	= ( clFolderRemovedFgnd + 1 ) ,
	clFolderRemovedFgnd3	= ( clFolderRemovedFgnd2 + 1 ) ,
	clFolderUnchangedBgnd	= ( clFolderRemovedFgnd3 + 1 ) ,
	clFolderUnchangedBgnd2	= ( clFolderUnchangedBgnd + 1 ) ,
	clFolderUnchangedBgnd3	= ( clFolderUnchangedBgnd2 + 1 ) ,
	clFolderChangedBgnd	= ( clFolderUnchangedBgnd3 + 1 ) ,
	clFolderChangedBgnd2	= ( clFolderChangedBgnd + 1 ) ,
	clFolderChangedBgnd3	= ( clFolderChangedBgnd2 + 1 ) ,
	clFolderInsertedBgnd	= ( clFolderChangedBgnd3 + 1 ) ,
	clFolderInsertedBgnd2	= ( clFolderInsertedBgnd + 1 ) ,
	clFolderInsertedBgnd3	= ( clFolderInsertedBgnd2 + 1 ) ,
	clFolderRemovedBgnd	= ( clFolderInsertedBgnd3 + 1 ) ,
	clFolderRemovedBgnd2	= ( clFolderRemovedBgnd + 1 ) ,
	clFolderRemovedBgnd3	= ( clFolderRemovedBgnd2 + 1 ) ,
	clFolderBgnd	= ( clFolderRemovedBgnd3 + 1 ) ,
	clMergedBlendFactor	= ( clFolderBgnd + 1 ) ,
	clDisplayCopyFilesDialog	= ( clMergedBlendFactor + 1 ) ,
	clPromptToReplaceFiles	= ( clDisplayCopyFilesDialog + 1 ) ,
	clAutomaticallyReloadExternallyModifiedFiles	= ( clPromptToReplaceFiles + 1 ) ,
	clWrapText	= ( clAutomaticallyReloadExternallyModifiedFiles + 1 ) ,
	clShowWhitespace	= ( clWrapText + 1 ) ,
	clWordWrapText	= ( clShowWhitespace + 1 ) ,
	clShowWrapIndicator	= ( clWordWrapText + 1 ) ,
	clUseLanguagesOrCodePagesForEncodings	= ( clShowWrapIndicator + 1 ) ,
	clCompactUnchangedBlocks	= ( clUseLanguagesOrCodePagesForEncodings + 1 ) ,
	clCompactUnchangedBlocksContext	= ( clCompactUnchangedBlocks + 1 ) ,
	clCollapsedRowFgnd	= ( clCompactUnchangedBlocksContext + 1 ) ,
	clXMLGenerateReportsFor	= ( clCollapsedRowFgnd + 1 ) ,
	clHTMLGenerateReportsFor	= ( clXMLGenerateReportsFor + 1 ) ,
	clReserved22	= ( clHTMLGenerateReportsFor + 1 ) ,
	clReserved23	= ( clReserved22 + 1 ) ,
	clReserved24	= ( clReserved23 + 1 ) ,
	clReserved25	= ( clReserved24 + 1 ) ,
	clCollapsedRowBgnd	= ( clReserved25 + 1 ) ,
	clPostEditRefreshTimeout	= ( clCollapsedRowBgnd + 1 ) ,
	clNeverShowSplash	= ( clPostEditRefreshTimeout + 1 ) ,
	clPrintToFile	= ( clNeverShowSplash + 1 ) ,
	clUILanguage	= ( clPrintToFile + 1 ) ,
	clShowResourceIDs	= ( clUILanguage + 1 ) ,
	clNoGdiPlus	= ( clShowResourceIDs + 1 ) ,
	clSwapBrowseAndHistory	= ( clNoGdiPlus + 1 ) ,
	clSimpleFilesystemIcons	= ( clSwapBrowseAndHistory + 1 ) ,
	clShowHistoryTip	= ( clSimpleFilesystemIcons + 1 ) ,
	clResetHiddenStatesOnRefresh	= ( clShowHistoryTip + 1 ) ,
	clCompareShellExt	= ( clResetHiddenStatesOnRefresh + 1 ) ,
	clShowOmittedLinesRow	= ( clCompareShellExt + 1 ) ,
	clNXNSwapInsertedAndRemovedStatus	= ( clShowOmittedLinesRow + 1 ) ,
	clDiagLimit	= ( clNXNSwapInsertedAndRemovedStatus + 1 ) ,
	clTransparencyCellWidth	= ( clDiagLimit + 1 ) ,
	clTransparencyCellHeight	= ( clTransparencyCellWidth + 1 ) ,
	clTransparencyColorA	= ( clTransparencyCellHeight + 1 ) ,
	clTransparencyColorB	= ( clTransparencyColorA + 1 ) ,
	clFolderSortOrder	= ( clTransparencyColorB + 1 ) ,
	clReportFileSizeThreshold	= ( clFolderSortOrder + 1 ) ,
	clScanConcealedFolders	= ( clReportFileSizeThreshold + 1 ) 
    } 	ConfigLong;

typedef /* [helpstring] */ 
enum _ConfigDouble
    {	cdFolderLeftMargin	= 0,
	cdFolderRightMargin	= ( cdFolderLeftMargin + 1 ) ,
	cdFolderTopMargin	= ( cdFolderRightMargin + 1 ) ,
	cdFolderBottomMargin	= ( cdFolderTopMargin + 1 ) ,
	cdFileLeftMargin	= ( cdFolderBottomMargin + 1 ) ,
	cdFileRightMargin	= ( cdFileLeftMargin + 1 ) ,
	cdFileTopMargin	= ( cdFileRightMargin + 1 ) ,
	cdFileBottomMargin	= ( cdFileTopMargin + 1 ) ,
	cdTwoWayFolderWidth0	= ( cdFileBottomMargin + 1 ) ,
	cdTwoWayFolderWidth1	= ( cdTwoWayFolderWidth0 + 1 ) ,
	cdThreeWayFolderWidth0	= ( cdTwoWayFolderWidth1 + 1 ) ,
	cdThreeWayFolderWidth1	= ( cdThreeWayFolderWidth0 + 1 ) ,
	cdThreeWayFolderWidth2	= ( cdThreeWayFolderWidth1 + 1 ) 
    } 	ConfigDouble;

typedef 
enum _PatternFilter
    {	pfInclude	= 0,
	pfExclude	= ( pfInclude + 1 ) 
    } 	PatternFilter;

typedef 
enum _PatternMatch
    {	pmFiles	= 0,
	pmFolders	= ( pmFiles + 1 ) ,
	pmFilesAndFolders	= ( pmFolders + 1 ) 
    } 	PatternMatch;


EXTERN_C const IID LIBID_Merge70;

#ifndef __IPreferences_INTERFACE_DEFINED__
#define __IPreferences_INTERFACE_DEFINED__

/* interface IPreferences */
/* [version][unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_IPreferences;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("c1aa592d-cfb4-4bcc-a63d-56014b2445b2")
    IPreferences : public IDispatch
    {
    public:
        virtual /* [helpstring][propget][id] */ HRESULT STDMETHODCALLTYPE get_Longs( 
            /* [retval][out] */ ILongPreferences **pVal) = 0;
        
        virtual /* [helpstring][propget][id] */ HRESULT STDMETHODCALLTYPE get_Strings( 
            /* [retval][out] */ IStringPreferences **pVal) = 0;
        
        virtual /* [helpstring][propget][id] */ HRESULT STDMETHODCALLTYPE get_Doubles( 
            /* [retval][out] */ IDoublePreferences **pVal) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ShowOptionsWindow( 
            /* [optional][in] */ VARIANT hWndParent) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE Save( void) = 0;
        
        virtual /* [helpstring][propget][id] */ HRESULT STDMETHODCALLTYPE get_Filters( 
            /* [retval][out] */ IFilters **filters) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE LoadFromFile( 
            /* [in] */ BSTR filename) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE SaveToFile( 
            /* [in] */ BSTR filename) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IPreferencesVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IPreferences * This,
            /* [in] */ REFIID riid,
            /* [annotation][iid_is][out] */ 
            __RPC__deref_out  void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IPreferences * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IPreferences * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            IPreferences * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            IPreferences * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            IPreferences * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [range][in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            IPreferences * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_Longs )( 
            IPreferences * This,
            /* [retval][out] */ ILongPreferences **pVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_Strings )( 
            IPreferences * This,
            /* [retval][out] */ IStringPreferences **pVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_Doubles )( 
            IPreferences * This,
            /* [retval][out] */ IDoublePreferences **pVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *ShowOptionsWindow )( 
            IPreferences * This,
            /* [optional][in] */ VARIANT hWndParent);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *Save )( 
            IPreferences * This);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_Filters )( 
            IPreferences * This,
            /* [retval][out] */ IFilters **filters);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *LoadFromFile )( 
            IPreferences * This,
            /* [in] */ BSTR filename);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *SaveToFile )( 
            IPreferences * This,
            /* [in] */ BSTR filename);
        
        END_INTERFACE
    } IPreferencesVtbl;

    interface IPreferences
    {
        CONST_VTBL struct IPreferencesVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IPreferences_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 

#define IPreferences_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 

#define IPreferences_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 


#define IPreferences_GetTypeInfoCount(This,pctinfo)	\
    ( (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo) ) 

#define IPreferences_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    ( (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo) ) 

#define IPreferences_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    ( (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId) ) 

#define IPreferences_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    ( (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr) ) 


#define IPreferences_get_Longs(This,pVal)	\
    ( (This)->lpVtbl -> get_Longs(This,pVal) ) 

#define IPreferences_get_Strings(This,pVal)	\
    ( (This)->lpVtbl -> get_Strings(This,pVal) ) 

#define IPreferences_get_Doubles(This,pVal)	\
    ( (This)->lpVtbl -> get_Doubles(This,pVal) ) 

#define IPreferences_ShowOptionsWindow(This,hWndParent)	\
    ( (This)->lpVtbl -> ShowOptionsWindow(This,hWndParent) ) 

#define IPreferences_Save(This)	\
    ( (This)->lpVtbl -> Save(This) ) 

#define IPreferences_get_Filters(This,filters)	\
    ( (This)->lpVtbl -> get_Filters(This,filters) ) 

#define IPreferences_LoadFromFile(This,filename)	\
    ( (This)->lpVtbl -> LoadFromFile(This,filename) ) 

#define IPreferences_SaveToFile(This,filename)	\
    ( (This)->lpVtbl -> SaveToFile(This,filename) ) 

#endif /* COBJMACROS */


#endif 	/* C style interface */




#endif 	/* __IPreferences_INTERFACE_DEFINED__ */


#ifndef __ICommonUI_INTERFACE_DEFINED__
#define __ICommonUI_INTERFACE_DEFINED__

/* interface ICommonUI */
/* [version][unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_ICommonUI;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("b1983de9-115b-457d-8218-9c235e5cb5e7")
    ICommonUI : public IDispatch
    {
    public:
        virtual /* [helpstring][propget][id] */ HRESULT STDMETHODCALLTYPE get_Active( 
            /* [retval][out] */ VARIANT_BOOL *pVal) = 0;
        
        virtual /* [helpstring][propput][id] */ HRESULT STDMETHODCALLTYPE put_Active( 
            /* [in] */ VARIANT_BOOL newVal) = 0;
        
        virtual /* [helpstring][propget][id] */ HRESULT STDMETHODCALLTYPE get_Visible( 
            /* [retval][out] */ VARIANT_BOOL *pVal) = 0;
        
        virtual /* [helpstring][propput][id] */ HRESULT STDMETHODCALLTYPE put_Visible( 
            /* [in] */ VARIANT_BOOL newVal) = 0;
        
        virtual /* [helpstring][propget][id] */ HRESULT STDMETHODCALLTYPE get_Minimized( 
            /* [retval][out] */ VARIANT_BOOL *pVal) = 0;
        
        virtual /* [helpstring][propput][id] */ HRESULT STDMETHODCALLTYPE put_Minimized( 
            /* [in] */ VARIANT_BOOL newVal) = 0;
        
        virtual /* [helpstring][propget][id] */ HRESULT STDMETHODCALLTYPE get_Maximized( 
            /* [retval][out] */ VARIANT_BOOL *pVal) = 0;
        
        virtual /* [helpstring][propput][id] */ HRESULT STDMETHODCALLTYPE put_Maximized( 
            /* [in] */ VARIANT_BOOL newVal) = 0;
        
        virtual /* [helpstring][propget][id] */ HRESULT STDMETHODCALLTYPE get_Left( 
            /* [retval][out] */ long *pVal) = 0;
        
        virtual /* [helpstring][propput][id] */ HRESULT STDMETHODCALLTYPE put_Left( 
            /* [in] */ long newVal) = 0;
        
        virtual /* [helpstring][propget][id] */ HRESULT STDMETHODCALLTYPE get_Top( 
            /* [retval][out] */ long *pVal) = 0;
        
        virtual /* [helpstring][propput][id] */ HRESULT STDMETHODCALLTYPE put_Top( 
            /* [in] */ long newVal) = 0;
        
        virtual /* [helpstring][propget][id] */ HRESULT STDMETHODCALLTYPE get_Width( 
            /* [retval][out] */ long *pVal) = 0;
        
        virtual /* [helpstring][propput][id] */ HRESULT STDMETHODCALLTYPE put_Width( 
            /* [in] */ long newVal) = 0;
        
        virtual /* [helpstring][propget][id] */ HRESULT STDMETHODCALLTYPE get_Height( 
            /* [retval][out] */ long *pVal) = 0;
        
        virtual /* [helpstring][propput][id] */ HRESULT STDMETHODCALLTYPE put_Height( 
            /* [in] */ long newVal) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE Restore( void) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE Close( void) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE GiveUserControl( void) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct ICommonUIVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            ICommonUI * This,
            /* [in] */ REFIID riid,
            /* [annotation][iid_is][out] */ 
            __RPC__deref_out  void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            ICommonUI * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            ICommonUI * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            ICommonUI * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            ICommonUI * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            ICommonUI * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [range][in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            ICommonUI * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_Active )( 
            ICommonUI * This,
            /* [retval][out] */ VARIANT_BOOL *pVal);
        
        /* [helpstring][propput][id] */ HRESULT ( STDMETHODCALLTYPE *put_Active )( 
            ICommonUI * This,
            /* [in] */ VARIANT_BOOL newVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_Visible )( 
            ICommonUI * This,
            /* [retval][out] */ VARIANT_BOOL *pVal);
        
        /* [helpstring][propput][id] */ HRESULT ( STDMETHODCALLTYPE *put_Visible )( 
            ICommonUI * This,
            /* [in] */ VARIANT_BOOL newVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_Minimized )( 
            ICommonUI * This,
            /* [retval][out] */ VARIANT_BOOL *pVal);
        
        /* [helpstring][propput][id] */ HRESULT ( STDMETHODCALLTYPE *put_Minimized )( 
            ICommonUI * This,
            /* [in] */ VARIANT_BOOL newVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_Maximized )( 
            ICommonUI * This,
            /* [retval][out] */ VARIANT_BOOL *pVal);
        
        /* [helpstring][propput][id] */ HRESULT ( STDMETHODCALLTYPE *put_Maximized )( 
            ICommonUI * This,
            /* [in] */ VARIANT_BOOL newVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_Left )( 
            ICommonUI * This,
            /* [retval][out] */ long *pVal);
        
        /* [helpstring][propput][id] */ HRESULT ( STDMETHODCALLTYPE *put_Left )( 
            ICommonUI * This,
            /* [in] */ long newVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_Top )( 
            ICommonUI * This,
            /* [retval][out] */ long *pVal);
        
        /* [helpstring][propput][id] */ HRESULT ( STDMETHODCALLTYPE *put_Top )( 
            ICommonUI * This,
            /* [in] */ long newVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_Width )( 
            ICommonUI * This,
            /* [retval][out] */ long *pVal);
        
        /* [helpstring][propput][id] */ HRESULT ( STDMETHODCALLTYPE *put_Width )( 
            ICommonUI * This,
            /* [in] */ long newVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_Height )( 
            ICommonUI * This,
            /* [retval][out] */ long *pVal);
        
        /* [helpstring][propput][id] */ HRESULT ( STDMETHODCALLTYPE *put_Height )( 
            ICommonUI * This,
            /* [in] */ long newVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *Restore )( 
            ICommonUI * This);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *Close )( 
            ICommonUI * This);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *GiveUserControl )( 
            ICommonUI * This);
        
        END_INTERFACE
    } ICommonUIVtbl;

    interface ICommonUI
    {
        CONST_VTBL struct ICommonUIVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define ICommonUI_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 

#define ICommonUI_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 

#define ICommonUI_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 


#define ICommonUI_GetTypeInfoCount(This,pctinfo)	\
    ( (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo) ) 

#define ICommonUI_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    ( (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo) ) 

#define ICommonUI_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    ( (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId) ) 

#define ICommonUI_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    ( (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr) ) 


#define ICommonUI_get_Active(This,pVal)	\
    ( (This)->lpVtbl -> get_Active(This,pVal) ) 

#define ICommonUI_put_Active(This,newVal)	\
    ( (This)->lpVtbl -> put_Active(This,newVal) ) 

#define ICommonUI_get_Visible(This,pVal)	\
    ( (This)->lpVtbl -> get_Visible(This,pVal) ) 

#define ICommonUI_put_Visible(This,newVal)	\
    ( (This)->lpVtbl -> put_Visible(This,newVal) ) 

#define ICommonUI_get_Minimized(This,pVal)	\
    ( (This)->lpVtbl -> get_Minimized(This,pVal) ) 

#define ICommonUI_put_Minimized(This,newVal)	\
    ( (This)->lpVtbl -> put_Minimized(This,newVal) ) 

#define ICommonUI_get_Maximized(This,pVal)	\
    ( (This)->lpVtbl -> get_Maximized(This,pVal) ) 

#define ICommonUI_put_Maximized(This,newVal)	\
    ( (This)->lpVtbl -> put_Maximized(This,newVal) ) 

#define ICommonUI_get_Left(This,pVal)	\
    ( (This)->lpVtbl -> get_Left(This,pVal) ) 

#define ICommonUI_put_Left(This,newVal)	\
    ( (This)->lpVtbl -> put_Left(This,newVal) ) 

#define ICommonUI_get_Top(This,pVal)	\
    ( (This)->lpVtbl -> get_Top(This,pVal) ) 

#define ICommonUI_put_Top(This,newVal)	\
    ( (This)->lpVtbl -> put_Top(This,newVal) ) 

#define ICommonUI_get_Width(This,pVal)	\
    ( (This)->lpVtbl -> get_Width(This,pVal) ) 

#define ICommonUI_put_Width(This,newVal)	\
    ( (This)->lpVtbl -> put_Width(This,newVal) ) 

#define ICommonUI_get_Height(This,pVal)	\
    ( (This)->lpVtbl -> get_Height(This,pVal) ) 

#define ICommonUI_put_Height(This,newVal)	\
    ( (This)->lpVtbl -> put_Height(This,newVal) ) 

#define ICommonUI_Restore(This)	\
    ( (This)->lpVtbl -> Restore(This) ) 

#define ICommonUI_Close(This)	\
    ( (This)->lpVtbl -> Close(This) ) 

#define ICommonUI_GiveUserControl(This)	\
    ( (This)->lpVtbl -> GiveUserControl(This) ) 

#endif /* COBJMACROS */


#endif 	/* C style interface */




#endif 	/* __ICommonUI_INTERFACE_DEFINED__ */


#ifndef __IApplication_INTERFACE_DEFINED__
#define __IApplication_INTERFACE_DEFINED__

/* interface IApplication */
/* [version][unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_IApplication;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("1840034b-4d43-4a5c-bf15-b8c10578c18f")
    IApplication : public ICommonUI
    {
    public:
        virtual /* [helpstring][propget][id] */ HRESULT STDMETHODCALLTYPE get_Preferences( 
            /* [retval][out] */ IPreferences **pVal) = 0;
        
        virtual /* [helpstring][propget][id] */ HRESULT STDMETHODCALLTYPE get_TextComparison( 
            /* [retval][out] */ ITextComparison2 **pVal) = 0;
        
        virtual /* [helpstring][propget][id] */ HRESULT STDMETHODCALLTYPE get_BinaryComparison( 
            /* [retval][out] */ IBinaryComparison **pVal) = 0;
        
        virtual /* [helpstring][propget][id] */ HRESULT STDMETHODCALLTYPE get_ImageComparison( 
            /* [retval][out] */ IImageComparison **pVal) = 0;
        
        virtual /* [helpstring][propget][id] */ HRESULT STDMETHODCALLTYPE get_FolderComparison( 
            /* [retval][out] */ IFolderComparison **pVal) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE CompareItems( 
            /* [in] */ VARIANT firstItem,
            /* [in] */ VARIANT secondItem,
            /* [optional][in] */ VARIANT thirdItem,
            /* [retval][out] */ IComparison **pObject) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE OpenComparison( 
            /* [in] */ BSTR filename) = 0;
        
        virtual /* [helpstring][propget][id] */ HRESULT STDMETHODCALLTYPE get_Version( 
            /* [retval][out] */ BSTR *pVal) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IApplicationVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IApplication * This,
            /* [in] */ REFIID riid,
            /* [annotation][iid_is][out] */ 
            __RPC__deref_out  void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IApplication * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IApplication * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            IApplication * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            IApplication * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            IApplication * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [range][in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            IApplication * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_Active )( 
            IApplication * This,
            /* [retval][out] */ VARIANT_BOOL *pVal);
        
        /* [helpstring][propput][id] */ HRESULT ( STDMETHODCALLTYPE *put_Active )( 
            IApplication * This,
            /* [in] */ VARIANT_BOOL newVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_Visible )( 
            IApplication * This,
            /* [retval][out] */ VARIANT_BOOL *pVal);
        
        /* [helpstring][propput][id] */ HRESULT ( STDMETHODCALLTYPE *put_Visible )( 
            IApplication * This,
            /* [in] */ VARIANT_BOOL newVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_Minimized )( 
            IApplication * This,
            /* [retval][out] */ VARIANT_BOOL *pVal);
        
        /* [helpstring][propput][id] */ HRESULT ( STDMETHODCALLTYPE *put_Minimized )( 
            IApplication * This,
            /* [in] */ VARIANT_BOOL newVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_Maximized )( 
            IApplication * This,
            /* [retval][out] */ VARIANT_BOOL *pVal);
        
        /* [helpstring][propput][id] */ HRESULT ( STDMETHODCALLTYPE *put_Maximized )( 
            IApplication * This,
            /* [in] */ VARIANT_BOOL newVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_Left )( 
            IApplication * This,
            /* [retval][out] */ long *pVal);
        
        /* [helpstring][propput][id] */ HRESULT ( STDMETHODCALLTYPE *put_Left )( 
            IApplication * This,
            /* [in] */ long newVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_Top )( 
            IApplication * This,
            /* [retval][out] */ long *pVal);
        
        /* [helpstring][propput][id] */ HRESULT ( STDMETHODCALLTYPE *put_Top )( 
            IApplication * This,
            /* [in] */ long newVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_Width )( 
            IApplication * This,
            /* [retval][out] */ long *pVal);
        
        /* [helpstring][propput][id] */ HRESULT ( STDMETHODCALLTYPE *put_Width )( 
            IApplication * This,
            /* [in] */ long newVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_Height )( 
            IApplication * This,
            /* [retval][out] */ long *pVal);
        
        /* [helpstring][propput][id] */ HRESULT ( STDMETHODCALLTYPE *put_Height )( 
            IApplication * This,
            /* [in] */ long newVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *Restore )( 
            IApplication * This);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *Close )( 
            IApplication * This);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *GiveUserControl )( 
            IApplication * This);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_Preferences )( 
            IApplication * This,
            /* [retval][out] */ IPreferences **pVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_TextComparison )( 
            IApplication * This,
            /* [retval][out] */ ITextComparison2 **pVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_BinaryComparison )( 
            IApplication * This,
            /* [retval][out] */ IBinaryComparison **pVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_ImageComparison )( 
            IApplication * This,
            /* [retval][out] */ IImageComparison **pVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_FolderComparison )( 
            IApplication * This,
            /* [retval][out] */ IFolderComparison **pVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *CompareItems )( 
            IApplication * This,
            /* [in] */ VARIANT firstItem,
            /* [in] */ VARIANT secondItem,
            /* [optional][in] */ VARIANT thirdItem,
            /* [retval][out] */ IComparison **pObject);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *OpenComparison )( 
            IApplication * This,
            /* [in] */ BSTR filename);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_Version )( 
            IApplication * This,
            /* [retval][out] */ BSTR *pVal);
        
        END_INTERFACE
    } IApplicationVtbl;

    interface IApplication
    {
        CONST_VTBL struct IApplicationVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IApplication_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 

#define IApplication_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 

#define IApplication_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 


#define IApplication_GetTypeInfoCount(This,pctinfo)	\
    ( (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo) ) 

#define IApplication_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    ( (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo) ) 

#define IApplication_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    ( (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId) ) 

#define IApplication_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    ( (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr) ) 


#define IApplication_get_Active(This,pVal)	\
    ( (This)->lpVtbl -> get_Active(This,pVal) ) 

#define IApplication_put_Active(This,newVal)	\
    ( (This)->lpVtbl -> put_Active(This,newVal) ) 

#define IApplication_get_Visible(This,pVal)	\
    ( (This)->lpVtbl -> get_Visible(This,pVal) ) 

#define IApplication_put_Visible(This,newVal)	\
    ( (This)->lpVtbl -> put_Visible(This,newVal) ) 

#define IApplication_get_Minimized(This,pVal)	\
    ( (This)->lpVtbl -> get_Minimized(This,pVal) ) 

#define IApplication_put_Minimized(This,newVal)	\
    ( (This)->lpVtbl -> put_Minimized(This,newVal) ) 

#define IApplication_get_Maximized(This,pVal)	\
    ( (This)->lpVtbl -> get_Maximized(This,pVal) ) 

#define IApplication_put_Maximized(This,newVal)	\
    ( (This)->lpVtbl -> put_Maximized(This,newVal) ) 

#define IApplication_get_Left(This,pVal)	\
    ( (This)->lpVtbl -> get_Left(This,pVal) ) 

#define IApplication_put_Left(This,newVal)	\
    ( (This)->lpVtbl -> put_Left(This,newVal) ) 

#define IApplication_get_Top(This,pVal)	\
    ( (This)->lpVtbl -> get_Top(This,pVal) ) 

#define IApplication_put_Top(This,newVal)	\
    ( (This)->lpVtbl -> put_Top(This,newVal) ) 

#define IApplication_get_Width(This,pVal)	\
    ( (This)->lpVtbl -> get_Width(This,pVal) ) 

#define IApplication_put_Width(This,newVal)	\
    ( (This)->lpVtbl -> put_Width(This,newVal) ) 

#define IApplication_get_Height(This,pVal)	\
    ( (This)->lpVtbl -> get_Height(This,pVal) ) 

#define IApplication_put_Height(This,newVal)	\
    ( (This)->lpVtbl -> put_Height(This,newVal) ) 

#define IApplication_Restore(This)	\
    ( (This)->lpVtbl -> Restore(This) ) 

#define IApplication_Close(This)	\
    ( (This)->lpVtbl -> Close(This) ) 

#define IApplication_GiveUserControl(This)	\
    ( (This)->lpVtbl -> GiveUserControl(This) ) 


#define IApplication_get_Preferences(This,pVal)	\
    ( (This)->lpVtbl -> get_Preferences(This,pVal) ) 

#define IApplication_get_TextComparison(This,pVal)	\
    ( (This)->lpVtbl -> get_TextComparison(This,pVal) ) 

#define IApplication_get_BinaryComparison(This,pVal)	\
    ( (This)->lpVtbl -> get_BinaryComparison(This,pVal) ) 

#define IApplication_get_ImageComparison(This,pVal)	\
    ( (This)->lpVtbl -> get_ImageComparison(This,pVal) ) 

#define IApplication_get_FolderComparison(This,pVal)	\
    ( (This)->lpVtbl -> get_FolderComparison(This,pVal) ) 

#define IApplication_CompareItems(This,firstItem,secondItem,thirdItem,pObject)	\
    ( (This)->lpVtbl -> CompareItems(This,firstItem,secondItem,thirdItem,pObject) ) 

#define IApplication_OpenComparison(This,filename)	\
    ( (This)->lpVtbl -> OpenComparison(This,filename) ) 

#define IApplication_get_Version(This,pVal)	\
    ( (This)->lpVtbl -> get_Version(This,pVal) ) 

#endif /* COBJMACROS */


#endif 	/* C style interface */




#endif 	/* __IApplication_INTERFACE_DEFINED__ */


#ifndef __IApplication2_INTERFACE_DEFINED__
#define __IApplication2_INTERFACE_DEFINED__

/* interface IApplication2 */
/* [version][unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_IApplication2;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("e61569ff-93dc-44ed-b943-7e9defde40bf")
    IApplication2 : public IApplication
    {
    public:
        virtual /* [helpstring][propget][id] */ HRESULT STDMETHODCALLTYPE get_Encodings( 
            /* [retval][out] */ IEncodings **pVal) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IApplication2Vtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IApplication2 * This,
            /* [in] */ REFIID riid,
            /* [annotation][iid_is][out] */ 
            __RPC__deref_out  void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IApplication2 * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IApplication2 * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            IApplication2 * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            IApplication2 * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            IApplication2 * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [range][in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            IApplication2 * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_Active )( 
            IApplication2 * This,
            /* [retval][out] */ VARIANT_BOOL *pVal);
        
        /* [helpstring][propput][id] */ HRESULT ( STDMETHODCALLTYPE *put_Active )( 
            IApplication2 * This,
            /* [in] */ VARIANT_BOOL newVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_Visible )( 
            IApplication2 * This,
            /* [retval][out] */ VARIANT_BOOL *pVal);
        
        /* [helpstring][propput][id] */ HRESULT ( STDMETHODCALLTYPE *put_Visible )( 
            IApplication2 * This,
            /* [in] */ VARIANT_BOOL newVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_Minimized )( 
            IApplication2 * This,
            /* [retval][out] */ VARIANT_BOOL *pVal);
        
        /* [helpstring][propput][id] */ HRESULT ( STDMETHODCALLTYPE *put_Minimized )( 
            IApplication2 * This,
            /* [in] */ VARIANT_BOOL newVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_Maximized )( 
            IApplication2 * This,
            /* [retval][out] */ VARIANT_BOOL *pVal);
        
        /* [helpstring][propput][id] */ HRESULT ( STDMETHODCALLTYPE *put_Maximized )( 
            IApplication2 * This,
            /* [in] */ VARIANT_BOOL newVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_Left )( 
            IApplication2 * This,
            /* [retval][out] */ long *pVal);
        
        /* [helpstring][propput][id] */ HRESULT ( STDMETHODCALLTYPE *put_Left )( 
            IApplication2 * This,
            /* [in] */ long newVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_Top )( 
            IApplication2 * This,
            /* [retval][out] */ long *pVal);
        
        /* [helpstring][propput][id] */ HRESULT ( STDMETHODCALLTYPE *put_Top )( 
            IApplication2 * This,
            /* [in] */ long newVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_Width )( 
            IApplication2 * This,
            /* [retval][out] */ long *pVal);
        
        /* [helpstring][propput][id] */ HRESULT ( STDMETHODCALLTYPE *put_Width )( 
            IApplication2 * This,
            /* [in] */ long newVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_Height )( 
            IApplication2 * This,
            /* [retval][out] */ long *pVal);
        
        /* [helpstring][propput][id] */ HRESULT ( STDMETHODCALLTYPE *put_Height )( 
            IApplication2 * This,
            /* [in] */ long newVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *Restore )( 
            IApplication2 * This);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *Close )( 
            IApplication2 * This);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *GiveUserControl )( 
            IApplication2 * This);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_Preferences )( 
            IApplication2 * This,
            /* [retval][out] */ IPreferences **pVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_TextComparison )( 
            IApplication2 * This,
            /* [retval][out] */ ITextComparison2 **pVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_BinaryComparison )( 
            IApplication2 * This,
            /* [retval][out] */ IBinaryComparison **pVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_ImageComparison )( 
            IApplication2 * This,
            /* [retval][out] */ IImageComparison **pVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_FolderComparison )( 
            IApplication2 * This,
            /* [retval][out] */ IFolderComparison **pVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *CompareItems )( 
            IApplication2 * This,
            /* [in] */ VARIANT firstItem,
            /* [in] */ VARIANT secondItem,
            /* [optional][in] */ VARIANT thirdItem,
            /* [retval][out] */ IComparison **pObject);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *OpenComparison )( 
            IApplication2 * This,
            /* [in] */ BSTR filename);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_Version )( 
            IApplication2 * This,
            /* [retval][out] */ BSTR *pVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_Encodings )( 
            IApplication2 * This,
            /* [retval][out] */ IEncodings **pVal);
        
        END_INTERFACE
    } IApplication2Vtbl;

    interface IApplication2
    {
        CONST_VTBL struct IApplication2Vtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IApplication2_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 

#define IApplication2_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 

#define IApplication2_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 


#define IApplication2_GetTypeInfoCount(This,pctinfo)	\
    ( (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo) ) 

#define IApplication2_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    ( (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo) ) 

#define IApplication2_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    ( (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId) ) 

#define IApplication2_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    ( (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr) ) 


#define IApplication2_get_Active(This,pVal)	\
    ( (This)->lpVtbl -> get_Active(This,pVal) ) 

#define IApplication2_put_Active(This,newVal)	\
    ( (This)->lpVtbl -> put_Active(This,newVal) ) 

#define IApplication2_get_Visible(This,pVal)	\
    ( (This)->lpVtbl -> get_Visible(This,pVal) ) 

#define IApplication2_put_Visible(This,newVal)	\
    ( (This)->lpVtbl -> put_Visible(This,newVal) ) 

#define IApplication2_get_Minimized(This,pVal)	\
    ( (This)->lpVtbl -> get_Minimized(This,pVal) ) 

#define IApplication2_put_Minimized(This,newVal)	\
    ( (This)->lpVtbl -> put_Minimized(This,newVal) ) 

#define IApplication2_get_Maximized(This,pVal)	\
    ( (This)->lpVtbl -> get_Maximized(This,pVal) ) 

#define IApplication2_put_Maximized(This,newVal)	\
    ( (This)->lpVtbl -> put_Maximized(This,newVal) ) 

#define IApplication2_get_Left(This,pVal)	\
    ( (This)->lpVtbl -> get_Left(This,pVal) ) 

#define IApplication2_put_Left(This,newVal)	\
    ( (This)->lpVtbl -> put_Left(This,newVal) ) 

#define IApplication2_get_Top(This,pVal)	\
    ( (This)->lpVtbl -> get_Top(This,pVal) ) 

#define IApplication2_put_Top(This,newVal)	\
    ( (This)->lpVtbl -> put_Top(This,newVal) ) 

#define IApplication2_get_Width(This,pVal)	\
    ( (This)->lpVtbl -> get_Width(This,pVal) ) 

#define IApplication2_put_Width(This,newVal)	\
    ( (This)->lpVtbl -> put_Width(This,newVal) ) 

#define IApplication2_get_Height(This,pVal)	\
    ( (This)->lpVtbl -> get_Height(This,pVal) ) 

#define IApplication2_put_Height(This,newVal)	\
    ( (This)->lpVtbl -> put_Height(This,newVal) ) 

#define IApplication2_Restore(This)	\
    ( (This)->lpVtbl -> Restore(This) ) 

#define IApplication2_Close(This)	\
    ( (This)->lpVtbl -> Close(This) ) 

#define IApplication2_GiveUserControl(This)	\
    ( (This)->lpVtbl -> GiveUserControl(This) ) 


#define IApplication2_get_Preferences(This,pVal)	\
    ( (This)->lpVtbl -> get_Preferences(This,pVal) ) 

#define IApplication2_get_TextComparison(This,pVal)	\
    ( (This)->lpVtbl -> get_TextComparison(This,pVal) ) 

#define IApplication2_get_BinaryComparison(This,pVal)	\
    ( (This)->lpVtbl -> get_BinaryComparison(This,pVal) ) 

#define IApplication2_get_ImageComparison(This,pVal)	\
    ( (This)->lpVtbl -> get_ImageComparison(This,pVal) ) 

#define IApplication2_get_FolderComparison(This,pVal)	\
    ( (This)->lpVtbl -> get_FolderComparison(This,pVal) ) 

#define IApplication2_CompareItems(This,firstItem,secondItem,thirdItem,pObject)	\
    ( (This)->lpVtbl -> CompareItems(This,firstItem,secondItem,thirdItem,pObject) ) 

#define IApplication2_OpenComparison(This,filename)	\
    ( (This)->lpVtbl -> OpenComparison(This,filename) ) 

#define IApplication2_get_Version(This,pVal)	\
    ( (This)->lpVtbl -> get_Version(This,pVal) ) 


#define IApplication2_get_Encodings(This,pVal)	\
    ( (This)->lpVtbl -> get_Encodings(This,pVal) ) 

#endif /* COBJMACROS */


#endif 	/* C style interface */




#endif 	/* __IApplication2_INTERFACE_DEFINED__ */


#ifndef __IApplication3_INTERFACE_DEFINED__
#define __IApplication3_INTERFACE_DEFINED__

/* interface IApplication3 */
/* [version][unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_IApplication3;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("85d5c97e-858f-4f89-9a4a-eab2a38a90a5")
    IApplication3 : public IApplication2
    {
    public:
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE CompareItemsAsync( 
            /* [in] */ VARIANT firstItem,
            /* [in] */ VARIANT secondItem,
            /* [optional][in] */ VARIANT thirdItem,
            /* [retval][out] */ IComparison **pObject) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IApplication3Vtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IApplication3 * This,
            /* [in] */ REFIID riid,
            /* [annotation][iid_is][out] */ 
            __RPC__deref_out  void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IApplication3 * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IApplication3 * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            IApplication3 * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            IApplication3 * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            IApplication3 * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [range][in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            IApplication3 * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_Active )( 
            IApplication3 * This,
            /* [retval][out] */ VARIANT_BOOL *pVal);
        
        /* [helpstring][propput][id] */ HRESULT ( STDMETHODCALLTYPE *put_Active )( 
            IApplication3 * This,
            /* [in] */ VARIANT_BOOL newVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_Visible )( 
            IApplication3 * This,
            /* [retval][out] */ VARIANT_BOOL *pVal);
        
        /* [helpstring][propput][id] */ HRESULT ( STDMETHODCALLTYPE *put_Visible )( 
            IApplication3 * This,
            /* [in] */ VARIANT_BOOL newVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_Minimized )( 
            IApplication3 * This,
            /* [retval][out] */ VARIANT_BOOL *pVal);
        
        /* [helpstring][propput][id] */ HRESULT ( STDMETHODCALLTYPE *put_Minimized )( 
            IApplication3 * This,
            /* [in] */ VARIANT_BOOL newVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_Maximized )( 
            IApplication3 * This,
            /* [retval][out] */ VARIANT_BOOL *pVal);
        
        /* [helpstring][propput][id] */ HRESULT ( STDMETHODCALLTYPE *put_Maximized )( 
            IApplication3 * This,
            /* [in] */ VARIANT_BOOL newVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_Left )( 
            IApplication3 * This,
            /* [retval][out] */ long *pVal);
        
        /* [helpstring][propput][id] */ HRESULT ( STDMETHODCALLTYPE *put_Left )( 
            IApplication3 * This,
            /* [in] */ long newVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_Top )( 
            IApplication3 * This,
            /* [retval][out] */ long *pVal);
        
        /* [helpstring][propput][id] */ HRESULT ( STDMETHODCALLTYPE *put_Top )( 
            IApplication3 * This,
            /* [in] */ long newVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_Width )( 
            IApplication3 * This,
            /* [retval][out] */ long *pVal);
        
        /* [helpstring][propput][id] */ HRESULT ( STDMETHODCALLTYPE *put_Width )( 
            IApplication3 * This,
            /* [in] */ long newVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_Height )( 
            IApplication3 * This,
            /* [retval][out] */ long *pVal);
        
        /* [helpstring][propput][id] */ HRESULT ( STDMETHODCALLTYPE *put_Height )( 
            IApplication3 * This,
            /* [in] */ long newVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *Restore )( 
            IApplication3 * This);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *Close )( 
            IApplication3 * This);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *GiveUserControl )( 
            IApplication3 * This);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_Preferences )( 
            IApplication3 * This,
            /* [retval][out] */ IPreferences **pVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_TextComparison )( 
            IApplication3 * This,
            /* [retval][out] */ ITextComparison2 **pVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_BinaryComparison )( 
            IApplication3 * This,
            /* [retval][out] */ IBinaryComparison **pVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_ImageComparison )( 
            IApplication3 * This,
            /* [retval][out] */ IImageComparison **pVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_FolderComparison )( 
            IApplication3 * This,
            /* [retval][out] */ IFolderComparison **pVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *CompareItems )( 
            IApplication3 * This,
            /* [in] */ VARIANT firstItem,
            /* [in] */ VARIANT secondItem,
            /* [optional][in] */ VARIANT thirdItem,
            /* [retval][out] */ IComparison **pObject);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *OpenComparison )( 
            IApplication3 * This,
            /* [in] */ BSTR filename);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_Version )( 
            IApplication3 * This,
            /* [retval][out] */ BSTR *pVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_Encodings )( 
            IApplication3 * This,
            /* [retval][out] */ IEncodings **pVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *CompareItemsAsync )( 
            IApplication3 * This,
            /* [in] */ VARIANT firstItem,
            /* [in] */ VARIANT secondItem,
            /* [optional][in] */ VARIANT thirdItem,
            /* [retval][out] */ IComparison **pObject);
        
        END_INTERFACE
    } IApplication3Vtbl;

    interface IApplication3
    {
        CONST_VTBL struct IApplication3Vtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IApplication3_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 

#define IApplication3_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 

#define IApplication3_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 


#define IApplication3_GetTypeInfoCount(This,pctinfo)	\
    ( (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo) ) 

#define IApplication3_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    ( (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo) ) 

#define IApplication3_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    ( (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId) ) 

#define IApplication3_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    ( (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr) ) 


#define IApplication3_get_Active(This,pVal)	\
    ( (This)->lpVtbl -> get_Active(This,pVal) ) 

#define IApplication3_put_Active(This,newVal)	\
    ( (This)->lpVtbl -> put_Active(This,newVal) ) 

#define IApplication3_get_Visible(This,pVal)	\
    ( (This)->lpVtbl -> get_Visible(This,pVal) ) 

#define IApplication3_put_Visible(This,newVal)	\
    ( (This)->lpVtbl -> put_Visible(This,newVal) ) 

#define IApplication3_get_Minimized(This,pVal)	\
    ( (This)->lpVtbl -> get_Minimized(This,pVal) ) 

#define IApplication3_put_Minimized(This,newVal)	\
    ( (This)->lpVtbl -> put_Minimized(This,newVal) ) 

#define IApplication3_get_Maximized(This,pVal)	\
    ( (This)->lpVtbl -> get_Maximized(This,pVal) ) 

#define IApplication3_put_Maximized(This,newVal)	\
    ( (This)->lpVtbl -> put_Maximized(This,newVal) ) 

#define IApplication3_get_Left(This,pVal)	\
    ( (This)->lpVtbl -> get_Left(This,pVal) ) 

#define IApplication3_put_Left(This,newVal)	\
    ( (This)->lpVtbl -> put_Left(This,newVal) ) 

#define IApplication3_get_Top(This,pVal)	\
    ( (This)->lpVtbl -> get_Top(This,pVal) ) 

#define IApplication3_put_Top(This,newVal)	\
    ( (This)->lpVtbl -> put_Top(This,newVal) ) 

#define IApplication3_get_Width(This,pVal)	\
    ( (This)->lpVtbl -> get_Width(This,pVal) ) 

#define IApplication3_put_Width(This,newVal)	\
    ( (This)->lpVtbl -> put_Width(This,newVal) ) 

#define IApplication3_get_Height(This,pVal)	\
    ( (This)->lpVtbl -> get_Height(This,pVal) ) 

#define IApplication3_put_Height(This,newVal)	\
    ( (This)->lpVtbl -> put_Height(This,newVal) ) 

#define IApplication3_Restore(This)	\
    ( (This)->lpVtbl -> Restore(This) ) 

#define IApplication3_Close(This)	\
    ( (This)->lpVtbl -> Close(This) ) 

#define IApplication3_GiveUserControl(This)	\
    ( (This)->lpVtbl -> GiveUserControl(This) ) 


#define IApplication3_get_Preferences(This,pVal)	\
    ( (This)->lpVtbl -> get_Preferences(This,pVal) ) 

#define IApplication3_get_TextComparison(This,pVal)	\
    ( (This)->lpVtbl -> get_TextComparison(This,pVal) ) 

#define IApplication3_get_BinaryComparison(This,pVal)	\
    ( (This)->lpVtbl -> get_BinaryComparison(This,pVal) ) 

#define IApplication3_get_ImageComparison(This,pVal)	\
    ( (This)->lpVtbl -> get_ImageComparison(This,pVal) ) 

#define IApplication3_get_FolderComparison(This,pVal)	\
    ( (This)->lpVtbl -> get_FolderComparison(This,pVal) ) 

#define IApplication3_CompareItems(This,firstItem,secondItem,thirdItem,pObject)	\
    ( (This)->lpVtbl -> CompareItems(This,firstItem,secondItem,thirdItem,pObject) ) 

#define IApplication3_OpenComparison(This,filename)	\
    ( (This)->lpVtbl -> OpenComparison(This,filename) ) 

#define IApplication3_get_Version(This,pVal)	\
    ( (This)->lpVtbl -> get_Version(This,pVal) ) 


#define IApplication3_get_Encodings(This,pVal)	\
    ( (This)->lpVtbl -> get_Encodings(This,pVal) ) 


#define IApplication3_CompareItemsAsync(This,firstItem,secondItem,thirdItem,pObject)	\
    ( (This)->lpVtbl -> CompareItemsAsync(This,firstItem,secondItem,thirdItem,pObject) ) 

#endif /* COBJMACROS */


#endif 	/* C style interface */




#endif 	/* __IApplication3_INTERFACE_DEFINED__ */


#ifndef __IUriInformation_INTERFACE_DEFINED__
#define __IUriInformation_INTERFACE_DEFINED__

/* interface IUriInformation */
/* [version][unique][helpstring][uuid][dual][object] */ 


EXTERN_C const IID IID_IUriInformation;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("5ee75d5a-cafe-4222-8a34-61f2a0ef0b0b")
    IUriInformation : public IUnknown
    {
    public:
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IsRealFolderUri( 
            /* [in] */ BSTR strUri) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IsWin32FileSystemUri( 
            /* [in] */ BSTR strUri) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IUriInformationVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IUriInformation * This,
            /* [in] */ REFIID riid,
            /* [annotation][iid_is][out] */ 
            __RPC__deref_out  void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IUriInformation * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IUriInformation * This);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *IsRealFolderUri )( 
            IUriInformation * This,
            /* [in] */ BSTR strUri);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *IsWin32FileSystemUri )( 
            IUriInformation * This,
            /* [in] */ BSTR strUri);
        
        END_INTERFACE
    } IUriInformationVtbl;

    interface IUriInformation
    {
        CONST_VTBL struct IUriInformationVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IUriInformation_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 

#define IUriInformation_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 

#define IUriInformation_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 


#define IUriInformation_IsRealFolderUri(This,strUri)	\
    ( (This)->lpVtbl -> IsRealFolderUri(This,strUri) ) 

#define IUriInformation_IsWin32FileSystemUri(This,strUri)	\
    ( (This)->lpVtbl -> IsWin32FileSystemUri(This,strUri) ) 

#endif /* COBJMACROS */


#endif 	/* C style interface */




#endif 	/* __IUriInformation_INTERFACE_DEFINED__ */


#ifndef __IWindowHandle_INTERFACE_DEFINED__
#define __IWindowHandle_INTERFACE_DEFINED__

/* interface IWindowHandle */
/* [version][unique][helpstring][uuid][dual][object] */ 


EXTERN_C const IID IID_IWindowHandle;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("f4388a36-8624-4e27-9e0d-843012e248e9")
    IWindowHandle : public IUnknown
    {
    public:
        virtual /* [helpstring][propget][id] */ HRESULT STDMETHODCALLTYPE get_WindowHandle( 
            /* [retval][out] */ unsigned __int64 *pHandle) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IWindowHandleVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IWindowHandle * This,
            /* [in] */ REFIID riid,
            /* [annotation][iid_is][out] */ 
            __RPC__deref_out  void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IWindowHandle * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IWindowHandle * This);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_WindowHandle )( 
            IWindowHandle * This,
            /* [retval][out] */ unsigned __int64 *pHandle);
        
        END_INTERFACE
    } IWindowHandleVtbl;

    interface IWindowHandle
    {
        CONST_VTBL struct IWindowHandleVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IWindowHandle_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 

#define IWindowHandle_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 

#define IWindowHandle_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 


#define IWindowHandle_get_WindowHandle(This,pHandle)	\
    ( (This)->lpVtbl -> get_WindowHandle(This,pHandle) ) 

#endif /* COBJMACROS */


#endif 	/* C style interface */




#endif 	/* __IWindowHandle_INTERFACE_DEFINED__ */


#ifndef __IStringPreferences_INTERFACE_DEFINED__
#define __IStringPreferences_INTERFACE_DEFINED__

/* interface IStringPreferences */
/* [version][uuid][helpstring][unique][dual][object] */ 


EXTERN_C const IID IID_IStringPreferences;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("c379af05-f8a5-4099-90ff-209245feac81")
    IStringPreferences : public IDispatch
    {
    public:
        virtual /* [helpstring][propget][id] */ HRESULT STDMETHODCALLTYPE get_Item( 
            /* [in] */ VARIANT index,
            /* [retval][out] */ BSTR *pVal) = 0;
        
        virtual /* [helpstring][propput][id] */ HRESULT STDMETHODCALLTYPE put_Item( 
            /* [in] */ VARIANT index,
            /* [in] */ BSTR newVal) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE Set( 
            /* [in] */ VARIANT index,
            /* [in] */ BSTR newVal) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IStringPreferencesVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IStringPreferences * This,
            /* [in] */ REFIID riid,
            /* [annotation][iid_is][out] */ 
            __RPC__deref_out  void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IStringPreferences * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IStringPreferences * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            IStringPreferences * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            IStringPreferences * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            IStringPreferences * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [range][in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            IStringPreferences * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_Item )( 
            IStringPreferences * This,
            /* [in] */ VARIANT index,
            /* [retval][out] */ BSTR *pVal);
        
        /* [helpstring][propput][id] */ HRESULT ( STDMETHODCALLTYPE *put_Item )( 
            IStringPreferences * This,
            /* [in] */ VARIANT index,
            /* [in] */ BSTR newVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *Set )( 
            IStringPreferences * This,
            /* [in] */ VARIANT index,
            /* [in] */ BSTR newVal);
        
        END_INTERFACE
    } IStringPreferencesVtbl;

    interface IStringPreferences
    {
        CONST_VTBL struct IStringPreferencesVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IStringPreferences_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 

#define IStringPreferences_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 

#define IStringPreferences_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 


#define IStringPreferences_GetTypeInfoCount(This,pctinfo)	\
    ( (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo) ) 

#define IStringPreferences_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    ( (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo) ) 

#define IStringPreferences_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    ( (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId) ) 

#define IStringPreferences_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    ( (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr) ) 


#define IStringPreferences_get_Item(This,index,pVal)	\
    ( (This)->lpVtbl -> get_Item(This,index,pVal) ) 

#define IStringPreferences_put_Item(This,index,newVal)	\
    ( (This)->lpVtbl -> put_Item(This,index,newVal) ) 

#define IStringPreferences_Set(This,index,newVal)	\
    ( (This)->lpVtbl -> Set(This,index,newVal) ) 

#endif /* COBJMACROS */


#endif 	/* C style interface */




#endif 	/* __IStringPreferences_INTERFACE_DEFINED__ */


#ifndef __ILongPreferences_INTERFACE_DEFINED__
#define __ILongPreferences_INTERFACE_DEFINED__

/* interface ILongPreferences */
/* [version][uuid][helpstring][unique][dual][object] */ 


EXTERN_C const IID IID_ILongPreferences;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("7a9ac575-c973-44fb-af25-a508dc311e73")
    ILongPreferences : public IDispatch
    {
    public:
        virtual /* [helpstring][propget][id] */ HRESULT STDMETHODCALLTYPE get_Item( 
            /* [in] */ VARIANT index,
            /* [retval][out] */ long *pVal) = 0;
        
        virtual /* [helpstring][propput][id] */ HRESULT STDMETHODCALLTYPE put_Item( 
            /* [in] */ VARIANT index,
            /* [in] */ long nNewValue) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE Set( 
            /* [in] */ VARIANT index,
            /* [in] */ long nNewValue) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct ILongPreferencesVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            ILongPreferences * This,
            /* [in] */ REFIID riid,
            /* [annotation][iid_is][out] */ 
            __RPC__deref_out  void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            ILongPreferences * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            ILongPreferences * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            ILongPreferences * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            ILongPreferences * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            ILongPreferences * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [range][in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            ILongPreferences * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_Item )( 
            ILongPreferences * This,
            /* [in] */ VARIANT index,
            /* [retval][out] */ long *pVal);
        
        /* [helpstring][propput][id] */ HRESULT ( STDMETHODCALLTYPE *put_Item )( 
            ILongPreferences * This,
            /* [in] */ VARIANT index,
            /* [in] */ long nNewValue);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *Set )( 
            ILongPreferences * This,
            /* [in] */ VARIANT index,
            /* [in] */ long nNewValue);
        
        END_INTERFACE
    } ILongPreferencesVtbl;

    interface ILongPreferences
    {
        CONST_VTBL struct ILongPreferencesVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define ILongPreferences_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 

#define ILongPreferences_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 

#define ILongPreferences_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 


#define ILongPreferences_GetTypeInfoCount(This,pctinfo)	\
    ( (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo) ) 

#define ILongPreferences_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    ( (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo) ) 

#define ILongPreferences_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    ( (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId) ) 

#define ILongPreferences_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    ( (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr) ) 


#define ILongPreferences_get_Item(This,index,pVal)	\
    ( (This)->lpVtbl -> get_Item(This,index,pVal) ) 

#define ILongPreferences_put_Item(This,index,nNewValue)	\
    ( (This)->lpVtbl -> put_Item(This,index,nNewValue) ) 

#define ILongPreferences_Set(This,index,nNewValue)	\
    ( (This)->lpVtbl -> Set(This,index,nNewValue) ) 

#endif /* COBJMACROS */


#endif 	/* C style interface */




#endif 	/* __ILongPreferences_INTERFACE_DEFINED__ */


#ifndef __IDoublePreferences_INTERFACE_DEFINED__
#define __IDoublePreferences_INTERFACE_DEFINED__

/* interface IDoublePreferences */
/* [version][uuid][helpstring][unique][dual][object] */ 


EXTERN_C const IID IID_IDoublePreferences;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("35dbc559-8f3d-4eb9-9569-30070cac935c")
    IDoublePreferences : public IDispatch
    {
    public:
        virtual /* [helpstring][propget][id] */ HRESULT STDMETHODCALLTYPE get_Item( 
            /* [in] */ VARIANT index,
            /* [retval][out] */ double *pVal) = 0;
        
        virtual /* [helpstring][propput][id] */ HRESULT STDMETHODCALLTYPE put_Item( 
            /* [in] */ VARIANT index,
            /* [in] */ double newVal) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE Set( 
            /* [in] */ VARIANT index,
            /* [in] */ double newVal) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IDoublePreferencesVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IDoublePreferences * This,
            /* [in] */ REFIID riid,
            /* [annotation][iid_is][out] */ 
            __RPC__deref_out  void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IDoublePreferences * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IDoublePreferences * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            IDoublePreferences * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            IDoublePreferences * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            IDoublePreferences * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [range][in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            IDoublePreferences * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_Item )( 
            IDoublePreferences * This,
            /* [in] */ VARIANT index,
            /* [retval][out] */ double *pVal);
        
        /* [helpstring][propput][id] */ HRESULT ( STDMETHODCALLTYPE *put_Item )( 
            IDoublePreferences * This,
            /* [in] */ VARIANT index,
            /* [in] */ double newVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *Set )( 
            IDoublePreferences * This,
            /* [in] */ VARIANT index,
            /* [in] */ double newVal);
        
        END_INTERFACE
    } IDoublePreferencesVtbl;

    interface IDoublePreferences
    {
        CONST_VTBL struct IDoublePreferencesVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IDoublePreferences_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 

#define IDoublePreferences_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 

#define IDoublePreferences_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 


#define IDoublePreferences_GetTypeInfoCount(This,pctinfo)	\
    ( (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo) ) 

#define IDoublePreferences_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    ( (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo) ) 

#define IDoublePreferences_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    ( (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId) ) 

#define IDoublePreferences_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    ( (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr) ) 


#define IDoublePreferences_get_Item(This,index,pVal)	\
    ( (This)->lpVtbl -> get_Item(This,index,pVal) ) 

#define IDoublePreferences_put_Item(This,index,newVal)	\
    ( (This)->lpVtbl -> put_Item(This,index,newVal) ) 

#define IDoublePreferences_Set(This,index,newVal)	\
    ( (This)->lpVtbl -> Set(This,index,newVal) ) 

#endif /* COBJMACROS */


#endif 	/* C style interface */




#endif 	/* __IDoublePreferences_INTERFACE_DEFINED__ */


#ifndef __IComparison_INTERFACE_DEFINED__
#define __IComparison_INTERFACE_DEFINED__

/* interface IComparison */
/* [version][uuid][helpstring][unique][dual][object] */ 


EXTERN_C const IID IID_IComparison;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("fe077546-8a67-4e66-af50-601a6c301529")
    IComparison : public ICommonUI
    {
    public:
        virtual /* [helpstring][propget][id] */ HRESULT STDMETHODCALLTYPE get_ViewType( 
            /* [retval][out] */ FileViewType *pVal) = 0;
        
        virtual /* [helpstring][propput][id] */ HRESULT STDMETHODCALLTYPE put_ViewType( 
            /* [in] */ FileViewType newVal) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE Compare( 
            /* [in] */ VARIANT strFirstFile,
            /* [in] */ VARIANT strSecondFile,
            /* [optional][in] */ VARIANT strThirdFile) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE Refresh( void) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE SaveComparison( 
            /* [in] */ BSTR filename) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE SetPanelTitles( 
            /* [in] */ VARIANT strFirst,
            /* [in] */ VARIANT strSecond,
            /* [optional][in] */ VARIANT strThird) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE Print( 
            /* [defaultvalue][in] */ VARIANT_BOOL bShowPrinterDialog = 0,
            /* [defaultvalue][in] */ PageOrientation nOrientation = poLandscape) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE Report( 
            /* [in] */ BSTR bstrReporter,
            /* [in] */ LineEndingStyle nLineEndingStyle,
            /* [in] */ BSTR strOutputFile) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE Report2( 
            /* [in] */ BSTR bstrReporter,
            /* [in] */ LineEndingStyle nLineEndingStyle,
            /* [in] */ VARIANT vtEncoding,
            /* [in] */ BSTR strOutputFile) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IComparisonVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IComparison * This,
            /* [in] */ REFIID riid,
            /* [annotation][iid_is][out] */ 
            __RPC__deref_out  void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IComparison * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IComparison * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            IComparison * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            IComparison * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            IComparison * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [range][in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            IComparison * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_Active )( 
            IComparison * This,
            /* [retval][out] */ VARIANT_BOOL *pVal);
        
        /* [helpstring][propput][id] */ HRESULT ( STDMETHODCALLTYPE *put_Active )( 
            IComparison * This,
            /* [in] */ VARIANT_BOOL newVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_Visible )( 
            IComparison * This,
            /* [retval][out] */ VARIANT_BOOL *pVal);
        
        /* [helpstring][propput][id] */ HRESULT ( STDMETHODCALLTYPE *put_Visible )( 
            IComparison * This,
            /* [in] */ VARIANT_BOOL newVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_Minimized )( 
            IComparison * This,
            /* [retval][out] */ VARIANT_BOOL *pVal);
        
        /* [helpstring][propput][id] */ HRESULT ( STDMETHODCALLTYPE *put_Minimized )( 
            IComparison * This,
            /* [in] */ VARIANT_BOOL newVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_Maximized )( 
            IComparison * This,
            /* [retval][out] */ VARIANT_BOOL *pVal);
        
        /* [helpstring][propput][id] */ HRESULT ( STDMETHODCALLTYPE *put_Maximized )( 
            IComparison * This,
            /* [in] */ VARIANT_BOOL newVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_Left )( 
            IComparison * This,
            /* [retval][out] */ long *pVal);
        
        /* [helpstring][propput][id] */ HRESULT ( STDMETHODCALLTYPE *put_Left )( 
            IComparison * This,
            /* [in] */ long newVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_Top )( 
            IComparison * This,
            /* [retval][out] */ long *pVal);
        
        /* [helpstring][propput][id] */ HRESULT ( STDMETHODCALLTYPE *put_Top )( 
            IComparison * This,
            /* [in] */ long newVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_Width )( 
            IComparison * This,
            /* [retval][out] */ long *pVal);
        
        /* [helpstring][propput][id] */ HRESULT ( STDMETHODCALLTYPE *put_Width )( 
            IComparison * This,
            /* [in] */ long newVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_Height )( 
            IComparison * This,
            /* [retval][out] */ long *pVal);
        
        /* [helpstring][propput][id] */ HRESULT ( STDMETHODCALLTYPE *put_Height )( 
            IComparison * This,
            /* [in] */ long newVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *Restore )( 
            IComparison * This);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *Close )( 
            IComparison * This);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *GiveUserControl )( 
            IComparison * This);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_ViewType )( 
            IComparison * This,
            /* [retval][out] */ FileViewType *pVal);
        
        /* [helpstring][propput][id] */ HRESULT ( STDMETHODCALLTYPE *put_ViewType )( 
            IComparison * This,
            /* [in] */ FileViewType newVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *Compare )( 
            IComparison * This,
            /* [in] */ VARIANT strFirstFile,
            /* [in] */ VARIANT strSecondFile,
            /* [optional][in] */ VARIANT strThirdFile);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *Refresh )( 
            IComparison * This);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *SaveComparison )( 
            IComparison * This,
            /* [in] */ BSTR filename);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *SetPanelTitles )( 
            IComparison * This,
            /* [in] */ VARIANT strFirst,
            /* [in] */ VARIANT strSecond,
            /* [optional][in] */ VARIANT strThird);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *Print )( 
            IComparison * This,
            /* [defaultvalue][in] */ VARIANT_BOOL bShowPrinterDialog,
            /* [defaultvalue][in] */ PageOrientation nOrientation);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *Report )( 
            IComparison * This,
            /* [in] */ BSTR bstrReporter,
            /* [in] */ LineEndingStyle nLineEndingStyle,
            /* [in] */ BSTR strOutputFile);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *Report2 )( 
            IComparison * This,
            /* [in] */ BSTR bstrReporter,
            /* [in] */ LineEndingStyle nLineEndingStyle,
            /* [in] */ VARIANT vtEncoding,
            /* [in] */ BSTR strOutputFile);
        
        END_INTERFACE
    } IComparisonVtbl;

    interface IComparison
    {
        CONST_VTBL struct IComparisonVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IComparison_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 

#define IComparison_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 

#define IComparison_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 


#define IComparison_GetTypeInfoCount(This,pctinfo)	\
    ( (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo) ) 

#define IComparison_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    ( (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo) ) 

#define IComparison_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    ( (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId) ) 

#define IComparison_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    ( (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr) ) 


#define IComparison_get_Active(This,pVal)	\
    ( (This)->lpVtbl -> get_Active(This,pVal) ) 

#define IComparison_put_Active(This,newVal)	\
    ( (This)->lpVtbl -> put_Active(This,newVal) ) 

#define IComparison_get_Visible(This,pVal)	\
    ( (This)->lpVtbl -> get_Visible(This,pVal) ) 

#define IComparison_put_Visible(This,newVal)	\
    ( (This)->lpVtbl -> put_Visible(This,newVal) ) 

#define IComparison_get_Minimized(This,pVal)	\
    ( (This)->lpVtbl -> get_Minimized(This,pVal) ) 

#define IComparison_put_Minimized(This,newVal)	\
    ( (This)->lpVtbl -> put_Minimized(This,newVal) ) 

#define IComparison_get_Maximized(This,pVal)	\
    ( (This)->lpVtbl -> get_Maximized(This,pVal) ) 

#define IComparison_put_Maximized(This,newVal)	\
    ( (This)->lpVtbl -> put_Maximized(This,newVal) ) 

#define IComparison_get_Left(This,pVal)	\
    ( (This)->lpVtbl -> get_Left(This,pVal) ) 

#define IComparison_put_Left(This,newVal)	\
    ( (This)->lpVtbl -> put_Left(This,newVal) ) 

#define IComparison_get_Top(This,pVal)	\
    ( (This)->lpVtbl -> get_Top(This,pVal) ) 

#define IComparison_put_Top(This,newVal)	\
    ( (This)->lpVtbl -> put_Top(This,newVal) ) 

#define IComparison_get_Width(This,pVal)	\
    ( (This)->lpVtbl -> get_Width(This,pVal) ) 

#define IComparison_put_Width(This,newVal)	\
    ( (This)->lpVtbl -> put_Width(This,newVal) ) 

#define IComparison_get_Height(This,pVal)	\
    ( (This)->lpVtbl -> get_Height(This,pVal) ) 

#define IComparison_put_Height(This,newVal)	\
    ( (This)->lpVtbl -> put_Height(This,newVal) ) 

#define IComparison_Restore(This)	\
    ( (This)->lpVtbl -> Restore(This) ) 

#define IComparison_Close(This)	\
    ( (This)->lpVtbl -> Close(This) ) 

#define IComparison_GiveUserControl(This)	\
    ( (This)->lpVtbl -> GiveUserControl(This) ) 


#define IComparison_get_ViewType(This,pVal)	\
    ( (This)->lpVtbl -> get_ViewType(This,pVal) ) 

#define IComparison_put_ViewType(This,newVal)	\
    ( (This)->lpVtbl -> put_ViewType(This,newVal) ) 

#define IComparison_Compare(This,strFirstFile,strSecondFile,strThirdFile)	\
    ( (This)->lpVtbl -> Compare(This,strFirstFile,strSecondFile,strThirdFile) ) 

#define IComparison_Refresh(This)	\
    ( (This)->lpVtbl -> Refresh(This) ) 

#define IComparison_SaveComparison(This,filename)	\
    ( (This)->lpVtbl -> SaveComparison(This,filename) ) 

#define IComparison_SetPanelTitles(This,strFirst,strSecond,strThird)	\
    ( (This)->lpVtbl -> SetPanelTitles(This,strFirst,strSecond,strThird) ) 

#define IComparison_Print(This,bShowPrinterDialog,nOrientation)	\
    ( (This)->lpVtbl -> Print(This,bShowPrinterDialog,nOrientation) ) 

#define IComparison_Report(This,bstrReporter,nLineEndingStyle,strOutputFile)	\
    ( (This)->lpVtbl -> Report(This,bstrReporter,nLineEndingStyle,strOutputFile) ) 

#define IComparison_Report2(This,bstrReporter,nLineEndingStyle,vtEncoding,strOutputFile)	\
    ( (This)->lpVtbl -> Report2(This,bstrReporter,nLineEndingStyle,vtEncoding,strOutputFile) ) 

#endif /* COBJMACROS */


#endif 	/* C style interface */




#endif 	/* __IComparison_INTERFACE_DEFINED__ */


#ifndef __IFileComparison_INTERFACE_DEFINED__
#define __IFileComparison_INTERFACE_DEFINED__

/* interface IFileComparison */
/* [version][uuid][helpstring][unique][dual][object] */ 


EXTERN_C const IID IID_IFileComparison;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("a53fc5d8-63a2-475f-a577-7c96859ef23c")
    IFileComparison : public IComparison
    {
    public:
        virtual /* [helpstring][propget][id] */ HRESULT STDMETHODCALLTYPE get_SaveFileName( 
            /* [retval][out] */ BSTR *pVal) = 0;
        
        virtual /* [helpstring][propput][id] */ HRESULT STDMETHODCALLTYPE put_SaveFileName( 
            /* [in] */ BSTR newVal) = 0;
        
        virtual /* [helpstring][propget][id] */ HRESULT STDMETHODCALLTYPE get_ComparisonResult( 
            /* [optional][in] */ VARIANT nFilePair,
            /* [retval][out] */ FileComparisonResult *pVal) = 0;
        
        virtual /* [helpstring][propget][id] */ HRESULT STDMETHODCALLTYPE get_ComparisonError( 
            /* [optional][in] */ VARIANT nFilePair,
            /* [retval][out] */ FileComparisonError *pVal) = 0;
        
        virtual /* [helpstring][propget][id] */ HRESULT STDMETHODCALLTYPE get_ErrorInfo( 
            /* [in] */ short nFile,
            /* [retval][out] */ BSTR *pVal) = 0;
        
        virtual /* [helpstring][propget][id] */ HRESULT STDMETHODCALLTYPE get_Modified( 
            /* [in] */ short nFile,
            /* [retval][out] */ VARIANT_BOOL *pVal) = 0;
        
        virtual /* [helpstring][propput][id] */ HRESULT STDMETHODCALLTYPE put_Modified( 
            /* [in] */ short nFile,
            /* [in] */ VARIANT_BOOL bModified) = 0;
        
        virtual /* [helpstring][propget][id] */ HRESULT STDMETHODCALLTYPE get_ReadOnly( 
            /* [in] */ short nFile,
            /* [retval][out] */ VARIANT_BOOL *pVal) = 0;
        
        virtual /* [helpstring][propput][id] */ HRESULT STDMETHODCALLTYPE put_ReadOnly( 
            /* [in] */ short nFile,
            /* [in] */ VARIANT_BOOL bReadOnly) = 0;
        
        virtual /* [helpstring][propget][id] */ HRESULT STDMETHODCALLTYPE get_PromptForUnsavedFiles( 
            /* [retval][out] */ VARIANT_BOOL *pVal) = 0;
        
        virtual /* [helpstring][propput][id] */ HRESULT STDMETHODCALLTYPE put_PromptForUnsavedFiles( 
            /* [in] */ VARIANT_BOOL bPrompt) = 0;
        
        virtual /* [helpstring][propget][id] */ HRESULT STDMETHODCALLTYPE get_AutoSaveOnClose( 
            /* [retval][out] */ VARIANT_BOOL *pVal) = 0;
        
        virtual /* [helpstring][propput][id] */ HRESULT STDMETHODCALLTYPE put_AutoSaveOnClose( 
            /* [in] */ VARIANT_BOOL bAutoSaveOnClose) = 0;
        
        virtual /* [helpstring][propget][id] */ HRESULT STDMETHODCALLTYPE get_ThreeWayMergeActions( 
            /* [retval][out] */ IThreeWayMergeActions **pVal) = 0;
        
        virtual /* [helpstring][propget][id] */ HRESULT STDMETHODCALLTYPE get_UnresolvedConflicts( 
            /* [in] */ short nFile,
            /* [retval][out] */ long *pVal) = 0;
        
        virtual /* [helpstring][propget][id] */ HRESULT STDMETHODCALLTYPE get_AllUnresolvedConflicts( 
            /* [retval][out] */ long *pVal) = 0;
        
        virtual /* [helpstring][propget][id] */ HRESULT STDMETHODCALLTYPE get_NumberOfChanges( 
            /* [optional][in] */ VARIANT nFilePair,
            /* [retval][out] */ long *pVal) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE CompareAsync( 
            /* [in] */ VARIANT strFirstFile,
            /* [in] */ VARIANT strSecondFile,
            /* [optional][in] */ VARIANT strThirdFile) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE SaveFile( 
            /* [in] */ short nFile,
            /* [optional][in] */ VARIANT strSaveTo) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE SaveFileAs( 
            /* [in] */ short nFile) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ThreeWayMerge( 
            /* [retval][out] */ long *pVal) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IFileComparisonVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IFileComparison * This,
            /* [in] */ REFIID riid,
            /* [annotation][iid_is][out] */ 
            __RPC__deref_out  void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IFileComparison * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IFileComparison * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            IFileComparison * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            IFileComparison * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            IFileComparison * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [range][in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            IFileComparison * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_Active )( 
            IFileComparison * This,
            /* [retval][out] */ VARIANT_BOOL *pVal);
        
        /* [helpstring][propput][id] */ HRESULT ( STDMETHODCALLTYPE *put_Active )( 
            IFileComparison * This,
            /* [in] */ VARIANT_BOOL newVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_Visible )( 
            IFileComparison * This,
            /* [retval][out] */ VARIANT_BOOL *pVal);
        
        /* [helpstring][propput][id] */ HRESULT ( STDMETHODCALLTYPE *put_Visible )( 
            IFileComparison * This,
            /* [in] */ VARIANT_BOOL newVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_Minimized )( 
            IFileComparison * This,
            /* [retval][out] */ VARIANT_BOOL *pVal);
        
        /* [helpstring][propput][id] */ HRESULT ( STDMETHODCALLTYPE *put_Minimized )( 
            IFileComparison * This,
            /* [in] */ VARIANT_BOOL newVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_Maximized )( 
            IFileComparison * This,
            /* [retval][out] */ VARIANT_BOOL *pVal);
        
        /* [helpstring][propput][id] */ HRESULT ( STDMETHODCALLTYPE *put_Maximized )( 
            IFileComparison * This,
            /* [in] */ VARIANT_BOOL newVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_Left )( 
            IFileComparison * This,
            /* [retval][out] */ long *pVal);
        
        /* [helpstring][propput][id] */ HRESULT ( STDMETHODCALLTYPE *put_Left )( 
            IFileComparison * This,
            /* [in] */ long newVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_Top )( 
            IFileComparison * This,
            /* [retval][out] */ long *pVal);
        
        /* [helpstring][propput][id] */ HRESULT ( STDMETHODCALLTYPE *put_Top )( 
            IFileComparison * This,
            /* [in] */ long newVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_Width )( 
            IFileComparison * This,
            /* [retval][out] */ long *pVal);
        
        /* [helpstring][propput][id] */ HRESULT ( STDMETHODCALLTYPE *put_Width )( 
            IFileComparison * This,
            /* [in] */ long newVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_Height )( 
            IFileComparison * This,
            /* [retval][out] */ long *pVal);
        
        /* [helpstring][propput][id] */ HRESULT ( STDMETHODCALLTYPE *put_Height )( 
            IFileComparison * This,
            /* [in] */ long newVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *Restore )( 
            IFileComparison * This);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *Close )( 
            IFileComparison * This);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *GiveUserControl )( 
            IFileComparison * This);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_ViewType )( 
            IFileComparison * This,
            /* [retval][out] */ FileViewType *pVal);
        
        /* [helpstring][propput][id] */ HRESULT ( STDMETHODCALLTYPE *put_ViewType )( 
            IFileComparison * This,
            /* [in] */ FileViewType newVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *Compare )( 
            IFileComparison * This,
            /* [in] */ VARIANT strFirstFile,
            /* [in] */ VARIANT strSecondFile,
            /* [optional][in] */ VARIANT strThirdFile);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *Refresh )( 
            IFileComparison * This);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *SaveComparison )( 
            IFileComparison * This,
            /* [in] */ BSTR filename);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *SetPanelTitles )( 
            IFileComparison * This,
            /* [in] */ VARIANT strFirst,
            /* [in] */ VARIANT strSecond,
            /* [optional][in] */ VARIANT strThird);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *Print )( 
            IFileComparison * This,
            /* [defaultvalue][in] */ VARIANT_BOOL bShowPrinterDialog,
            /* [defaultvalue][in] */ PageOrientation nOrientation);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *Report )( 
            IFileComparison * This,
            /* [in] */ BSTR bstrReporter,
            /* [in] */ LineEndingStyle nLineEndingStyle,
            /* [in] */ BSTR strOutputFile);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *Report2 )( 
            IFileComparison * This,
            /* [in] */ BSTR bstrReporter,
            /* [in] */ LineEndingStyle nLineEndingStyle,
            /* [in] */ VARIANT vtEncoding,
            /* [in] */ BSTR strOutputFile);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_SaveFileName )( 
            IFileComparison * This,
            /* [retval][out] */ BSTR *pVal);
        
        /* [helpstring][propput][id] */ HRESULT ( STDMETHODCALLTYPE *put_SaveFileName )( 
            IFileComparison * This,
            /* [in] */ BSTR newVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_ComparisonResult )( 
            IFileComparison * This,
            /* [optional][in] */ VARIANT nFilePair,
            /* [retval][out] */ FileComparisonResult *pVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_ComparisonError )( 
            IFileComparison * This,
            /* [optional][in] */ VARIANT nFilePair,
            /* [retval][out] */ FileComparisonError *pVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_ErrorInfo )( 
            IFileComparison * This,
            /* [in] */ short nFile,
            /* [retval][out] */ BSTR *pVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_Modified )( 
            IFileComparison * This,
            /* [in] */ short nFile,
            /* [retval][out] */ VARIANT_BOOL *pVal);
        
        /* [helpstring][propput][id] */ HRESULT ( STDMETHODCALLTYPE *put_Modified )( 
            IFileComparison * This,
            /* [in] */ short nFile,
            /* [in] */ VARIANT_BOOL bModified);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_ReadOnly )( 
            IFileComparison * This,
            /* [in] */ short nFile,
            /* [retval][out] */ VARIANT_BOOL *pVal);
        
        /* [helpstring][propput][id] */ HRESULT ( STDMETHODCALLTYPE *put_ReadOnly )( 
            IFileComparison * This,
            /* [in] */ short nFile,
            /* [in] */ VARIANT_BOOL bReadOnly);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_PromptForUnsavedFiles )( 
            IFileComparison * This,
            /* [retval][out] */ VARIANT_BOOL *pVal);
        
        /* [helpstring][propput][id] */ HRESULT ( STDMETHODCALLTYPE *put_PromptForUnsavedFiles )( 
            IFileComparison * This,
            /* [in] */ VARIANT_BOOL bPrompt);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_AutoSaveOnClose )( 
            IFileComparison * This,
            /* [retval][out] */ VARIANT_BOOL *pVal);
        
        /* [helpstring][propput][id] */ HRESULT ( STDMETHODCALLTYPE *put_AutoSaveOnClose )( 
            IFileComparison * This,
            /* [in] */ VARIANT_BOOL bAutoSaveOnClose);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_ThreeWayMergeActions )( 
            IFileComparison * This,
            /* [retval][out] */ IThreeWayMergeActions **pVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_UnresolvedConflicts )( 
            IFileComparison * This,
            /* [in] */ short nFile,
            /* [retval][out] */ long *pVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_AllUnresolvedConflicts )( 
            IFileComparison * This,
            /* [retval][out] */ long *pVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_NumberOfChanges )( 
            IFileComparison * This,
            /* [optional][in] */ VARIANT nFilePair,
            /* [retval][out] */ long *pVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *CompareAsync )( 
            IFileComparison * This,
            /* [in] */ VARIANT strFirstFile,
            /* [in] */ VARIANT strSecondFile,
            /* [optional][in] */ VARIANT strThirdFile);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *SaveFile )( 
            IFileComparison * This,
            /* [in] */ short nFile,
            /* [optional][in] */ VARIANT strSaveTo);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *SaveFileAs )( 
            IFileComparison * This,
            /* [in] */ short nFile);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *ThreeWayMerge )( 
            IFileComparison * This,
            /* [retval][out] */ long *pVal);
        
        END_INTERFACE
    } IFileComparisonVtbl;

    interface IFileComparison
    {
        CONST_VTBL struct IFileComparisonVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IFileComparison_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 

#define IFileComparison_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 

#define IFileComparison_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 


#define IFileComparison_GetTypeInfoCount(This,pctinfo)	\
    ( (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo) ) 

#define IFileComparison_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    ( (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo) ) 

#define IFileComparison_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    ( (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId) ) 

#define IFileComparison_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    ( (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr) ) 


#define IFileComparison_get_Active(This,pVal)	\
    ( (This)->lpVtbl -> get_Active(This,pVal) ) 

#define IFileComparison_put_Active(This,newVal)	\
    ( (This)->lpVtbl -> put_Active(This,newVal) ) 

#define IFileComparison_get_Visible(This,pVal)	\
    ( (This)->lpVtbl -> get_Visible(This,pVal) ) 

#define IFileComparison_put_Visible(This,newVal)	\
    ( (This)->lpVtbl -> put_Visible(This,newVal) ) 

#define IFileComparison_get_Minimized(This,pVal)	\
    ( (This)->lpVtbl -> get_Minimized(This,pVal) ) 

#define IFileComparison_put_Minimized(This,newVal)	\
    ( (This)->lpVtbl -> put_Minimized(This,newVal) ) 

#define IFileComparison_get_Maximized(This,pVal)	\
    ( (This)->lpVtbl -> get_Maximized(This,pVal) ) 

#define IFileComparison_put_Maximized(This,newVal)	\
    ( (This)->lpVtbl -> put_Maximized(This,newVal) ) 

#define IFileComparison_get_Left(This,pVal)	\
    ( (This)->lpVtbl -> get_Left(This,pVal) ) 

#define IFileComparison_put_Left(This,newVal)	\
    ( (This)->lpVtbl -> put_Left(This,newVal) ) 

#define IFileComparison_get_Top(This,pVal)	\
    ( (This)->lpVtbl -> get_Top(This,pVal) ) 

#define IFileComparison_put_Top(This,newVal)	\
    ( (This)->lpVtbl -> put_Top(This,newVal) ) 

#define IFileComparison_get_Width(This,pVal)	\
    ( (This)->lpVtbl -> get_Width(This,pVal) ) 

#define IFileComparison_put_Width(This,newVal)	\
    ( (This)->lpVtbl -> put_Width(This,newVal) ) 

#define IFileComparison_get_Height(This,pVal)	\
    ( (This)->lpVtbl -> get_Height(This,pVal) ) 

#define IFileComparison_put_Height(This,newVal)	\
    ( (This)->lpVtbl -> put_Height(This,newVal) ) 

#define IFileComparison_Restore(This)	\
    ( (This)->lpVtbl -> Restore(This) ) 

#define IFileComparison_Close(This)	\
    ( (This)->lpVtbl -> Close(This) ) 

#define IFileComparison_GiveUserControl(This)	\
    ( (This)->lpVtbl -> GiveUserControl(This) ) 


#define IFileComparison_get_ViewType(This,pVal)	\
    ( (This)->lpVtbl -> get_ViewType(This,pVal) ) 

#define IFileComparison_put_ViewType(This,newVal)	\
    ( (This)->lpVtbl -> put_ViewType(This,newVal) ) 

#define IFileComparison_Compare(This,strFirstFile,strSecondFile,strThirdFile)	\
    ( (This)->lpVtbl -> Compare(This,strFirstFile,strSecondFile,strThirdFile) ) 

#define IFileComparison_Refresh(This)	\
    ( (This)->lpVtbl -> Refresh(This) ) 

#define IFileComparison_SaveComparison(This,filename)	\
    ( (This)->lpVtbl -> SaveComparison(This,filename) ) 

#define IFileComparison_SetPanelTitles(This,strFirst,strSecond,strThird)	\
    ( (This)->lpVtbl -> SetPanelTitles(This,strFirst,strSecond,strThird) ) 

#define IFileComparison_Print(This,bShowPrinterDialog,nOrientation)	\
    ( (This)->lpVtbl -> Print(This,bShowPrinterDialog,nOrientation) ) 

#define IFileComparison_Report(This,bstrReporter,nLineEndingStyle,strOutputFile)	\
    ( (This)->lpVtbl -> Report(This,bstrReporter,nLineEndingStyle,strOutputFile) ) 

#define IFileComparison_Report2(This,bstrReporter,nLineEndingStyle,vtEncoding,strOutputFile)	\
    ( (This)->lpVtbl -> Report2(This,bstrReporter,nLineEndingStyle,vtEncoding,strOutputFile) ) 


#define IFileComparison_get_SaveFileName(This,pVal)	\
    ( (This)->lpVtbl -> get_SaveFileName(This,pVal) ) 

#define IFileComparison_put_SaveFileName(This,newVal)	\
    ( (This)->lpVtbl -> put_SaveFileName(This,newVal) ) 

#define IFileComparison_get_ComparisonResult(This,nFilePair,pVal)	\
    ( (This)->lpVtbl -> get_ComparisonResult(This,nFilePair,pVal) ) 

#define IFileComparison_get_ComparisonError(This,nFilePair,pVal)	\
    ( (This)->lpVtbl -> get_ComparisonError(This,nFilePair,pVal) ) 

#define IFileComparison_get_ErrorInfo(This,nFile,pVal)	\
    ( (This)->lpVtbl -> get_ErrorInfo(This,nFile,pVal) ) 

#define IFileComparison_get_Modified(This,nFile,pVal)	\
    ( (This)->lpVtbl -> get_Modified(This,nFile,pVal) ) 

#define IFileComparison_put_Modified(This,nFile,bModified)	\
    ( (This)->lpVtbl -> put_Modified(This,nFile,bModified) ) 

#define IFileComparison_get_ReadOnly(This,nFile,pVal)	\
    ( (This)->lpVtbl -> get_ReadOnly(This,nFile,pVal) ) 

#define IFileComparison_put_ReadOnly(This,nFile,bReadOnly)	\
    ( (This)->lpVtbl -> put_ReadOnly(This,nFile,bReadOnly) ) 

#define IFileComparison_get_PromptForUnsavedFiles(This,pVal)	\
    ( (This)->lpVtbl -> get_PromptForUnsavedFiles(This,pVal) ) 

#define IFileComparison_put_PromptForUnsavedFiles(This,bPrompt)	\
    ( (This)->lpVtbl -> put_PromptForUnsavedFiles(This,bPrompt) ) 

#define IFileComparison_get_AutoSaveOnClose(This,pVal)	\
    ( (This)->lpVtbl -> get_AutoSaveOnClose(This,pVal) ) 

#define IFileComparison_put_AutoSaveOnClose(This,bAutoSaveOnClose)	\
    ( (This)->lpVtbl -> put_AutoSaveOnClose(This,bAutoSaveOnClose) ) 

#define IFileComparison_get_ThreeWayMergeActions(This,pVal)	\
    ( (This)->lpVtbl -> get_ThreeWayMergeActions(This,pVal) ) 

#define IFileComparison_get_UnresolvedConflicts(This,nFile,pVal)	\
    ( (This)->lpVtbl -> get_UnresolvedConflicts(This,nFile,pVal) ) 

#define IFileComparison_get_AllUnresolvedConflicts(This,pVal)	\
    ( (This)->lpVtbl -> get_AllUnresolvedConflicts(This,pVal) ) 

#define IFileComparison_get_NumberOfChanges(This,nFilePair,pVal)	\
    ( (This)->lpVtbl -> get_NumberOfChanges(This,nFilePair,pVal) ) 

#define IFileComparison_CompareAsync(This,strFirstFile,strSecondFile,strThirdFile)	\
    ( (This)->lpVtbl -> CompareAsync(This,strFirstFile,strSecondFile,strThirdFile) ) 

#define IFileComparison_SaveFile(This,nFile,strSaveTo)	\
    ( (This)->lpVtbl -> SaveFile(This,nFile,strSaveTo) ) 

#define IFileComparison_SaveFileAs(This,nFile)	\
    ( (This)->lpVtbl -> SaveFileAs(This,nFile) ) 

#define IFileComparison_ThreeWayMerge(This,pVal)	\
    ( (This)->lpVtbl -> ThreeWayMerge(This,pVal) ) 

#endif /* COBJMACROS */


#endif 	/* C style interface */




#endif 	/* __IFileComparison_INTERFACE_DEFINED__ */


#ifndef __ITextComparison_INTERFACE_DEFINED__
#define __ITextComparison_INTERFACE_DEFINED__

/* interface ITextComparison */
/* [version][uuid][helpstring][unique][dual][object] */ 


EXTERN_C const IID IID_ITextComparison;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("2cadcd65-9e70-4ee2-8300-b3be47329a5d")
    ITextComparison : public IFileComparison
    {
    public:
        virtual /* [helpstring][propget][id] */ HRESULT STDMETHODCALLTYPE get_NumberOfLines( 
            /* [in] */ short nFile,
            /* [retval][out] */ long *pVal) = 0;
        
        virtual /* [helpstring][propget][id] */ HRESULT STDMETHODCALLTYPE get_ChangeStartLine( 
            /* [in] */ long nChange,
            /* [in] */ short nSide,
            /* [optional][in] */ VARIANT nFilePair,
            /* [retval][out] */ long *pVal) = 0;
        
        virtual /* [helpstring][propget][id] */ HRESULT STDMETHODCALLTYPE get_ChangeLength( 
            /* [in] */ long nChange,
            /* [in] */ short nSide,
            /* [optional][in] */ VARIANT nFilePair,
            /* [retval][out] */ long *pVal) = 0;
        
        virtual /* [helpstring][propget][id] */ HRESULT STDMETHODCALLTYPE get_LineLength( 
            /* [in] */ long nLine,
            /* [in] */ short nFile,
            /* [retval][out] */ long *pVal) = 0;
        
        virtual /* [helpstring][propget][id] */ HRESULT STDMETHODCALLTYPE get_FullLineLength( 
            /* [in] */ long nLine,
            /* [in] */ short nFile,
            /* [retval][out] */ long *pVal) = 0;
        
        virtual /* [helpstring][propget][id] */ HRESULT STDMETHODCALLTYPE get_ChangeType( 
            /* [in] */ long nChange,
            /* [optional][in] */ VARIANT nFilePair,
            /* [retval][out] */ ChangeStyle *pVal) = 0;
        
        virtual /* [helpstring][propget][id] */ HRESULT STDMETHODCALLTYPE get_FullLineData( 
            /* [in] */ long nLine,
            /* [in] */ short nFile,
            /* [retval][out] */ BSTR *pVal) = 0;
        
        virtual /* [helpstring][propget][id] */ HRESULT STDMETHODCALLTYPE get_LineData( 
            /* [in] */ long nLine,
            /* [in] */ short nFile,
            /* [retval][out] */ BSTR *pVal) = 0;
        
        virtual /* [helpstring][propget][id] */ HRESULT STDMETHODCALLTYPE get_FileContent( 
            /* [in] */ short nFile,
            /* [retval][out] */ BSTR *pVal) = 0;
        
        virtual /* [helpstring][propput][id] */ HRESULT STDMETHODCALLTYPE put_FileContent( 
            /* [in] */ short nFile,
            /* [in] */ BSTR strText) = 0;
        
        virtual /* [helpstring][propget][id] */ HRESULT STDMETHODCALLTYPE get_LineNumber( 
            /* [in] */ short nFile,
            /* [retval][out] */ long *pVal) = 0;
        
        virtual /* [helpstring][propput][id] */ HRESULT STDMETHODCALLTYPE put_LineNumber( 
            /* [in] */ short nFile,
            /* [in] */ long nLineNumber) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct ITextComparisonVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            ITextComparison * This,
            /* [in] */ REFIID riid,
            /* [annotation][iid_is][out] */ 
            __RPC__deref_out  void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            ITextComparison * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            ITextComparison * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            ITextComparison * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            ITextComparison * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            ITextComparison * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [range][in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            ITextComparison * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_Active )( 
            ITextComparison * This,
            /* [retval][out] */ VARIANT_BOOL *pVal);
        
        /* [helpstring][propput][id] */ HRESULT ( STDMETHODCALLTYPE *put_Active )( 
            ITextComparison * This,
            /* [in] */ VARIANT_BOOL newVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_Visible )( 
            ITextComparison * This,
            /* [retval][out] */ VARIANT_BOOL *pVal);
        
        /* [helpstring][propput][id] */ HRESULT ( STDMETHODCALLTYPE *put_Visible )( 
            ITextComparison * This,
            /* [in] */ VARIANT_BOOL newVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_Minimized )( 
            ITextComparison * This,
            /* [retval][out] */ VARIANT_BOOL *pVal);
        
        /* [helpstring][propput][id] */ HRESULT ( STDMETHODCALLTYPE *put_Minimized )( 
            ITextComparison * This,
            /* [in] */ VARIANT_BOOL newVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_Maximized )( 
            ITextComparison * This,
            /* [retval][out] */ VARIANT_BOOL *pVal);
        
        /* [helpstring][propput][id] */ HRESULT ( STDMETHODCALLTYPE *put_Maximized )( 
            ITextComparison * This,
            /* [in] */ VARIANT_BOOL newVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_Left )( 
            ITextComparison * This,
            /* [retval][out] */ long *pVal);
        
        /* [helpstring][propput][id] */ HRESULT ( STDMETHODCALLTYPE *put_Left )( 
            ITextComparison * This,
            /* [in] */ long newVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_Top )( 
            ITextComparison * This,
            /* [retval][out] */ long *pVal);
        
        /* [helpstring][propput][id] */ HRESULT ( STDMETHODCALLTYPE *put_Top )( 
            ITextComparison * This,
            /* [in] */ long newVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_Width )( 
            ITextComparison * This,
            /* [retval][out] */ long *pVal);
        
        /* [helpstring][propput][id] */ HRESULT ( STDMETHODCALLTYPE *put_Width )( 
            ITextComparison * This,
            /* [in] */ long newVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_Height )( 
            ITextComparison * This,
            /* [retval][out] */ long *pVal);
        
        /* [helpstring][propput][id] */ HRESULT ( STDMETHODCALLTYPE *put_Height )( 
            ITextComparison * This,
            /* [in] */ long newVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *Restore )( 
            ITextComparison * This);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *Close )( 
            ITextComparison * This);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *GiveUserControl )( 
            ITextComparison * This);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_ViewType )( 
            ITextComparison * This,
            /* [retval][out] */ FileViewType *pVal);
        
        /* [helpstring][propput][id] */ HRESULT ( STDMETHODCALLTYPE *put_ViewType )( 
            ITextComparison * This,
            /* [in] */ FileViewType newVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *Compare )( 
            ITextComparison * This,
            /* [in] */ VARIANT strFirstFile,
            /* [in] */ VARIANT strSecondFile,
            /* [optional][in] */ VARIANT strThirdFile);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *Refresh )( 
            ITextComparison * This);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *SaveComparison )( 
            ITextComparison * This,
            /* [in] */ BSTR filename);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *SetPanelTitles )( 
            ITextComparison * This,
            /* [in] */ VARIANT strFirst,
            /* [in] */ VARIANT strSecond,
            /* [optional][in] */ VARIANT strThird);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *Print )( 
            ITextComparison * This,
            /* [defaultvalue][in] */ VARIANT_BOOL bShowPrinterDialog,
            /* [defaultvalue][in] */ PageOrientation nOrientation);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *Report )( 
            ITextComparison * This,
            /* [in] */ BSTR bstrReporter,
            /* [in] */ LineEndingStyle nLineEndingStyle,
            /* [in] */ BSTR strOutputFile);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *Report2 )( 
            ITextComparison * This,
            /* [in] */ BSTR bstrReporter,
            /* [in] */ LineEndingStyle nLineEndingStyle,
            /* [in] */ VARIANT vtEncoding,
            /* [in] */ BSTR strOutputFile);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_SaveFileName )( 
            ITextComparison * This,
            /* [retval][out] */ BSTR *pVal);
        
        /* [helpstring][propput][id] */ HRESULT ( STDMETHODCALLTYPE *put_SaveFileName )( 
            ITextComparison * This,
            /* [in] */ BSTR newVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_ComparisonResult )( 
            ITextComparison * This,
            /* [optional][in] */ VARIANT nFilePair,
            /* [retval][out] */ FileComparisonResult *pVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_ComparisonError )( 
            ITextComparison * This,
            /* [optional][in] */ VARIANT nFilePair,
            /* [retval][out] */ FileComparisonError *pVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_ErrorInfo )( 
            ITextComparison * This,
            /* [in] */ short nFile,
            /* [retval][out] */ BSTR *pVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_Modified )( 
            ITextComparison * This,
            /* [in] */ short nFile,
            /* [retval][out] */ VARIANT_BOOL *pVal);
        
        /* [helpstring][propput][id] */ HRESULT ( STDMETHODCALLTYPE *put_Modified )( 
            ITextComparison * This,
            /* [in] */ short nFile,
            /* [in] */ VARIANT_BOOL bModified);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_ReadOnly )( 
            ITextComparison * This,
            /* [in] */ short nFile,
            /* [retval][out] */ VARIANT_BOOL *pVal);
        
        /* [helpstring][propput][id] */ HRESULT ( STDMETHODCALLTYPE *put_ReadOnly )( 
            ITextComparison * This,
            /* [in] */ short nFile,
            /* [in] */ VARIANT_BOOL bReadOnly);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_PromptForUnsavedFiles )( 
            ITextComparison * This,
            /* [retval][out] */ VARIANT_BOOL *pVal);
        
        /* [helpstring][propput][id] */ HRESULT ( STDMETHODCALLTYPE *put_PromptForUnsavedFiles )( 
            ITextComparison * This,
            /* [in] */ VARIANT_BOOL bPrompt);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_AutoSaveOnClose )( 
            ITextComparison * This,
            /* [retval][out] */ VARIANT_BOOL *pVal);
        
        /* [helpstring][propput][id] */ HRESULT ( STDMETHODCALLTYPE *put_AutoSaveOnClose )( 
            ITextComparison * This,
            /* [in] */ VARIANT_BOOL bAutoSaveOnClose);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_ThreeWayMergeActions )( 
            ITextComparison * This,
            /* [retval][out] */ IThreeWayMergeActions **pVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_UnresolvedConflicts )( 
            ITextComparison * This,
            /* [in] */ short nFile,
            /* [retval][out] */ long *pVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_AllUnresolvedConflicts )( 
            ITextComparison * This,
            /* [retval][out] */ long *pVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_NumberOfChanges )( 
            ITextComparison * This,
            /* [optional][in] */ VARIANT nFilePair,
            /* [retval][out] */ long *pVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *CompareAsync )( 
            ITextComparison * This,
            /* [in] */ VARIANT strFirstFile,
            /* [in] */ VARIANT strSecondFile,
            /* [optional][in] */ VARIANT strThirdFile);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *SaveFile )( 
            ITextComparison * This,
            /* [in] */ short nFile,
            /* [optional][in] */ VARIANT strSaveTo);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *SaveFileAs )( 
            ITextComparison * This,
            /* [in] */ short nFile);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *ThreeWayMerge )( 
            ITextComparison * This,
            /* [retval][out] */ long *pVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_NumberOfLines )( 
            ITextComparison * This,
            /* [in] */ short nFile,
            /* [retval][out] */ long *pVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_ChangeStartLine )( 
            ITextComparison * This,
            /* [in] */ long nChange,
            /* [in] */ short nSide,
            /* [optional][in] */ VARIANT nFilePair,
            /* [retval][out] */ long *pVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_ChangeLength )( 
            ITextComparison * This,
            /* [in] */ long nChange,
            /* [in] */ short nSide,
            /* [optional][in] */ VARIANT nFilePair,
            /* [retval][out] */ long *pVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_LineLength )( 
            ITextComparison * This,
            /* [in] */ long nLine,
            /* [in] */ short nFile,
            /* [retval][out] */ long *pVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_FullLineLength )( 
            ITextComparison * This,
            /* [in] */ long nLine,
            /* [in] */ short nFile,
            /* [retval][out] */ long *pVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_ChangeType )( 
            ITextComparison * This,
            /* [in] */ long nChange,
            /* [optional][in] */ VARIANT nFilePair,
            /* [retval][out] */ ChangeStyle *pVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_FullLineData )( 
            ITextComparison * This,
            /* [in] */ long nLine,
            /* [in] */ short nFile,
            /* [retval][out] */ BSTR *pVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_LineData )( 
            ITextComparison * This,
            /* [in] */ long nLine,
            /* [in] */ short nFile,
            /* [retval][out] */ BSTR *pVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_FileContent )( 
            ITextComparison * This,
            /* [in] */ short nFile,
            /* [retval][out] */ BSTR *pVal);
        
        /* [helpstring][propput][id] */ HRESULT ( STDMETHODCALLTYPE *put_FileContent )( 
            ITextComparison * This,
            /* [in] */ short nFile,
            /* [in] */ BSTR strText);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_LineNumber )( 
            ITextComparison * This,
            /* [in] */ short nFile,
            /* [retval][out] */ long *pVal);
        
        /* [helpstring][propput][id] */ HRESULT ( STDMETHODCALLTYPE *put_LineNumber )( 
            ITextComparison * This,
            /* [in] */ short nFile,
            /* [in] */ long nLineNumber);
        
        END_INTERFACE
    } ITextComparisonVtbl;

    interface ITextComparison
    {
        CONST_VTBL struct ITextComparisonVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define ITextComparison_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 

#define ITextComparison_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 

#define ITextComparison_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 


#define ITextComparison_GetTypeInfoCount(This,pctinfo)	\
    ( (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo) ) 

#define ITextComparison_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    ( (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo) ) 

#define ITextComparison_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    ( (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId) ) 

#define ITextComparison_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    ( (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr) ) 


#define ITextComparison_get_Active(This,pVal)	\
    ( (This)->lpVtbl -> get_Active(This,pVal) ) 

#define ITextComparison_put_Active(This,newVal)	\
    ( (This)->lpVtbl -> put_Active(This,newVal) ) 

#define ITextComparison_get_Visible(This,pVal)	\
    ( (This)->lpVtbl -> get_Visible(This,pVal) ) 

#define ITextComparison_put_Visible(This,newVal)	\
    ( (This)->lpVtbl -> put_Visible(This,newVal) ) 

#define ITextComparison_get_Minimized(This,pVal)	\
    ( (This)->lpVtbl -> get_Minimized(This,pVal) ) 

#define ITextComparison_put_Minimized(This,newVal)	\
    ( (This)->lpVtbl -> put_Minimized(This,newVal) ) 

#define ITextComparison_get_Maximized(This,pVal)	\
    ( (This)->lpVtbl -> get_Maximized(This,pVal) ) 

#define ITextComparison_put_Maximized(This,newVal)	\
    ( (This)->lpVtbl -> put_Maximized(This,newVal) ) 

#define ITextComparison_get_Left(This,pVal)	\
    ( (This)->lpVtbl -> get_Left(This,pVal) ) 

#define ITextComparison_put_Left(This,newVal)	\
    ( (This)->lpVtbl -> put_Left(This,newVal) ) 

#define ITextComparison_get_Top(This,pVal)	\
    ( (This)->lpVtbl -> get_Top(This,pVal) ) 

#define ITextComparison_put_Top(This,newVal)	\
    ( (This)->lpVtbl -> put_Top(This,newVal) ) 

#define ITextComparison_get_Width(This,pVal)	\
    ( (This)->lpVtbl -> get_Width(This,pVal) ) 

#define ITextComparison_put_Width(This,newVal)	\
    ( (This)->lpVtbl -> put_Width(This,newVal) ) 

#define ITextComparison_get_Height(This,pVal)	\
    ( (This)->lpVtbl -> get_Height(This,pVal) ) 

#define ITextComparison_put_Height(This,newVal)	\
    ( (This)->lpVtbl -> put_Height(This,newVal) ) 

#define ITextComparison_Restore(This)	\
    ( (This)->lpVtbl -> Restore(This) ) 

#define ITextComparison_Close(This)	\
    ( (This)->lpVtbl -> Close(This) ) 

#define ITextComparison_GiveUserControl(This)	\
    ( (This)->lpVtbl -> GiveUserControl(This) ) 


#define ITextComparison_get_ViewType(This,pVal)	\
    ( (This)->lpVtbl -> get_ViewType(This,pVal) ) 

#define ITextComparison_put_ViewType(This,newVal)	\
    ( (This)->lpVtbl -> put_ViewType(This,newVal) ) 

#define ITextComparison_Compare(This,strFirstFile,strSecondFile,strThirdFile)	\
    ( (This)->lpVtbl -> Compare(This,strFirstFile,strSecondFile,strThirdFile) ) 

#define ITextComparison_Refresh(This)	\
    ( (This)->lpVtbl -> Refresh(This) ) 

#define ITextComparison_SaveComparison(This,filename)	\
    ( (This)->lpVtbl -> SaveComparison(This,filename) ) 

#define ITextComparison_SetPanelTitles(This,strFirst,strSecond,strThird)	\
    ( (This)->lpVtbl -> SetPanelTitles(This,strFirst,strSecond,strThird) ) 

#define ITextComparison_Print(This,bShowPrinterDialog,nOrientation)	\
    ( (This)->lpVtbl -> Print(This,bShowPrinterDialog,nOrientation) ) 

#define ITextComparison_Report(This,bstrReporter,nLineEndingStyle,strOutputFile)	\
    ( (This)->lpVtbl -> Report(This,bstrReporter,nLineEndingStyle,strOutputFile) ) 

#define ITextComparison_Report2(This,bstrReporter,nLineEndingStyle,vtEncoding,strOutputFile)	\
    ( (This)->lpVtbl -> Report2(This,bstrReporter,nLineEndingStyle,vtEncoding,strOutputFile) ) 


#define ITextComparison_get_SaveFileName(This,pVal)	\
    ( (This)->lpVtbl -> get_SaveFileName(This,pVal) ) 

#define ITextComparison_put_SaveFileName(This,newVal)	\
    ( (This)->lpVtbl -> put_SaveFileName(This,newVal) ) 

#define ITextComparison_get_ComparisonResult(This,nFilePair,pVal)	\
    ( (This)->lpVtbl -> get_ComparisonResult(This,nFilePair,pVal) ) 

#define ITextComparison_get_ComparisonError(This,nFilePair,pVal)	\
    ( (This)->lpVtbl -> get_ComparisonError(This,nFilePair,pVal) ) 

#define ITextComparison_get_ErrorInfo(This,nFile,pVal)	\
    ( (This)->lpVtbl -> get_ErrorInfo(This,nFile,pVal) ) 

#define ITextComparison_get_Modified(This,nFile,pVal)	\
    ( (This)->lpVtbl -> get_Modified(This,nFile,pVal) ) 

#define ITextComparison_put_Modified(This,nFile,bModified)	\
    ( (This)->lpVtbl -> put_Modified(This,nFile,bModified) ) 

#define ITextComparison_get_ReadOnly(This,nFile,pVal)	\
    ( (This)->lpVtbl -> get_ReadOnly(This,nFile,pVal) ) 

#define ITextComparison_put_ReadOnly(This,nFile,bReadOnly)	\
    ( (This)->lpVtbl -> put_ReadOnly(This,nFile,bReadOnly) ) 

#define ITextComparison_get_PromptForUnsavedFiles(This,pVal)	\
    ( (This)->lpVtbl -> get_PromptForUnsavedFiles(This,pVal) ) 

#define ITextComparison_put_PromptForUnsavedFiles(This,bPrompt)	\
    ( (This)->lpVtbl -> put_PromptForUnsavedFiles(This,bPrompt) ) 

#define ITextComparison_get_AutoSaveOnClose(This,pVal)	\
    ( (This)->lpVtbl -> get_AutoSaveOnClose(This,pVal) ) 

#define ITextComparison_put_AutoSaveOnClose(This,bAutoSaveOnClose)	\
    ( (This)->lpVtbl -> put_AutoSaveOnClose(This,bAutoSaveOnClose) ) 

#define ITextComparison_get_ThreeWayMergeActions(This,pVal)	\
    ( (This)->lpVtbl -> get_ThreeWayMergeActions(This,pVal) ) 

#define ITextComparison_get_UnresolvedConflicts(This,nFile,pVal)	\
    ( (This)->lpVtbl -> get_UnresolvedConflicts(This,nFile,pVal) ) 

#define ITextComparison_get_AllUnresolvedConflicts(This,pVal)	\
    ( (This)->lpVtbl -> get_AllUnresolvedConflicts(This,pVal) ) 

#define ITextComparison_get_NumberOfChanges(This,nFilePair,pVal)	\
    ( (This)->lpVtbl -> get_NumberOfChanges(This,nFilePair,pVal) ) 

#define ITextComparison_CompareAsync(This,strFirstFile,strSecondFile,strThirdFile)	\
    ( (This)->lpVtbl -> CompareAsync(This,strFirstFile,strSecondFile,strThirdFile) ) 

#define ITextComparison_SaveFile(This,nFile,strSaveTo)	\
    ( (This)->lpVtbl -> SaveFile(This,nFile,strSaveTo) ) 

#define ITextComparison_SaveFileAs(This,nFile)	\
    ( (This)->lpVtbl -> SaveFileAs(This,nFile) ) 

#define ITextComparison_ThreeWayMerge(This,pVal)	\
    ( (This)->lpVtbl -> ThreeWayMerge(This,pVal) ) 


#define ITextComparison_get_NumberOfLines(This,nFile,pVal)	\
    ( (This)->lpVtbl -> get_NumberOfLines(This,nFile,pVal) ) 

#define ITextComparison_get_ChangeStartLine(This,nChange,nSide,nFilePair,pVal)	\
    ( (This)->lpVtbl -> get_ChangeStartLine(This,nChange,nSide,nFilePair,pVal) ) 

#define ITextComparison_get_ChangeLength(This,nChange,nSide,nFilePair,pVal)	\
    ( (This)->lpVtbl -> get_ChangeLength(This,nChange,nSide,nFilePair,pVal) ) 

#define ITextComparison_get_LineLength(This,nLine,nFile,pVal)	\
    ( (This)->lpVtbl -> get_LineLength(This,nLine,nFile,pVal) ) 

#define ITextComparison_get_FullLineLength(This,nLine,nFile,pVal)	\
    ( (This)->lpVtbl -> get_FullLineLength(This,nLine,nFile,pVal) ) 

#define ITextComparison_get_ChangeType(This,nChange,nFilePair,pVal)	\
    ( (This)->lpVtbl -> get_ChangeType(This,nChange,nFilePair,pVal) ) 

#define ITextComparison_get_FullLineData(This,nLine,nFile,pVal)	\
    ( (This)->lpVtbl -> get_FullLineData(This,nLine,nFile,pVal) ) 

#define ITextComparison_get_LineData(This,nLine,nFile,pVal)	\
    ( (This)->lpVtbl -> get_LineData(This,nLine,nFile,pVal) ) 

#define ITextComparison_get_FileContent(This,nFile,pVal)	\
    ( (This)->lpVtbl -> get_FileContent(This,nFile,pVal) ) 

#define ITextComparison_put_FileContent(This,nFile,strText)	\
    ( (This)->lpVtbl -> put_FileContent(This,nFile,strText) ) 

#define ITextComparison_get_LineNumber(This,nFile,pVal)	\
    ( (This)->lpVtbl -> get_LineNumber(This,nFile,pVal) ) 

#define ITextComparison_put_LineNumber(This,nFile,nLineNumber)	\
    ( (This)->lpVtbl -> put_LineNumber(This,nFile,nLineNumber) ) 

#endif /* COBJMACROS */


#endif 	/* C style interface */




#endif 	/* __ITextComparison_INTERFACE_DEFINED__ */


#ifndef __ITextComparison2_INTERFACE_DEFINED__
#define __ITextComparison2_INTERFACE_DEFINED__

/* interface ITextComparison2 */
/* [version][uuid][helpstring][unique][dual][object] */ 


EXTERN_C const IID IID_ITextComparison2;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("e32bda76-99c5-46d1-ac2f-5ff5c84e2de2")
    ITextComparison2 : public ITextComparison
    {
    public:
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE CompareWithEncoding( 
            /* [in] */ VARIANT strFirstFile,
            /* [in] */ IEncoding *firstEncoding,
            /* [in] */ VARIANT strSecondFile,
            /* [in] */ IEncoding *secondEncoding,
            /* [optional][in] */ VARIANT strThirdFile,
            /* [defaultvalue][in] */ IEncoding *thirdEncoding = 0) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE CompareAsyncWithEncoding( 
            /* [in] */ VARIANT strFirstFile,
            /* [in] */ IEncoding *firstEncoding,
            /* [in] */ VARIANT strSecondFile,
            /* [in] */ IEncoding *secondEncoding,
            /* [optional][in] */ VARIANT strThirdFile,
            /* [defaultvalue][in] */ IEncoding *thirdEncoding = 0) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct ITextComparison2Vtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            ITextComparison2 * This,
            /* [in] */ REFIID riid,
            /* [annotation][iid_is][out] */ 
            __RPC__deref_out  void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            ITextComparison2 * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            ITextComparison2 * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            ITextComparison2 * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            ITextComparison2 * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            ITextComparison2 * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [range][in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            ITextComparison2 * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_Active )( 
            ITextComparison2 * This,
            /* [retval][out] */ VARIANT_BOOL *pVal);
        
        /* [helpstring][propput][id] */ HRESULT ( STDMETHODCALLTYPE *put_Active )( 
            ITextComparison2 * This,
            /* [in] */ VARIANT_BOOL newVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_Visible )( 
            ITextComparison2 * This,
            /* [retval][out] */ VARIANT_BOOL *pVal);
        
        /* [helpstring][propput][id] */ HRESULT ( STDMETHODCALLTYPE *put_Visible )( 
            ITextComparison2 * This,
            /* [in] */ VARIANT_BOOL newVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_Minimized )( 
            ITextComparison2 * This,
            /* [retval][out] */ VARIANT_BOOL *pVal);
        
        /* [helpstring][propput][id] */ HRESULT ( STDMETHODCALLTYPE *put_Minimized )( 
            ITextComparison2 * This,
            /* [in] */ VARIANT_BOOL newVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_Maximized )( 
            ITextComparison2 * This,
            /* [retval][out] */ VARIANT_BOOL *pVal);
        
        /* [helpstring][propput][id] */ HRESULT ( STDMETHODCALLTYPE *put_Maximized )( 
            ITextComparison2 * This,
            /* [in] */ VARIANT_BOOL newVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_Left )( 
            ITextComparison2 * This,
            /* [retval][out] */ long *pVal);
        
        /* [helpstring][propput][id] */ HRESULT ( STDMETHODCALLTYPE *put_Left )( 
            ITextComparison2 * This,
            /* [in] */ long newVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_Top )( 
            ITextComparison2 * This,
            /* [retval][out] */ long *pVal);
        
        /* [helpstring][propput][id] */ HRESULT ( STDMETHODCALLTYPE *put_Top )( 
            ITextComparison2 * This,
            /* [in] */ long newVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_Width )( 
            ITextComparison2 * This,
            /* [retval][out] */ long *pVal);
        
        /* [helpstring][propput][id] */ HRESULT ( STDMETHODCALLTYPE *put_Width )( 
            ITextComparison2 * This,
            /* [in] */ long newVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_Height )( 
            ITextComparison2 * This,
            /* [retval][out] */ long *pVal);
        
        /* [helpstring][propput][id] */ HRESULT ( STDMETHODCALLTYPE *put_Height )( 
            ITextComparison2 * This,
            /* [in] */ long newVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *Restore )( 
            ITextComparison2 * This);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *Close )( 
            ITextComparison2 * This);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *GiveUserControl )( 
            ITextComparison2 * This);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_ViewType )( 
            ITextComparison2 * This,
            /* [retval][out] */ FileViewType *pVal);
        
        /* [helpstring][propput][id] */ HRESULT ( STDMETHODCALLTYPE *put_ViewType )( 
            ITextComparison2 * This,
            /* [in] */ FileViewType newVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *Compare )( 
            ITextComparison2 * This,
            /* [in] */ VARIANT strFirstFile,
            /* [in] */ VARIANT strSecondFile,
            /* [optional][in] */ VARIANT strThirdFile);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *Refresh )( 
            ITextComparison2 * This);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *SaveComparison )( 
            ITextComparison2 * This,
            /* [in] */ BSTR filename);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *SetPanelTitles )( 
            ITextComparison2 * This,
            /* [in] */ VARIANT strFirst,
            /* [in] */ VARIANT strSecond,
            /* [optional][in] */ VARIANT strThird);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *Print )( 
            ITextComparison2 * This,
            /* [defaultvalue][in] */ VARIANT_BOOL bShowPrinterDialog,
            /* [defaultvalue][in] */ PageOrientation nOrientation);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *Report )( 
            ITextComparison2 * This,
            /* [in] */ BSTR bstrReporter,
            /* [in] */ LineEndingStyle nLineEndingStyle,
            /* [in] */ BSTR strOutputFile);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *Report2 )( 
            ITextComparison2 * This,
            /* [in] */ BSTR bstrReporter,
            /* [in] */ LineEndingStyle nLineEndingStyle,
            /* [in] */ VARIANT vtEncoding,
            /* [in] */ BSTR strOutputFile);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_SaveFileName )( 
            ITextComparison2 * This,
            /* [retval][out] */ BSTR *pVal);
        
        /* [helpstring][propput][id] */ HRESULT ( STDMETHODCALLTYPE *put_SaveFileName )( 
            ITextComparison2 * This,
            /* [in] */ BSTR newVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_ComparisonResult )( 
            ITextComparison2 * This,
            /* [optional][in] */ VARIANT nFilePair,
            /* [retval][out] */ FileComparisonResult *pVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_ComparisonError )( 
            ITextComparison2 * This,
            /* [optional][in] */ VARIANT nFilePair,
            /* [retval][out] */ FileComparisonError *pVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_ErrorInfo )( 
            ITextComparison2 * This,
            /* [in] */ short nFile,
            /* [retval][out] */ BSTR *pVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_Modified )( 
            ITextComparison2 * This,
            /* [in] */ short nFile,
            /* [retval][out] */ VARIANT_BOOL *pVal);
        
        /* [helpstring][propput][id] */ HRESULT ( STDMETHODCALLTYPE *put_Modified )( 
            ITextComparison2 * This,
            /* [in] */ short nFile,
            /* [in] */ VARIANT_BOOL bModified);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_ReadOnly )( 
            ITextComparison2 * This,
            /* [in] */ short nFile,
            /* [retval][out] */ VARIANT_BOOL *pVal);
        
        /* [helpstring][propput][id] */ HRESULT ( STDMETHODCALLTYPE *put_ReadOnly )( 
            ITextComparison2 * This,
            /* [in] */ short nFile,
            /* [in] */ VARIANT_BOOL bReadOnly);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_PromptForUnsavedFiles )( 
            ITextComparison2 * This,
            /* [retval][out] */ VARIANT_BOOL *pVal);
        
        /* [helpstring][propput][id] */ HRESULT ( STDMETHODCALLTYPE *put_PromptForUnsavedFiles )( 
            ITextComparison2 * This,
            /* [in] */ VARIANT_BOOL bPrompt);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_AutoSaveOnClose )( 
            ITextComparison2 * This,
            /* [retval][out] */ VARIANT_BOOL *pVal);
        
        /* [helpstring][propput][id] */ HRESULT ( STDMETHODCALLTYPE *put_AutoSaveOnClose )( 
            ITextComparison2 * This,
            /* [in] */ VARIANT_BOOL bAutoSaveOnClose);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_ThreeWayMergeActions )( 
            ITextComparison2 * This,
            /* [retval][out] */ IThreeWayMergeActions **pVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_UnresolvedConflicts )( 
            ITextComparison2 * This,
            /* [in] */ short nFile,
            /* [retval][out] */ long *pVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_AllUnresolvedConflicts )( 
            ITextComparison2 * This,
            /* [retval][out] */ long *pVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_NumberOfChanges )( 
            ITextComparison2 * This,
            /* [optional][in] */ VARIANT nFilePair,
            /* [retval][out] */ long *pVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *CompareAsync )( 
            ITextComparison2 * This,
            /* [in] */ VARIANT strFirstFile,
            /* [in] */ VARIANT strSecondFile,
            /* [optional][in] */ VARIANT strThirdFile);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *SaveFile )( 
            ITextComparison2 * This,
            /* [in] */ short nFile,
            /* [optional][in] */ VARIANT strSaveTo);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *SaveFileAs )( 
            ITextComparison2 * This,
            /* [in] */ short nFile);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *ThreeWayMerge )( 
            ITextComparison2 * This,
            /* [retval][out] */ long *pVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_NumberOfLines )( 
            ITextComparison2 * This,
            /* [in] */ short nFile,
            /* [retval][out] */ long *pVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_ChangeStartLine )( 
            ITextComparison2 * This,
            /* [in] */ long nChange,
            /* [in] */ short nSide,
            /* [optional][in] */ VARIANT nFilePair,
            /* [retval][out] */ long *pVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_ChangeLength )( 
            ITextComparison2 * This,
            /* [in] */ long nChange,
            /* [in] */ short nSide,
            /* [optional][in] */ VARIANT nFilePair,
            /* [retval][out] */ long *pVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_LineLength )( 
            ITextComparison2 * This,
            /* [in] */ long nLine,
            /* [in] */ short nFile,
            /* [retval][out] */ long *pVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_FullLineLength )( 
            ITextComparison2 * This,
            /* [in] */ long nLine,
            /* [in] */ short nFile,
            /* [retval][out] */ long *pVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_ChangeType )( 
            ITextComparison2 * This,
            /* [in] */ long nChange,
            /* [optional][in] */ VARIANT nFilePair,
            /* [retval][out] */ ChangeStyle *pVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_FullLineData )( 
            ITextComparison2 * This,
            /* [in] */ long nLine,
            /* [in] */ short nFile,
            /* [retval][out] */ BSTR *pVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_LineData )( 
            ITextComparison2 * This,
            /* [in] */ long nLine,
            /* [in] */ short nFile,
            /* [retval][out] */ BSTR *pVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_FileContent )( 
            ITextComparison2 * This,
            /* [in] */ short nFile,
            /* [retval][out] */ BSTR *pVal);
        
        /* [helpstring][propput][id] */ HRESULT ( STDMETHODCALLTYPE *put_FileContent )( 
            ITextComparison2 * This,
            /* [in] */ short nFile,
            /* [in] */ BSTR strText);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_LineNumber )( 
            ITextComparison2 * This,
            /* [in] */ short nFile,
            /* [retval][out] */ long *pVal);
        
        /* [helpstring][propput][id] */ HRESULT ( STDMETHODCALLTYPE *put_LineNumber )( 
            ITextComparison2 * This,
            /* [in] */ short nFile,
            /* [in] */ long nLineNumber);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *CompareWithEncoding )( 
            ITextComparison2 * This,
            /* [in] */ VARIANT strFirstFile,
            /* [in] */ IEncoding *firstEncoding,
            /* [in] */ VARIANT strSecondFile,
            /* [in] */ IEncoding *secondEncoding,
            /* [optional][in] */ VARIANT strThirdFile,
            /* [defaultvalue][in] */ IEncoding *thirdEncoding);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *CompareAsyncWithEncoding )( 
            ITextComparison2 * This,
            /* [in] */ VARIANT strFirstFile,
            /* [in] */ IEncoding *firstEncoding,
            /* [in] */ VARIANT strSecondFile,
            /* [in] */ IEncoding *secondEncoding,
            /* [optional][in] */ VARIANT strThirdFile,
            /* [defaultvalue][in] */ IEncoding *thirdEncoding);
        
        END_INTERFACE
    } ITextComparison2Vtbl;

    interface ITextComparison2
    {
        CONST_VTBL struct ITextComparison2Vtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define ITextComparison2_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 

#define ITextComparison2_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 

#define ITextComparison2_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 


#define ITextComparison2_GetTypeInfoCount(This,pctinfo)	\
    ( (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo) ) 

#define ITextComparison2_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    ( (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo) ) 

#define ITextComparison2_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    ( (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId) ) 

#define ITextComparison2_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    ( (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr) ) 


#define ITextComparison2_get_Active(This,pVal)	\
    ( (This)->lpVtbl -> get_Active(This,pVal) ) 

#define ITextComparison2_put_Active(This,newVal)	\
    ( (This)->lpVtbl -> put_Active(This,newVal) ) 

#define ITextComparison2_get_Visible(This,pVal)	\
    ( (This)->lpVtbl -> get_Visible(This,pVal) ) 

#define ITextComparison2_put_Visible(This,newVal)	\
    ( (This)->lpVtbl -> put_Visible(This,newVal) ) 

#define ITextComparison2_get_Minimized(This,pVal)	\
    ( (This)->lpVtbl -> get_Minimized(This,pVal) ) 

#define ITextComparison2_put_Minimized(This,newVal)	\
    ( (This)->lpVtbl -> put_Minimized(This,newVal) ) 

#define ITextComparison2_get_Maximized(This,pVal)	\
    ( (This)->lpVtbl -> get_Maximized(This,pVal) ) 

#define ITextComparison2_put_Maximized(This,newVal)	\
    ( (This)->lpVtbl -> put_Maximized(This,newVal) ) 

#define ITextComparison2_get_Left(This,pVal)	\
    ( (This)->lpVtbl -> get_Left(This,pVal) ) 

#define ITextComparison2_put_Left(This,newVal)	\
    ( (This)->lpVtbl -> put_Left(This,newVal) ) 

#define ITextComparison2_get_Top(This,pVal)	\
    ( (This)->lpVtbl -> get_Top(This,pVal) ) 

#define ITextComparison2_put_Top(This,newVal)	\
    ( (This)->lpVtbl -> put_Top(This,newVal) ) 

#define ITextComparison2_get_Width(This,pVal)	\
    ( (This)->lpVtbl -> get_Width(This,pVal) ) 

#define ITextComparison2_put_Width(This,newVal)	\
    ( (This)->lpVtbl -> put_Width(This,newVal) ) 

#define ITextComparison2_get_Height(This,pVal)	\
    ( (This)->lpVtbl -> get_Height(This,pVal) ) 

#define ITextComparison2_put_Height(This,newVal)	\
    ( (This)->lpVtbl -> put_Height(This,newVal) ) 

#define ITextComparison2_Restore(This)	\
    ( (This)->lpVtbl -> Restore(This) ) 

#define ITextComparison2_Close(This)	\
    ( (This)->lpVtbl -> Close(This) ) 

#define ITextComparison2_GiveUserControl(This)	\
    ( (This)->lpVtbl -> GiveUserControl(This) ) 


#define ITextComparison2_get_ViewType(This,pVal)	\
    ( (This)->lpVtbl -> get_ViewType(This,pVal) ) 

#define ITextComparison2_put_ViewType(This,newVal)	\
    ( (This)->lpVtbl -> put_ViewType(This,newVal) ) 

#define ITextComparison2_Compare(This,strFirstFile,strSecondFile,strThirdFile)	\
    ( (This)->lpVtbl -> Compare(This,strFirstFile,strSecondFile,strThirdFile) ) 

#define ITextComparison2_Refresh(This)	\
    ( (This)->lpVtbl -> Refresh(This) ) 

#define ITextComparison2_SaveComparison(This,filename)	\
    ( (This)->lpVtbl -> SaveComparison(This,filename) ) 

#define ITextComparison2_SetPanelTitles(This,strFirst,strSecond,strThird)	\
    ( (This)->lpVtbl -> SetPanelTitles(This,strFirst,strSecond,strThird) ) 

#define ITextComparison2_Print(This,bShowPrinterDialog,nOrientation)	\
    ( (This)->lpVtbl -> Print(This,bShowPrinterDialog,nOrientation) ) 

#define ITextComparison2_Report(This,bstrReporter,nLineEndingStyle,strOutputFile)	\
    ( (This)->lpVtbl -> Report(This,bstrReporter,nLineEndingStyle,strOutputFile) ) 

#define ITextComparison2_Report2(This,bstrReporter,nLineEndingStyle,vtEncoding,strOutputFile)	\
    ( (This)->lpVtbl -> Report2(This,bstrReporter,nLineEndingStyle,vtEncoding,strOutputFile) ) 


#define ITextComparison2_get_SaveFileName(This,pVal)	\
    ( (This)->lpVtbl -> get_SaveFileName(This,pVal) ) 

#define ITextComparison2_put_SaveFileName(This,newVal)	\
    ( (This)->lpVtbl -> put_SaveFileName(This,newVal) ) 

#define ITextComparison2_get_ComparisonResult(This,nFilePair,pVal)	\
    ( (This)->lpVtbl -> get_ComparisonResult(This,nFilePair,pVal) ) 

#define ITextComparison2_get_ComparisonError(This,nFilePair,pVal)	\
    ( (This)->lpVtbl -> get_ComparisonError(This,nFilePair,pVal) ) 

#define ITextComparison2_get_ErrorInfo(This,nFile,pVal)	\
    ( (This)->lpVtbl -> get_ErrorInfo(This,nFile,pVal) ) 

#define ITextComparison2_get_Modified(This,nFile,pVal)	\
    ( (This)->lpVtbl -> get_Modified(This,nFile,pVal) ) 

#define ITextComparison2_put_Modified(This,nFile,bModified)	\
    ( (This)->lpVtbl -> put_Modified(This,nFile,bModified) ) 

#define ITextComparison2_get_ReadOnly(This,nFile,pVal)	\
    ( (This)->lpVtbl -> get_ReadOnly(This,nFile,pVal) ) 

#define ITextComparison2_put_ReadOnly(This,nFile,bReadOnly)	\
    ( (This)->lpVtbl -> put_ReadOnly(This,nFile,bReadOnly) ) 

#define ITextComparison2_get_PromptForUnsavedFiles(This,pVal)	\
    ( (This)->lpVtbl -> get_PromptForUnsavedFiles(This,pVal) ) 

#define ITextComparison2_put_PromptForUnsavedFiles(This,bPrompt)	\
    ( (This)->lpVtbl -> put_PromptForUnsavedFiles(This,bPrompt) ) 

#define ITextComparison2_get_AutoSaveOnClose(This,pVal)	\
    ( (This)->lpVtbl -> get_AutoSaveOnClose(This,pVal) ) 

#define ITextComparison2_put_AutoSaveOnClose(This,bAutoSaveOnClose)	\
    ( (This)->lpVtbl -> put_AutoSaveOnClose(This,bAutoSaveOnClose) ) 

#define ITextComparison2_get_ThreeWayMergeActions(This,pVal)	\
    ( (This)->lpVtbl -> get_ThreeWayMergeActions(This,pVal) ) 

#define ITextComparison2_get_UnresolvedConflicts(This,nFile,pVal)	\
    ( (This)->lpVtbl -> get_UnresolvedConflicts(This,nFile,pVal) ) 

#define ITextComparison2_get_AllUnresolvedConflicts(This,pVal)	\
    ( (This)->lpVtbl -> get_AllUnresolvedConflicts(This,pVal) ) 

#define ITextComparison2_get_NumberOfChanges(This,nFilePair,pVal)	\
    ( (This)->lpVtbl -> get_NumberOfChanges(This,nFilePair,pVal) ) 

#define ITextComparison2_CompareAsync(This,strFirstFile,strSecondFile,strThirdFile)	\
    ( (This)->lpVtbl -> CompareAsync(This,strFirstFile,strSecondFile,strThirdFile) ) 

#define ITextComparison2_SaveFile(This,nFile,strSaveTo)	\
    ( (This)->lpVtbl -> SaveFile(This,nFile,strSaveTo) ) 

#define ITextComparison2_SaveFileAs(This,nFile)	\
    ( (This)->lpVtbl -> SaveFileAs(This,nFile) ) 

#define ITextComparison2_ThreeWayMerge(This,pVal)	\
    ( (This)->lpVtbl -> ThreeWayMerge(This,pVal) ) 


#define ITextComparison2_get_NumberOfLines(This,nFile,pVal)	\
    ( (This)->lpVtbl -> get_NumberOfLines(This,nFile,pVal) ) 

#define ITextComparison2_get_ChangeStartLine(This,nChange,nSide,nFilePair,pVal)	\
    ( (This)->lpVtbl -> get_ChangeStartLine(This,nChange,nSide,nFilePair,pVal) ) 

#define ITextComparison2_get_ChangeLength(This,nChange,nSide,nFilePair,pVal)	\
    ( (This)->lpVtbl -> get_ChangeLength(This,nChange,nSide,nFilePair,pVal) ) 

#define ITextComparison2_get_LineLength(This,nLine,nFile,pVal)	\
    ( (This)->lpVtbl -> get_LineLength(This,nLine,nFile,pVal) ) 

#define ITextComparison2_get_FullLineLength(This,nLine,nFile,pVal)	\
    ( (This)->lpVtbl -> get_FullLineLength(This,nLine,nFile,pVal) ) 

#define ITextComparison2_get_ChangeType(This,nChange,nFilePair,pVal)	\
    ( (This)->lpVtbl -> get_ChangeType(This,nChange,nFilePair,pVal) ) 

#define ITextComparison2_get_FullLineData(This,nLine,nFile,pVal)	\
    ( (This)->lpVtbl -> get_FullLineData(This,nLine,nFile,pVal) ) 

#define ITextComparison2_get_LineData(This,nLine,nFile,pVal)	\
    ( (This)->lpVtbl -> get_LineData(This,nLine,nFile,pVal) ) 

#define ITextComparison2_get_FileContent(This,nFile,pVal)	\
    ( (This)->lpVtbl -> get_FileContent(This,nFile,pVal) ) 

#define ITextComparison2_put_FileContent(This,nFile,strText)	\
    ( (This)->lpVtbl -> put_FileContent(This,nFile,strText) ) 

#define ITextComparison2_get_LineNumber(This,nFile,pVal)	\
    ( (This)->lpVtbl -> get_LineNumber(This,nFile,pVal) ) 

#define ITextComparison2_put_LineNumber(This,nFile,nLineNumber)	\
    ( (This)->lpVtbl -> put_LineNumber(This,nFile,nLineNumber) ) 


#define ITextComparison2_CompareWithEncoding(This,strFirstFile,firstEncoding,strSecondFile,secondEncoding,strThirdFile,thirdEncoding)	\
    ( (This)->lpVtbl -> CompareWithEncoding(This,strFirstFile,firstEncoding,strSecondFile,secondEncoding,strThirdFile,thirdEncoding) ) 

#define ITextComparison2_CompareAsyncWithEncoding(This,strFirstFile,firstEncoding,strSecondFile,secondEncoding,strThirdFile,thirdEncoding)	\
    ( (This)->lpVtbl -> CompareAsyncWithEncoding(This,strFirstFile,firstEncoding,strSecondFile,secondEncoding,strThirdFile,thirdEncoding) ) 

#endif /* COBJMACROS */


#endif 	/* C style interface */




#endif 	/* __ITextComparison2_INTERFACE_DEFINED__ */


#ifndef __IBinaryComparison_INTERFACE_DEFINED__
#define __IBinaryComparison_INTERFACE_DEFINED__

/* interface IBinaryComparison */
/* [version][uuid][helpstring][unique][dual][object] */ 


EXTERN_C const IID IID_IBinaryComparison;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("bc3955fe-1b77-47bd-8186-ca3403f2473c")
    IBinaryComparison : public IFileComparison
    {
    public:
        virtual /* [helpstring][propget][id] */ HRESULT STDMETHODCALLTYPE get_NumberOfBytes( 
            /* [in] */ short nFile,
            /* [retval][out] */ long *pVal) = 0;
        
        virtual /* [helpstring][propget][id] */ HRESULT STDMETHODCALLTYPE get_ChangeStartByte( 
            /* [in] */ long nChange,
            /* [in] */ short nSide,
            /* [optional][in] */ VARIANT nFilePair,
            /* [retval][out] */ long *pVal) = 0;
        
        virtual /* [helpstring][propget][id] */ HRESULT STDMETHODCALLTYPE get_ChangeLength( 
            /* [in] */ long nChange,
            /* [in] */ short nSide,
            /* [optional][in] */ VARIANT nFilePair,
            /* [retval][out] */ long *pVal) = 0;
        
        virtual /* [helpstring][propget][id] */ HRESULT STDMETHODCALLTYPE get_ChangeType( 
            /* [in] */ long nChange,
            /* [optional][in] */ VARIANT nFilePair,
            /* [retval][out] */ ChangeStyle *pVal) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IBinaryComparisonVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IBinaryComparison * This,
            /* [in] */ REFIID riid,
            /* [annotation][iid_is][out] */ 
            __RPC__deref_out  void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IBinaryComparison * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IBinaryComparison * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            IBinaryComparison * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            IBinaryComparison * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            IBinaryComparison * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [range][in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            IBinaryComparison * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_Active )( 
            IBinaryComparison * This,
            /* [retval][out] */ VARIANT_BOOL *pVal);
        
        /* [helpstring][propput][id] */ HRESULT ( STDMETHODCALLTYPE *put_Active )( 
            IBinaryComparison * This,
            /* [in] */ VARIANT_BOOL newVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_Visible )( 
            IBinaryComparison * This,
            /* [retval][out] */ VARIANT_BOOL *pVal);
        
        /* [helpstring][propput][id] */ HRESULT ( STDMETHODCALLTYPE *put_Visible )( 
            IBinaryComparison * This,
            /* [in] */ VARIANT_BOOL newVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_Minimized )( 
            IBinaryComparison * This,
            /* [retval][out] */ VARIANT_BOOL *pVal);
        
        /* [helpstring][propput][id] */ HRESULT ( STDMETHODCALLTYPE *put_Minimized )( 
            IBinaryComparison * This,
            /* [in] */ VARIANT_BOOL newVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_Maximized )( 
            IBinaryComparison * This,
            /* [retval][out] */ VARIANT_BOOL *pVal);
        
        /* [helpstring][propput][id] */ HRESULT ( STDMETHODCALLTYPE *put_Maximized )( 
            IBinaryComparison * This,
            /* [in] */ VARIANT_BOOL newVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_Left )( 
            IBinaryComparison * This,
            /* [retval][out] */ long *pVal);
        
        /* [helpstring][propput][id] */ HRESULT ( STDMETHODCALLTYPE *put_Left )( 
            IBinaryComparison * This,
            /* [in] */ long newVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_Top )( 
            IBinaryComparison * This,
            /* [retval][out] */ long *pVal);
        
        /* [helpstring][propput][id] */ HRESULT ( STDMETHODCALLTYPE *put_Top )( 
            IBinaryComparison * This,
            /* [in] */ long newVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_Width )( 
            IBinaryComparison * This,
            /* [retval][out] */ long *pVal);
        
        /* [helpstring][propput][id] */ HRESULT ( STDMETHODCALLTYPE *put_Width )( 
            IBinaryComparison * This,
            /* [in] */ long newVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_Height )( 
            IBinaryComparison * This,
            /* [retval][out] */ long *pVal);
        
        /* [helpstring][propput][id] */ HRESULT ( STDMETHODCALLTYPE *put_Height )( 
            IBinaryComparison * This,
            /* [in] */ long newVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *Restore )( 
            IBinaryComparison * This);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *Close )( 
            IBinaryComparison * This);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *GiveUserControl )( 
            IBinaryComparison * This);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_ViewType )( 
            IBinaryComparison * This,
            /* [retval][out] */ FileViewType *pVal);
        
        /* [helpstring][propput][id] */ HRESULT ( STDMETHODCALLTYPE *put_ViewType )( 
            IBinaryComparison * This,
            /* [in] */ FileViewType newVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *Compare )( 
            IBinaryComparison * This,
            /* [in] */ VARIANT strFirstFile,
            /* [in] */ VARIANT strSecondFile,
            /* [optional][in] */ VARIANT strThirdFile);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *Refresh )( 
            IBinaryComparison * This);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *SaveComparison )( 
            IBinaryComparison * This,
            /* [in] */ BSTR filename);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *SetPanelTitles )( 
            IBinaryComparison * This,
            /* [in] */ VARIANT strFirst,
            /* [in] */ VARIANT strSecond,
            /* [optional][in] */ VARIANT strThird);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *Print )( 
            IBinaryComparison * This,
            /* [defaultvalue][in] */ VARIANT_BOOL bShowPrinterDialog,
            /* [defaultvalue][in] */ PageOrientation nOrientation);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *Report )( 
            IBinaryComparison * This,
            /* [in] */ BSTR bstrReporter,
            /* [in] */ LineEndingStyle nLineEndingStyle,
            /* [in] */ BSTR strOutputFile);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *Report2 )( 
            IBinaryComparison * This,
            /* [in] */ BSTR bstrReporter,
            /* [in] */ LineEndingStyle nLineEndingStyle,
            /* [in] */ VARIANT vtEncoding,
            /* [in] */ BSTR strOutputFile);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_SaveFileName )( 
            IBinaryComparison * This,
            /* [retval][out] */ BSTR *pVal);
        
        /* [helpstring][propput][id] */ HRESULT ( STDMETHODCALLTYPE *put_SaveFileName )( 
            IBinaryComparison * This,
            /* [in] */ BSTR newVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_ComparisonResult )( 
            IBinaryComparison * This,
            /* [optional][in] */ VARIANT nFilePair,
            /* [retval][out] */ FileComparisonResult *pVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_ComparisonError )( 
            IBinaryComparison * This,
            /* [optional][in] */ VARIANT nFilePair,
            /* [retval][out] */ FileComparisonError *pVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_ErrorInfo )( 
            IBinaryComparison * This,
            /* [in] */ short nFile,
            /* [retval][out] */ BSTR *pVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_Modified )( 
            IBinaryComparison * This,
            /* [in] */ short nFile,
            /* [retval][out] */ VARIANT_BOOL *pVal);
        
        /* [helpstring][propput][id] */ HRESULT ( STDMETHODCALLTYPE *put_Modified )( 
            IBinaryComparison * This,
            /* [in] */ short nFile,
            /* [in] */ VARIANT_BOOL bModified);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_ReadOnly )( 
            IBinaryComparison * This,
            /* [in] */ short nFile,
            /* [retval][out] */ VARIANT_BOOL *pVal);
        
        /* [helpstring][propput][id] */ HRESULT ( STDMETHODCALLTYPE *put_ReadOnly )( 
            IBinaryComparison * This,
            /* [in] */ short nFile,
            /* [in] */ VARIANT_BOOL bReadOnly);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_PromptForUnsavedFiles )( 
            IBinaryComparison * This,
            /* [retval][out] */ VARIANT_BOOL *pVal);
        
        /* [helpstring][propput][id] */ HRESULT ( STDMETHODCALLTYPE *put_PromptForUnsavedFiles )( 
            IBinaryComparison * This,
            /* [in] */ VARIANT_BOOL bPrompt);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_AutoSaveOnClose )( 
            IBinaryComparison * This,
            /* [retval][out] */ VARIANT_BOOL *pVal);
        
        /* [helpstring][propput][id] */ HRESULT ( STDMETHODCALLTYPE *put_AutoSaveOnClose )( 
            IBinaryComparison * This,
            /* [in] */ VARIANT_BOOL bAutoSaveOnClose);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_ThreeWayMergeActions )( 
            IBinaryComparison * This,
            /* [retval][out] */ IThreeWayMergeActions **pVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_UnresolvedConflicts )( 
            IBinaryComparison * This,
            /* [in] */ short nFile,
            /* [retval][out] */ long *pVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_AllUnresolvedConflicts )( 
            IBinaryComparison * This,
            /* [retval][out] */ long *pVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_NumberOfChanges )( 
            IBinaryComparison * This,
            /* [optional][in] */ VARIANT nFilePair,
            /* [retval][out] */ long *pVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *CompareAsync )( 
            IBinaryComparison * This,
            /* [in] */ VARIANT strFirstFile,
            /* [in] */ VARIANT strSecondFile,
            /* [optional][in] */ VARIANT strThirdFile);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *SaveFile )( 
            IBinaryComparison * This,
            /* [in] */ short nFile,
            /* [optional][in] */ VARIANT strSaveTo);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *SaveFileAs )( 
            IBinaryComparison * This,
            /* [in] */ short nFile);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *ThreeWayMerge )( 
            IBinaryComparison * This,
            /* [retval][out] */ long *pVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_NumberOfBytes )( 
            IBinaryComparison * This,
            /* [in] */ short nFile,
            /* [retval][out] */ long *pVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_ChangeStartByte )( 
            IBinaryComparison * This,
            /* [in] */ long nChange,
            /* [in] */ short nSide,
            /* [optional][in] */ VARIANT nFilePair,
            /* [retval][out] */ long *pVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_ChangeLength )( 
            IBinaryComparison * This,
            /* [in] */ long nChange,
            /* [in] */ short nSide,
            /* [optional][in] */ VARIANT nFilePair,
            /* [retval][out] */ long *pVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_ChangeType )( 
            IBinaryComparison * This,
            /* [in] */ long nChange,
            /* [optional][in] */ VARIANT nFilePair,
            /* [retval][out] */ ChangeStyle *pVal);
        
        END_INTERFACE
    } IBinaryComparisonVtbl;

    interface IBinaryComparison
    {
        CONST_VTBL struct IBinaryComparisonVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IBinaryComparison_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 

#define IBinaryComparison_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 

#define IBinaryComparison_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 


#define IBinaryComparison_GetTypeInfoCount(This,pctinfo)	\
    ( (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo) ) 

#define IBinaryComparison_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    ( (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo) ) 

#define IBinaryComparison_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    ( (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId) ) 

#define IBinaryComparison_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    ( (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr) ) 


#define IBinaryComparison_get_Active(This,pVal)	\
    ( (This)->lpVtbl -> get_Active(This,pVal) ) 

#define IBinaryComparison_put_Active(This,newVal)	\
    ( (This)->lpVtbl -> put_Active(This,newVal) ) 

#define IBinaryComparison_get_Visible(This,pVal)	\
    ( (This)->lpVtbl -> get_Visible(This,pVal) ) 

#define IBinaryComparison_put_Visible(This,newVal)	\
    ( (This)->lpVtbl -> put_Visible(This,newVal) ) 

#define IBinaryComparison_get_Minimized(This,pVal)	\
    ( (This)->lpVtbl -> get_Minimized(This,pVal) ) 

#define IBinaryComparison_put_Minimized(This,newVal)	\
    ( (This)->lpVtbl -> put_Minimized(This,newVal) ) 

#define IBinaryComparison_get_Maximized(This,pVal)	\
    ( (This)->lpVtbl -> get_Maximized(This,pVal) ) 

#define IBinaryComparison_put_Maximized(This,newVal)	\
    ( (This)->lpVtbl -> put_Maximized(This,newVal) ) 

#define IBinaryComparison_get_Left(This,pVal)	\
    ( (This)->lpVtbl -> get_Left(This,pVal) ) 

#define IBinaryComparison_put_Left(This,newVal)	\
    ( (This)->lpVtbl -> put_Left(This,newVal) ) 

#define IBinaryComparison_get_Top(This,pVal)	\
    ( (This)->lpVtbl -> get_Top(This,pVal) ) 

#define IBinaryComparison_put_Top(This,newVal)	\
    ( (This)->lpVtbl -> put_Top(This,newVal) ) 

#define IBinaryComparison_get_Width(This,pVal)	\
    ( (This)->lpVtbl -> get_Width(This,pVal) ) 

#define IBinaryComparison_put_Width(This,newVal)	\
    ( (This)->lpVtbl -> put_Width(This,newVal) ) 

#define IBinaryComparison_get_Height(This,pVal)	\
    ( (This)->lpVtbl -> get_Height(This,pVal) ) 

#define IBinaryComparison_put_Height(This,newVal)	\
    ( (This)->lpVtbl -> put_Height(This,newVal) ) 

#define IBinaryComparison_Restore(This)	\
    ( (This)->lpVtbl -> Restore(This) ) 

#define IBinaryComparison_Close(This)	\
    ( (This)->lpVtbl -> Close(This) ) 

#define IBinaryComparison_GiveUserControl(This)	\
    ( (This)->lpVtbl -> GiveUserControl(This) ) 


#define IBinaryComparison_get_ViewType(This,pVal)	\
    ( (This)->lpVtbl -> get_ViewType(This,pVal) ) 

#define IBinaryComparison_put_ViewType(This,newVal)	\
    ( (This)->lpVtbl -> put_ViewType(This,newVal) ) 

#define IBinaryComparison_Compare(This,strFirstFile,strSecondFile,strThirdFile)	\
    ( (This)->lpVtbl -> Compare(This,strFirstFile,strSecondFile,strThirdFile) ) 

#define IBinaryComparison_Refresh(This)	\
    ( (This)->lpVtbl -> Refresh(This) ) 

#define IBinaryComparison_SaveComparison(This,filename)	\
    ( (This)->lpVtbl -> SaveComparison(This,filename) ) 

#define IBinaryComparison_SetPanelTitles(This,strFirst,strSecond,strThird)	\
    ( (This)->lpVtbl -> SetPanelTitles(This,strFirst,strSecond,strThird) ) 

#define IBinaryComparison_Print(This,bShowPrinterDialog,nOrientation)	\
    ( (This)->lpVtbl -> Print(This,bShowPrinterDialog,nOrientation) ) 

#define IBinaryComparison_Report(This,bstrReporter,nLineEndingStyle,strOutputFile)	\
    ( (This)->lpVtbl -> Report(This,bstrReporter,nLineEndingStyle,strOutputFile) ) 

#define IBinaryComparison_Report2(This,bstrReporter,nLineEndingStyle,vtEncoding,strOutputFile)	\
    ( (This)->lpVtbl -> Report2(This,bstrReporter,nLineEndingStyle,vtEncoding,strOutputFile) ) 


#define IBinaryComparison_get_SaveFileName(This,pVal)	\
    ( (This)->lpVtbl -> get_SaveFileName(This,pVal) ) 

#define IBinaryComparison_put_SaveFileName(This,newVal)	\
    ( (This)->lpVtbl -> put_SaveFileName(This,newVal) ) 

#define IBinaryComparison_get_ComparisonResult(This,nFilePair,pVal)	\
    ( (This)->lpVtbl -> get_ComparisonResult(This,nFilePair,pVal) ) 

#define IBinaryComparison_get_ComparisonError(This,nFilePair,pVal)	\
    ( (This)->lpVtbl -> get_ComparisonError(This,nFilePair,pVal) ) 

#define IBinaryComparison_get_ErrorInfo(This,nFile,pVal)	\
    ( (This)->lpVtbl -> get_ErrorInfo(This,nFile,pVal) ) 

#define IBinaryComparison_get_Modified(This,nFile,pVal)	\
    ( (This)->lpVtbl -> get_Modified(This,nFile,pVal) ) 

#define IBinaryComparison_put_Modified(This,nFile,bModified)	\
    ( (This)->lpVtbl -> put_Modified(This,nFile,bModified) ) 

#define IBinaryComparison_get_ReadOnly(This,nFile,pVal)	\
    ( (This)->lpVtbl -> get_ReadOnly(This,nFile,pVal) ) 

#define IBinaryComparison_put_ReadOnly(This,nFile,bReadOnly)	\
    ( (This)->lpVtbl -> put_ReadOnly(This,nFile,bReadOnly) ) 

#define IBinaryComparison_get_PromptForUnsavedFiles(This,pVal)	\
    ( (This)->lpVtbl -> get_PromptForUnsavedFiles(This,pVal) ) 

#define IBinaryComparison_put_PromptForUnsavedFiles(This,bPrompt)	\
    ( (This)->lpVtbl -> put_PromptForUnsavedFiles(This,bPrompt) ) 

#define IBinaryComparison_get_AutoSaveOnClose(This,pVal)	\
    ( (This)->lpVtbl -> get_AutoSaveOnClose(This,pVal) ) 

#define IBinaryComparison_put_AutoSaveOnClose(This,bAutoSaveOnClose)	\
    ( (This)->lpVtbl -> put_AutoSaveOnClose(This,bAutoSaveOnClose) ) 

#define IBinaryComparison_get_ThreeWayMergeActions(This,pVal)	\
    ( (This)->lpVtbl -> get_ThreeWayMergeActions(This,pVal) ) 

#define IBinaryComparison_get_UnresolvedConflicts(This,nFile,pVal)	\
    ( (This)->lpVtbl -> get_UnresolvedConflicts(This,nFile,pVal) ) 

#define IBinaryComparison_get_AllUnresolvedConflicts(This,pVal)	\
    ( (This)->lpVtbl -> get_AllUnresolvedConflicts(This,pVal) ) 

#define IBinaryComparison_get_NumberOfChanges(This,nFilePair,pVal)	\
    ( (This)->lpVtbl -> get_NumberOfChanges(This,nFilePair,pVal) ) 

#define IBinaryComparison_CompareAsync(This,strFirstFile,strSecondFile,strThirdFile)	\
    ( (This)->lpVtbl -> CompareAsync(This,strFirstFile,strSecondFile,strThirdFile) ) 

#define IBinaryComparison_SaveFile(This,nFile,strSaveTo)	\
    ( (This)->lpVtbl -> SaveFile(This,nFile,strSaveTo) ) 

#define IBinaryComparison_SaveFileAs(This,nFile)	\
    ( (This)->lpVtbl -> SaveFileAs(This,nFile) ) 

#define IBinaryComparison_ThreeWayMerge(This,pVal)	\
    ( (This)->lpVtbl -> ThreeWayMerge(This,pVal) ) 


#define IBinaryComparison_get_NumberOfBytes(This,nFile,pVal)	\
    ( (This)->lpVtbl -> get_NumberOfBytes(This,nFile,pVal) ) 

#define IBinaryComparison_get_ChangeStartByte(This,nChange,nSide,nFilePair,pVal)	\
    ( (This)->lpVtbl -> get_ChangeStartByte(This,nChange,nSide,nFilePair,pVal) ) 

#define IBinaryComparison_get_ChangeLength(This,nChange,nSide,nFilePair,pVal)	\
    ( (This)->lpVtbl -> get_ChangeLength(This,nChange,nSide,nFilePair,pVal) ) 

#define IBinaryComparison_get_ChangeType(This,nChange,nFilePair,pVal)	\
    ( (This)->lpVtbl -> get_ChangeType(This,nChange,nFilePair,pVal) ) 

#endif /* COBJMACROS */


#endif 	/* C style interface */




#endif 	/* __IBinaryComparison_INTERFACE_DEFINED__ */


#ifndef __IImageComparison_INTERFACE_DEFINED__
#define __IImageComparison_INTERFACE_DEFINED__

/* interface IImageComparison */
/* [version][uuid][helpstring][unique][dual][object] */ 


EXTERN_C const IID IID_IImageComparison;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("64064555-5ee6-403d-9dd5-1701e7f7025d")
    IImageComparison : public IFileComparison
    {
    public:
    };
    
#else 	/* C style interface */

    typedef struct IImageComparisonVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IImageComparison * This,
            /* [in] */ REFIID riid,
            /* [annotation][iid_is][out] */ 
            __RPC__deref_out  void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IImageComparison * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IImageComparison * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            IImageComparison * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            IImageComparison * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            IImageComparison * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [range][in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            IImageComparison * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_Active )( 
            IImageComparison * This,
            /* [retval][out] */ VARIANT_BOOL *pVal);
        
        /* [helpstring][propput][id] */ HRESULT ( STDMETHODCALLTYPE *put_Active )( 
            IImageComparison * This,
            /* [in] */ VARIANT_BOOL newVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_Visible )( 
            IImageComparison * This,
            /* [retval][out] */ VARIANT_BOOL *pVal);
        
        /* [helpstring][propput][id] */ HRESULT ( STDMETHODCALLTYPE *put_Visible )( 
            IImageComparison * This,
            /* [in] */ VARIANT_BOOL newVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_Minimized )( 
            IImageComparison * This,
            /* [retval][out] */ VARIANT_BOOL *pVal);
        
        /* [helpstring][propput][id] */ HRESULT ( STDMETHODCALLTYPE *put_Minimized )( 
            IImageComparison * This,
            /* [in] */ VARIANT_BOOL newVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_Maximized )( 
            IImageComparison * This,
            /* [retval][out] */ VARIANT_BOOL *pVal);
        
        /* [helpstring][propput][id] */ HRESULT ( STDMETHODCALLTYPE *put_Maximized )( 
            IImageComparison * This,
            /* [in] */ VARIANT_BOOL newVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_Left )( 
            IImageComparison * This,
            /* [retval][out] */ long *pVal);
        
        /* [helpstring][propput][id] */ HRESULT ( STDMETHODCALLTYPE *put_Left )( 
            IImageComparison * This,
            /* [in] */ long newVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_Top )( 
            IImageComparison * This,
            /* [retval][out] */ long *pVal);
        
        /* [helpstring][propput][id] */ HRESULT ( STDMETHODCALLTYPE *put_Top )( 
            IImageComparison * This,
            /* [in] */ long newVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_Width )( 
            IImageComparison * This,
            /* [retval][out] */ long *pVal);
        
        /* [helpstring][propput][id] */ HRESULT ( STDMETHODCALLTYPE *put_Width )( 
            IImageComparison * This,
            /* [in] */ long newVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_Height )( 
            IImageComparison * This,
            /* [retval][out] */ long *pVal);
        
        /* [helpstring][propput][id] */ HRESULT ( STDMETHODCALLTYPE *put_Height )( 
            IImageComparison * This,
            /* [in] */ long newVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *Restore )( 
            IImageComparison * This);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *Close )( 
            IImageComparison * This);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *GiveUserControl )( 
            IImageComparison * This);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_ViewType )( 
            IImageComparison * This,
            /* [retval][out] */ FileViewType *pVal);
        
        /* [helpstring][propput][id] */ HRESULT ( STDMETHODCALLTYPE *put_ViewType )( 
            IImageComparison * This,
            /* [in] */ FileViewType newVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *Compare )( 
            IImageComparison * This,
            /* [in] */ VARIANT strFirstFile,
            /* [in] */ VARIANT strSecondFile,
            /* [optional][in] */ VARIANT strThirdFile);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *Refresh )( 
            IImageComparison * This);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *SaveComparison )( 
            IImageComparison * This,
            /* [in] */ BSTR filename);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *SetPanelTitles )( 
            IImageComparison * This,
            /* [in] */ VARIANT strFirst,
            /* [in] */ VARIANT strSecond,
            /* [optional][in] */ VARIANT strThird);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *Print )( 
            IImageComparison * This,
            /* [defaultvalue][in] */ VARIANT_BOOL bShowPrinterDialog,
            /* [defaultvalue][in] */ PageOrientation nOrientation);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *Report )( 
            IImageComparison * This,
            /* [in] */ BSTR bstrReporter,
            /* [in] */ LineEndingStyle nLineEndingStyle,
            /* [in] */ BSTR strOutputFile);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *Report2 )( 
            IImageComparison * This,
            /* [in] */ BSTR bstrReporter,
            /* [in] */ LineEndingStyle nLineEndingStyle,
            /* [in] */ VARIANT vtEncoding,
            /* [in] */ BSTR strOutputFile);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_SaveFileName )( 
            IImageComparison * This,
            /* [retval][out] */ BSTR *pVal);
        
        /* [helpstring][propput][id] */ HRESULT ( STDMETHODCALLTYPE *put_SaveFileName )( 
            IImageComparison * This,
            /* [in] */ BSTR newVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_ComparisonResult )( 
            IImageComparison * This,
            /* [optional][in] */ VARIANT nFilePair,
            /* [retval][out] */ FileComparisonResult *pVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_ComparisonError )( 
            IImageComparison * This,
            /* [optional][in] */ VARIANT nFilePair,
            /* [retval][out] */ FileComparisonError *pVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_ErrorInfo )( 
            IImageComparison * This,
            /* [in] */ short nFile,
            /* [retval][out] */ BSTR *pVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_Modified )( 
            IImageComparison * This,
            /* [in] */ short nFile,
            /* [retval][out] */ VARIANT_BOOL *pVal);
        
        /* [helpstring][propput][id] */ HRESULT ( STDMETHODCALLTYPE *put_Modified )( 
            IImageComparison * This,
            /* [in] */ short nFile,
            /* [in] */ VARIANT_BOOL bModified);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_ReadOnly )( 
            IImageComparison * This,
            /* [in] */ short nFile,
            /* [retval][out] */ VARIANT_BOOL *pVal);
        
        /* [helpstring][propput][id] */ HRESULT ( STDMETHODCALLTYPE *put_ReadOnly )( 
            IImageComparison * This,
            /* [in] */ short nFile,
            /* [in] */ VARIANT_BOOL bReadOnly);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_PromptForUnsavedFiles )( 
            IImageComparison * This,
            /* [retval][out] */ VARIANT_BOOL *pVal);
        
        /* [helpstring][propput][id] */ HRESULT ( STDMETHODCALLTYPE *put_PromptForUnsavedFiles )( 
            IImageComparison * This,
            /* [in] */ VARIANT_BOOL bPrompt);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_AutoSaveOnClose )( 
            IImageComparison * This,
            /* [retval][out] */ VARIANT_BOOL *pVal);
        
        /* [helpstring][propput][id] */ HRESULT ( STDMETHODCALLTYPE *put_AutoSaveOnClose )( 
            IImageComparison * This,
            /* [in] */ VARIANT_BOOL bAutoSaveOnClose);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_ThreeWayMergeActions )( 
            IImageComparison * This,
            /* [retval][out] */ IThreeWayMergeActions **pVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_UnresolvedConflicts )( 
            IImageComparison * This,
            /* [in] */ short nFile,
            /* [retval][out] */ long *pVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_AllUnresolvedConflicts )( 
            IImageComparison * This,
            /* [retval][out] */ long *pVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_NumberOfChanges )( 
            IImageComparison * This,
            /* [optional][in] */ VARIANT nFilePair,
            /* [retval][out] */ long *pVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *CompareAsync )( 
            IImageComparison * This,
            /* [in] */ VARIANT strFirstFile,
            /* [in] */ VARIANT strSecondFile,
            /* [optional][in] */ VARIANT strThirdFile);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *SaveFile )( 
            IImageComparison * This,
            /* [in] */ short nFile,
            /* [optional][in] */ VARIANT strSaveTo);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *SaveFileAs )( 
            IImageComparison * This,
            /* [in] */ short nFile);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *ThreeWayMerge )( 
            IImageComparison * This,
            /* [retval][out] */ long *pVal);
        
        END_INTERFACE
    } IImageComparisonVtbl;

    interface IImageComparison
    {
        CONST_VTBL struct IImageComparisonVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IImageComparison_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 

#define IImageComparison_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 

#define IImageComparison_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 


#define IImageComparison_GetTypeInfoCount(This,pctinfo)	\
    ( (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo) ) 

#define IImageComparison_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    ( (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo) ) 

#define IImageComparison_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    ( (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId) ) 

#define IImageComparison_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    ( (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr) ) 


#define IImageComparison_get_Active(This,pVal)	\
    ( (This)->lpVtbl -> get_Active(This,pVal) ) 

#define IImageComparison_put_Active(This,newVal)	\
    ( (This)->lpVtbl -> put_Active(This,newVal) ) 

#define IImageComparison_get_Visible(This,pVal)	\
    ( (This)->lpVtbl -> get_Visible(This,pVal) ) 

#define IImageComparison_put_Visible(This,newVal)	\
    ( (This)->lpVtbl -> put_Visible(This,newVal) ) 

#define IImageComparison_get_Minimized(This,pVal)	\
    ( (This)->lpVtbl -> get_Minimized(This,pVal) ) 

#define IImageComparison_put_Minimized(This,newVal)	\
    ( (This)->lpVtbl -> put_Minimized(This,newVal) ) 

#define IImageComparison_get_Maximized(This,pVal)	\
    ( (This)->lpVtbl -> get_Maximized(This,pVal) ) 

#define IImageComparison_put_Maximized(This,newVal)	\
    ( (This)->lpVtbl -> put_Maximized(This,newVal) ) 

#define IImageComparison_get_Left(This,pVal)	\
    ( (This)->lpVtbl -> get_Left(This,pVal) ) 

#define IImageComparison_put_Left(This,newVal)	\
    ( (This)->lpVtbl -> put_Left(This,newVal) ) 

#define IImageComparison_get_Top(This,pVal)	\
    ( (This)->lpVtbl -> get_Top(This,pVal) ) 

#define IImageComparison_put_Top(This,newVal)	\
    ( (This)->lpVtbl -> put_Top(This,newVal) ) 

#define IImageComparison_get_Width(This,pVal)	\
    ( (This)->lpVtbl -> get_Width(This,pVal) ) 

#define IImageComparison_put_Width(This,newVal)	\
    ( (This)->lpVtbl -> put_Width(This,newVal) ) 

#define IImageComparison_get_Height(This,pVal)	\
    ( (This)->lpVtbl -> get_Height(This,pVal) ) 

#define IImageComparison_put_Height(This,newVal)	\
    ( (This)->lpVtbl -> put_Height(This,newVal) ) 

#define IImageComparison_Restore(This)	\
    ( (This)->lpVtbl -> Restore(This) ) 

#define IImageComparison_Close(This)	\
    ( (This)->lpVtbl -> Close(This) ) 

#define IImageComparison_GiveUserControl(This)	\
    ( (This)->lpVtbl -> GiveUserControl(This) ) 


#define IImageComparison_get_ViewType(This,pVal)	\
    ( (This)->lpVtbl -> get_ViewType(This,pVal) ) 

#define IImageComparison_put_ViewType(This,newVal)	\
    ( (This)->lpVtbl -> put_ViewType(This,newVal) ) 

#define IImageComparison_Compare(This,strFirstFile,strSecondFile,strThirdFile)	\
    ( (This)->lpVtbl -> Compare(This,strFirstFile,strSecondFile,strThirdFile) ) 

#define IImageComparison_Refresh(This)	\
    ( (This)->lpVtbl -> Refresh(This) ) 

#define IImageComparison_SaveComparison(This,filename)	\
    ( (This)->lpVtbl -> SaveComparison(This,filename) ) 

#define IImageComparison_SetPanelTitles(This,strFirst,strSecond,strThird)	\
    ( (This)->lpVtbl -> SetPanelTitles(This,strFirst,strSecond,strThird) ) 

#define IImageComparison_Print(This,bShowPrinterDialog,nOrientation)	\
    ( (This)->lpVtbl -> Print(This,bShowPrinterDialog,nOrientation) ) 

#define IImageComparison_Report(This,bstrReporter,nLineEndingStyle,strOutputFile)	\
    ( (This)->lpVtbl -> Report(This,bstrReporter,nLineEndingStyle,strOutputFile) ) 

#define IImageComparison_Report2(This,bstrReporter,nLineEndingStyle,vtEncoding,strOutputFile)	\
    ( (This)->lpVtbl -> Report2(This,bstrReporter,nLineEndingStyle,vtEncoding,strOutputFile) ) 


#define IImageComparison_get_SaveFileName(This,pVal)	\
    ( (This)->lpVtbl -> get_SaveFileName(This,pVal) ) 

#define IImageComparison_put_SaveFileName(This,newVal)	\
    ( (This)->lpVtbl -> put_SaveFileName(This,newVal) ) 

#define IImageComparison_get_ComparisonResult(This,nFilePair,pVal)	\
    ( (This)->lpVtbl -> get_ComparisonResult(This,nFilePair,pVal) ) 

#define IImageComparison_get_ComparisonError(This,nFilePair,pVal)	\
    ( (This)->lpVtbl -> get_ComparisonError(This,nFilePair,pVal) ) 

#define IImageComparison_get_ErrorInfo(This,nFile,pVal)	\
    ( (This)->lpVtbl -> get_ErrorInfo(This,nFile,pVal) ) 

#define IImageComparison_get_Modified(This,nFile,pVal)	\
    ( (This)->lpVtbl -> get_Modified(This,nFile,pVal) ) 

#define IImageComparison_put_Modified(This,nFile,bModified)	\
    ( (This)->lpVtbl -> put_Modified(This,nFile,bModified) ) 

#define IImageComparison_get_ReadOnly(This,nFile,pVal)	\
    ( (This)->lpVtbl -> get_ReadOnly(This,nFile,pVal) ) 

#define IImageComparison_put_ReadOnly(This,nFile,bReadOnly)	\
    ( (This)->lpVtbl -> put_ReadOnly(This,nFile,bReadOnly) ) 

#define IImageComparison_get_PromptForUnsavedFiles(This,pVal)	\
    ( (This)->lpVtbl -> get_PromptForUnsavedFiles(This,pVal) ) 

#define IImageComparison_put_PromptForUnsavedFiles(This,bPrompt)	\
    ( (This)->lpVtbl -> put_PromptForUnsavedFiles(This,bPrompt) ) 

#define IImageComparison_get_AutoSaveOnClose(This,pVal)	\
    ( (This)->lpVtbl -> get_AutoSaveOnClose(This,pVal) ) 

#define IImageComparison_put_AutoSaveOnClose(This,bAutoSaveOnClose)	\
    ( (This)->lpVtbl -> put_AutoSaveOnClose(This,bAutoSaveOnClose) ) 

#define IImageComparison_get_ThreeWayMergeActions(This,pVal)	\
    ( (This)->lpVtbl -> get_ThreeWayMergeActions(This,pVal) ) 

#define IImageComparison_get_UnresolvedConflicts(This,nFile,pVal)	\
    ( (This)->lpVtbl -> get_UnresolvedConflicts(This,nFile,pVal) ) 

#define IImageComparison_get_AllUnresolvedConflicts(This,pVal)	\
    ( (This)->lpVtbl -> get_AllUnresolvedConflicts(This,pVal) ) 

#define IImageComparison_get_NumberOfChanges(This,nFilePair,pVal)	\
    ( (This)->lpVtbl -> get_NumberOfChanges(This,nFilePair,pVal) ) 

#define IImageComparison_CompareAsync(This,strFirstFile,strSecondFile,strThirdFile)	\
    ( (This)->lpVtbl -> CompareAsync(This,strFirstFile,strSecondFile,strThirdFile) ) 

#define IImageComparison_SaveFile(This,nFile,strSaveTo)	\
    ( (This)->lpVtbl -> SaveFile(This,nFile,strSaveTo) ) 

#define IImageComparison_SaveFileAs(This,nFile)	\
    ( (This)->lpVtbl -> SaveFileAs(This,nFile) ) 

#define IImageComparison_ThreeWayMerge(This,pVal)	\
    ( (This)->lpVtbl -> ThreeWayMerge(This,pVal) ) 


#endif /* COBJMACROS */


#endif 	/* C style interface */




#endif 	/* __IImageComparison_INTERFACE_DEFINED__ */


#ifndef __IFilters_INTERFACE_DEFINED__
#define __IFilters_INTERFACE_DEFINED__

/* interface IFilters */
/* [version][uuid][helpstring][unique][dual][object] */ 


EXTERN_C const IID IID_IFilters;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("57731878-8f6c-4721-b890-a5df736466b7")
    IFilters : public IDispatch
    {
    public:
        virtual /* [helpstring][propget][id] */ HRESULT STDMETHODCALLTYPE get_Count( 
            /* [retval][out] */ long *count) = 0;
        
        virtual /* [helpstring][propget][id] */ HRESULT STDMETHODCALLTYPE get_Item( 
            /* [in] */ VARIANT index,
            /* [retval][out] */ IFilter **filter) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE Store( 
            /* [in] */ IFilter *filter,
            /* [retval][out] */ long *index) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE Remove( 
            /* [in] */ long index) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE MakeActive( 
            /* [in] */ long index) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IFiltersVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IFilters * This,
            /* [in] */ REFIID riid,
            /* [annotation][iid_is][out] */ 
            __RPC__deref_out  void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IFilters * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IFilters * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            IFilters * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            IFilters * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            IFilters * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [range][in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            IFilters * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_Count )( 
            IFilters * This,
            /* [retval][out] */ long *count);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_Item )( 
            IFilters * This,
            /* [in] */ VARIANT index,
            /* [retval][out] */ IFilter **filter);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *Store )( 
            IFilters * This,
            /* [in] */ IFilter *filter,
            /* [retval][out] */ long *index);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *Remove )( 
            IFilters * This,
            /* [in] */ long index);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *MakeActive )( 
            IFilters * This,
            /* [in] */ long index);
        
        END_INTERFACE
    } IFiltersVtbl;

    interface IFilters
    {
        CONST_VTBL struct IFiltersVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IFilters_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 

#define IFilters_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 

#define IFilters_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 


#define IFilters_GetTypeInfoCount(This,pctinfo)	\
    ( (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo) ) 

#define IFilters_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    ( (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo) ) 

#define IFilters_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    ( (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId) ) 

#define IFilters_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    ( (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr) ) 


#define IFilters_get_Count(This,count)	\
    ( (This)->lpVtbl -> get_Count(This,count) ) 

#define IFilters_get_Item(This,index,filter)	\
    ( (This)->lpVtbl -> get_Item(This,index,filter) ) 

#define IFilters_Store(This,filter,index)	\
    ( (This)->lpVtbl -> Store(This,filter,index) ) 

#define IFilters_Remove(This,index)	\
    ( (This)->lpVtbl -> Remove(This,index) ) 

#define IFilters_MakeActive(This,index)	\
    ( (This)->lpVtbl -> MakeActive(This,index) ) 

#endif /* COBJMACROS */


#endif 	/* C style interface */




#endif 	/* __IFilters_INTERFACE_DEFINED__ */


#ifndef __IFilter_INTERFACE_DEFINED__
#define __IFilter_INTERFACE_DEFINED__

/* interface IFilter */
/* [version][uuid][helpstring][unique][dual][object] */ 


EXTERN_C const IID IID_IFilter;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("6f7cb99c-5a23-4637-9dbb-245862f6acca")
    IFilter : public IDispatch
    {
    public:
        virtual /* [helpstring][propget][id] */ HRESULT STDMETHODCALLTYPE get_Name( 
            /* [retval][out] */ BSTR *name) = 0;
        
        virtual /* [helpstring][propput][id] */ HRESULT STDMETHODCALLTYPE put_Name( 
            /* [in] */ BSTR name) = 0;
        
        virtual /* [helpstring][propget][id] */ HRESULT STDMETHODCALLTYPE get_Count( 
            /* [retval][out] */ long *count) = 0;
        
        virtual /* [helpstring][propget][id] */ HRESULT STDMETHODCALLTYPE get_Item( 
            /* [in] */ long index,
            /* [retval][out] */ IFilterPattern **pattern) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE Add( 
            /* [in] */ IFilterPattern *pattern,
            /* [retval][out] */ long *index) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE Remove( 
            /* [in] */ long index) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE RepositionPattern( 
            /* [in] */ long oldIndex,
            /* [in] */ long newIndex) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE InitializeFromExcludePattern( 
            /* [in] */ BSTR pattern) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE InitializeFromIncludePattern( 
            /* [in] */ BSTR pattern) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IFilterVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IFilter * This,
            /* [in] */ REFIID riid,
            /* [annotation][iid_is][out] */ 
            __RPC__deref_out  void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IFilter * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IFilter * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            IFilter * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            IFilter * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            IFilter * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [range][in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            IFilter * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_Name )( 
            IFilter * This,
            /* [retval][out] */ BSTR *name);
        
        /* [helpstring][propput][id] */ HRESULT ( STDMETHODCALLTYPE *put_Name )( 
            IFilter * This,
            /* [in] */ BSTR name);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_Count )( 
            IFilter * This,
            /* [retval][out] */ long *count);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_Item )( 
            IFilter * This,
            /* [in] */ long index,
            /* [retval][out] */ IFilterPattern **pattern);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *Add )( 
            IFilter * This,
            /* [in] */ IFilterPattern *pattern,
            /* [retval][out] */ long *index);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *Remove )( 
            IFilter * This,
            /* [in] */ long index);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *RepositionPattern )( 
            IFilter * This,
            /* [in] */ long oldIndex,
            /* [in] */ long newIndex);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *InitializeFromExcludePattern )( 
            IFilter * This,
            /* [in] */ BSTR pattern);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *InitializeFromIncludePattern )( 
            IFilter * This,
            /* [in] */ BSTR pattern);
        
        END_INTERFACE
    } IFilterVtbl;

    interface IFilter
    {
        CONST_VTBL struct IFilterVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IFilter_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 

#define IFilter_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 

#define IFilter_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 


#define IFilter_GetTypeInfoCount(This,pctinfo)	\
    ( (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo) ) 

#define IFilter_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    ( (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo) ) 

#define IFilter_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    ( (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId) ) 

#define IFilter_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    ( (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr) ) 


#define IFilter_get_Name(This,name)	\
    ( (This)->lpVtbl -> get_Name(This,name) ) 

#define IFilter_put_Name(This,name)	\
    ( (This)->lpVtbl -> put_Name(This,name) ) 

#define IFilter_get_Count(This,count)	\
    ( (This)->lpVtbl -> get_Count(This,count) ) 

#define IFilter_get_Item(This,index,pattern)	\
    ( (This)->lpVtbl -> get_Item(This,index,pattern) ) 

#define IFilter_Add(This,pattern,index)	\
    ( (This)->lpVtbl -> Add(This,pattern,index) ) 

#define IFilter_Remove(This,index)	\
    ( (This)->lpVtbl -> Remove(This,index) ) 

#define IFilter_RepositionPattern(This,oldIndex,newIndex)	\
    ( (This)->lpVtbl -> RepositionPattern(This,oldIndex,newIndex) ) 

#define IFilter_InitializeFromExcludePattern(This,pattern)	\
    ( (This)->lpVtbl -> InitializeFromExcludePattern(This,pattern) ) 

#define IFilter_InitializeFromIncludePattern(This,pattern)	\
    ( (This)->lpVtbl -> InitializeFromIncludePattern(This,pattern) ) 

#endif /* COBJMACROS */


#endif 	/* C style interface */




#endif 	/* __IFilter_INTERFACE_DEFINED__ */


#ifndef __IFilterPattern_INTERFACE_DEFINED__
#define __IFilterPattern_INTERFACE_DEFINED__

/* interface IFilterPattern */
/* [version][uuid][helpstring][unique][dual][object] */ 


EXTERN_C const IID IID_IFilterPattern;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("4258e5a5-9e77-4e54-b345-6fbc43e39bb7")
    IFilterPattern : public IDispatch
    {
    public:
        virtual /* [helpstring][propget][id] */ HRESULT STDMETHODCALLTYPE get_Filter( 
            /* [retval][out] */ PatternFilter *filter) = 0;
        
        virtual /* [helpstring][propput][id] */ HRESULT STDMETHODCALLTYPE put_Filter( 
            /* [in] */ PatternFilter filter) = 0;
        
        virtual /* [helpstring][propget][id] */ HRESULT STDMETHODCALLTYPE get_Match( 
            /* [retval][out] */ PatternMatch *match) = 0;
        
        virtual /* [helpstring][propput][id] */ HRESULT STDMETHODCALLTYPE put_Match( 
            /* [in] */ PatternMatch match) = 0;
        
        virtual /* [helpstring][propget][id] */ HRESULT STDMETHODCALLTYPE get_Pattern( 
            /* [retval][out] */ BSTR *pattern) = 0;
        
        virtual /* [helpstring][propput][id] */ HRESULT STDMETHODCALLTYPE put_Pattern( 
            /* [in] */ BSTR pattern) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IFilterPatternVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IFilterPattern * This,
            /* [in] */ REFIID riid,
            /* [annotation][iid_is][out] */ 
            __RPC__deref_out  void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IFilterPattern * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IFilterPattern * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            IFilterPattern * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            IFilterPattern * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            IFilterPattern * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [range][in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            IFilterPattern * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_Filter )( 
            IFilterPattern * This,
            /* [retval][out] */ PatternFilter *filter);
        
        /* [helpstring][propput][id] */ HRESULT ( STDMETHODCALLTYPE *put_Filter )( 
            IFilterPattern * This,
            /* [in] */ PatternFilter filter);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_Match )( 
            IFilterPattern * This,
            /* [retval][out] */ PatternMatch *match);
        
        /* [helpstring][propput][id] */ HRESULT ( STDMETHODCALLTYPE *put_Match )( 
            IFilterPattern * This,
            /* [in] */ PatternMatch match);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_Pattern )( 
            IFilterPattern * This,
            /* [retval][out] */ BSTR *pattern);
        
        /* [helpstring][propput][id] */ HRESULT ( STDMETHODCALLTYPE *put_Pattern )( 
            IFilterPattern * This,
            /* [in] */ BSTR pattern);
        
        END_INTERFACE
    } IFilterPatternVtbl;

    interface IFilterPattern
    {
        CONST_VTBL struct IFilterPatternVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IFilterPattern_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 

#define IFilterPattern_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 

#define IFilterPattern_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 


#define IFilterPattern_GetTypeInfoCount(This,pctinfo)	\
    ( (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo) ) 

#define IFilterPattern_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    ( (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo) ) 

#define IFilterPattern_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    ( (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId) ) 

#define IFilterPattern_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    ( (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr) ) 


#define IFilterPattern_get_Filter(This,filter)	\
    ( (This)->lpVtbl -> get_Filter(This,filter) ) 

#define IFilterPattern_put_Filter(This,filter)	\
    ( (This)->lpVtbl -> put_Filter(This,filter) ) 

#define IFilterPattern_get_Match(This,match)	\
    ( (This)->lpVtbl -> get_Match(This,match) ) 

#define IFilterPattern_put_Match(This,match)	\
    ( (This)->lpVtbl -> put_Match(This,match) ) 

#define IFilterPattern_get_Pattern(This,pattern)	\
    ( (This)->lpVtbl -> get_Pattern(This,pattern) ) 

#define IFilterPattern_put_Pattern(This,pattern)	\
    ( (This)->lpVtbl -> put_Pattern(This,pattern) ) 

#endif /* COBJMACROS */


#endif 	/* C style interface */




#endif 	/* __IFilterPattern_INTERFACE_DEFINED__ */


#ifndef __IThreeWayMergeActions_INTERFACE_DEFINED__
#define __IThreeWayMergeActions_INTERFACE_DEFINED__

/* interface IThreeWayMergeActions */
/* [version][uuid][helpstring][unique][dual][object] */ 


EXTERN_C const IID IID_IThreeWayMergeActions;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("7a1b09cb-3966-43d3-8674-352f1ce7a5e0")
    IThreeWayMergeActions : public IDispatch
    {
    public:
        virtual /* [helpstring][propget][id] */ HRESULT STDMETHODCALLTYPE get_Count( 
            /* [retval][out] */ long *pVal) = 0;
        
        virtual /* [helpstring][propget][id] */ HRESULT STDMETHODCALLTYPE get_Item( 
            /* [in] */ long index,
            /* [retval][out] */ IThreeWayMergeAction **pVal) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IThreeWayMergeActionsVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IThreeWayMergeActions * This,
            /* [in] */ REFIID riid,
            /* [annotation][iid_is][out] */ 
            __RPC__deref_out  void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IThreeWayMergeActions * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IThreeWayMergeActions * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            IThreeWayMergeActions * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            IThreeWayMergeActions * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            IThreeWayMergeActions * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [range][in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            IThreeWayMergeActions * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_Count )( 
            IThreeWayMergeActions * This,
            /* [retval][out] */ long *pVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_Item )( 
            IThreeWayMergeActions * This,
            /* [in] */ long index,
            /* [retval][out] */ IThreeWayMergeAction **pVal);
        
        END_INTERFACE
    } IThreeWayMergeActionsVtbl;

    interface IThreeWayMergeActions
    {
        CONST_VTBL struct IThreeWayMergeActionsVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IThreeWayMergeActions_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 

#define IThreeWayMergeActions_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 

#define IThreeWayMergeActions_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 


#define IThreeWayMergeActions_GetTypeInfoCount(This,pctinfo)	\
    ( (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo) ) 

#define IThreeWayMergeActions_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    ( (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo) ) 

#define IThreeWayMergeActions_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    ( (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId) ) 

#define IThreeWayMergeActions_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    ( (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr) ) 


#define IThreeWayMergeActions_get_Count(This,pVal)	\
    ( (This)->lpVtbl -> get_Count(This,pVal) ) 

#define IThreeWayMergeActions_get_Item(This,index,pVal)	\
    ( (This)->lpVtbl -> get_Item(This,index,pVal) ) 

#endif /* COBJMACROS */


#endif 	/* C style interface */




#endif 	/* __IThreeWayMergeActions_INTERFACE_DEFINED__ */


#ifndef __IThreeWayMergeAction_INTERFACE_DEFINED__
#define __IThreeWayMergeAction_INTERFACE_DEFINED__

/* interface IThreeWayMergeAction */
/* [version][uuid][helpstring][unique][dual][object] */ 


EXTERN_C const IID IID_IThreeWayMergeAction;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("dce0e3b2-bdb8-4b7a-b162-0c6874d49eab")
    IThreeWayMergeAction : public IDispatch
    {
    public:
        virtual /* [helpstring][propget][id] */ HRESULT STDMETHODCALLTYPE get_Type( 
            /* [retval][out] */ ThreeWayMergeActionType *pVal) = 0;
        
        virtual /* [helpstring][propget][id] */ HRESULT STDMETHODCALLTYPE get_ConflictLine( 
            /* [in] */ short nFile,
            /* [retval][out] */ long *pVal) = 0;
        
        virtual /* [helpstring][propget][id] */ HRESULT STDMETHODCALLTYPE get_ConflictCount( 
            /* [in] */ short nFile,
            /* [retval][out] */ long *pVal) = 0;
        
        virtual /* [helpstring][propget][id] */ HRESULT STDMETHODCALLTYPE get_MergeSourceFile( 
            /* [retval][out] */ short *pVal) = 0;
        
        virtual /* [helpstring][propget][id] */ HRESULT STDMETHODCALLTYPE get_MergeFromLine( 
            /* [retval][out] */ long *pVal) = 0;
        
        virtual /* [helpstring][propget][id] */ HRESULT STDMETHODCALLTYPE get_MergeFromCount( 
            /* [retval][out] */ long *pVal) = 0;
        
        virtual /* [helpstring][propget][id] */ HRESULT STDMETHODCALLTYPE get_MergeToLine( 
            /* [retval][out] */ long *pVal) = 0;
        
        virtual /* [helpstring][propget][id] */ HRESULT STDMETHODCALLTYPE get_MergeToCount( 
            /* [retval][out] */ long *pVal) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IThreeWayMergeActionVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IThreeWayMergeAction * This,
            /* [in] */ REFIID riid,
            /* [annotation][iid_is][out] */ 
            __RPC__deref_out  void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IThreeWayMergeAction * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IThreeWayMergeAction * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            IThreeWayMergeAction * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            IThreeWayMergeAction * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            IThreeWayMergeAction * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [range][in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            IThreeWayMergeAction * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_Type )( 
            IThreeWayMergeAction * This,
            /* [retval][out] */ ThreeWayMergeActionType *pVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_ConflictLine )( 
            IThreeWayMergeAction * This,
            /* [in] */ short nFile,
            /* [retval][out] */ long *pVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_ConflictCount )( 
            IThreeWayMergeAction * This,
            /* [in] */ short nFile,
            /* [retval][out] */ long *pVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_MergeSourceFile )( 
            IThreeWayMergeAction * This,
            /* [retval][out] */ short *pVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_MergeFromLine )( 
            IThreeWayMergeAction * This,
            /* [retval][out] */ long *pVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_MergeFromCount )( 
            IThreeWayMergeAction * This,
            /* [retval][out] */ long *pVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_MergeToLine )( 
            IThreeWayMergeAction * This,
            /* [retval][out] */ long *pVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_MergeToCount )( 
            IThreeWayMergeAction * This,
            /* [retval][out] */ long *pVal);
        
        END_INTERFACE
    } IThreeWayMergeActionVtbl;

    interface IThreeWayMergeAction
    {
        CONST_VTBL struct IThreeWayMergeActionVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IThreeWayMergeAction_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 

#define IThreeWayMergeAction_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 

#define IThreeWayMergeAction_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 


#define IThreeWayMergeAction_GetTypeInfoCount(This,pctinfo)	\
    ( (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo) ) 

#define IThreeWayMergeAction_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    ( (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo) ) 

#define IThreeWayMergeAction_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    ( (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId) ) 

#define IThreeWayMergeAction_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    ( (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr) ) 


#define IThreeWayMergeAction_get_Type(This,pVal)	\
    ( (This)->lpVtbl -> get_Type(This,pVal) ) 

#define IThreeWayMergeAction_get_ConflictLine(This,nFile,pVal)	\
    ( (This)->lpVtbl -> get_ConflictLine(This,nFile,pVal) ) 

#define IThreeWayMergeAction_get_ConflictCount(This,nFile,pVal)	\
    ( (This)->lpVtbl -> get_ConflictCount(This,nFile,pVal) ) 

#define IThreeWayMergeAction_get_MergeSourceFile(This,pVal)	\
    ( (This)->lpVtbl -> get_MergeSourceFile(This,pVal) ) 

#define IThreeWayMergeAction_get_MergeFromLine(This,pVal)	\
    ( (This)->lpVtbl -> get_MergeFromLine(This,pVal) ) 

#define IThreeWayMergeAction_get_MergeFromCount(This,pVal)	\
    ( (This)->lpVtbl -> get_MergeFromCount(This,pVal) ) 

#define IThreeWayMergeAction_get_MergeToLine(This,pVal)	\
    ( (This)->lpVtbl -> get_MergeToLine(This,pVal) ) 

#define IThreeWayMergeAction_get_MergeToCount(This,pVal)	\
    ( (This)->lpVtbl -> get_MergeToCount(This,pVal) ) 

#endif /* COBJMACROS */


#endif 	/* C style interface */




#endif 	/* __IThreeWayMergeAction_INTERFACE_DEFINED__ */


#ifndef __IFileComparisonEvents_INTERFACE_DEFINED__
#define __IFileComparisonEvents_INTERFACE_DEFINED__

/* interface IFileComparisonEvents */
/* [version][uuid][helpstring][unique][dual][object] */ 


EXTERN_C const IID IID_IFileComparisonEvents;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("1ff464a3-47e4-4d3e-8824-8dd073065fe3")
    IFileComparisonEvents : public IDispatch
    {
    public:
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ComparisonComplete( 
            /* [in] */ FileComparisonError error,
            /* [in] */ FileComparisonResult result) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE Close( void) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE Closed( void) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IFileComparisonEventsVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IFileComparisonEvents * This,
            /* [in] */ REFIID riid,
            /* [annotation][iid_is][out] */ 
            __RPC__deref_out  void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IFileComparisonEvents * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IFileComparisonEvents * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            IFileComparisonEvents * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            IFileComparisonEvents * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            IFileComparisonEvents * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [range][in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            IFileComparisonEvents * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *ComparisonComplete )( 
            IFileComparisonEvents * This,
            /* [in] */ FileComparisonError error,
            /* [in] */ FileComparisonResult result);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *Close )( 
            IFileComparisonEvents * This);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *Closed )( 
            IFileComparisonEvents * This);
        
        END_INTERFACE
    } IFileComparisonEventsVtbl;

    interface IFileComparisonEvents
    {
        CONST_VTBL struct IFileComparisonEventsVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IFileComparisonEvents_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 

#define IFileComparisonEvents_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 

#define IFileComparisonEvents_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 


#define IFileComparisonEvents_GetTypeInfoCount(This,pctinfo)	\
    ( (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo) ) 

#define IFileComparisonEvents_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    ( (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo) ) 

#define IFileComparisonEvents_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    ( (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId) ) 

#define IFileComparisonEvents_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    ( (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr) ) 


#define IFileComparisonEvents_ComparisonComplete(This,error,result)	\
    ( (This)->lpVtbl -> ComparisonComplete(This,error,result) ) 

#define IFileComparisonEvents_Close(This)	\
    ( (This)->lpVtbl -> Close(This) ) 

#define IFileComparisonEvents_Closed(This)	\
    ( (This)->lpVtbl -> Closed(This) ) 

#endif /* COBJMACROS */


#endif 	/* C style interface */




#endif 	/* __IFileComparisonEvents_INTERFACE_DEFINED__ */


#ifndef ___FileComparisonEvents_DISPINTERFACE_DEFINED__
#define ___FileComparisonEvents_DISPINTERFACE_DEFINED__

/* dispinterface _FileComparisonEvents */
/* [version][uuid][helpstring] */ 


EXTERN_C const IID DIID__FileComparisonEvents;

#if defined(__cplusplus) && !defined(CINTERFACE)

    MIDL_INTERFACE("26b11471-27e2-4c82-81dd-4b44f388020f")
    _FileComparisonEvents : public IDispatch
    {
    };
    
#else 	/* C style interface */

    typedef struct _FileComparisonEventsVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            _FileComparisonEvents * This,
            /* [in] */ REFIID riid,
            /* [annotation][iid_is][out] */ 
            __RPC__deref_out  void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            _FileComparisonEvents * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            _FileComparisonEvents * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            _FileComparisonEvents * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            _FileComparisonEvents * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            _FileComparisonEvents * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [range][in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            _FileComparisonEvents * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        END_INTERFACE
    } _FileComparisonEventsVtbl;

    interface _FileComparisonEvents
    {
        CONST_VTBL struct _FileComparisonEventsVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define _FileComparisonEvents_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 

#define _FileComparisonEvents_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 

#define _FileComparisonEvents_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 


#define _FileComparisonEvents_GetTypeInfoCount(This,pctinfo)	\
    ( (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo) ) 

#define _FileComparisonEvents_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    ( (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo) ) 

#define _FileComparisonEvents_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    ( (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId) ) 

#define _FileComparisonEvents_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    ( (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr) ) 

#endif /* COBJMACROS */


#endif 	/* C style interface */


#endif 	/* ___FileComparisonEvents_DISPINTERFACE_DEFINED__ */


#ifndef __IFolderComparisonEvents_INTERFACE_DEFINED__
#define __IFolderComparisonEvents_INTERFACE_DEFINED__

/* interface IFolderComparisonEvents */
/* [version][uuid][helpstring][unique][dual][object] */ 


EXTERN_C const IID IID_IFolderComparisonEvents;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("4e1b7d80-a519-4a1c-84e7-d0d64b5961e5")
    IFolderComparisonEvents : public IDispatch
    {
    public:
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ComparisonComplete( 
            FolderComparisonResult nResult) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE RetestComplete( void) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE Close( void) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE Closed( void) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IFolderComparisonEventsVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IFolderComparisonEvents * This,
            /* [in] */ REFIID riid,
            /* [annotation][iid_is][out] */ 
            __RPC__deref_out  void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IFolderComparisonEvents * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IFolderComparisonEvents * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            IFolderComparisonEvents * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            IFolderComparisonEvents * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            IFolderComparisonEvents * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [range][in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            IFolderComparisonEvents * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *ComparisonComplete )( 
            IFolderComparisonEvents * This,
            FolderComparisonResult nResult);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *RetestComplete )( 
            IFolderComparisonEvents * This);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *Close )( 
            IFolderComparisonEvents * This);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *Closed )( 
            IFolderComparisonEvents * This);
        
        END_INTERFACE
    } IFolderComparisonEventsVtbl;

    interface IFolderComparisonEvents
    {
        CONST_VTBL struct IFolderComparisonEventsVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IFolderComparisonEvents_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 

#define IFolderComparisonEvents_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 

#define IFolderComparisonEvents_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 


#define IFolderComparisonEvents_GetTypeInfoCount(This,pctinfo)	\
    ( (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo) ) 

#define IFolderComparisonEvents_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    ( (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo) ) 

#define IFolderComparisonEvents_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    ( (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId) ) 

#define IFolderComparisonEvents_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    ( (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr) ) 


#define IFolderComparisonEvents_ComparisonComplete(This,nResult)	\
    ( (This)->lpVtbl -> ComparisonComplete(This,nResult) ) 

#define IFolderComparisonEvents_RetestComplete(This)	\
    ( (This)->lpVtbl -> RetestComplete(This) ) 

#define IFolderComparisonEvents_Close(This)	\
    ( (This)->lpVtbl -> Close(This) ) 

#define IFolderComparisonEvents_Closed(This)	\
    ( (This)->lpVtbl -> Closed(This) ) 

#endif /* COBJMACROS */


#endif 	/* C style interface */




#endif 	/* __IFolderComparisonEvents_INTERFACE_DEFINED__ */


#ifndef ___FolderComparisonEvents_DISPINTERFACE_DEFINED__
#define ___FolderComparisonEvents_DISPINTERFACE_DEFINED__

/* dispinterface _FolderComparisonEvents */
/* [version][uuid][helpstring] */ 


EXTERN_C const IID DIID__FolderComparisonEvents;

#if defined(__cplusplus) && !defined(CINTERFACE)

    MIDL_INTERFACE("7be5063c-8e44-45c1-94a4-a3cc48eafc44")
    _FolderComparisonEvents : public IDispatch
    {
    };
    
#else 	/* C style interface */

    typedef struct _FolderComparisonEventsVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            _FolderComparisonEvents * This,
            /* [in] */ REFIID riid,
            /* [annotation][iid_is][out] */ 
            __RPC__deref_out  void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            _FolderComparisonEvents * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            _FolderComparisonEvents * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            _FolderComparisonEvents * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            _FolderComparisonEvents * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            _FolderComparisonEvents * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [range][in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            _FolderComparisonEvents * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        END_INTERFACE
    } _FolderComparisonEventsVtbl;

    interface _FolderComparisonEvents
    {
        CONST_VTBL struct _FolderComparisonEventsVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define _FolderComparisonEvents_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 

#define _FolderComparisonEvents_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 

#define _FolderComparisonEvents_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 


#define _FolderComparisonEvents_GetTypeInfoCount(This,pctinfo)	\
    ( (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo) ) 

#define _FolderComparisonEvents_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    ( (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo) ) 

#define _FolderComparisonEvents_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    ( (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId) ) 

#define _FolderComparisonEvents_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    ( (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr) ) 

#endif /* COBJMACROS */


#endif 	/* C style interface */


#endif 	/* ___FolderComparisonEvents_DISPINTERFACE_DEFINED__ */


#ifndef __IFolderComparison_INTERFACE_DEFINED__
#define __IFolderComparison_INTERFACE_DEFINED__

/* interface IFolderComparison */
/* [version][uuid][helpstring][unique][dual][object] */ 


EXTERN_C const IID IID_IFolderComparison;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("d1908618-baf7-4f84-85f7-fb21e9dea594")
    IFolderComparison : public IComparison
    {
    public:
        virtual /* [helpstring][propget][id] */ HRESULT STDMETHODCALLTYPE get_NumberOfEntries( 
            /* [retval][out] */ long *pVal) = 0;
        
        virtual /* [helpstring][propget][id] */ HRESULT STDMETHODCALLTYPE get_NumberOfSelectedItems( 
            /* [retval][out] */ long *pVal) = 0;
        
        virtual /* [helpstring][propget][id] */ HRESULT STDMETHODCALLTYPE get_Busy( 
            /* [retval][out] */ VARIANT_BOOL *pVal) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE SelectChanged( void) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE SelectAll( void) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE Stop( void) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE CompareSelected( void) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE DeselectAll( void) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE RetestSelected( void) = 0;
        
        virtual /* [helpstring][propget][id] */ HRESULT STDMETHODCALLTYPE get_FileName( 
            /* [in] */ long nIndex,
            /* [in] */ short nFolder,
            /* [retval][out] */ BSTR *pVal) = 0;
        
        virtual /* [helpstring][propget][id] */ HRESULT STDMETHODCALLTYPE get_FilePath( 
            /* [in] */ long nIndex,
            /* [in] */ short nFolder,
            /* [retval][out] */ BSTR *pVal) = 0;
        
        virtual /* [helpstring][propget][id] */ HRESULT STDMETHODCALLTYPE get_FullFilePath( 
            /* [in] */ long nIndex,
            /* [in] */ short nFolder,
            /* [retval][out] */ BSTR *pVal) = 0;
        
        virtual /* [helpstring][propget][id] */ HRESULT STDMETHODCALLTYPE get_FileType( 
            /* [in] */ long nIndex,
            /* [retval][out] */ FolderFileType *pVal) = 0;
        
        virtual /* [helpstring][propget][id] */ HRESULT STDMETHODCALLTYPE get_Folder( 
            /* [in] */ short nFolder,
            /* [retval][out] */ BSTR *pVal) = 0;
        
        virtual /* [helpstring][propput][id] */ HRESULT STDMETHODCALLTYPE put_Folder( 
            /* [in] */ short nFolder,
            /* [in] */ BSTR newVal) = 0;
        
        virtual /* [helpstring][propget][id] */ HRESULT STDMETHODCALLTYPE get_Selected( 
            /* [in] */ long nIndex,
            /* [retval][out] */ VARIANT_BOOL *pVal) = 0;
        
        virtual /* [helpstring][propput][id] */ HRESULT STDMETHODCALLTYPE put_Selected( 
            /* [in] */ long nIndex,
            /* [in] */ VARIANT_BOOL newVal) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE HideEmptyFolders( void) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ThreeWayMerge( 
            BSTR reportOutputFile,
            /* [retval][out] */ long *pVal) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IFolderComparisonVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IFolderComparison * This,
            /* [in] */ REFIID riid,
            /* [annotation][iid_is][out] */ 
            __RPC__deref_out  void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IFolderComparison * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IFolderComparison * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            IFolderComparison * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            IFolderComparison * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            IFolderComparison * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [range][in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            IFolderComparison * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_Active )( 
            IFolderComparison * This,
            /* [retval][out] */ VARIANT_BOOL *pVal);
        
        /* [helpstring][propput][id] */ HRESULT ( STDMETHODCALLTYPE *put_Active )( 
            IFolderComparison * This,
            /* [in] */ VARIANT_BOOL newVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_Visible )( 
            IFolderComparison * This,
            /* [retval][out] */ VARIANT_BOOL *pVal);
        
        /* [helpstring][propput][id] */ HRESULT ( STDMETHODCALLTYPE *put_Visible )( 
            IFolderComparison * This,
            /* [in] */ VARIANT_BOOL newVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_Minimized )( 
            IFolderComparison * This,
            /* [retval][out] */ VARIANT_BOOL *pVal);
        
        /* [helpstring][propput][id] */ HRESULT ( STDMETHODCALLTYPE *put_Minimized )( 
            IFolderComparison * This,
            /* [in] */ VARIANT_BOOL newVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_Maximized )( 
            IFolderComparison * This,
            /* [retval][out] */ VARIANT_BOOL *pVal);
        
        /* [helpstring][propput][id] */ HRESULT ( STDMETHODCALLTYPE *put_Maximized )( 
            IFolderComparison * This,
            /* [in] */ VARIANT_BOOL newVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_Left )( 
            IFolderComparison * This,
            /* [retval][out] */ long *pVal);
        
        /* [helpstring][propput][id] */ HRESULT ( STDMETHODCALLTYPE *put_Left )( 
            IFolderComparison * This,
            /* [in] */ long newVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_Top )( 
            IFolderComparison * This,
            /* [retval][out] */ long *pVal);
        
        /* [helpstring][propput][id] */ HRESULT ( STDMETHODCALLTYPE *put_Top )( 
            IFolderComparison * This,
            /* [in] */ long newVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_Width )( 
            IFolderComparison * This,
            /* [retval][out] */ long *pVal);
        
        /* [helpstring][propput][id] */ HRESULT ( STDMETHODCALLTYPE *put_Width )( 
            IFolderComparison * This,
            /* [in] */ long newVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_Height )( 
            IFolderComparison * This,
            /* [retval][out] */ long *pVal);
        
        /* [helpstring][propput][id] */ HRESULT ( STDMETHODCALLTYPE *put_Height )( 
            IFolderComparison * This,
            /* [in] */ long newVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *Restore )( 
            IFolderComparison * This);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *Close )( 
            IFolderComparison * This);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *GiveUserControl )( 
            IFolderComparison * This);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_ViewType )( 
            IFolderComparison * This,
            /* [retval][out] */ FileViewType *pVal);
        
        /* [helpstring][propput][id] */ HRESULT ( STDMETHODCALLTYPE *put_ViewType )( 
            IFolderComparison * This,
            /* [in] */ FileViewType newVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *Compare )( 
            IFolderComparison * This,
            /* [in] */ VARIANT strFirstFile,
            /* [in] */ VARIANT strSecondFile,
            /* [optional][in] */ VARIANT strThirdFile);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *Refresh )( 
            IFolderComparison * This);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *SaveComparison )( 
            IFolderComparison * This,
            /* [in] */ BSTR filename);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *SetPanelTitles )( 
            IFolderComparison * This,
            /* [in] */ VARIANT strFirst,
            /* [in] */ VARIANT strSecond,
            /* [optional][in] */ VARIANT strThird);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *Print )( 
            IFolderComparison * This,
            /* [defaultvalue][in] */ VARIANT_BOOL bShowPrinterDialog,
            /* [defaultvalue][in] */ PageOrientation nOrientation);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *Report )( 
            IFolderComparison * This,
            /* [in] */ BSTR bstrReporter,
            /* [in] */ LineEndingStyle nLineEndingStyle,
            /* [in] */ BSTR strOutputFile);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *Report2 )( 
            IFolderComparison * This,
            /* [in] */ BSTR bstrReporter,
            /* [in] */ LineEndingStyle nLineEndingStyle,
            /* [in] */ VARIANT vtEncoding,
            /* [in] */ BSTR strOutputFile);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_NumberOfEntries )( 
            IFolderComparison * This,
            /* [retval][out] */ long *pVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_NumberOfSelectedItems )( 
            IFolderComparison * This,
            /* [retval][out] */ long *pVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_Busy )( 
            IFolderComparison * This,
            /* [retval][out] */ VARIANT_BOOL *pVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *SelectChanged )( 
            IFolderComparison * This);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *SelectAll )( 
            IFolderComparison * This);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *Stop )( 
            IFolderComparison * This);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *CompareSelected )( 
            IFolderComparison * This);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *DeselectAll )( 
            IFolderComparison * This);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *RetestSelected )( 
            IFolderComparison * This);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_FileName )( 
            IFolderComparison * This,
            /* [in] */ long nIndex,
            /* [in] */ short nFolder,
            /* [retval][out] */ BSTR *pVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_FilePath )( 
            IFolderComparison * This,
            /* [in] */ long nIndex,
            /* [in] */ short nFolder,
            /* [retval][out] */ BSTR *pVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_FullFilePath )( 
            IFolderComparison * This,
            /* [in] */ long nIndex,
            /* [in] */ short nFolder,
            /* [retval][out] */ BSTR *pVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_FileType )( 
            IFolderComparison * This,
            /* [in] */ long nIndex,
            /* [retval][out] */ FolderFileType *pVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_Folder )( 
            IFolderComparison * This,
            /* [in] */ short nFolder,
            /* [retval][out] */ BSTR *pVal);
        
        /* [helpstring][propput][id] */ HRESULT ( STDMETHODCALLTYPE *put_Folder )( 
            IFolderComparison * This,
            /* [in] */ short nFolder,
            /* [in] */ BSTR newVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_Selected )( 
            IFolderComparison * This,
            /* [in] */ long nIndex,
            /* [retval][out] */ VARIANT_BOOL *pVal);
        
        /* [helpstring][propput][id] */ HRESULT ( STDMETHODCALLTYPE *put_Selected )( 
            IFolderComparison * This,
            /* [in] */ long nIndex,
            /* [in] */ VARIANT_BOOL newVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *HideEmptyFolders )( 
            IFolderComparison * This);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *ThreeWayMerge )( 
            IFolderComparison * This,
            BSTR reportOutputFile,
            /* [retval][out] */ long *pVal);
        
        END_INTERFACE
    } IFolderComparisonVtbl;

    interface IFolderComparison
    {
        CONST_VTBL struct IFolderComparisonVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IFolderComparison_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 

#define IFolderComparison_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 

#define IFolderComparison_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 


#define IFolderComparison_GetTypeInfoCount(This,pctinfo)	\
    ( (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo) ) 

#define IFolderComparison_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    ( (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo) ) 

#define IFolderComparison_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    ( (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId) ) 

#define IFolderComparison_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    ( (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr) ) 


#define IFolderComparison_get_Active(This,pVal)	\
    ( (This)->lpVtbl -> get_Active(This,pVal) ) 

#define IFolderComparison_put_Active(This,newVal)	\
    ( (This)->lpVtbl -> put_Active(This,newVal) ) 

#define IFolderComparison_get_Visible(This,pVal)	\
    ( (This)->lpVtbl -> get_Visible(This,pVal) ) 

#define IFolderComparison_put_Visible(This,newVal)	\
    ( (This)->lpVtbl -> put_Visible(This,newVal) ) 

#define IFolderComparison_get_Minimized(This,pVal)	\
    ( (This)->lpVtbl -> get_Minimized(This,pVal) ) 

#define IFolderComparison_put_Minimized(This,newVal)	\
    ( (This)->lpVtbl -> put_Minimized(This,newVal) ) 

#define IFolderComparison_get_Maximized(This,pVal)	\
    ( (This)->lpVtbl -> get_Maximized(This,pVal) ) 

#define IFolderComparison_put_Maximized(This,newVal)	\
    ( (This)->lpVtbl -> put_Maximized(This,newVal) ) 

#define IFolderComparison_get_Left(This,pVal)	\
    ( (This)->lpVtbl -> get_Left(This,pVal) ) 

#define IFolderComparison_put_Left(This,newVal)	\
    ( (This)->lpVtbl -> put_Left(This,newVal) ) 

#define IFolderComparison_get_Top(This,pVal)	\
    ( (This)->lpVtbl -> get_Top(This,pVal) ) 

#define IFolderComparison_put_Top(This,newVal)	\
    ( (This)->lpVtbl -> put_Top(This,newVal) ) 

#define IFolderComparison_get_Width(This,pVal)	\
    ( (This)->lpVtbl -> get_Width(This,pVal) ) 

#define IFolderComparison_put_Width(This,newVal)	\
    ( (This)->lpVtbl -> put_Width(This,newVal) ) 

#define IFolderComparison_get_Height(This,pVal)	\
    ( (This)->lpVtbl -> get_Height(This,pVal) ) 

#define IFolderComparison_put_Height(This,newVal)	\
    ( (This)->lpVtbl -> put_Height(This,newVal) ) 

#define IFolderComparison_Restore(This)	\
    ( (This)->lpVtbl -> Restore(This) ) 

#define IFolderComparison_Close(This)	\
    ( (This)->lpVtbl -> Close(This) ) 

#define IFolderComparison_GiveUserControl(This)	\
    ( (This)->lpVtbl -> GiveUserControl(This) ) 


#define IFolderComparison_get_ViewType(This,pVal)	\
    ( (This)->lpVtbl -> get_ViewType(This,pVal) ) 

#define IFolderComparison_put_ViewType(This,newVal)	\
    ( (This)->lpVtbl -> put_ViewType(This,newVal) ) 

#define IFolderComparison_Compare(This,strFirstFile,strSecondFile,strThirdFile)	\
    ( (This)->lpVtbl -> Compare(This,strFirstFile,strSecondFile,strThirdFile) ) 

#define IFolderComparison_Refresh(This)	\
    ( (This)->lpVtbl -> Refresh(This) ) 

#define IFolderComparison_SaveComparison(This,filename)	\
    ( (This)->lpVtbl -> SaveComparison(This,filename) ) 

#define IFolderComparison_SetPanelTitles(This,strFirst,strSecond,strThird)	\
    ( (This)->lpVtbl -> SetPanelTitles(This,strFirst,strSecond,strThird) ) 

#define IFolderComparison_Print(This,bShowPrinterDialog,nOrientation)	\
    ( (This)->lpVtbl -> Print(This,bShowPrinterDialog,nOrientation) ) 

#define IFolderComparison_Report(This,bstrReporter,nLineEndingStyle,strOutputFile)	\
    ( (This)->lpVtbl -> Report(This,bstrReporter,nLineEndingStyle,strOutputFile) ) 

#define IFolderComparison_Report2(This,bstrReporter,nLineEndingStyle,vtEncoding,strOutputFile)	\
    ( (This)->lpVtbl -> Report2(This,bstrReporter,nLineEndingStyle,vtEncoding,strOutputFile) ) 


#define IFolderComparison_get_NumberOfEntries(This,pVal)	\
    ( (This)->lpVtbl -> get_NumberOfEntries(This,pVal) ) 

#define IFolderComparison_get_NumberOfSelectedItems(This,pVal)	\
    ( (This)->lpVtbl -> get_NumberOfSelectedItems(This,pVal) ) 

#define IFolderComparison_get_Busy(This,pVal)	\
    ( (This)->lpVtbl -> get_Busy(This,pVal) ) 

#define IFolderComparison_SelectChanged(This)	\
    ( (This)->lpVtbl -> SelectChanged(This) ) 

#define IFolderComparison_SelectAll(This)	\
    ( (This)->lpVtbl -> SelectAll(This) ) 

#define IFolderComparison_Stop(This)	\
    ( (This)->lpVtbl -> Stop(This) ) 

#define IFolderComparison_CompareSelected(This)	\
    ( (This)->lpVtbl -> CompareSelected(This) ) 

#define IFolderComparison_DeselectAll(This)	\
    ( (This)->lpVtbl -> DeselectAll(This) ) 

#define IFolderComparison_RetestSelected(This)	\
    ( (This)->lpVtbl -> RetestSelected(This) ) 

#define IFolderComparison_get_FileName(This,nIndex,nFolder,pVal)	\
    ( (This)->lpVtbl -> get_FileName(This,nIndex,nFolder,pVal) ) 

#define IFolderComparison_get_FilePath(This,nIndex,nFolder,pVal)	\
    ( (This)->lpVtbl -> get_FilePath(This,nIndex,nFolder,pVal) ) 

#define IFolderComparison_get_FullFilePath(This,nIndex,nFolder,pVal)	\
    ( (This)->lpVtbl -> get_FullFilePath(This,nIndex,nFolder,pVal) ) 

#define IFolderComparison_get_FileType(This,nIndex,pVal)	\
    ( (This)->lpVtbl -> get_FileType(This,nIndex,pVal) ) 

#define IFolderComparison_get_Folder(This,nFolder,pVal)	\
    ( (This)->lpVtbl -> get_Folder(This,nFolder,pVal) ) 

#define IFolderComparison_put_Folder(This,nFolder,newVal)	\
    ( (This)->lpVtbl -> put_Folder(This,nFolder,newVal) ) 

#define IFolderComparison_get_Selected(This,nIndex,pVal)	\
    ( (This)->lpVtbl -> get_Selected(This,nIndex,pVal) ) 

#define IFolderComparison_put_Selected(This,nIndex,newVal)	\
    ( (This)->lpVtbl -> put_Selected(This,nIndex,newVal) ) 

#define IFolderComparison_HideEmptyFolders(This)	\
    ( (This)->lpVtbl -> HideEmptyFolders(This) ) 

#define IFolderComparison_ThreeWayMerge(This,reportOutputFile,pVal)	\
    ( (This)->lpVtbl -> ThreeWayMerge(This,reportOutputFile,pVal) ) 

#endif /* COBJMACROS */


#endif 	/* C style interface */




#endif 	/* __IFolderComparison_INTERFACE_DEFINED__ */


#ifndef __IEncoding_INTERFACE_DEFINED__
#define __IEncoding_INTERFACE_DEFINED__

/* interface IEncoding */
/* [version][uuid][helpstring][unique][dual][object] */ 


EXTERN_C const IID IID_IEncoding;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("d9740de6-3e7d-4db8-bc53-308c84df5486")
    IEncoding : public IDispatch
    {
    public:
        virtual /* [helpstring][propget][id] */ HRESULT STDMETHODCALLTYPE get_Name( 
            /* [retval][out] */ BSTR *pVal) = 0;
        
        virtual /* [helpstring][propget][id] */ HRESULT STDMETHODCALLTYPE get_Codepage( 
            /* [retval][out] */ long *pVal) = 0;
        
        virtual /* [helpstring][propget][id] */ HRESULT STDMETHODCALLTYPE get_LittleEndian( 
            /* [retval][out] */ VARIANT_BOOL *pVal) = 0;
        
        virtual /* [helpstring][propget][id] */ HRESULT STDMETHODCALLTYPE get_UsesByteOrderMarker( 
            /* [retval][out] */ VARIANT_BOOL *pVal) = 0;
        
        virtual /* [helpstring][propget][id] */ HRESULT STDMETHODCALLTYPE get_PersistentName( 
            /* [retval][out] */ BSTR *pVal) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IEncodingVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IEncoding * This,
            /* [in] */ REFIID riid,
            /* [annotation][iid_is][out] */ 
            __RPC__deref_out  void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IEncoding * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IEncoding * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            IEncoding * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            IEncoding * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            IEncoding * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [range][in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            IEncoding * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_Name )( 
            IEncoding * This,
            /* [retval][out] */ BSTR *pVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_Codepage )( 
            IEncoding * This,
            /* [retval][out] */ long *pVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_LittleEndian )( 
            IEncoding * This,
            /* [retval][out] */ VARIANT_BOOL *pVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_UsesByteOrderMarker )( 
            IEncoding * This,
            /* [retval][out] */ VARIANT_BOOL *pVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_PersistentName )( 
            IEncoding * This,
            /* [retval][out] */ BSTR *pVal);
        
        END_INTERFACE
    } IEncodingVtbl;

    interface IEncoding
    {
        CONST_VTBL struct IEncodingVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IEncoding_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 

#define IEncoding_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 

#define IEncoding_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 


#define IEncoding_GetTypeInfoCount(This,pctinfo)	\
    ( (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo) ) 

#define IEncoding_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    ( (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo) ) 

#define IEncoding_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    ( (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId) ) 

#define IEncoding_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    ( (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr) ) 


#define IEncoding_get_Name(This,pVal)	\
    ( (This)->lpVtbl -> get_Name(This,pVal) ) 

#define IEncoding_get_Codepage(This,pVal)	\
    ( (This)->lpVtbl -> get_Codepage(This,pVal) ) 

#define IEncoding_get_LittleEndian(This,pVal)	\
    ( (This)->lpVtbl -> get_LittleEndian(This,pVal) ) 

#define IEncoding_get_UsesByteOrderMarker(This,pVal)	\
    ( (This)->lpVtbl -> get_UsesByteOrderMarker(This,pVal) ) 

#define IEncoding_get_PersistentName(This,pVal)	\
    ( (This)->lpVtbl -> get_PersistentName(This,pVal) ) 

#endif /* COBJMACROS */


#endif 	/* C style interface */




#endif 	/* __IEncoding_INTERFACE_DEFINED__ */


#ifndef __IEncodings_INTERFACE_DEFINED__
#define __IEncodings_INTERFACE_DEFINED__

/* interface IEncodings */
/* [version][uuid][helpstring][unique][dual][object] */ 


EXTERN_C const IID IID_IEncodings;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("9e01c777-c540-4c32-a5dd-19efcf8d8d94")
    IEncodings : public IDispatch
    {
    public:
        virtual /* [helpstring][propget][id] */ HRESULT STDMETHODCALLTYPE get_Count( 
            /* [retval][out] */ long *pVal) = 0;
        
        virtual /* [helpstring][propget][id] */ HRESULT STDMETHODCALLTYPE get_Item( 
            /* [in] */ long index,
            /* [retval][out] */ IEncoding **pVal) = 0;
        
        virtual /* [helpstring][propget][id] */ HRESULT STDMETHODCALLTYPE get_Default( 
            /* [retval][out] */ IEncoding **pVal) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE CreateUTF8Encoding( 
            /* [in] */ VARIANT_BOOL usesByteOrderMarker,
            /* [retval][out] */ IEncoding **pVal) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE CreateUCS2Encoding( 
            /* [in] */ VARIANT_BOOL usesByteOrderMarker,
            /* [in] */ VARIANT_BOOL littleEndian,
            /* [retval][out] */ IEncoding **pVal) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE CreateEncoding( 
            /* [in] */ long codepage,
            /* [in] */ VARIANT_BOOL usesByteOrderMarker,
            /* [retval][out] */ IEncoding **pVal) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IEncodingsVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IEncodings * This,
            /* [in] */ REFIID riid,
            /* [annotation][iid_is][out] */ 
            __RPC__deref_out  void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IEncodings * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IEncodings * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            IEncodings * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            IEncodings * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            IEncodings * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [range][in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            IEncodings * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_Count )( 
            IEncodings * This,
            /* [retval][out] */ long *pVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_Item )( 
            IEncodings * This,
            /* [in] */ long index,
            /* [retval][out] */ IEncoding **pVal);
        
        /* [helpstring][propget][id] */ HRESULT ( STDMETHODCALLTYPE *get_Default )( 
            IEncodings * This,
            /* [retval][out] */ IEncoding **pVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *CreateUTF8Encoding )( 
            IEncodings * This,
            /* [in] */ VARIANT_BOOL usesByteOrderMarker,
            /* [retval][out] */ IEncoding **pVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *CreateUCS2Encoding )( 
            IEncodings * This,
            /* [in] */ VARIANT_BOOL usesByteOrderMarker,
            /* [in] */ VARIANT_BOOL littleEndian,
            /* [retval][out] */ IEncoding **pVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *CreateEncoding )( 
            IEncodings * This,
            /* [in] */ long codepage,
            /* [in] */ VARIANT_BOOL usesByteOrderMarker,
            /* [retval][out] */ IEncoding **pVal);
        
        END_INTERFACE
    } IEncodingsVtbl;

    interface IEncodings
    {
        CONST_VTBL struct IEncodingsVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IEncodings_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 

#define IEncodings_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 

#define IEncodings_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 


#define IEncodings_GetTypeInfoCount(This,pctinfo)	\
    ( (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo) ) 

#define IEncodings_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    ( (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo) ) 

#define IEncodings_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    ( (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId) ) 

#define IEncodings_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    ( (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr) ) 


#define IEncodings_get_Count(This,pVal)	\
    ( (This)->lpVtbl -> get_Count(This,pVal) ) 

#define IEncodings_get_Item(This,index,pVal)	\
    ( (This)->lpVtbl -> get_Item(This,index,pVal) ) 

#define IEncodings_get_Default(This,pVal)	\
    ( (This)->lpVtbl -> get_Default(This,pVal) ) 

#define IEncodings_CreateUTF8Encoding(This,usesByteOrderMarker,pVal)	\
    ( (This)->lpVtbl -> CreateUTF8Encoding(This,usesByteOrderMarker,pVal) ) 

#define IEncodings_CreateUCS2Encoding(This,usesByteOrderMarker,littleEndian,pVal)	\
    ( (This)->lpVtbl -> CreateUCS2Encoding(This,usesByteOrderMarker,littleEndian,pVal) ) 

#define IEncodings_CreateEncoding(This,codepage,usesByteOrderMarker,pVal)	\
    ( (This)->lpVtbl -> CreateEncoding(This,codepage,usesByteOrderMarker,pVal) ) 

#endif /* COBJMACROS */


#endif 	/* C style interface */




#endif 	/* __IEncodings_INTERFACE_DEFINED__ */


EXTERN_C const CLSID CLSID_TextComparison;

#ifdef __cplusplus

class DECLSPEC_UUID("ee2a7d38-0d03-452d-a451-2bb7a8c86398")
TextComparison;
#endif

EXTERN_C const CLSID CLSID_BinaryComparison;

#ifdef __cplusplus

class DECLSPEC_UUID("e2a123d7-b19d-4a4f-a0c5-b60cd431f274")
BinaryComparison;
#endif

EXTERN_C const CLSID CLSID_ImageComparison;

#ifdef __cplusplus

class DECLSPEC_UUID("409ce168-57c6-41f1-84eb-8ef371feb65e")
ImageComparison;
#endif

EXTERN_C const CLSID CLSID_FolderComparison;

#ifdef __cplusplus

class DECLSPEC_UUID("edf5e275-97ed-461e-bfd8-ff920e7ad4bd")
FolderComparison;
#endif

EXTERN_C const CLSID CLSID_Preferences;

#ifdef __cplusplus

class DECLSPEC_UUID("8aa527b3-e535-4daa-b32d-201c807a010f")
Preferences;
#endif

EXTERN_C const CLSID CLSID_Filters;

#ifdef __cplusplus

class DECLSPEC_UUID("5b44d5f2-22d1-4abb-9fd0-b2fd7131447b")
Filters;
#endif

EXTERN_C const CLSID CLSID_ThreeWayMergeActions;

#ifdef __cplusplus

class DECLSPEC_UUID("c0ed72cc-8930-4acd-b43b-62b1e6b24d7e")
ThreeWayMergeActions;
#endif

EXTERN_C const CLSID CLSID_ThreeWayMergeAction;

#ifdef __cplusplus

class DECLSPEC_UUID("66251a01-471b-4568-8b03-9580ce08edde")
ThreeWayMergeAction;
#endif

EXTERN_C const CLSID CLSID_Filter;

#ifdef __cplusplus

class DECLSPEC_UUID("f0818c87-edf1-40a2-aedf-a962c8a0c4e9")
Filter;
#endif

EXTERN_C const CLSID CLSID_FilterPattern;

#ifdef __cplusplus

class DECLSPEC_UUID("a9e9f1ad-a64f-49a4-a17f-d247f8f49e27")
FilterPattern;
#endif

EXTERN_C const CLSID CLSID_Application;

#ifdef __cplusplus

class DECLSPEC_UUID("5b30ff06-4854-418b-a388-334190776310")
Application;
#endif

EXTERN_C const CLSID CLSID_StringPreferences;

#ifdef __cplusplus

class DECLSPEC_UUID("9b0acab7-085c-4a0d-ab08-aacaa42ef8b4")
StringPreferences;
#endif

EXTERN_C const CLSID CLSID_LongPreferences;

#ifdef __cplusplus

class DECLSPEC_UUID("0a13e0e7-bd00-4068-9ab8-68387fe8c4b0")
LongPreferences;
#endif

EXTERN_C const CLSID CLSID_DoublePreferences;

#ifdef __cplusplus

class DECLSPEC_UUID("bb6ba4df-e8b1-4a20-af0e-85635358bcfe")
DoublePreferences;
#endif

EXTERN_C const CLSID CLSID_Encoding;

#ifdef __cplusplus

class DECLSPEC_UUID("0a7e42be-9dd5-4398-9205-8b9ab123ae46")
Encoding;
#endif

EXTERN_C const CLSID CLSID_Encodings;

#ifdef __cplusplus

class DECLSPEC_UUID("a18ad595-44ec-4b9e-b404-3a21c3c4df15")
Encodings;
#endif
#endif /* __Merge70_LIBRARY_DEFINED__ */

/* Additional Prototypes for ALL interfaces */

/* end of Additional Prototypes */

#ifdef __cplusplus
}
#endif

#endif



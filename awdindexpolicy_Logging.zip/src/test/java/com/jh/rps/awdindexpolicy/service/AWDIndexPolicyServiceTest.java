package com.jh.rps.awdindexpolicy.service;

import com.jh.rps.awdindexpolicy.model.PolicyData;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.junit4.SpringRunner;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;

@RunWith(SpringRunner.class)
public class AWDIndexPolicyServiceTest {

    private AWDIndexPolicyService policyService = new AWDIndexPolicyService();

    private PolicyData policyData = new PolicyData();

    /**
     * @Before
     * Method will be called before each test case execution
     */
    @Before
    public void setUp() {
        policyData.setAgentBrokerDealerId("121");
        policyData.setAgentBrokerDealerName("Asd");
        policyData.setAgentCustomBrokerCode(true);
        policyData.setAgentFirstName("ANBC");
        policyData.setAgentLastName("LASTNAME");
    }

    @Test
    public void getAWDIndexPolicyTest() throws Exception{
        List<PolicyData> expPolicyDataList = policyService.getAWDIndexPolicy("1234");
        //Test Size
        assertThat(expPolicyDataList.size(), is(1));
        assertThat(expPolicyDataList.get(0).getAgentBrokerDealerId(), is(policyData.getAgentBrokerDealerId()));
        assertThat(expPolicyDataList.get(0).getAgentBrokerDealerName(), is(policyData.getAgentBrokerDealerName()));
        assertThat(expPolicyDataList.get(0).isAgentCustomBrokerCode(), is(policyData.isAgentCustomBrokerCode()));
        assertThat(expPolicyDataList.get(0).getAgentFirstName(), is(policyData.getAgentFirstName()));
        assertThat(expPolicyDataList.get(0).getAgentLastName(), is(policyData.getAgentLastName()));
    }

    @Test(expected = SQLException.class)
    public void databaseNotReadyExceptionTest() throws Exception {
        policyService.getAWDIndexPolicy("2222");
    }

    @Test(expected = IOException.class)
    public void ioExceptionTest() throws Exception {
        policyService.getAWDIndexPolicy("3333");
    }

    @After
    public void teardown(){
        policyData = new PolicyData();
    }
}

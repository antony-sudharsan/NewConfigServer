package com.jh.rps.awdindexpolicy.utils;

import org.slf4j.Logger;
import org.springframework.stereotype.Component;

@Component
public class LogUtil {
    public LogUtil() {}

    /**
     *
     * @param logger
     * @param methodName
     * @param logMsg
     */
    public static void debug(Logger logger, String methodName, String logMsg)
    {
        if (logger.isDebugEnabled()) {
            logger.debug(frameLogMessage(logger.getName(),methodName,logMsg));
        }
    }

    /**
     *
     * @param logger
     * @param methodName
     * @param logMsg
     */
    public static void warn(Logger logger, String methodName, String logMsg)
    {
        if (logger.isDebugEnabled()) {
            logger.warn(frameLogMessage(logger.getName(),methodName,logMsg));
        }
    }

    /**
     *
     * @param logger
     * @param methodName
     * @param logMsg
     */
    public static void trace(Logger logger, String methodName, String logMsg)
    {
        if (logger.isDebugEnabled()) {
            logger.trace(frameLogMessage(logger.getName(),methodName,logMsg));
        }
    }

    /**
     *
     * @param logger
     * @param methodName
     * @param logMsg
     */
    public static void info(Logger logger, String methodName, String logMsg)
    {
        if (logger.isDebugEnabled()) {
            logger.info(frameLogMessage(logger.getName(),methodName,logMsg));
        }
    }

    /**
     *
     * @param logger
     * @param methodName
     * @param logMsg
     */
    public static void error(Logger logger, String methodName, String logMsg)
    {
            logger.error(frameLogMessage(logger.getName(),methodName,logMsg));
    }



    public static void error(Logger logger, String methodName, String logMsg, Throwable exception)
    {
        logger.error(frameLogMessage(logger.getName(),methodName,logMsg), exception);
    }


    /**
     *
     * @param className
     * @param methodName
     * @param msg
     * @return
     */
    private static String frameLogMessage(String className, String methodName, String msg){
        StringBuffer localStringBuffer = new StringBuffer();
        localStringBuffer.append(className);
        localStringBuffer.append(".");
        localStringBuffer.append(methodName);
        localStringBuffer.append("() - ");
        localStringBuffer.append(msg);
        return localStringBuffer.toString();
    }
}

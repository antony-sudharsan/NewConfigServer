package com.jh.rps.awdindexpolicy.service;

/**
 *  Copyright (c) 2018, John Hancock and/or its affiliates. All rights reserved.
 *  DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 *  Please contact John Hancock, 200 Berkley, Boston, MA 02116 USA
 *  or visit https://www.johnhancock.com/legal.html if you need additional information or have any
 *  questions.
 */


import com.jh.rps.awdindexpolicy.model.PolicyData;
import com.jh.rps.awdindexpolicy.utils.LogUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.StoredProcedureQuery;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * This class consists exclusively methods to expose the methods as RestFull webservices
 *
 *
 * @author      Antony Sudharsan Gnanaraj
 * @version     %I%, %G%
 * @since       1.0
 */
@Service
public class AWDIndexPolicyService {

    @PersistenceContext
    EntityManager entityManager;
    StoredProcedureQuery awdIndexPolicyProcedure;

    @Autowired
    private LogUtil log;

    private static final Logger logger = LoggerFactory.getLogger(AWDIndexPolicyService.class);

    public List<PolicyData> getAWDIndexPolicy(String policyNo) throws Exception {
        //logger.info("Precessed Policy Number "+policyNo +" Inside the awdIndexPolicyService get AWD Index Policy function");
        log.debug(logger,"getAWDIndexPolicy","Entering the function with policyNo - "+policyNo);
        //This block is just a reference to throw different exceptions TO BE IMPLEMENTED as required
        if (policyNo.equalsIgnoreCase("2222")) {
            throw new SQLException("Database is not available yet to process the PolicyNo=" + policyNo);
        } else if (policyNo.equalsIgnoreCase("3333")) {
            throw new IOException("IOException, PolicyNo=" + policyNo);
        }else {
//        awdIndexPolicyProcedure = entityManager.createStoredProcedureQuery("GET_POLICY_DATA");
//        List<PolicyData> policyDataList = ((List<PolicyData>) awdIndexPolicyProcedure.getResultList());
            log.debug(logger,"getAWDIndexPolicy","Leaving the function with policy details for policyNo - "+policyNo);
            return populateDummyData();
        }
    }

    /**
     * Dummy method to populate the Test Data
     *
     * @return
     */
    private List<PolicyData> populateDummyData() {
        log.debug(logger,"populateDummyData","Entering the function");
        List<PolicyData> policyDataList = new ArrayList<PolicyData>();

        PolicyData policyData = new PolicyData();
        policyData.setAgentBrokerDealerId("121");
        policyData.setAgentBrokerDealerName("Asd");
        policyData.setAgentCustomBrokerCode(true);
        policyData.setAgentFirstName("ANBC");
        policyData.setAgentLastName("LASTNAME");

        policyDataList.add(policyData);
        log.debug(logger,"populateDummyData","Leaving the function");
        return policyDataList;
    }
}

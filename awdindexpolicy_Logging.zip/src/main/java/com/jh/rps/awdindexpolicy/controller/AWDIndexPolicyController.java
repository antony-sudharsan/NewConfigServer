package com.jh.rps.awdindexpolicy.controller;

/**
 *  Copyright (c) 2018, John Hancock and/or its affiliates. All rights reserved.
 *  DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 *  Please contact John Hancock, 200 Berkley, Boston, MA 02116 USA
 *  or visit https://www.johnhancock.com/legal.html if you need additional information or have any
 *  questions.
 */

import com.jh.rps.awdindexpolicy.exception.PolicyNotFoundException;
import com.jh.rps.awdindexpolicy.model.PolicyData;
import com.jh.rps.awdindexpolicy.service.AWDIndexPolicyService;
import com.jh.rps.awdindexpolicy.utils.LogUtil;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

import java.util.List;

/**
 * This class consists exclusively methods to expose the methods as RestFull webservices
 *
 *
 * @author      Antony Sudharsan Gnanaraj
 * @version     %I%, %G%
 * @since       1.0
 */
@RestController
@EnableSwagger2
public class AWDIndexPolicyController {

    @Autowired
    private AWDIndexPolicyService awdIndexPolicyService;



    private Logger logger = LoggerFactory.getLogger(AWDIndexPolicyController.class);
    //http://localhost:8080/jh/wealth/ann/awdindex/policy?policyNo=1234

    @ApiOperation(
            value = "Get AWD Index Policy Details",
            notes = "Service is designed to retrieve required policy information",
            response = PolicyData.class)
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Successfully retrieved list"),
            @ApiResponse(code = 401, message = "You are not authorized to view the resource"),
            @ApiResponse(code = 403, message = "Accessing the resource you were trying to reach is forbidden"),
            @ApiResponse(code = 404, message = "The resource you were trying to reach is not found")
    })
    @RequestMapping(value = "/jh/wealth/ann/awdindex/policy", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
    public ResponseEntity<List<PolicyData>> getAWDIndexPolicy(@RequestParam String policyNo) throws Exception {
        LogUtil.debug(logger,"getAWDIndexPolicy","Entering with policyNo - "+policyNo);
        HttpHeaders responseHeaders = new HttpHeaders();
        if (policyNo.equalsIgnoreCase("1111")) {
            LogUtil.error(logger,"getAWDIndexPolicy","No policy details found for policyNo - "+policyNo);
            throw new PolicyNotFoundException(policyNo);
        }   else {
            // responseHeaders.set("","");
            // return new ResponseEntity<>(awdIndexPolicyService.getAWDIndexPolicy(policyNo), responseHeaders, HttpStatus.OK);
            LogUtil.debug(logger,"getAWDIndexPolicy","Found policy details for policyNo - "+policyNo);
            return ResponseEntity.ok().headers(responseHeaders).body(awdIndexPolicyService.getAWDIndexPolicy(policyNo));

        }
    }


}

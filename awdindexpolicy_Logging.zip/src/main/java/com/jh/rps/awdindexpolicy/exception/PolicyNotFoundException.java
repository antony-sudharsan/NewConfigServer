package com.jh.rps.awdindexpolicy.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

/**
 *  To define the HTTP code that will be sent by our application when this type of exception
 */
@ResponseStatus(value= HttpStatus.NOT_FOUND) //404
public class PolicyNotFoundException extends Exception {

    public PolicyNotFoundException(final String policyNo) {
        super("No Policy found with Policy number: " + policyNo);
    }
}

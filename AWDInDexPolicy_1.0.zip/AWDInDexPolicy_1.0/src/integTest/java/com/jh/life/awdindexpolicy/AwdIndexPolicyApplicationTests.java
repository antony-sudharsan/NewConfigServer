package com.jh.life.awdindexpolicy;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.skyscreamer.jsonassert.JSONAssert;
import org.springframework.boot.context.embedded.LocalServerPort;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.jh.life.Application;
import com.jh.life.awdindexpolicy.model.AWDIndexPolicyDataResponse;


/**
* Launch the entire Spring Boot Application on a Random Port
*/
@RunWith(SpringRunner.class)
@SpringBootTest(classes = Application.class,webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class AwdIndexPolicyApplicationTests {

   /**
    * Autowire the random port into the variable so that we can use it create the url
    */
   @LocalServerPort
   private int port;

   TestRestTemplate restTemplate = new TestRestTemplate();


   HttpHeaders headers = new HttpHeaders();

   @Test
   public void testGetAWDPolicyForGivenPolicyNo() throws Exception {
      //To have the flexibility of adding in request headers
      HttpEntity<String> entity = new HttpEntity<String>(null, headers);

      //Perform a GET request to the specify uri and get the response as a JSON String.
      ResponseEntity<String> response = restTemplate.exchange(
            createURLWithPort("/jh/wealth/ann/awdindex/policy?policyNo=16003"),
            HttpMethod.GET, entity, String.class);

      AWDIndexPolicyDataResponse testData = new AWDIndexPolicyDataResponse();
      testData.setCompanyCode("FNA");
      testData.setLob("NQI");
      testData.setAgentFirstName("Claman");
      testData.setAgentLastName("Perine");
      testData.setAnnuitantFirstName("Phanthavongsa");
      testData.setAnnuitantLastName("Kheitmeyer");
      

      String expected = "[{\"lob\":null,\"fixedVarCode\":null,\"reInstrtyInd\":null,\"ownerCompanyIndivCode\":null,\"ownerFirstName\":null,\"ownerLastName\":null,\"ownerCompanyname\":null,\"ownerSSN\":null,\"annuitantFirstName\":null,\"annuitantLastName\":null,\"annuitantSSN\":null,\"brokerCount\":null,\"agentId\":null,\"agentBrokerDealerId\":\"121\",\"agentBrokerDealerName\":\"ASG\",\"agentCustomBrokerCode\":true,\"agentFirstName\":\"Antony\",\"agentLastName\":\"Sudharsan\",\"agentTaxId\":null,\"agentPhoneNo\":null,\"repAgentid\":null,\"repBrokerDealerId\":null,\"repBrokerdealerName\":null,\"repCustombrokerCode\":false,\"repAgentFirstName\":null,\"repAgentLastName\":null,\"repAgentTaxId\":null,\"repAgentPhoneNo\":null}]";

      //Assert that the response contains expected fields.
      JSONAssert.assertEquals(expected, response.getBody().toString(), false);
   }


   private String createURLWithPort(String uri) {
      return "http://localhost:" + port + uri;
   }

   private String getJSON(Object obj) throws JsonProcessingException {
      ObjectMapper mapper = new ObjectMapper();
      System.out.print("The value of the ");
      return mapper.writeValueAsString(obj);
   }
}


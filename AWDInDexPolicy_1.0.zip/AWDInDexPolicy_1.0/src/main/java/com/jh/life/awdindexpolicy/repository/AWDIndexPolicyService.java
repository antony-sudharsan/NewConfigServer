package com.jh.life.awdindexpolicy.repository;


import com.jh.life.awdindexpolicy.loggingexception.InvalidRequestException;
import com.jh.life.awdindexpolicy.loggingexception.NotFoundException;
import com.jh.life.awdindexpolicy.loggingexception.RequestTimeoutException;
import com.jh.life.awdindexpolicy.mapper.AWDIndexPolicyDataMapper;
import org.springframework.beans.factory.annotation.Value;

/**
 *  Copyright (c) 2018, John Hancock and/or its affiliates. All rights reserved.
 *  DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 *  Please contact John Hancock, 200 Berkley, Boston, MA 02116 USA
 *  or visit https://www.johnhancock.com/legal.html if you need additional information or have any
 *  questions.
 */


import com.jh.life.awdindexpolicy.model.AWDIndexPolicyDataResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import javax.persistence.EntityManager;
import javax.persistence.ParameterMode;
import javax.persistence.PersistenceContext;
import javax.persistence.StoredProcedureQuery;
import java.util.ArrayList;
import java.util.List;

/**
 * This class consists exclusively methods to expose the methods as RestFull webservices
 *
 *
 * @author      Antony Sudharsan Gnanaraj
 * @version     %I%, %G%
 * @since       1.0
 */
@Service
public class AWDIndexPolicyService {

    @PersistenceContext
    EntityManager entityManager;
    StoredProcedureQuery awdIndexPolicyProcedure;
    
	@Autowired
	private JdbcTemplate jdbctemplate;
	@Value("${RequestTimeoutLimit}")
	private  long RequestTimeoutLimit;
	
    public  List<AWDIndexPolicyDataResponse> getAWDIndexPolicy(String policyNo) throws Exception{
    
	long start_time = System.currentTimeMillis();	
  
	List<AWDIndexPolicyDataResponse> policyDataResponse = (List<AWDIndexPolicyDataResponse>) jdbctemplate.query("{call uspGetConsolidatedPolicyData(?)}",
			new Object[] { policyNo }, new AWDIndexPolicyDataMapper());

	System.out.println("policyDataResponse.toString() " + policyDataResponse.toString());
	
	long end_time = System.currentTimeMillis();
	long difference = end_time-start_time;
	if ((difference/1000)>RequestTimeoutLimit)
		throw new RequestTimeoutException("SQL Server back end timed out");
	return policyDataResponse;
    }

    /**
     * Dummy method to populate the Test Data
     *
     * @return
     */
    private List<AWDIndexPolicyDataResponse> populateDummyData() {
        List<AWDIndexPolicyDataResponse> policyDataList = new ArrayList<AWDIndexPolicyDataResponse>();

        AWDIndexPolicyDataResponse policyData = new AWDIndexPolicyDataResponse();
        policyData.setAgentBrokerDealerId("121");
        policyData.setAgentBrokerDealerName("Asd");
        policyData.setAgentCustomBrokerCode(true);
        policyData.setAgentFirstName("ANBC");
        policyData.setAgentLastName("LASTNAME");

        policyDataList.add(policyData);
        return policyDataList;
    }
}

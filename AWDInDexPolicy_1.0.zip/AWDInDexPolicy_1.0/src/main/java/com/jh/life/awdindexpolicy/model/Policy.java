package com.jh.life.awdindexpolicy.model;

/**
 *  Copyright (c) 2018, John Hancock and/or its affiliates. All rights reserved.
 *  DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 *  Please contact John Hancock, 200 Berkley, Boston, MA 02116 USA
 *  or visit https://www.johnhancock.com/legal.html if you need additional information or have any
 *  questions.
 */


import javax.validation.constraints.Size;

/**
 * This class consists exclusively methods to expose the methods as RestFull webservices
 *
 *
 * @author      Antony Sudharsan Gnanaraj
 * @version     %I%, %G%
 * @since       1.0
 */

public class Policy {

    @Size(min=2, message="Policy Number should have atleast 2 characters")
    private String policyNo;

    public String getPolicyNo() {
        return policyNo;
    }

    public void setPolicyNo(String policyNo) {
        this.policyNo = policyNo;
    }
}

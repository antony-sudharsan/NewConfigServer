package com.jh.life;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import com.jh.common.logging.LoggerHandler;

@Component
public class LogInitializer {
	
	
	@Autowired
	private Environment env;
	@PostConstruct
	public void LoggerInstance()
	{
		try 
		{
			//LoggerHandler.getInstance();
			//LoggerHandler.getInstance(env.getProperty("log.appID"), "GlobalAuth1", "GlobalAuth2", "GlobalAuth3");
			LoggerHandler.getInstance(env.getProperty("log.appID"), env.getProperty("log.svcName"), env.getProperty("log.componentName"), env.getProperty("log.svcVersion"));
		} catch(Exception e)
		{
			System.out.println("Error in Log Initialization in LifeUserAuth service" + e.getStackTrace());;
		}
	
	}

}


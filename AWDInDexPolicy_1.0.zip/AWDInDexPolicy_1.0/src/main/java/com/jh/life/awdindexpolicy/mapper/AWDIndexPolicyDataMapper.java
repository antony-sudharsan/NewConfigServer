package com.jh.life.awdindexpolicy.mapper;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;
import com.jh.life.awdindexpolicy.model.AWDIndexPolicyDataResponse;

/**
 * @author chaudha
 *
 */
public class AWDIndexPolicyDataMapper implements RowMapper {

	@Override
	public Object mapRow(ResultSet rsPolicyData, int rowNum) throws SQLException {
		AWDIndexPolicyDataResponse awdIndexPolicyDataResponse = new AWDIndexPolicyDataResponse();
		
		awdIndexPolicyDataResponse.setLob(rsPolicyData.getString("lob"));
		awdIndexPolicyDataResponse.setCompanyCode(rsPolicyData.getString("company_code"));
		awdIndexPolicyDataResponse.setFixedVarCode(rsPolicyData.getString("FixedVarInd"));
		awdIndexPolicyDataResponse.setOwnerCompanyIndivCode(rsPolicyData.getString("OwnerCompanyIndividualCode"));
		awdIndexPolicyDataResponse.setOwnerCompanyname(rsPolicyData.getString("OwnerCompanyName"));
		awdIndexPolicyDataResponse.setOwnerLastName(rsPolicyData.getString("OwnerLastName"));
		awdIndexPolicyDataResponse.setOwnerFirstName(rsPolicyData.getString("OwnerFirstName"));
		awdIndexPolicyDataResponse.setOwnerSSN(rsPolicyData.getString("OwnerSSN"));
		awdIndexPolicyDataResponse.setAnnuitantFirstName(rsPolicyData.getString("AnnuitantFirstName"));
		awdIndexPolicyDataResponse.setAnnuitantLastName(rsPolicyData.getString("AnnuitantLastName"));
		awdIndexPolicyDataResponse.setAnnuitantSSN(rsPolicyData.getString("AnnuitantSSN"));
		awdIndexPolicyDataResponse.setCustomBrokerInd(rsPolicyData.getBoolean("CustomBroker"));
		//awdIndexPolicyDataResponse.setcust
		awdIndexPolicyDataResponse.setAgentId(rsPolicyData.getString("agent_id"));
		awdIndexPolicyDataResponse.setRepBrokerDealerId(rsPolicyData.getString("broker_dealer_id"));
		awdIndexPolicyDataResponse.setBrokerCount(rsPolicyData.getString("number_of_brokers"));
		awdIndexPolicyDataResponse.setAgentBrokerDealerName(rsPolicyData.getString("broker_dealer_name"));
		awdIndexPolicyDataResponse.setAgentTaxId(rsPolicyData.getString("AgentTaxNumber"));
		awdIndexPolicyDataResponse.setAgentFirstName(rsPolicyData.getString("AgentFirstName"));
		awdIndexPolicyDataResponse.setAgentLastName(rsPolicyData.getString("AgentLastName"));
		awdIndexPolicyDataResponse.setAgentPhoneNo(rsPolicyData.getString("AgentPhoneNumber"));
		awdIndexPolicyDataResponse.setRepAgentid(rsPolicyData.getString("rep_agent_id"));
		awdIndexPolicyDataResponse.setRepBrokerDealerId(rsPolicyData.getString("rep_broker_dealer_id"));
		awdIndexPolicyDataResponse.setRepBrokerdealerName(rsPolicyData.getString("rep_broker_dealer_name"));
		awdIndexPolicyDataResponse.setRepCustombrokerCode(rsPolicyData.getBoolean("rep_CustomBroker"));
		awdIndexPolicyDataResponse.setRepAgentTaxId(rsPolicyData.getString("rep_AgentTaxNumber"));
		awdIndexPolicyDataResponse.setRepAgentFirstName(rsPolicyData.getString("rep_AgentFirstName"));
		awdIndexPolicyDataResponse.setRepAgentLastName(rsPolicyData.getString("rep_AgentLastName"));
		awdIndexPolicyDataResponse.setRepAgentPhoneNo(rsPolicyData.getString("rep_AgentPhoneNumber"));
		return awdIndexPolicyDataResponse;
	}

}


package com.jh.life.awdindexpolicy.loggingexception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;


@ResponseStatus(HttpStatus.NOT_FOUND)
public class RequestTimeoutException extends RuntimeException {
	public RequestTimeoutException(String message) {
		super(message);
	}
}



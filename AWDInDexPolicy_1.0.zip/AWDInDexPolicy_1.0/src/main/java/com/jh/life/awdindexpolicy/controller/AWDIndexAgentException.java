package com.jh.life.awdindexpolicy.controller;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.request.WebRequest;

import com.jh.life.awdindexpolicy.loggingexception.*;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;



@ControllerAdvice
public class AWDIndexAgentException extends ResponseEntityExceptionHandler{
	
	
	/*@ExceptionHandler(Exception.class)
	public final ResponseEntity<Object> handleAllExceptions(Exception ex, WebRequest request) {
		ExceptionResponse exceptionResponse = new ExceptionResponse("500", ex.getMessage(),
				request.getDescription(false));
		return new ResponseEntity(exceptionResponse, HttpStatus.INTERNAL_SERVER_ERROR);
		
	}*/
	
	@ExceptionHandler(NoContentException.class)
	 @ResponseStatus(HttpStatus.NO_CONTENT)
	public final ResponseEntity<Object> handleAllExceptions(Exception ex, WebRequest request) {
		ExceptionResponse exceptionResponse = new ExceptionResponse("204", "No Content Found",
				ex.getMessage());
		return new ResponseEntity(exceptionResponse, HttpStatus.NO_CONTENT);
		
	}
	
	//408
	@ExceptionHandler(RequestTimeoutException.class)
	public final ResponseEntity<ExceptionResponse>  handleException(RequestTimeoutException ex, WebRequest request) {

		ExceptionResponse exceptionResponse = new ExceptionResponse("408", "SQL Server back end timed out" ,ex.getMessage());		
		return new ResponseEntity(exceptionResponse, HttpStatus.REQUEST_TIMEOUT);
	}

	@ExceptionHandler(NotFoundException.class)
	 @ResponseStatus(HttpStatus.NOT_FOUND)
	@ResponseBody
	public final ResponseEntity<Object> handleNotFoundException(NotFoundException ex, WebRequest request) {
		ExceptionResponse exceptionResponse = new ExceptionResponse("404", "No Data Found For Policy No",
				ex.getMessage());
		return new ResponseEntity(exceptionResponse, HttpStatus.NOT_FOUND);
	}
	
	@ExceptionHandler(InvalidRequestException.class)
	 @ResponseStatus(HttpStatus.BAD_REQUEST)
	@ResponseBody
	public final ResponseEntity<Object> handleNotFoundException(InvalidRequestException ex, WebRequest request) {
		ExceptionResponse exceptionResponse = new ExceptionResponse("400", "Invalid Request Policy Not Valid or Less than 2 characters",
				ex.getMessage());
		return new ResponseEntity(exceptionResponse, HttpStatus.BAD_REQUEST);
	}
	
	//500
		@ExceptionHandler(SQLServerErrorException.class)
		public final ResponseEntity<Object>  handleException(SQLServerErrorException ex, WebRequest request) {

			ExceptionResponse exceptionResponse = new ExceptionResponse("500", ex.getMessage(),ex.getDetails());		
			return new ResponseEntity(exceptionResponse, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	
	@Override
	protected ResponseEntity<Object> handleMethodArgumentNotValid(MethodArgumentNotValidException ex,
			HttpHeaders headers, HttpStatus status, WebRequest request) {
		ExceptionResponse exceptionResponse = new ExceptionResponse("400", "Validation Failed",
				ex.getBindingResult().toString());
		return new ResponseEntity(exceptionResponse, HttpStatus.BAD_REQUEST);
	}	
	
	
	
}


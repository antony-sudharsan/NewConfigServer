package com.jh.life.awdindexpolicy.controller;

/**
 *  Copyright (c) 2018, John Hancock and/or its affiliates. All rights reserved.
 *  DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 *  Please contact John Hancock, 200 Berkley, Boston, MA 02116 USA
 *  or visit https://www.johnhancock.com/legal.html if you need additional information or have any
 *  questions.
 */

import com.jh.life.awdindexpolicy.model.Policy;
import com.jh.life.awdindexpolicy.loggingexception.InvalidRequestException;
import com.jh.life.awdindexpolicy.loggingexception.NotFoundException;
import com.jh.life.awdindexpolicy.model.AWDIndexPolicyDataResponse;
import com.jh.life.awdindexpolicy.repository.AWDIndexPolicyService;
import com.jh.life.awdindexpolicy.validation.AWDIndexPolicyValidation;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

import javax.validation.Valid;
import java.util.ArrayList;
import java.util.List;

/**
 * This class consists exclusively methods to expose the methods as RestFull webservices
 *
 *
 * @author      Antony Sudharsan Gnanaraj
 * @version     %I%, %G%
 * @since       1.0
 */

@RestController
@EnableSwagger2
public class AWDIndexPolicyController {

    @Autowired
    private AWDIndexPolicyService awdIndexPolicyService;

   /* @Autowired
    private AWDIndexPolicyValidation awdIndexPolicyValidation;*/

      
    @ApiOperation(
    		httpMethod="GET",
            value = "Get AWD Index Policy Details",
            notes = "Service is designed to retrieve required policy information",
            response = AWDIndexPolicyDataResponse.class)
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Successfully retrieved list"),
            @ApiResponse(code = 401, message = "You are not authorized to view the resource"),
            @ApiResponse(code = 403, message = "Accessing the resource you were trying to reach is forbidden"),
            @ApiResponse(code = 404, message = "The resource you were trying to reach is not found")
    })
    @RequestMapping(path = "/jh/wealth/ann/awdindex/policy", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<AWDIndexPolicyDataResponse>> getAWDIndexPolicy(@RequestHeader("MessageUUID") String transactionId,
			@RequestHeader("SourceSystemName") String sourceSystemName, @RequestParam(name = "policyNo") String policyNo)  throws Exception{

        System.out.println("Inside the Get AWD Index Policy>>");

        // validate the policy No
        if(policyNo.length()<=2) {
        //return ResponseEntity.notFound().build();
           throw new InvalidRequestException("Please provide valid Data=  " + policyNo);
        }
        List<AWDIndexPolicyDataResponse> policyDataResponse=awdIndexPolicyService.getAWDIndexPolicy(policyNo);
        System.out.println("policyDataResponse.toString().length() " + policyDataResponse.toString().length());
        
        if (policyDataResponse.toString().length()==2)
    	{
    		System.out.println("No data");
        	throw new NotFoundException("No data found for Policy No=  " + policyNo);
    	}
        
        

        HttpHeaders responseHeaders = new HttpHeaders();
       
        return ResponseEntity.ok().headers(responseHeaders).body( policyDataResponse);
    }


  /*  @ApiOperation(
            value = "Test to showcase the validation",
            notes = "Test End Point to showcase the validation",
            response = AWDIndexPolicyDataResponse.class)
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Successfully retrieved list"),
            @ApiResponse(code = 401, message = "You are not authorized to view the resource"),
            @ApiResponse(code = 403, message = "Accessing the resource you were trying to reach is forbidden"),
            @ApiResponse(code = 404, message = "The resource you were trying to reach is not found")
    })

    @RequestMapping(value = "/jh/wealth/ann/awdindex/policy/create", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<AWDIndexPolicyDataResponse>> insertPolicy(@Valid @RequestBody Policy policy){

        System.out.println("Inside the Get AWD Index Policy");

        List<AWDIndexPolicyDataResponse> policyDataList = new ArrayList<AWDIndexPolicyDataResponse>();
        HttpHeaders responseHeaders = new HttpHeaders();
        // responseHeaders.set("","");
        // return new ResponseEntity<>(awdIndexPolicyService.getAWDIndexPolicy(policyNo), responseHeaders, HttpStatus.OK);
        return ResponseEntity.ok().headers(responseHeaders).body(policyDataList);
    }*/
}

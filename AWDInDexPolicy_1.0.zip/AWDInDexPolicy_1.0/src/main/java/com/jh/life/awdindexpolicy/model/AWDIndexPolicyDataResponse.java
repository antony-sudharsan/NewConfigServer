package com.jh.life.awdindexpolicy.model;

import javax.persistence.Column;

/**
 *  Copyright (c) 2018, John Hancock and/or its affiliates. All rights reserved.
 *  DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 *  Please contact John Hancock, 200 Berkley, Boston, MA 02116 USA
 *  or visit https://www.johnhancock.com/legal.html if you need additional information or have any
 *  questions.
 */


import io.swagger.annotations.ApiModelProperty;

/**
 * This class consists exclusively methods to expose the methods as RestFull webservices
 *
 *
 * @author      Abhishek Chaudhuri
 * @version     %I%, %G%
 * @since       1.0
 */
public class AWDIndexPolicyDataResponse {

    
	 @ApiModelProperty(notes = "Company Code",required=true)
	   
	 private String companyCode;
	
	@ApiModelProperty(notes = "Line of Business",required=true)
    @Column(name = "lob")
    private String lob;
    
    @ApiModelProperty(notes = "Fixed Variable Code")
    private String fixedVarCode;
    @ApiModelProperty(notes = "ReIndustry Indicator")
    private String reInstrtyInd;
    @ApiModelProperty(notes = "Owner Company Individual Code")
    private String ownerCompanyIndivCode;
    @ApiModelProperty(notes = "Owner First Name",required=true)
    private String ownerFirstName;
    @ApiModelProperty(notes = "Owner Last Name",required=true)
    private String ownerLastName;
    @ApiModelProperty(notes = "Owner Company Name",required=true)
    private String ownerCompanyname;
    @ApiModelProperty(notes = "Owner SSN,required=true")
    private String ownerSSN;
    @ApiModelProperty(notes = "First name of Annuitant",required=true)
    private String annuitantFirstName;
    @Override
	public String toString() {
		return "AWDIndexPolicyDataResponse [companyCode=" + companyCode + ", lob=" + lob + ", fixedVarCode=" + fixedVarCode + ", reInstrtyInd=" + reInstrtyInd
				+ ", ownerCompanyIndivCode=" + ownerCompanyIndivCode + ", ownerFirstName=" + ownerFirstName + ", ownerLastName=" + ownerLastName
				+ ", ownerCompanyname=" + ownerCompanyname + ", ownerSSN=" + ownerSSN + ", annuitantFirstName=" + annuitantFirstName + ", annuitantLastName="
				+ annuitantLastName + ", annuitantSSN=" + annuitantSSN + ", brokerCount=" + brokerCount + ", agentId=" + agentId + ", agentBrokerDealerId="
				+ agentBrokerDealerId + ", agentBrokerDealerName=" + agentBrokerDealerName + ", agentCustomBrokerCode=" + agentCustomBrokerCode
				+ ", agentFirstName=" + agentFirstName + ", agentLastName=" + agentLastName + ", agentTaxId=" + agentTaxId + ", agentPhoneNo=" + agentPhoneNo
				+ ", repAgentid=" + repAgentid + ", repBrokerDealerId=" + repBrokerDealerId + ", repBrokerdealerName=" + repBrokerdealerName
				+ ", repCustombrokerCode=" + repCustombrokerCode + ", repAgentFirstName=" + repAgentFirstName + ", repAgentLastName=" + repAgentLastName
				+ ", repAgentTaxId=" + repAgentTaxId + ", repAgentPhoneNo=" + repAgentPhoneNo + "]";
	}

	public String getCompanyCode() {
		return companyCode;
	}

	public void setCompanyCode(String companyCode) {
		this.companyCode = companyCode;
	}
	@ApiModelProperty(notes = "Last name of Annuitant",required=true)
	private String annuitantLastName;
	@ApiModelProperty(notes = "SSN of Annuitant",required=true)
    private String annuitantSSN;
	@ApiModelProperty(notes = "Number of brokers")
    private String brokerCount;
	@ApiModelProperty(notes = "Agent Id")
    private String agentId;
	@ApiModelProperty(notes = "Agent Broker Dealer Id")
    private String agentBrokerDealerId;
	@ApiModelProperty(notes = "Agent Broker Dealer Name")
    private String agentBrokerDealerName;
	@ApiModelProperty(notes = "Agent Custom Broker Code")
    private boolean agentCustomBrokerCode;
	@ApiModelProperty(notes = "Agent Custom Broker Indicator")
    private boolean customBrokerInd;
    public boolean isCustomBrokerInd() {
		return customBrokerInd;
	}

	public void setCustomBrokerInd(boolean customBrokerInd) {
		this.customBrokerInd = customBrokerInd;
	}
	@ApiModelProperty(notes = "First name of agent")
	private String agentFirstName;
	@ApiModelProperty(notes = "Last name of agent")
    private String agentLastName;
	@ApiModelProperty(notes = "Tax ID of agent")
    private String agentTaxId;
	@ApiModelProperty(notes = "Phone number of agent")
    private String agentPhoneNo;
	@ApiModelProperty(notes = "REP Agent Id")
    private String repAgentid;
	@ApiModelProperty(notes = "REP Broker Dealer Id")
    private String repBrokerDealerId;
	@ApiModelProperty(notes = "REP Broker Dealer Name")
    private String repBrokerdealerName;
	@ApiModelProperty(notes = "REP Custom Broker Code")
    private boolean repCustombrokerCode;
	@ApiModelProperty(notes = "REP Agent First Name")
    private String repAgentFirstName;
	@ApiModelProperty(notes = "REP Agent Last Name")
    private String repAgentLastName;
	@ApiModelProperty(notes = "REP Agent TAX ID")
    private String repAgentTaxId;
	@ApiModelProperty(notes = "REP Agent Phone No")
    private String repAgentPhoneNo;
	@ApiModelProperty(notes = "REP Custom broker Ind")
    private boolean repCustombrokerInd;
    public String getLob() {
        return lob;
    }

    public void setLob(String lob) {
        this.lob = lob;
    }

    public String getFixedVarCode() {
        return fixedVarCode;
    }

    public void setFixedVarCode(String fixedVarCode) {
        this.fixedVarCode = fixedVarCode;
    }

    public String getReInstrtyInd() {
        return reInstrtyInd;
    }

    public void setReInstrtyInd(String reInstrtyInd) {
        this.reInstrtyInd = reInstrtyInd;
    }

    public String getOwnerCompanyIndivCode() {
        return ownerCompanyIndivCode;
    }

    public void setOwnerCompanyIndivCode(String ownerCompanyIndivCode) {
        this.ownerCompanyIndivCode = ownerCompanyIndivCode;
    }

    public String getOwnerFirstName() {
        return ownerFirstName;
    }

    public void setOwnerFirstName(String ownerFirstName) {
        this.ownerFirstName = ownerFirstName;
    }

    public String getOwnerLastName() {
        return ownerLastName;
    }

    public void setOwnerLastName(String ownerLastName) {
        this.ownerLastName = ownerLastName;
    }

    public String getOwnerCompanyname() {
        return ownerCompanyname;
    }

    public void setOwnerCompanyname(String ownerCompanyname) {
        this.ownerCompanyname = ownerCompanyname;
    }

    public String getOwnerSSN() {
        return ownerSSN;
    }

    public void setOwnerSSN(String ownerSSN) {
        this.ownerSSN = ownerSSN;
    }

    public String getAnnuitantFirstName() {
        return annuitantFirstName;
    }

    public void setAnnuitantFirstName(String annuitantFirstName) {
        this.annuitantFirstName = annuitantFirstName;
    }

    public String getAnnuitantLastName() {
        return annuitantLastName;
    }

    public void setAnnuitantLastName(String annuitantLastName) {
        this.annuitantLastName = annuitantLastName;
    }

    public String getAnnuitantSSN() {
        return annuitantSSN;
    }

    public void setAnnuitantSSN(String annuitantSSN) {
        this.annuitantSSN = annuitantSSN;
    }

    public String getBrokerCount() {
        return brokerCount;
    }

    public void setBrokerCount(String brokerCount) {
        this.brokerCount = brokerCount;
    }

    public String getAgentId() {
        return agentId;
    }

    public void setAgentId(String agentId) {
        this.agentId = agentId;
    }

    public String getAgentBrokerDealerId() {
        return agentBrokerDealerId;
    }

    public void setAgentBrokerDealerId(String agentBrokerDealerId) {
        this.agentBrokerDealerId = agentBrokerDealerId;
    }

    public String getAgentBrokerDealerName() {
        return agentBrokerDealerName;
    }

    public void setAgentBrokerDealerName(String agentBrokerDealerName) {
        this.agentBrokerDealerName = agentBrokerDealerName;
    }

    public boolean isAgentCustomBrokerCode() {
        return agentCustomBrokerCode;
    }

    public void setAgentCustomBrokerCode(boolean agentCustomBrokerCode) {
        this.agentCustomBrokerCode = agentCustomBrokerCode;
    }

    public String getAgentFirstName() {
        return agentFirstName;
    }

    public void setAgentFirstName(String agentFirstName) {
        this.agentFirstName = agentFirstName;
    }

    public String getAgentLastName() {
        return agentLastName;
    }

    public void setAgentLastName(String agentLastName) {
        this.agentLastName = agentLastName;
    }

    public String getAgentTaxId() {
        return agentTaxId;
    }

    public void setAgentTaxId(String agentTaxId) {
        this.agentTaxId = agentTaxId;
    }

    public String getAgentPhoneNo() {
        return agentPhoneNo;
    }

    public void setAgentPhoneNo(String agentPhoneNo) {
        this.agentPhoneNo = agentPhoneNo;
    }

    public String getRepAgentid() {
        return repAgentid;
    }

    public void setRepAgentid(String repAgentid) {
        this.repAgentid = repAgentid;
    }

    public String getRepBrokerDealerId() {
        return repBrokerDealerId;
    }

    public void setRepBrokerDealerId(String repBrokerDealerId) {
        this.repBrokerDealerId = repBrokerDealerId;
    }

    public String getRepBrokerdealerName() {
        return repBrokerdealerName;
    }

    public void setRepBrokerdealerName(String repBrokerdealerName) {
        this.repBrokerdealerName = repBrokerdealerName;
    }

    public boolean isRepCustombrokerCode() {
        return repCustombrokerCode;
    }

    public void setRepCustombrokerCode(boolean repCustombrokerCode) {
        this.repCustombrokerCode = repCustombrokerCode;
    }

    public String getRepAgentFirstName() {
        return repAgentFirstName;
    }

    public void setRepAgentFirstName(String repAgentFirstName) {
        this.repAgentFirstName = repAgentFirstName;
    }

    public String getRepAgentLastName() {
        return repAgentLastName;
    }

    public void setRepAgentLastName(String repAgentLastName) {
        this.repAgentLastName = repAgentLastName;
    }

    public String getRepAgentTaxId() {
        return repAgentTaxId;
    }

    public void setRepAgentTaxId(String repAgentTaxId) {
        this.repAgentTaxId = repAgentTaxId;
    }

    public String getRepAgentPhoneNo() {
        return repAgentPhoneNo;
    }

    public void setRepAgentPhoneNo(String repAgentPhoneNo) {
        this.repAgentPhoneNo = repAgentPhoneNo;
    }
}

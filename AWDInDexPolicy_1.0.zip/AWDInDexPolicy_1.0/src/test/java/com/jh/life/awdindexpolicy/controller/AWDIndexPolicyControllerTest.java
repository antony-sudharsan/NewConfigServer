package com.jh.life.awdindexpolicy.controller;

import static org.hamcrest.CoreMatchers.is;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;

import com.jh.life.awdindexpolicy.model.AWDIndexPolicyDataResponse;
import com.jh.life.awdindexpolicy.repository.AWDIndexPolicyService;

@RunWith(SpringRunner.class)
/**
 * @WebMvcTest.
 * It will auto-configure the Spring MVC infrastructure for our unit tests.
 * Setting up WebMvc Context for the Controller which is under test("AnnuityController")
 */
@WebMvcTest(AWDIndexPolicyController.class)
public class AWDIndexPolicyControllerTest {

    /**
     * Initializing MockMvc
     */
    @Autowired
    private MockMvc mvc;

    /**
     * @MockBean
     * The class is included in the spring-boot-test library.
     * It allows to add Mockito mocks in a Spring ApplicationContext.
     * If a bean, compatible with the declared class exists in the context, it replaces it by the mock.
     * If it is not the case, it adds the mock in the context as a bean.
     */
    @MockBean
    private AWDIndexPolicyService awdIndexPolicyService;

    private AWDIndexPolicyDataResponse  awdIndexPolicyDataResponse=  new AWDIndexPolicyDataResponse();
    
    private List<AWDIndexPolicyDataResponse> policyAntonyDataList = new ArrayList<AWDIndexPolicyDataResponse>();
    
   /* @MockBean
    private AnnuityValidator annuityValidator;
    /**
     * @Before
     * Method will be called before each test case execution
     */
    
	@Before
    public void setup() throws Exception{
		awdIndexPolicyDataResponse = new AWDIndexPolicyDataResponse();
		awdIndexPolicyDataResponse.setCompanyCode("FNA");
		awdIndexPolicyDataResponse.setLob("NQI");
		awdIndexPolicyDataResponse.setFixedVarCode("V");
		awdIndexPolicyDataResponse.setOwnerCompanyIndivCode("I");
		awdIndexPolicyDataResponse.setOwnerFirstName("Phanthavongsa");
		awdIndexPolicyDataResponse.setOwnerLastName("Kheitmeyer");
		awdIndexPolicyDataResponse.setAnnuitantFirstName("Phanthavongsa");
		awdIndexPolicyDataResponse.setAnnuitantLastName("Kheitmeyer");
		awdIndexPolicyDataResponse.setBrokerCount("1");
		awdIndexPolicyDataResponse.setAgentFirstName("Claman");
		awdIndexPolicyDataResponse.setAgentLastName("Perine");
		awdIndexPolicyDataResponse.setAgentPhoneNo("123456789");
		awdIndexPolicyDataResponse.setRepAgentFirstName("Sam");
		awdIndexPolicyDataResponse.setRepAgentLastName("Harris");
		awdIndexPolicyDataResponse.setRepAgentPhoneNo("123456789");
		awdIndexPolicyDataResponse.setRepAgentTaxId("123456789");
		awdIndexPolicyDataResponse.setAgentBrokerDealerId("123456789");
		policyAntonyDataList.add(awdIndexPolicyDataResponse);
    }

    @Test
    public void getAWDIndexPolicyTest() throws Exception{

        when(awdIndexPolicyService.getAWDIndexPolicy("16003")).thenReturn(policyAntonyDataList);

       // mvc.perform(get("/jh/wealth/ann/contract/valuation").header("contractID", "FNA70053569").header("MessageUUID", "1234").header("sourceSystemName", "FNA"));
        
        mvc.perform(get("/jh/wealth/ann/awdindex/policy?policyNo=16003").header("MessageUUID", "1234").header("SourceSystemName", "FNA")
        		)
                .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
                                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].companyCode", is("FNA")))
                .andExpect(jsonPath("$[0].lob", is("NQI")))
                .andExpect(jsonPath("$[0].fixedVarCode", is("V")))
                .andExpect(jsonPath("$[0].ownerCompanyIndivCode", is("I")))
                .andExpect(jsonPath("$[0].agentFirstName", is("Claman")))
                .andExpect(jsonPath("$[0].agentLastName", is("Perine")))
                .andExpect(jsonPath("$[0].agentPhoneNo", is("123456789")))
                .andExpect(jsonPath("$[0].repAgentFirstName", is("Sam")))
                .andExpect(jsonPath("$[0].repAgentPhoneNo", is("123456789")))
                .andExpect(jsonPath("$[0].repAgentTaxId", is("123456789")))
                .andExpect(jsonPath("$[0].agentBrokerDealerId", is("123456789")))
                .andExpect(jsonPath("$[0].brokerCount", is("1")))
                .andExpect(jsonPath("$[0].ownerFirstName", is("Phanthavongsa")))
                .andExpect(jsonPath("$[0].ownerLastName", is("Kheitmeyer")))
                .andExpect(jsonPath("$[0].annuitantFirstName", is("Phanthavongsa")))
                .andExpect(jsonPath("$[0].repAgentLastName", is("Harris")));
        		
        verify(awdIndexPolicyService, times(1)).getAWDIndexPolicy("16003");
        verifyNoMoreInteractions(awdIndexPolicyService);
    }

//NO DATA FOUND
  @Test
    public void policyNotFoundTest() throws Exception {
    	mvc.perform(get("/jh/wealth/ann/awdindex/policy?policyNo=1111").header("MessageUUID", "1234").header("SourceSystemName", "FNA")).andExpect(status().isNotFound());
    }
//BAD REQUEST
  @Test
  public void policyBadRequest() throws Exception {
  	mvc.perform(get("/jh/wealth/ann/awdindex/policy?policyNo=11").header("MessageUUID", "1234").header("SourceSystemName", "FNA")).andExpect(status().isBadRequest());
  }

    @After
    public void teardown(){
    	awdIndexPolicyService = null;
    }

}
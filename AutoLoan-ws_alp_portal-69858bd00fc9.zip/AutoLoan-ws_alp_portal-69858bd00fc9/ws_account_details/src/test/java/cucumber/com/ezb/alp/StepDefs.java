package cucumber.com.ezb.alp;

import static org.junit.Assert.assertNotNull;

import java.util.Date;

import org.apache.commons.lang3.time.DateUtils;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.ezb.alp.Application;
import com.ezb.alp.Loan;
import com.ezb.alp.User;
import com.ezb.alp.repository.AccountDetailRepository;
import com.ezb.alp.repository.LoanRepository;
import com.ezb.alp.service.AccountDetailService;

import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

@WebAppConfiguration
@ContextConfiguration(classes = { Application.class })
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
@RunWith(SpringJUnit4ClassRunner.class)
public class StepDefs {

	@Mock
	private AccountDetailRepository accountDetailRepository;

	@Mock
	private LoanRepository loanRepository;

	@InjectMocks
	AccountDetailService accountDetailService;

	@Before
	public void initMocks() {
		MockitoAnnotations.initMocks(this);
	}

	private static Application app, appl, applica;
	private static Loan loan;

	@Test
	@Given("^Load the Account Details$")
	public void loadAccountDetailsForSave() {
		app = new Application();
		app.setApplicationId("786");
		app.setUid(123);
		app.setUserName("JohnBecker");
		app.setRequestedAmt(350000);
		app.setLoanTerm(3);
		app.setLoanYearPeriod(3);
		app.setApplicationState("Submitted");

		double interestamount = (13 / 100) * app.getRequestedAmt();
		int oneyearinterest = (int) Math.round(interestamount);
		int totalpaymentamount = (oneyearinterest * app.getLoanTerm()) + app.getRequestedAmt();
		int totalmonths = app.getLoanTerm() * 12;
		int monthlydueamount = totalpaymentamount / totalmonths;
		Date loanenddate = DateUtils.addMonths(new Date(), totalmonths);
		Date nextduedate = DateUtils.addMonths(new Date(), 1);

		loan = new Loan();
		loan.setRequestedAmt(app.getRequestedAmt());
		loan.setLoanYearPeriod(app.getLoanYearPeriod());
		loan.setLoanTerm(app.getLoanTerm());
		loan.setLoanstartdate(new Date());
		loan.setEmi(monthlydueamount);
		loan.setLoanEndDate(loanenddate);
		loan.setPaymentDueDate(nextduedate);
		loan.setCurrentPaymentDue(monthlydueamount);
		loan.setTotalPaymentDue(totalpaymentamount - monthlydueamount);
		loan.setReceivedOn(new Date());
		loan.setMaturityDate(loanenddate);
		loan.setPayoffAmount(monthlydueamount);
		loan.setInterestPaid((int) Math.round(interestamount));

	}

	@Test
	@When("^Save Account Details$")
	public void saveAccountDetails() {

		Mockito.when(accountDetailRepository.findByApplicationId(app.getApplicationId())).thenReturn(app);

		Mockito.when(loanRepository.insert(loan)).thenReturn(loan);

		Mockito.when(accountDetailService.saveAccountDetails(app)).thenReturn(loan);

	}

	@Test
	@Then("^Verify the Account Details After Insertion$")
	public void verifyAccountDetails() {
		assertNotNull(loan);
	}

	@Test
	@Given("^Initialize the Account Details Parameter Value$")
	public void initializeAccountDetails() {
		appl = new Application();
		appl.setApplicationId("786");
		appl.setUid(123);
		appl.setUserName("JohnBecker");
		appl.setRequestedAmt(350000);
		appl.setLoanTerm(3);
		appl.setLoanYearPeriod(3);
		appl.setApplicationState("Submitted");
	}

	@Test
	@When("^Fetch Account Details$")
	public void loadAccountDetails() {
		Mockito.when(accountDetailRepository.findByApplicationId(appl.getApplicationId())).thenReturn(appl);
		applica = accountDetailService.getAccountDetails(appl.getApplicationId());
	}

	@Test
	@Then("^Fetch the Account Details Value$")
	public void verifyAccountDetailsValue() {
		assertNotNull(applica);
	}

}
package cucumber.com.ezb.alp;

import static org.junit.Assert.assertEquals;

import java.util.Calendar;

import static org.junit.Assert.*;

import javax.validation.constraints.AssertTrue;

import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.ezb.alp.Application;
import com.ezb.alp.User;
import com.ezb.alp.model.LoanApplication;
import com.ezb.alp.repository.ApplicationRepository;
import com.ezb.alp.repository.UserRepository;
import com.ezb.alp.service.LoanApplicationService;

import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import cucumber.runtime.junit.Assertions;

@WebAppConfiguration
@ContextConfiguration(classes = { Application.class })
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
@RunWith(SpringJUnit4ClassRunner.class)
public class StepDefs {

	@Mock
	ApplicationRepository repository;

	@Mock
	UserRepository userRepository;

	@InjectMocks
	LoanApplicationService loanApplicationService;

	private static LoanApplication loanApplication;
	private static User user;
	private static Application application;
	private static String lastno, newno;

	@Before
	public void initMocks() {
		MockitoAnnotations.initMocks(this);
	}

	String accNo = null;
	String genAccNo = null;

	@Test
	@Given("^Load the Loan Application Details$")
	public void loadLoanApplicationDetails() {
		user = new User();
		user.setUserName("john");

		application = new Application();
		application.setApplicationId("201610000001");
		application.setUser(user);

		loanApplication = new LoanApplication();
		loanApplication.setUser(user);
		loanApplication.setApplication(application);

	}

	@Test
	@When("^Save Loan Application Details$")
	public void saveLoanApplicationDetails() throws Throwable {
		Application app = Mockito.mock(com.ezb.alp.Application.class);
		Mockito.when(userRepository.insert(loanApplication.getUser())).thenReturn(user);
		Mockito.when(repository.findTopByOrderByApplicationIdDesc()).thenReturn(application);
		Mockito.when(loanApplicationService.saveLoanApplicationDetails(loanApplication)).thenReturn(application);
		Mockito.when(repository.insert(application)).thenReturn(application);
	}

	@Test
	@Then("^Verify the Loan Application Details After Insertion$")
	public void verifyLoanApplicationDetails() {
		assertNotNull(application);
	}

	@Test
	@Given("^Initialize the Account No Generation$")
	public void initializeAccountNoGeneration() {
		lastno = "20161100000007";
	}

	@Test
	@When("^Generate the Account Number$")
	public void createAccountNumber() throws Throwable {
		newno = loanApplicationService.generateAccountNumber(lastno);
	}

	@Test
	@Then("^Verify the Generated New Account Number$")
	public void verifyGeneratedAccountNumber() {
		assertNotNull(newno);
	}

}
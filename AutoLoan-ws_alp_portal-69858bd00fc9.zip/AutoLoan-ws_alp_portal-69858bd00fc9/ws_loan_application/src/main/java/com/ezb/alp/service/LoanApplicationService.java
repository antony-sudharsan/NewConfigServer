package com.ezb.alp.service;

import java.util.Calendar;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.ezb.alp.Application;
import com.ezb.alp.User;
import com.ezb.alp.model.LoanApplication;
import com.ezb.alp.repository.ApplicationRepository;
import com.ezb.alp.repository.UserRepository;

@Service
public class LoanApplicationService implements ILoanApplicationService {
	
	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	private ApplicationRepository repository;

	@Autowired
	private UserRepository userRepository;

	/**
	 * 14 Digit Account Number Generation
	 * 
	 * @param lastno
	 * @return
	 */
	public String generateAccountNumber(String lastno) {
		logger.info("Entered Generate Account Number Logic Method - generateAccountNumber() !!!");
		int year = Calendar.getInstance().get(Calendar.YEAR);
		String month = String.format("%02d", Calendar.getInstance().get(Calendar.MONTH) + 1);
		if (lastno != null && lastno.length() > 0) {
			long newnum = Long.valueOf(lastno.substring(6, lastno.length())) + 1;
			return year + month + String.format("%08d", newnum);
		} else {
			return year + month + String.format("%08d", 1);
		}

	}

	/**
	 * Service for Save Loan Application Details
	 * 
	 * @return application
	 */
	public Application saveLoanApplicationDetails(LoanApplication loanApplication) {
		logger.info("Entered Save Loan Application Details Method - saveLoanApplicationDetails() !!!");
			User user = userRepository.insert(loanApplication.getUser());
	
			Application application = loanApplication.getApplication();
	
			Application maxAppId = repository.findTopByOrderByApplicationIdDesc();
	
			String appId = null;
			if (maxAppId != null) {
				appId = generateAccountNumber(maxAppId.getApplicationId());
			} else {
				appId = generateAccountNumber(null);
			}
	
			application.setApplicationId(appId);
			application.setUser(user);
		
		return repository.insert(application);
	}

}

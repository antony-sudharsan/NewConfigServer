package cucumber.com.ezb.alp;

import static org.junit.Assert.assertNotNull;

import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.ezb.alp.Application;
import com.ezb.alp.Identity;
import com.ezb.alp.User;
import com.ezb.alp.repository.CustomerRepository;
import com.ezb.alp.service.CustomerService;

import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.When;

@WebAppConfiguration
@ContextConfiguration(classes = { Application.class })
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
@RunWith(SpringJUnit4ClassRunner.class)
public class StepDefs {

	@Mock
	private CustomerRepository customerRepository;

	@InjectMocks
	CustomerService customerService;

	@Before
	public void initMocks() {
		MockitoAnnotations.initMocks(this);
	}

	private static User user;
	private static Identity identity;

	@Test
	@Given("^Load User Credentials$")
	public void loadUserCredentials() {
		user = new User();
		user.setUserName("john");

		identity = new Identity();
		identity.setUserName("john");
		identity.setPassword("john");
		identity.setPlatinum(true);
		identity.setUser(user);
	}

	@Test
	@When("^Validate the User Credentials$")
	public void validateUserCredentials() {
		Mockito.when(customerRepository.findByUserNameAndPassword(identity.getUserName(), identity.getPassword()))
				.thenReturn(identity);
		assertNotNull(identity);
	}

}
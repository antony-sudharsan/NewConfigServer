package com.ezb.alp.controller;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.ezb.alp.Identity;
import com.ezb.alp.User;
import com.ezb.alp.repository.CustomerRepository;
import com.ezb.alp.service.CustomerService;

import gherkin.deps.com.google.gson.Gson;

public class CustomerControllerTesting {

	private MockMvc mockMvc;

	@Mock
	private CustomerService customerService;

	@Mock
	@Autowired
	private CustomerRepository customerRepository;

	@InjectMocks
	private CustomerController customerController;

	@Before
	public void initMocks() {
		MockitoAnnotations.initMocks(this);
		mockMvc = MockMvcBuilders.standaloneSetup(customerController).build();
	}

	@Test
	public void testFindByUserName() throws Exception {
		User user = new User();
		user.setUserName("john");

		Identity identity = new Identity();
		identity.setUserName("john");
		identity.setPassword("john");
		identity.setPlatinum(true);
		identity.setUser(user);
		Gson gson = new Gson();
		String json = gson.toJson(identity);
		Mockito.when(customerRepository.findByUserNameAndPassword(identity.getUserName(), identity.getPassword()))
				.thenReturn(identity);
		mockMvc.perform(
				post("/login").contentType(MediaType.APPLICATION_JSON).content(json))
				.andExpect(MockMvcResultMatchers.status().isOk());
				/*.andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
				.andExpect(MockMvcResultMatchers.jsonPath("userName", is("john")));*/
		
	}

}

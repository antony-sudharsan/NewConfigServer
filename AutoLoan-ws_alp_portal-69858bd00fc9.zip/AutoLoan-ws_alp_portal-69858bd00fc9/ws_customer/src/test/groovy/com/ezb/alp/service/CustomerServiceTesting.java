package com.ezb.alp.service;

import static org.junit.Assert.assertNotNull;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.test.web.servlet.MockMvc;

import com.ezb.alp.Identity;
import com.ezb.alp.User;
import com.ezb.alp.repository.CustomerRepository;

@RunWith(MockitoJUnitRunner.class)
public class CustomerServiceTesting {

	private MockMvc mockMvc;

	@Mock
	private CustomerRepository customerRepository;

	@InjectMocks
	CustomerService customerService;

	@Before
	public void initMocks() {
		MockitoAnnotations.initMocks(this);
		//mockMvc = MockMvcBuilders.standaloneSetup(customerService).build();
	}

	@Test
	public void testLogin() throws Exception {

		User user = new User();
		user.setUserName("john");

		Identity identity = new Identity();
		identity.setUserName("john");
		identity.setPassword("john");
		identity.setPlatinum(true);
		identity.setUser(user);
		Mockito.when(customerRepository.findByUserNameAndPassword(identity.getUserName(), identity.getPassword()))
		.thenReturn(identity);
		User userObj = customerService.login(identity);
		assertNotNull(userObj);


	}

}

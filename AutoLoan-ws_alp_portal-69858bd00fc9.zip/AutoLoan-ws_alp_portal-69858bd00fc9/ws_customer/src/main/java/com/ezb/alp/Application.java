package com.ezb.alp;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.context.embedded.ConfigurableEmbeddedServletContainer;
import org.springframework.boot.context.embedded.EmbeddedServletContainerCustomizer;
import org.springframework.boot.web.servlet.ServletContextInitializer;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;
import org.springframework.web.filter.CorsFilter;
import org.stagemonitor.core.Stagemonitor;
import org.stagemonitor.web.WebPlugin;

import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

@SpringBootApplication
@EnableSwagger2
public class Application {
	
	private Logger logger = LoggerFactory.getLogger(Application.class);
	
	protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
		return application.sources(Application.class);
	}

	/*
	@Bean
	@Profile("!default")
	public EurekaInstanceConfigBean eurekaInstanceConfig(InetUtils inetUtils) {
	  EurekaInstanceConfigBean b = new EurekaInstanceConfigBean(inetUtils);
	  AmazonInfo info = AmazonInfo.Builder.newBuilder().autoBuild("eureka");
	  b.setDataCenterInfo(info);
	  return b;
	}
	*/
	
	public static void main(String[] args) {
		Stagemonitor.init();
		SpringApplication.run(Application.class, args);
	}
	
	@Bean
    public Docket api() { 
		logger.info("ws-customer-Swagger Configuration");
        return new Docket(DocumentationType.SWAGGER_2)  
          .select()                                  
          .apis(RequestHandlerSelectors.basePackage("com.ezb.alp.service"))   
          .paths(PathSelectors.any())                          
          .build().apiInfo(apiInfo());                                           
    }
	
	private ApiInfo apiInfo() {
	    ApiInfo apiInfo = new ApiInfo("Login Service",
	      null,
	      "API TOS",
	      "Terms of service",
	      "AntroMicdison@cognizant.com", null,null);
	    return apiInfo;
	}
	
	@Bean
	  public CorsFilter corsFilter() {
		logger.info("ws_customer-Cors Filter Configuration");
	    UrlBasedCorsConfigurationSource source = 
	      new UrlBasedCorsConfigurationSource();
	    CorsConfiguration config = new CorsConfiguration();
	    config.setAllowCredentials(true); // you USUALLY want this
	    config.addAllowedOrigin("*");
	    config.addAllowedHeader("*");
	    config.addAllowedMethod("GET");
	    config.addAllowedMethod("PUT");
	    config.addAllowedMethod("POST");
	    source.registerCorsConfiguration("/**", config);
	    return new CorsFilter(source);
	  }

	@Component
	public static class StagemonitorEnabler implements EmbeddedServletContainerCustomizer {
		@Override
		public void customize(ConfigurableEmbeddedServletContainer container) {
			container.addInitializers(new ServletContextInitializer() {
				@Override
				public void onStartup(ServletContext servletContext) throws ServletException {
					new WebPlugin().onStartup(null, servletContext);
				}
			});
		}
	}
}

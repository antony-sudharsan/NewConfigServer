package com.ezb.alp.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.ezb.alp.Identity;
import com.ezb.alp.User;

import com.ezb.alp.service.CustomerService;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;

@RestController
@RequestMapping("/")
@CrossOrigin()
public class CustomerController {
	private Logger logger = LoggerFactory.getLogger(CustomerController.class);
	@Autowired
	private CustomerService customerService;

	/**
	 * @param identity
	 * @return
	 */
	@ApiOperation(value = "Login Verification Service", notes = "Service for User Authentication and Login into the Application", response = User.class)
	@RequestMapping(value = "/login", method = RequestMethod.POST)
	public @ResponseBody User login(
			@ApiParam(value = "User Credentials", required = true) @RequestBody Identity identity) {
		logger.info("Entered Customer login Method - !!!");

		return customerService.login(identity);
	}
}

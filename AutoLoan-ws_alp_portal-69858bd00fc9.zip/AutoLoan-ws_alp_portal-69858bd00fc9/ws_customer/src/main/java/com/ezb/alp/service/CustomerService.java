package com.ezb.alp.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ezb.alp.Identity;
import com.ezb.alp.User;
import com.ezb.alp.repository.CustomerRepository;

@Service
public class CustomerService implements ICustomerService {

	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	private CustomerRepository customerRepository;

	public User login(Identity identity) {
		logger.info("Entered login method  !!!");
		User user = null;
		Identity customer = customerRepository.findByUserNameAndPassword(identity.getUserName(),
				identity.getPassword());
		if (customer.isPlatinum()) {
			user = customer.getUser();
		}

		return user;
	}
}
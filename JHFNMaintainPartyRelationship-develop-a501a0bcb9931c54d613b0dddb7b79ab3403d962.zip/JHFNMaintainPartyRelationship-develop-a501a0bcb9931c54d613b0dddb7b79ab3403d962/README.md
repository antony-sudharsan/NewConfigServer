# JHFNMaintainPartyRelationship  Design Document
## Introduction
    This document defines the service specification for SOA components making up the  JHFNMaintainPartyRelationship service for John Hancock LTC.
                This service supports operations related to JHFNMaintainPartyRelationship . The operations currently specified are:

1 Search
2 Read

## REST
## Operation
Operation|URI|Method
---|---|---
Search|/jh/signator/maintainparty/relationship/search|GET
Read|/jh/signator/maintainparty/relationship/read|GET
# SOAP Endpoint URL
Operation|URI
---|---|
Search|https://jhfnmaintainpartyrelationship-dev.apps.cac.preview.pcf.manulife.com/MaintainPartyRelationship_1.0/
Read|https://jhfnmaintainpartyrelationship-dev.apps.cac.preview.pcf.manulife.com/MaintainPartyRelationship_1.0/

## Swagger URL
https://jhfnmaintainpartyrelationship-dev.apps.cac.preview.pcf.manulife.com/swagger-ui.html

## Audit Point
No|Reference Interpretation
---|---
1|Data received From Input
2|Data Sent to End System
3|Data Output received from End System
4|Data sent back to Output

## HTTP Error Codes
# For REST Service
Error Code|Error Description
---|---
200|Success
408|Request Timeout         
500|Technical Error
400|Validation Failed
404|Record not found 

# For SOAP Service
Code|Reason|Detail
---|---|---
999|No Data Found|No Data Found based on criteria
9999|Technical Error|Stacktrace Message
99999|Service Timed Out|Service Timed Out
996|Operation not Implemented|Operation not Implemented

## Notes
For SearchPartyRelationship, only exact_match implemented as other options are not defined in schema.

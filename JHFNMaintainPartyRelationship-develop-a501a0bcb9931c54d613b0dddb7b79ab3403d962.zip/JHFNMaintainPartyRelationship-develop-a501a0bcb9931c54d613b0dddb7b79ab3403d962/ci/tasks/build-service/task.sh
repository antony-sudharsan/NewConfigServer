#!/bin/bash

set -e # fail fast
#set -x # debug

echo ""
echo " .. Running build"
echo ""

cd service-repo

# gradle build
export GRADLE_OPTS="-Dorg.gradle.native=false"
chmod 755 ./gradlew
./gradlew clean test build

# -- target folder is auto created
# mkdir -f ../build-output

# move all manifests file to target
cp -f manifest.yml  ../build-output/
cp -f build/libs/*.jar ../build-output/

# change dir to the libs folder
cd build/libs

# get the file name from the archive
export vers=vers=$(ls -1 *.jar);
export vers=${vers%-*};
# export vers=${vers##*-};
echo " .. current version - ${vers} ";

# go back
cd ../../

# copy the reports of the tests to the output folder
cp -rfv build/reports  ../build-output/${vers}-reports

echo ""
echo " Build completed!!!"
echo ""

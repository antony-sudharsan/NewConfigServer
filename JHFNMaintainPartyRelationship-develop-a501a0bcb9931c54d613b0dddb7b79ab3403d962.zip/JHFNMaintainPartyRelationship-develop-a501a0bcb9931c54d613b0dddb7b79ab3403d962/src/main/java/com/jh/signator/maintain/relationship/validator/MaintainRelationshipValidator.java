package com.jh.signator.maintain.relationship.validator;

import com.jh.signator.maintain.relationship.exception.BadRequestException;
import com.jh.signator.maintain.relationship.exception.OperationNotImplementedException;
import com.manulife.esb.xsd.distribution.jhfn.partyrelationship.RELATIONIDREF;
import com.manulife.esb.xsd.distribution.jhfn.partyrelationship.ReadPartyRelationshipRequest;
import com.manulife.esb.xsd.distribution.jhfn.partyrelationship.SearchPartyRelationshipRequest;
import com.microsoft.sqlserver.jdbc.StringUtils;

public class MaintainRelationshipValidator {

	public static void validateRequest(final String messageUUID, final String sourceSystemName,
			final ReadPartyRelationshipRequest readPartyRelationshipRequest) {
		System.out.println("readPartyRelationshipRequest.getRelationIDRef()" + readPartyRelationshipRequest.getRelationIDRef());
		System.out.println("RELATIONIDREF.CONCATENATION " + RELATIONIDREF.CONCATENATION);

		if (!(readPartyRelationshipRequest.getRelationIDRef().equals(RELATIONIDREF.BUSINESS_PLATFORM))
				&& !(readPartyRelationshipRequest.getRelationIDRef().equals(RELATIONIDREF.CONCATENATION))) {
			throw new OperationNotImplementedException();
		}

	}

	public static void validateRequest(final String messageUUID, final String sourceSystemName,
			final SearchPartyRelationshipRequest readPartyRelationshipRequest) {

		if (StringUtils.isEmpty(messageUUID) || StringUtils.isEmpty(sourceSystemName)) {
			throw new BadRequestException("Invalid Header Sent");
		}
	}

}
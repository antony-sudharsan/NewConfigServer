package com.jh.signator.maintain.relationship.dao;

import java.util.List;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Profile;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.jh.signator.maintain.relationship.model.data.BusinessPlatformLookUpCriteria;
import com.jh.signator.maintain.relationship.model.data.PartyLookupResult;
import com.jh.signator.maintain.relationship.model.data.SearchBusinessPlatformLookUpResult;
import com.jh.signator.maintain.relationship.model.data.SearchPartyLookupCriteria;

@Repository
@Profile("!test-fake")
public class MaintainRelationshipSearchDaoImpl implements MaintainRelationshipSearchDao {

	@Value("${RequestTimeoutLimit}")
	private int requestTimeoutLimit;

	// TODO: Determine if BeanPropertyRowMapper is thread-safe and if so can make
	// each one an attribute and create one.

	// Queries
	private static final String ACTIVE_ONLY_PARTY_LOOKUP_SQL = "select distinct a.party_id_no,a.prd_id,a.firm_cd,a.contract_status,a.term_date,a.contract_date,a.contract_org_party_id_no from\r\n"
			+ "(\r\n" + "--active contract\r\n" + "SELECT distinct  \r\n" + "                p.party_id_no,\r\n"
			+ "                p.prd_id\r\n" + "                ,pc.agency_cd as firm_cd\r\n"
			+ "                ,case when pc.ccstopdt is null and pc.agency_cd is not null then 'active' else 'zombie' end as contract_status\r\n"
			+ "                ,pc.ccstopdt as term_date\r\n" + "                ,pc.ccstdt as contract_date\r\n"
			+ "                ,case when pc.org_party_id_no is null then pc.office_id_no else pc.org_party_id_no end as contract_org_party_id_no\r\n"
			+ "FROM tparty p (nolock)                 \r\n" + "                LEFT JOIN tproducer pr (nolock)\r\n"
			+ "                                ON p.party_id_no = pr.party_id_no\r\n"
			+ "                LEFT JOIN tprdcr_con pc (nolock)\r\n"
			+ "                                ON pr.prdcr_id_no = pc.prdcr_id_no \r\n"
			+ "                                and pc.PRIM_CON_IND = '1'\r\n"
			+ "                                and pc.ccstopdt is null\r\n"
			+ "WHERE p.prd_id like ? or p.party_id_no like ?\r\n" + "union\r\n" + "--active p2p\r\n"
			+ "SELECT distinct  \r\n" + "                p.party_id_no,\r\n" + "                p.prd_id\r\n"
			+ "                ,org.org_agency_cd as firm_cd\r\n"
			+ "                ,case when org.org_agency_cd is not null then 'active' else 'zombie' end as contract_status\r\n"
			+ "                ,p2p.PARTY2PARTY_END_DT as term_date\r\n"
			+ "                ,p2p.PARTY2PARTY_EFF_DT as contract_date\r\n"
			+ "                ,p2p.party2_id_no as contract_org_party_id_no\r\n"
			+ "FROM tparty p (nolock)                 \r\n"
			+ "                LEFT JOIN tparty_to_party p2p (nolock)\r\n"
			+ "                                ON p.party_id_no = p2p.party1_id_no\r\n"
			+ "                                and (p2p.PARTY2PARTY_END_DT is null or p2p.PARTY2PARTY_END_DT >= getdate())\r\n"
			+ "                                --and p2p.RELATIONSHIP_TYP_CD not in ('PRADM','SUPPR','DTCH')\r\n"
			+ "                                and p2p.RELATIONSHIP_TYP_CD in ('ADMFM','ACS')\r\n"
			+ "                LEFT JOIN tparty org (nolock)\r\n"
			+ "                                ON p2p.party2_id_no = org.party_id_no\r\n"
			+ "WHERE p.prd_id like ? or p.party_id_no like ?\r\n" + ") a where a.contract_status <> 'zombie'\r\n"
			+ "order by a.contract_date desc";

	public static final String ACTIVE_ONLY_BUSINESS_PLATFORM_LOOKUP_SQL = "SELECT distinct\r\n"
			+ "	t.transaction_id_no,\r\n" + "	t.party_id_no,\r\n" + "	p.prd_id,\r\n" + "	r.role_cd,\r\n"
			+ "	t.other_role,\r\n" + "	t.rep_party_id_no,\r\n" + "	rep.prd_id as agent_prd_id,\r\n"
			+ "	agent_org.party_id_no as agent_org_party_id_no,\r\n" + "	agent_org.prd_id as agent_org_prd_id,\r\n"
			+ "	org.party_id_no as org_party_id_no,\r\n" + "	org.prd_id as org_prd_id,\r\n"
			+ "	org.org_agency_cd,\r\n" + "	pc.agency_cd,\r\n" + "	p2p.party2_id_no,\r\n"
			+ "	t.transaction_eff_date,\r\n" + "    t.transaction_end_date,\r\n" + "	t.creat_dtm,\r\n"
			+ "	t.creat_by_nm,\r\n" + "	t.last_upd_dtm,\r\n" + "	t.last_upd_by_nm\r\n"
			+ "FROM ttransaction t (nolock)\r\n" + "	INNER JOIN tparty_role r (nolock)\r\n"
			+ "		ON t.party_id_no = r.party_id_no		\r\n"
			+ "		and (r.party_role_end_dt is null or r.party_role_end_dt  >= getdate())\r\n"
			+ "		and r.role_typ_cd = 'BIZPF'\r\n" + "	INNER JOIN tparty p (nolock)\r\n"
			+ "		ON t.party_id_no = p.party_id_no\r\n" + "	LEFT JOIN tparty rep (nolock)\r\n"
			+ "		ON rep.party_id_no = t.rep_party_id_no\r\n" + "	LEFT JOIN tproducer pr (nolock)\r\n"
			+ "		ON p.party_id_no = pr.party_id_no\r\n" + "	LEFT JOIN tprdcr_con pc (nolock)\r\n"
			+ "		ON pr.prdcr_id_no = pc.prdcr_id_no \r\n" + "		and pc.PRIM_CON_IND = '1'				\r\n"
			+ "		and pc.ccstopdt is null\r\n" + "	LEFT JOIN tparty agent_org (nolock)\r\n"
			+ "		ON (pc.agency_cd = agent_org.org_agency_cd and agent_org.org_dtch_cd = 0)\r\n"
			+ "	LEFT JOIN tparty_to_party p2p (nolock)\r\n" + "		ON p.party_id_no = p2p.party1_id_no\r\n"
			+ "		and (p2p.PARTY2PARTY_END_DT is null or p2p.PARTY2PARTY_END_DT >= getdate())	\r\n"
			+ "		and p2p.RELATIONSHIP_TYP_CD in ('ACS','ADMFM')	\r\n" + "    LEFT JOIN tparty org (nolock)\r\n"
			+ "		ON org.party_id_no = p2p.party2_id_no\r\n" + "WHERE \r\n"
			+ "	(t.transaction_end_date is null or t.transaction_end_date >= getdate()) and\r\n"
			+ "	(org.org_agency_cd = ? or pc.agency_cd = ?)\r\n"
			+ "ORDER BY t.transaction_end_date DESC, t.transaction_eff_date DESC	";

	public static final String ALL_PARTY_LOOKUP_SQL = "select distinct a.party_id_no,a.prd_id,a.firm_cd,a.contract_status,a.term_date,a.contract_date,a.contract_org_party_id_no from\r\n"
			+ "(\r\n" + "--active contract\r\n" + "SELECT distinct  \r\n" + "                p.party_id_no,\r\n"
			+ "                p.prd_id\r\n" + "                ,pc.agency_cd as firm_cd\r\n"
			+ "                ,case when pc.ccstopdt is null and pc.agency_cd is not null then 'active' else 'zombie' end as contract_status\r\n"
			+ "                ,pc.ccstopdt as term_date\r\n" + "                ,pc.ccstdt as contract_date\r\n"
			+ "                ,case when pc.org_party_id_no is null then pc.office_id_no else pc.org_party_id_no end as contract_org_party_id_no\r\n"
			+ "FROM tparty p (nolock)                 \r\n" + "                LEFT JOIN tproducer pr (nolock)\r\n"
			+ "                                ON p.party_id_no = pr.party_id_no\r\n"
			+ "                LEFT JOIN tprdcr_con pc (nolock)\r\n"
			+ "                                ON pr.prdcr_id_no = pc.prdcr_id_no \r\n"
			+ "                                and pc.PRIM_CON_IND = '1'\r\n"
			+ "                                and pc.ccstopdt is null\r\n"
			+ "WHERE p.prd_id like ? or p.party_id_no like ?\r\n" + "union\r\n" + "--active p2p\r\n"
			+ "SELECT distinct  \r\n" + "                p.party_id_no,\r\n" + "                p.prd_id\r\n"
			+ "                ,org.org_agency_cd as firm_cd\r\n"
			+ "                ,case when org.org_agency_cd is not null then 'active' else 'zombie' end as contract_status\r\n"
			+ "                ,p2p.PARTY2PARTY_END_DT as term_date\r\n"
			+ "                ,p2p.PARTY2PARTY_EFF_DT as contract_date\r\n"
			+ "                ,p2p.party2_id_no as contract_org_party_id_no \r\n"
			+ "FROM tparty p (nolock)                 \r\n"
			+ "                LEFT JOIN tparty_to_party p2p (nolock)\r\n"
			+ "                                ON p.party_id_no = p2p.party1_id_no\r\n"
			+ "                                and (p2p.PARTY2PARTY_END_DT is null or p2p.PARTY2PARTY_END_DT >= getdate())\r\n"
			+ "                                --and p2p.RELATIONSHIP_TYP_CD not in ('PRADM','SUPPR','DTCH')\r\n"
			+ "                                and p2p.RELATIONSHIP_TYP_CD in ('ADMFM','ACS')\r\n"
			+ "                LEFT JOIN tparty org (nolock)\r\n"
			+ "                                ON p2p.party2_id_no = org.party_id_no\r\n"
			+ "WHERE p.prd_id like ? or p.party_id_no like ?\r\n" + "union\r\n" + "--term contract\r\n"
			+ "SELECT distinct  \r\n" + "                p.party_id_no,\r\n" + "                p.prd_id\r\n"
			+ "                ,pc.agency_cd as firm_cd\r\n"
			+ "                ,case when pc.ccstopdt is null then 'zombie' else 'terminated' end as contract_status\r\n"
			+ "                ,pc.ccstopdt as term_date\r\n" + "                ,pc.ccstdt as contract_date\r\n"
			+ "                ,case when pc.org_party_id_no is null then pc.office_id_no else pc.org_party_id_no end as contract_org_party_id_no           \r\n"
			+ "FROM tparty p (nolock) \r\n" + "                LEFT JOIN tproducer pr (nolock)\r\n"
			+ "                                ON p.party_id_no = pr.party_id_no\r\n"
			+ "                LEFT JOIN tprdcr_con pc (nolock)\r\n"
			+ "                                ON pr.prdcr_id_no = pc.prdcr_id_no \r\n"
			+ "                                and pc.PRIM_CON_IND = '1'\r\n"
			+ "                                and pc.ccstopdt is not null\r\n"
			+ "                                and pc.agency_cd not in (select pc2.agency_cd from tprdcr_con pc2 (nolock)\r\n"
			+ "                                where pr.prdcr_id_no = pc2.prdcr_id_no \r\n"
			+ "                                and pc2.PRIM_CON_IND = '1' and pc2.ccstopdt is null)\r\n"
			+ "WHERE p.prd_id like ? or p.party_id_no like ?\r\n" + "union\r\n" + "--term p2p\r\n"
			+ "SELECT distinct  \r\n" + "                p.party_id_no,\r\n" + "                p.prd_id\r\n"
			+ "                ,org.org_agency_cd as firm_cd\r\n"
			+ "                ,case when p2p.PARTY2PARTY_END_DT is null then 'zombie' else 'terminated' end as contract_status\r\n"
			+ "                ,p2p.PARTY2PARTY_END_DT      as term_date\r\n"
			+ "                ,p2p.PARTY2PARTY_EFF_DT as contract_date\r\n"
			+ "                ,p2p.party2_id_no as contract_org_party_id_no \r\n" + "FROM tparty p (nolock) \r\n"
			+ "                LEFT JOIN tparty_to_party p2p (nolock)\r\n"
			+ "                                ON p.party_id_no = p2p.party1_id_no\r\n"
			+ "                                and (p2p.PARTY2PARTY_END_DT is not null or p2p.PARTY2PARTY_END_DT < getdate())\r\n"
			+ "                                --and p2p.RELATIONSHIP_TYP_CD not in ('PRADM','SUPPR','DTCH')\r\n"
			+ "                                and p2p.RELATIONSHIP_TYP_CD in ('ADMFM','ACS')\r\n"
			+ "                LEFT JOIN tparty org (nolock)\r\n"
			+ "                                ON p2p.party2_id_no = org.party_id_no\r\n"
			+ "WHERE p.prd_id like ? or p.party_id_no like ?\r\n" + ") a where a.contract_status <> 'zombie'\r\n"
			+ "order by a.contract_status,a.contract_date desc";

	public static final String ALL_CONTRACT_STATUS_ACTIVE_BUSINESS_PLATFORM_SQL = "SELECT distinct\r\n"
			+ "      t.transaction_id_no,\r\n" + "      t.party_id_no,\r\n" + "      p.prd_id,\r\n"
			+ "      r.role_cd,\r\n" + "      t.other_role,\r\n" + "      t.rep_party_id_no,\r\n"
			+ "      rep.prd_id as agent_prd_id,\r\n" + "      agent_org.party_id_no as agent_org_party_id_no,\r\n"
			+ "      agent_org.prd_id as agent_org_prd_id,\r\n" + "      org.party_id_no as org_party_id_no,\r\n"
			+ "      org.prd_id as org_prd_id,\r\n" + "      --org.org_agency_cd,\r\n" + "      --pc.agency_cd,\r\n"
			+ "      case when org.org_agency_cd is null then pc.agency_cd else org.org_agency_cd end as firm_cd,\r\n"
			+ "      p2p.party2_id_no,\r\n" + "      t.transaction_eff_date,\r\n" + "      t.transaction_end_date,\r\n"
			+ "      t.creat_dtm,\r\n" + "      t.creat_by_nm,\r\n" + "      t.last_upd_dtm,\r\n"
			+ "      t.last_upd_by_nm\r\n"
			+ "      ,case when t.transaction_end_date is null then 'active' else 'terminated' end as txn_status\r\n"
			+ "FROM ttransaction t (nolock)	\r\n" + "     LEFT JOIN tparty_role r (nolock)\r\n"
			+ "         ON t.party_id_no = r.party_id_no		\r\n"
			+ "         and r.role_typ_cd = 'BIZPF'		\r\n"
			+ "         and r.party_role_id_no = (select max(party_role_id_no) from tparty_role where party_id_no = t.party_id_no and role_typ_cd = 'BIZPF' and party_role_end_dt is null) 	     \r\n"
			+ "     INNER JOIN tparty p (nolock)\r\n" + "         ON t.party_id_no = p.party_id_no\r\n"
			+ "     LEFT JOIN tparty rep (nolock)\r\n" + "         ON rep.party_id_no = t.rep_party_id_no\r\n"
			+ "     LEFT JOIN tproducer pr (nolock)\r\n" + "         ON p.party_id_no = pr.party_id_no\r\n"
			+ "     LEFT JOIN tprdcr_con pc (nolock)\r\n" + "         ON pr.prdcr_id_no = pc.prdcr_id_no \r\n"
			+ "         and pc.PRIM_CON_IND = '1'\r\n" + "         and pc.ccstopdt is null					\r\n"
			+ "     LEFT JOIN tparty agent_org (nolock)\r\n"
			+ "         ON (pc.agency_cd = agent_org.org_agency_cd  and agent_org.org_dtch_cd = 0)\r\n"
			+ "     LEFT JOIN tparty_to_party p2p (nolock)\r\n" + "         ON p.party_id_no = p2p.party1_id_no\r\n"
			+ "         --and agent_org.party_id_no = p2p.party1_id_no\r\n"
			+ "         and p2p.RELATIONSHIP_TYP_CD not in ('PRADM','SUPPR','DTCH')\r\n"
			+ "         and party2party_end_dt is null\r\n" + "     LEFT JOIN tparty org (nolock)\r\n"
			+ "         ON org.party_id_no = p2p.party2_id_no\r\n" + "WHERE \r\n"
			+ "     (org.org_agency_cd = ? or pc.agency_cd = ?) \r\n" + "     and t.transaction_end_date is null\r\n"
			+ "ORDER BY txn_status,t.transaction_end_date DESC, t.transaction_eff_date DESC";

	public static final String ALL_CONTRACT_STATUS_TERMINATED_BUSINESS_PLATFORM_SQL = "SELECT distinct\r\n"
			+ "      t.transaction_id_no,\r\n" + "      t.party_id_no,\r\n" + "      p.prd_id,\r\n"
			+ "      r.role_cd,\r\n" + "      t.other_role,\r\n" + "      t.rep_party_id_no,\r\n"
			+ "      rep.prd_id as agent_prd_id,\r\n"
			+ "      case when (r.role_cd in ('STAFF','ACS','MP') or r.role_cd is null) then null else agent_org.party_id_no end as agent_org_party_id_no,\r\n"
			+ "      agent_org.prd_id as agent_org_prd_id,\r\n" + "      org.party_id_no as org_party_id_no,\r\n"
			+ "      org.prd_id as org_prd_id,\r\n" + "      --org.org_agency_cd,\r\n" + "      --pc.agency_cd,\r\n"
			+ "      case when org.org_agency_cd is null then pc.agency_cd else org.org_agency_cd end as firm_cd,\r\n"
			+ "      p2p.party2_id_no,\r\n" + "      t.transaction_eff_date,\r\n" + "      t.transaction_end_date,\r\n"
			+ "      t.creat_dtm,\r\n" + "      t.creat_by_nm,\r\n" + "      t.last_upd_dtm,\r\n"
			+ "      t.last_upd_by_nm\r\n"
			+ "      ,case when t.transaction_end_date is null then 'active' else 'terminated' end as txn_status\r\n"
			+ "FROM ttransaction t (nolock)	\r\n" + "     LEFT JOIN tparty_role r (nolock)\r\n"
			+ "         ON t.party_id_no = r.party_id_no		\r\n"
			+ "         and r.role_typ_cd = 'BIZPF'		\r\n"
			+ "         and r.party_role_id_no = (select max(party_role_id_no) from tparty_role where party_id_no = t.party_id_no and role_typ_cd = 'BIZPF' and party_role_end_dt is not null) 	     \r\n"
			+ "     INNER JOIN tparty p (nolock)\r\n" + "         ON t.party_id_no = p.party_id_no\r\n"
			+ "     LEFT JOIN tparty rep (nolock)\r\n" + "         ON rep.party_id_no = t.rep_party_id_no\r\n"
			+ "     LEFT JOIN tproducer pr (nolock)\r\n" + "         ON p.party_id_no = pr.party_id_no\r\n"
			+ "     LEFT JOIN tprdcr_con pc (nolock)\r\n" + "         ON pr.prdcr_id_no = pc.prdcr_id_no \r\n"
			+ "         and pc.PRIM_CON_IND = '1'\r\n" + "         and pc.ccstopdt is not null					\r\n"
			+ "     LEFT JOIN tparty agent_org (nolock)\r\n"
			+ "         ON (pc.agency_cd = agent_org.org_agency_cd  and agent_org.org_dtch_cd = 0)\r\n"
			+ "     LEFT JOIN tparty_to_party p2p (nolock)\r\n" + "         ON p.party_id_no = p2p.party1_id_no\r\n"
			+ "         and p2p.RELATIONSHIP_TYP_CD not in ('PRADM','SUPPR','DTCH')\r\n"
			+ "         and party2party_end_dt is not null\r\n" + "     LEFT JOIN tparty org (nolock)\r\n"
			+ "         ON org.party_id_no = p2p.party2_id_no\r\n" + "WHERE \r\n"
			+ "     (org.org_agency_cd = ? or pc.agency_cd = ?) \r\n"
			+ "     and t.transaction_end_date is not null \r\n" + "ORDER BY txn_status,t.transaction_end_date DESC";

	private final JdbcTemplate jdbcTemplate;

	@Autowired
	public MaintainRelationshipSearchDaoImpl(final JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	@PostConstruct
	public void init() {

		if (requestTimeoutLimit != 0) {
			this.jdbcTemplate.setQueryTimeout(requestTimeoutLimit);
		}
	}

	@Override
	public PartyLookupResult getActiveOnlyPartyLookupResult(final SearchPartyLookupCriteria searchPartyLookupCriteria) {
		PartyLookupResult result = null;

		final RowMapper<PartyLookupResult> rowMapper = new BeanPropertyRowMapper<>(PartyLookupResult.class);
		final List<PartyLookupResult> results = jdbcTemplate.query(ACTIVE_ONLY_PARTY_LOOKUP_SQL,
				new Object[] { searchPartyLookupCriteria.getPrdId(), searchPartyLookupCriteria.getPrdIdNo(),
						searchPartyLookupCriteria.getPrdIdP2p(), searchPartyLookupCriteria.getPrdIdNoP2p() },
				rowMapper);
		if (!results.isEmpty()) {
			result = results.get(0);
		}

		return result;
	}

	@Override
	public List<SearchBusinessPlatformLookUpResult> getActiveOnlyBusinessPlatformLookupResult(
			final BusinessPlatformLookUpCriteria criteria) {

		final RowMapper<SearchBusinessPlatformLookUpResult> rowMapper = new BeanPropertyRowMapper<>(
				SearchBusinessPlatformLookUpResult.class);
		return jdbcTemplate.query(ACTIVE_ONLY_BUSINESS_PLATFORM_LOOKUP_SQL,
				new Object[] { criteria.getOrg_agency_cd(), criteria.getAgency_cd() }, rowMapper);
	}

	@Override
	public PartyLookupResult getAllPartyLookupResult(final SearchPartyLookupCriteria searchPartyLookupCriteria) {
		PartyLookupResult result = null;

		final RowMapper<PartyLookupResult> rowMapper = new BeanPropertyRowMapper<>(PartyLookupResult.class);
		final List<PartyLookupResult> results = jdbcTemplate.query(ALL_PARTY_LOOKUP_SQL,
				new Object[] { searchPartyLookupCriteria.getPrdIdContract(),
						searchPartyLookupCriteria.getPrdIdNoContract(), searchPartyLookupCriteria.getPrdIdP2p(),
						searchPartyLookupCriteria.getPrdIdNoP2p(), searchPartyLookupCriteria.getPrdIdContractTerm(),
						searchPartyLookupCriteria.getPrdIdNoContractTerm(), searchPartyLookupCriteria.getPrdIdP2pTerm(),
						searchPartyLookupCriteria.getPrdIdNoP2pTerm() },
				rowMapper);
		if (!results.isEmpty()) {
			result = results.get(0);
		}

		return result;
	}

	@Override
	public List<SearchBusinessPlatformLookUpResult> getAllContractStatusActiveBusinessPlatformLookupResult(
			final BusinessPlatformLookUpCriteria criteria) {

		final RowMapper<SearchBusinessPlatformLookUpResult> rowMapper = new BeanPropertyRowMapper<>(
				SearchBusinessPlatformLookUpResult.class);
		return jdbcTemplate.query(ALL_CONTRACT_STATUS_ACTIVE_BUSINESS_PLATFORM_SQL,
				new Object[] { criteria.getOrg_agency_cd(), criteria.getAgency_cd() }, rowMapper);
	}

	@Override
	public List<SearchBusinessPlatformLookUpResult> getAllContractStatusTerminatedBusinessPlatformLookupResult(
			final BusinessPlatformLookUpCriteria criteria) {

		final RowMapper<SearchBusinessPlatformLookUpResult> rowMapper = new BeanPropertyRowMapper<>(
				SearchBusinessPlatformLookUpResult.class);
		return jdbcTemplate.query(ALL_CONTRACT_STATUS_TERMINATED_BUSINESS_PLATFORM_SQL,
				new Object[] { criteria.getOrg_agency_cd(), criteria.getAgency_cd() }, rowMapper);
	}

}
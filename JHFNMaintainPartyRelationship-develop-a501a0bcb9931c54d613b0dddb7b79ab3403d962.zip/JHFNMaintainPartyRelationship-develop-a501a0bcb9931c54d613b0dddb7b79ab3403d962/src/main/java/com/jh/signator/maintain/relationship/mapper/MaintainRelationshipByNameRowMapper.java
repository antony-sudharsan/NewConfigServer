package com.jh.signator.maintain.relationship.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import com.jh.signator.maintain.relationship.model.data.LookupByConcatenation;

@Component
public class MaintainRelationshipByNameRowMapper implements RowMapper<LookupByConcatenation> {
	// ReadPartyRelationshipReply readPartyRelationshipReply = new
	// ReadPartyRelationshipReply();
	@Override
	public LookupByConcatenation mapRow(final ResultSet rs, final int rowNum) throws SQLException {

		final LookupByConcatenation lookupByConcatenation = new LookupByConcatenation();
		lookupByConcatenation.setAgency_cd(rs.getDouble("agency_cd"));
		lookupByConcatenation.setTransaction_id_no(rs.getString("transaction_id_no"));
		lookupByConcatenation.setParty_id_no(rs.getDouble("party_id_no"));
		lookupByConcatenation.setPrd_id(rs.getString("prd_id"));
		lookupByConcatenation.setOther_role(rs.getString("other_role"));
		lookupByConcatenation.setRep_party_id_no(rs.getDouble("rep_party_id_no"));
		lookupByConcatenation.setAgent_prd_id(rs.getString("agent_prd_id"));
		lookupByConcatenation.setAgent_org_party_id_no(rs.getDouble("agent_org_party_id_no"));
		lookupByConcatenation.setAgent_org_prd_id(rs.getString("agent_org_prd_id"));
		lookupByConcatenation.setOrg_party_id_no(rs.getDouble("org_party_id_no"));
		lookupByConcatenation.setOrg_prd_id(rs.getString("org_prd_id"));
		lookupByConcatenation.setOrg_agency_cd(rs.getDouble("org_agency_cd"));
		lookupByConcatenation.setAgency_cd(rs.getDouble("agency_cd"));
		lookupByConcatenation.setParty2_id_no(rs.getDouble("party2_id_no"));
		lookupByConcatenation.setTransaction_eff_date(rs.getTimestamp("transaction_eff_date"));
		lookupByConcatenation.setTransaction_end_date(rs.getTimestamp("transaction_end_date"));
		lookupByConcatenation.setCreat_dtm(rs.getTimestamp("creat_dtm"));
		lookupByConcatenation.setCreat_by_nm(rs.getString("creat_by_nm"));
		lookupByConcatenation.setLast_upd_by_nm(rs.getString("last_upd_by_nm"));
		lookupByConcatenation.setLast_upd_dtm(rs.getTimestamp("last_upd_dtm"));

		return lookupByConcatenation;
	}
}
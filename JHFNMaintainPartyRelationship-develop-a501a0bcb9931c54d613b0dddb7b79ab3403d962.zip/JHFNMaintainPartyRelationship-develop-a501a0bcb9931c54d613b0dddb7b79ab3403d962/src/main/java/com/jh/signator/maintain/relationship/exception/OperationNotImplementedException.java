package com.jh.signator.maintain.relationship.exception;

public class OperationNotImplementedException extends BaseFaultException {
	private static final long serialVersionUID = -6016805724195451879L;

	private static final String DEFAULT_CODE = "996";
	private static final String DEFAULT_REASON = "Operation Not Implemented";
	private static final String DEFAULT_DETAILS = "Operation is not implemented.";
	private static final String FAULT_STRING = "Internal Error";

	public OperationNotImplementedException() {
		super(DEFAULT_CODE, DEFAULT_REASON, DEFAULT_DETAILS, FAULT_STRING);
	}

}

package com.jh.signator.maintain.relationship.model.data;

public class PartyLookUpResponse {

	public Double party_id_no;
	public String prd_id;
	public Double agency_cd;
	public Double org_agency_cd;

	public Double getParty_id_no() {
		return party_id_no;
	}

	public void setParty_id_no(final Double party_id_no) {
		this.party_id_no = party_id_no;
	}

	public String getPrd_id() {
		return prd_id;
	}

	public void setPrd_id(final String prd_id) {
		this.prd_id = prd_id;
	}

	public Double getAgency_cd() {
		return agency_cd;
	}

	public void setAgency_cd(final Double agency_cd) {
		this.agency_cd = agency_cd;
	}

	public Double getOrg_agency_cd() {
		return org_agency_cd;
	}

	public void setOrg_agency_cd(final Double org_agency_cd) {
		this.org_agency_cd = org_agency_cd;
	}

	@Override
	public String toString() {
		return "PartyLookUpRequest [party_id_no=" + party_id_no + ", prd_id=" + prd_id + ", agency_cd=" + agency_cd
				+ ", org_agency_cd=" + org_agency_cd + ", getParty_id_no()=" + getParty_id_no() + ", getPrd_id()="
				+ getPrd_id() + ", getAgency_cd()=" + getAgency_cd() + ", getOrg_agency_cd()=" + getOrg_agency_cd()
				+ ", getClass()=" + getClass() + ", hashCode()=" + hashCode() + ", toString()=" + super.toString()
				+ "]";
	}

}

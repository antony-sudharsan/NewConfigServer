package com.jh.signator.maintain.relationship.dao;

import java.util.List;

import com.jh.signator.maintain.relationship.model.data.BusinessPlatformLookUpCriteria;
import com.jh.signator.maintain.relationship.model.data.PartyLookupResult;
import com.jh.signator.maintain.relationship.model.data.SearchBusinessPlatformLookUpResult;
import com.jh.signator.maintain.relationship.model.data.SearchPartyLookupCriteria;

public interface MaintainRelationshipSearchDao {

	PartyLookupResult getActiveOnlyPartyLookupResult(final SearchPartyLookupCriteria searchPartyLookupCriteria);

	List<SearchBusinessPlatformLookUpResult> getActiveOnlyBusinessPlatformLookupResult(
			final BusinessPlatformLookUpCriteria criteria);

	PartyLookupResult getAllPartyLookupResult(final SearchPartyLookupCriteria searchPartyLookupCriteria);

	List<SearchBusinessPlatformLookUpResult> getAllContractStatusActiveBusinessPlatformLookupResult(
			final BusinessPlatformLookUpCriteria criteria);

	List<SearchBusinessPlatformLookUpResult> getAllContractStatusTerminatedBusinessPlatformLookupResult(
			final BusinessPlatformLookUpCriteria criteria);
}

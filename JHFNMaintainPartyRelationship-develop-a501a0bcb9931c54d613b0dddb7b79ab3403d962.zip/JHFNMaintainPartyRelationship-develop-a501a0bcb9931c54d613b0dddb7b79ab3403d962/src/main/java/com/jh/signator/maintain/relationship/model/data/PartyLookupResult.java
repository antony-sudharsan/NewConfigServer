package com.jh.signator.maintain.relationship.model.data;

import java.math.BigDecimal;
import java.sql.Timestamp;

import org.apache.commons.lang3.builder.ToStringBuilder;

public class PartyLookupResult {
	private BigDecimal partyIdNo;
	private String prdId;
	private BigDecimal firmCd;
	private String contractStatus;
	private Timestamp termDate;
	private Timestamp contractDate;
	private BigDecimal contractOrgPartyIdNo;

	public BigDecimal getPartyIdNo() {
		return partyIdNo;
	}

	public void setPartyIdNo(final BigDecimal partyIdNo) {
		this.partyIdNo = partyIdNo;
	}

	public String getPrdId() {
		return prdId;
	}

	public void setPrdId(final String prdId) {
		this.prdId = prdId;
	}

	public BigDecimal getFirmCd() {
		return firmCd;
	}

	public void setFirmCd(final BigDecimal firmCd) {
		this.firmCd = firmCd;
	}

	public String getContractStatus() {
		return contractStatus;
	}

	public void setContractStatus(final String contractStatus) {
		this.contractStatus = contractStatus;
	}

	public Timestamp getTermDate() {
		return termDate;
	}

	public void setTermDate(final Timestamp termDate) {
		this.termDate = termDate;
	}

	public Timestamp getContractDate() {
		return contractDate;
	}

	public void setContractDate(final Timestamp contractDate) {
		this.contractDate = contractDate;
	}

	public BigDecimal getContractOrgPartyIdNo() {
		return contractOrgPartyIdNo;
	}

	public void setContractOrgPartyIdNo(final BigDecimal contractOrgPartyIdNo) {
		this.contractOrgPartyIdNo = contractOrgPartyIdNo;
	}

	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}

}
package com.jh.signator.maintain.relationship.controller;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.jh.signator.maintain.relationship.exception.BadRequestException;
import com.jh.signator.maintain.relationship.exception.ExceptionResponse;
import com.jh.signator.maintain.relationship.exception.OperationNotImplementedException;
import com.jh.signator.maintain.relationship.exception.RecordNotFoundException;
import com.jh.signator.maintain.relationship.exception.RequestTimeoutException;
import com.jh.signator.maintain.relationship.exception.TechnicalErrorException;
import com.jh.signator.maintain.relationship.utils.Utility;

@ControllerAdvice
public class MaintainAttachmentControllerExceptionHandler extends ResponseEntityExceptionHandler {

	// 500
	@ExceptionHandler(Exception.class)
	public final ResponseEntity<Object> handleAllExceptions(final Exception ex, final WebRequest request) {
		final TechnicalErrorException techError = new TechnicalErrorException(ex.getMessage(), ex);
		return new ResponseEntity<>(techError.getExceptionResponse(), HttpStatus.NOT_ACCEPTABLE);

	}

	// 408
	@ExceptionHandler(RequestTimeoutException.class)
	public final ResponseEntity<ExceptionResponse> handleException(final RequestTimeoutException ex,
			final WebRequest request) {

		return new ResponseEntity<>(ex.getExceptionResponse(), HttpStatus.REQUEST_TIMEOUT);
	}

	// 404
	@ExceptionHandler(RecordNotFoundException.class)
	public final ResponseEntity<ExceptionResponse> handleException(final RecordNotFoundException ex,
			final WebRequest request) {
		return new ResponseEntity<>(ex.getExceptionResponse(), HttpStatus.NOT_FOUND);
	}

	@Override
	protected ResponseEntity<Object> handleHttpMessageNotReadable(final HttpMessageNotReadableException ex,
			final HttpHeaders headers, final HttpStatus status, final WebRequest request) {
		final ExceptionResponse exceptionResponse = new ExceptionResponse("400", ex.getMessage(),
				Utility.getStackTrace(ex));
		return new ResponseEntity<>(exceptionResponse, HttpStatus.BAD_REQUEST);
	}

	// 400
	@ExceptionHandler(BadRequestException.class)
	public final ResponseEntity<Object> handleException(final BadRequestException ex, final WebRequest request) {

		return new ResponseEntity<>(ex.getExceptionResponse(), HttpStatus.BAD_REQUEST);
	}

	// 400
	@ExceptionHandler(OperationNotImplementedException.class)
	public final ResponseEntity<Object> handleException(final OperationNotImplementedException ex,
			final WebRequest request) {

		return new ResponseEntity<>(ex.getExceptionResponse(), HttpStatus.BAD_REQUEST);
	}

	// 500
	@ExceptionHandler(TechnicalErrorException.class)
	public final ResponseEntity<Object> handleException(final TechnicalErrorException ex, final WebRequest request) {
		return new ResponseEntity<>(ex.getExceptionResponse(), HttpStatus.INTERNAL_SERVER_ERROR);
	}

}

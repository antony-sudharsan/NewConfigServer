package com.jh.signator.maintain.relationship.endpoint;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ws.context.MessageContext;
import org.springframework.ws.server.endpoint.annotation.Endpoint;
import org.springframework.ws.server.endpoint.annotation.PayloadRoot;
import org.springframework.ws.server.endpoint.annotation.RequestPayload;
import org.springframework.ws.server.endpoint.annotation.ResponsePayload;
import org.springframework.ws.soap.SoapHeaderElement;
import org.springframework.ws.soap.server.endpoint.annotation.SoapHeader;

import com.jh.common.logging.LoggerHandler;
import com.jh.signator.maintain.relationship.exception.BadRequestException;
import com.jh.signator.maintain.relationship.service.MaintainRelationshipService;
import com.jh.signator.maintain.relationship.utils.HeaderKey;
import com.jh.signator.maintain.relationship.utils.JHHeaderJaxbUtils;
import com.jh.signator.maintain.relationship.utils.LoggerUtils;
import com.jh.signator.maintain.relationship.utils.LoggingContextHolder;
import com.jh.signator.maintain.relationship.validator.MaintainRelationshipValidator;
import com.manulife.esb.xsd.common.jh.header.JHHeader;
import com.manulife.esb.xsd.distribution.jhfn.partyrelationship.ReadPartyRelationshipReply;
import com.manulife.esb.xsd.distribution.jhfn.partyrelationship.ReadPartyRelationshipRequest;
import com.manulife.esb.xsd.distribution.jhfn.partyrelationship.SearchPartyRelationshipReply;
import com.manulife.esb.xsd.distribution.jhfn.partyrelationship.SearchPartyRelationshipRequest;

/**
 * Exposes MaintainPartyRelationship Operations via SOAP.
 *
 */
@Endpoint
public class MaintainPartyRelationshipEndpoint {
	private static final String NAMESPACE_URI = "http://www.esb.manulife.com/xsd/distribution/jhfn/partyrelationship";

	private static final String JH_HEADER_NS = "http://www.esb.manulife.com/xsd/common/jh/header";

	private final MaintainRelationshipService maintainRelationshipService;
	private final JHHeaderJaxbUtils jhHeaderJaxbUtils;
	private final LoggerUtils loggerUtils;

	@Autowired
	public MaintainPartyRelationshipEndpoint(final MaintainRelationshipService maintainRelationshipService,
			final JHHeaderJaxbUtils jhHeaderJaxbUtils, final LoggerUtils loggerUtils) {
		this.jhHeaderJaxbUtils = jhHeaderJaxbUtils;
		this.maintainRelationshipService = maintainRelationshipService;
		this.loggerUtils = loggerUtils;
	}

	@PayloadRoot(namespace = NAMESPACE_URI, localPart = "SearchPartyRelationship_request")
	@ResponsePayload
	public SearchPartyRelationshipReply searchPartyRelationship(
			final @RequestPayload SearchPartyRelationshipRequest request,
			final @SoapHeader("{" + JH_HEADER_NS + "}JHHeader") SoapHeaderElement jhHeaderElement,
			final MessageContext messageContext) {

		SearchPartyRelationshipReply reply = null;
		final JHHeader header = parseHeader(jhHeaderElement);
		validateHeader(header);

		final String messageUUID = header.getMessageUID();
		final String sourceSystemName = header.getMessageSource().getApplicationName();
		try {
			LoggingContextHolder.getLoggingContext().setContext(messageUUID, sourceSystemName);
			LoggerHandler.LogOut("INFO", "1", messageUUID, sourceSystemName, this.getClass().getName(),
					"Entering searchPartyRelationship EndPoint " + loggerUtils.writeAsJson(request));
			reply = maintainRelationshipService.searchPartyRelationship(messageUUID, sourceSystemName, request);
			LoggerHandler.LogOut("INFO", "4", messageUUID, sourceSystemName, this.getClass().getName(),
					"Exiting searchPartyRelationship EndPoint " + loggerUtils.writeAsJson(reply));
		} catch (final Exception e) {
			LoggerHandler.ErrorOut(e, messageUUID, sourceSystemName, this.getClass().getName(), e.getMessage());
			throw e;
		}

		// add response header as a property to be used by EndpointInterceptor
		// Current service does not modify header on response
		messageContext.setProperty(HeaderKey.JH_HEADER_KEY.getValue(), header);
		LoggingContextHolder.getLoggingContext().clear();

		return reply;
	}

	// TODO:Fix throws Exception declaration
	@PayloadRoot(namespace = NAMESPACE_URI, localPart = "ReadPartyRelationship_request")
	@ResponsePayload
	public ReadPartyRelationshipReply readPartyRelationship(final @RequestPayload ReadPartyRelationshipRequest request,
			final @SoapHeader("{" + JH_HEADER_NS + "}JHHeader") SoapHeaderElement jhHeaderElement,
			final MessageContext messageContext) {

		ReadPartyRelationshipReply reply = null;
		final JHHeader header = parseHeader(jhHeaderElement);
		validateHeader(header);

		final String messageUUID = header.getMessageUID();
		final String sourceSystemName = header.getMessageSource().getApplicationName();
		MaintainRelationshipValidator.validateRequest(messageUUID, sourceSystemName, request);
		try {
			LoggingContextHolder.getLoggingContext().setContext(messageUUID, sourceSystemName);
			LoggerHandler.LogOut("INFO", "1", messageUUID, sourceSystemName, this.getClass().getName(),
					"Entering readPartyRelationship EndPoint " + loggerUtils.writeAsJson(request));
			reply = maintainRelationshipService.readPartyRelationship(messageUUID, sourceSystemName, request);
			LoggerHandler.LogOut("INFO", "4", messageUUID, sourceSystemName, this.getClass().getName(),
					"Exiting readPartyRelationship EndPoint " + loggerUtils.writeAsJson(reply));
		} catch (final Exception e) {
			LoggerHandler.ErrorOut(e, messageUUID, sourceSystemName, this.getClass().getName(), e.getMessage());
			throw e;
		}

		// add response header as a property to be used by EndpointInterceptor
		// Current service does not modify header on response
		messageContext.setProperty(HeaderKey.JH_HEADER_KEY.getValue(), header);
		LoggingContextHolder.getLoggingContext().clear();

		return reply;
	}

	private JHHeader parseHeader(final SoapHeaderElement jhHeaderElement) {
		// parse JH Header if present
		JHHeader header = null;
		if (null != jhHeaderElement) {
			header = jhHeaderJaxbUtils.unmarshallJHHeader(jhHeaderElement);
		} else {
			throw new BadRequestException("Missing Header");
		}

		return header;
	}

	private void validateHeader(final JHHeader header) {
		if ((header == null) || (header.getMessageSource() == null)
				|| StringUtils.isEmpty(header.getMessageSource().getApplicationName())) {
			throw new BadRequestException("Invalid Header Sent");
		}
	}

}
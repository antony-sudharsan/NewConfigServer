package com.jh.signator.maintain.relationship.dao;

import java.util.List;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Profile;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.jh.common.logging.LoggerHandler;
import com.jh.signator.maintain.relationship.exception.RecordNotFoundException;
import com.jh.signator.maintain.relationship.mapper.MaintainRelationshipByNameRowMapper;
import com.jh.signator.maintain.relationship.mapper.MaintainRelationshipPartyLookUpRowMapper;
import com.jh.signator.maintain.relationship.mapper.MaintainRelationshipRowMapper;
import com.jh.signator.maintain.relationship.model.data.LookupByConcatenation;
import com.jh.signator.maintain.relationship.model.data.PartyLookUpResponse;
import com.manulife.esb.xsd.distribution.jhfn.partyrelationship.ReadPartyRelationshipReply;
import com.manulife.esb.xsd.distribution.jhfn.partyrelationship.Relation;

/**
 * Implementation for Dao handling queries related to the read operation.
 */
@Repository
@Profile("!test-fake")
public class MaintainRelationshipReadDaoImpl implements MaintainRelationshipReadDao {
	@Autowired
	private JdbcTemplate jdbcTemplate;
	@Autowired
	private MaintainRelationshipRowMapper maintainRelationshipRowMapper;

	@Autowired
	private MaintainRelationshipByNameRowMapper maintainRelationshipByNameRowMapper;

	@Autowired
	private MaintainRelationshipPartyLookUpRowMapper maintainRelationshipPartyLookUpRowMapper;

	@Value("${RequestTimeoutLimit}")
	private int requestTimeoutLimit;

	public static final String SQL_READ_PARTY_REL = "SELECT 	t.transaction_id_no,	t.party_id_no,	p.prd_id,	r.role_cd,	t.other_role,	t.rep_party_id_no,	rep.prd_id as rep_prd_id,t.transaction_eff_date,  t.transaction_end_date,	t.creat_dtm,	t.creat_by_nm,	t.last_upd_dtm,	t.last_upd_by_nm FROM ttransaction t (nolock) 	INNER JOIN tparty_role r (nolock) ON t.party_id_no = r.party_id_no 	and r.role_typ_cd = 'BIZPF'	  and r.party_role_id_no = (select max(party_role_id_no) from tparty_role where party_id_no = t.party_id_no and role_typ_cd = 'BIZPF') INNER JOIN tparty p (nolock) ON t.party_id_no = p.party_id_no	LEFT OUTER JOIN tparty rep (nolock) ON t.rep_party_id_no = rep.party_id_no WHERE t.transaction_id_no  = ?";
	public static final String SQL_LOOK_CONCATL = "SELECT distinct  t.transaction_id_no, t.party_id_no, p.prd_id, r.role_cd, t.other_role, t.rep_party_id_no, rep.prd_id as agent_prd_id, agent_org.party_id_no as agent_org_party_id_no, agent_org.prd_id as agent_org_prd_id, org.party_id_no as org_party_id_no, org.prd_id as org_prd_id, org.org_agency_cd, pc.agency_cd, p2p.party2_id_no, t.transaction_eff_date,     t.transaction_end_date, t.creat_dtm, t.creat_by_nm, t.last_upd_dtm, t.last_upd_by_nm FROM ttransaction t (nolock) INNER JOIN tparty_role r (nolock) ON t.party_id_no = r.party_id_no  and r.role_typ_cd = 'BIZPF' and r.party_role_id_no = (select max(party_role_id_no) from tparty_role where party_id_no = t.party_id_no and role_typ_cd = 'BIZPF') INNER JOIN tparty p (nolock) ON t.party_id_no = p.party_id_no LEFT JOIN tparty rep (nolock) ON rep.party_id_no = t.rep_party_id_no LEFT JOIN tproducer pr (nolock) ON p.party_id_no = pr.party_id_no LEFT JOIN tprdcr_con pc (nolock) ON pr.prdcr_id_no = pc.prdcr_id_no  and pc.PRIM_CON_IND = '1' LEFT JOIN tparty agent_org (nolock) ON pc.agency_cd = agent_org.org_agency_cd LEFT JOIN tparty_to_party p2p (nolock) ON p.party_id_no = p2p.party1_id_no and p2p.RELATIONSHIP_TYP_CD not in ('PRADM','SUPPR')     LEFT JOIN tparty org (nolock) ON org.party_id_no = p2p.party2_id_no  WHERE  (org.org_agency_cd = ? or pc.agency_cd = ?)";
	public static final String SQL_PARTY_LOOKUP_RESP = "SELECT distinct	p.party_id_no,	p.prd_id,		pc.agency_cd,	org.org_agency_cd FROM tparty p (nolock) LEFT JOIN tproducer pr (nolock) ON p.party_id_no = pr.party_id_no 	LEFT JOIN tprdcr_con pc (nolock) 	ON pr.prdcr_id_no = pc.prdcr_id_no  and pc.PRIM_CON_IND = '1' LEFT JOIN tparty_to_party p2p (nolock) 	ON p.party_id_no = p2p.party1_id_no and p2p.RELATIONSHIP_TYP_CD not in ('PRADM','SUPPR') LEFT JOIN tparty org (nolock) ON p2p.party2_id_no = org.party_id_no WHERE p.party_id_no = ? order by pc.agency_cd, org.org_agency_cd";

	@PostConstruct
	public void init() {

		if (requestTimeoutLimit != 0) {
			this.jdbcTemplate.setQueryTimeout(requestTimeoutLimit);
		}
	}

	@Override
	public ReadPartyRelationshipReply readPartyRelationshipByID(final String relationID, final String messageUUID,
			final String sourceSystemName) {

		List<Relation> relation = null;

		relation = jdbcTemplate.query(SQL_READ_PARTY_REL, new Object[] { relationID }, maintainRelationshipRowMapper);
		LoggerHandler.LogOut("DEBUG", "2d", messageUUID, sourceSystemName, this.getClass().getName(),
				"Inside DAO readPartyRelationshipByID " + SQL_READ_PARTY_REL);

		if (relation.isEmpty()) {
			throw new RecordNotFoundException();
		}
		final ReadPartyRelationshipReply readPartyRelationshipReply = new ReadPartyRelationshipReply();
		readPartyRelationshipReply.setRelation(relation.get(0));
		return readPartyRelationshipReply;

	}

	@Override
	public List<LookupByConcatenation> readPartyRelationship(final String orgAgencyCode, final String agencyCode,
			final String messageUUID, final String sourceSystemName) {

		List<LookupByConcatenation> lookupByConcatenation = null;

		new ReadPartyRelationshipReply();
		LoggerHandler.LogOut("DEBUG", "2d", messageUUID, sourceSystemName, this.getClass().getName(),
				"Inside DAO readPartyRelationship " + SQL_LOOK_CONCATL);

		lookupByConcatenation = jdbcTemplate.query(SQL_LOOK_CONCATL, new Object[] { orgAgencyCode, agencyCode },
				maintainRelationshipByNameRowMapper);

		if (lookupByConcatenation.isEmpty()) {
			throw new RecordNotFoundException();
		}

		return lookupByConcatenation;

	}

	public PartyLookUpResponse partyLookUpResponse(final String relationId, final String messageUUID,
			final String sourceSystemName) {

		List<PartyLookUpResponse> partyLookUpResponse = null;

		LoggerHandler.LogOut("DEBUG", "2d", messageUUID, sourceSystemName, this.getClass().getName(),
				"Inside DAO PartyLookUpRelationship " + SQL_PARTY_LOOKUP_RESP);
		partyLookUpResponse = jdbcTemplate.query(SQL_PARTY_LOOKUP_RESP, new Object[] { relationId },
				maintainRelationshipPartyLookUpRowMapper);

		LoggerHandler.LogOut("INFO", "3", messageUUID, sourceSystemName, this.getClass().getName(),
				"Exiting getContractDetailsData ");
		LoggerHandler.LogOut("DEBUG", "3", messageUUID, sourceSystemName, this.getClass().getName(),
				"Passed getContractDetailsData");

		if (partyLookUpResponse.isEmpty()) {
			throw new RecordNotFoundException();
		}

		return partyLookUpResponse.get(0);

	}

}

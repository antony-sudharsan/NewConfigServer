package com.jh.signator.maintain.relationship.model.data;

import java.math.BigDecimal;
import java.sql.Timestamp;

import org.apache.commons.lang3.builder.ToStringBuilder;

public class SearchBusinessPlatformLookUpResult {

	private String transactionIdNo;
	private BigDecimal partyIdNo;
	private String prdId;
	private String roleCd;
	private String otherRole;
	private BigDecimal repPartyIdNo;
	private String agentPrdId;
	private BigDecimal agentOrgPartyIdNo;
	private String agentOrgPrdId;
	private BigDecimal orgPartyIdNo;
	private String orgPrdId;
	private BigDecimal firmCd;
	private BigDecimal orgAgencyCd;
	private BigDecimal agencyCd;
	private BigDecimal party2IdNo;
	private Timestamp transactionEffDate;
	private Timestamp transactionEndDate;
	private Timestamp creatDtm;
	private String creatByNm;
	private Timestamp lastUpdDtm;
	private String lastUpdByNm;
	private String txnStatus;

	public String getTransactionIdNo() {
		return transactionIdNo;
	}

	public void setTransactionIdNo(final String transactionIdNo) {
		this.transactionIdNo = transactionIdNo;
	}

	public BigDecimal getPartyIdNo() {
		return partyIdNo;
	}

	public void setPartyIdNo(final BigDecimal partyIdNo) {
		this.partyIdNo = partyIdNo;
	}

	public String getPrdId() {
		return prdId;
	}

	public void setPrdId(final String prdId) {
		this.prdId = prdId;
	}

	public String getRoleCd() {
		return roleCd;
	}

	public void setRoleCd(final String roleCd) {
		this.roleCd = roleCd;
	}

	public String getOtherRole() {
		return otherRole;
	}

	public void setOtherRole(final String otherRole) {
		this.otherRole = otherRole;
	}

	public BigDecimal getRepPartyIdNo() {
		return repPartyIdNo;
	}

	public void setRepPartyIdNo(final BigDecimal repPartyIdNo) {
		this.repPartyIdNo = repPartyIdNo;
	}

	public String getAgentPrdId() {
		return agentPrdId;
	}

	public void setAgentPrdId(final String agentPrdId) {
		this.agentPrdId = agentPrdId;
	}

	public BigDecimal getAgentOrgPartyIdNo() {
		return agentOrgPartyIdNo;
	}

	public void setAgentOrgPartyIdNo(final BigDecimal agentOrgPartyIdNo) {
		this.agentOrgPartyIdNo = agentOrgPartyIdNo;
	}

	public String getAgentOrgPrdId() {
		return agentOrgPrdId;
	}

	public void setAgentOrgPrdId(final String agentOrgPrdId) {
		this.agentOrgPrdId = agentOrgPrdId;
	}

	public BigDecimal getOrgPartyIdNo() {
		return orgPartyIdNo;
	}

	public void setOrgPartyIdNo(final BigDecimal orgPartyIdNo) {
		this.orgPartyIdNo = orgPartyIdNo;
	}

	public String getOrgPrdId() {
		return orgPrdId;
	}

	public void setOrgPrdId(final String orgPrdId) {
		this.orgPrdId = orgPrdId;
	}

	public BigDecimal getFirmCd() {
		return firmCd;
	}

	public void setFirmCd(final BigDecimal firmCd) {
		this.firmCd = firmCd;
	}

	public BigDecimal getOrgAgencyCd() {
		return orgAgencyCd;
	}

	public void setOrgAgencyCd(final BigDecimal orgAgencyCd) {
		this.orgAgencyCd = orgAgencyCd;
	}

	public BigDecimal getAgencyCd() {
		return agencyCd;
	}

	public void setAgencyCd(final BigDecimal agencyCd) {
		this.agencyCd = agencyCd;
	}

	public BigDecimal getParty2IdNo() {
		return party2IdNo;
	}

	public void setParty2IdNo(final BigDecimal party2IdNo) {
		this.party2IdNo = party2IdNo;
	}

	public Timestamp getTransactionEffDate() {
		return transactionEffDate;
	}

	public void setTransactionEffDate(final Timestamp transactionEffDate) {
		this.transactionEffDate = transactionEffDate;
	}

	public Timestamp getTransactionEndDate() {
		return transactionEndDate;
	}

	public void setTransactionEndDate(final Timestamp transactionEndDate) {
		this.transactionEndDate = transactionEndDate;
	}

	public Timestamp getCreatDtm() {
		return creatDtm;
	}

	public void setCreatDtm(final Timestamp creatDtm) {
		this.creatDtm = creatDtm;
	}

	public String getCreatByNm() {
		return creatByNm;
	}

	public void setCreatByNm(final String creatByNm) {
		this.creatByNm = creatByNm;
	}

	public Timestamp getLastUpdDtm() {
		return lastUpdDtm;
	}

	public void setLastUpdDtm(final Timestamp lastUpdDtm) {
		this.lastUpdDtm = lastUpdDtm;
	}

	public String getLastUpdByNm() {
		return lastUpdByNm;
	}

	public void setLastUpdByNm(final String lastUpdByNm) {
		this.lastUpdByNm = lastUpdByNm;
	}

	public String getTxnStatus() {
		return txnStatus;
	}

	public void setTxnStatus(final String txnStatus) {
		this.txnStatus = txnStatus;
	}

	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}

}

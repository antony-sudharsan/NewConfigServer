package com.jh.signator.maintain.relationship;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MaintainRelationshipApplication {
	

	public static void main(String[] args) {
		SpringApplication.run(MaintainRelationshipApplication.class, args);
	}
	

}

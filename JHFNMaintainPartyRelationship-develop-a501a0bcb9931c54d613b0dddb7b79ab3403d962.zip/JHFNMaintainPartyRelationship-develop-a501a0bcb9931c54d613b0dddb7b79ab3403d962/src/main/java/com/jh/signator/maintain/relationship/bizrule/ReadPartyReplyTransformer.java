package com.jh.signator.maintain.relationship.bizrule;

import java.math.BigInteger;
import java.util.List;
import java.util.Optional;

import org.apache.commons.lang3.StringUtils;

import com.jh.common.utility.DataMappingCrossLookUp;
import com.jh.signator.maintain.relationship.model.data.LookupByConcatenation;
import com.jh.signator.maintain.relationship.model.data.PartyLookUpResponse;
import com.jh.signator.maintain.relationship.utils.SearchPartyUtils;
import com.manulife.esb.xsd.distribution.jhfn.partyrelationship.RELATIONIDREF;
import com.manulife.esb.xsd.distribution.jhfn.partyrelationship.ReadPartyRelationshipReply;
import com.manulife.esb.xsd.distribution.jhfn.partyrelationship.ReadPartyRelationshipRequest;
import com.manulife.esb.xsd.distribution.jhfn.partyrelationship.Relation;

public class ReadPartyReplyTransformer {
	public static final BigInteger ID_REF_TYPE_DEFAULT = new BigInteger("8000");
	public static final BigInteger ID_REF_TYPE_OTHER = new BigInteger("8001");
	protected static final Integer DEFAULT_SEQUENCE = 0;
	protected static final String TEMPORARY_ROLE_IND = "0";
	protected static final BigInteger BUSINESS_REL = new BigInteger("9200");
	protected static final Double DEFAULT_PERCENT = 0d;

	public ReadPartyRelationshipReply populateFinalResponseByLookUp(
			final List<LookupByConcatenation> lookupByConcatenationList, final PartyLookUpResponse partyLookUpResponse,
			final ReadPartyRelationshipRequest readPartyRelationshipRequest) {

		final ReadPartyRelationshipReply readPartyRelationshipReply = new ReadPartyRelationshipReply();

		final Relation relation = new Relation();
		final String id;
		final String prd_id;

		//
		final Optional<LookupByConcatenation> match = (lookupByConcatenationList.stream()
				.filter(s -> s.getParty_id_no().equals(partyLookUpResponse.getParty_id_no()))).findFirst();
		if (match.isPresent()) {
			final LookupByConcatenation lookupByConcatenation = match.get();
			if (StringUtils.substringAfter(readPartyRelationshipRequest.getRelationID(), ",")
					.equalsIgnoreCase(lookupByConcatenation.getAgent_org_party_id_no().toString())) {

				relation.setRelationID(lookupByConcatenation.getParty_id_no() + ","
						+ lookupByConcatenation.getAgent_org_party_id_no().toString());
				relation.setStartDate(SearchPartyUtils
						.convertTimestampToXmlGregorianCalendar(lookupByConcatenation.getTransaction_eff_date()));
				relation.setEndDate(SearchPartyUtils
						.convertTimestampToXmlGregorianCalendar(lookupByConcatenation.getTransaction_end_date()));
				relation.setRelationIDRef(RELATIONIDREF.CONCATENATION);
				relation.setCreatedDate(
						SearchPartyUtils.convertTimestampToXmlGregorianCalendar(lookupByConcatenation.getCreat_dtm()));
				relation.setCreatedByNm(lookupByConcatenation.getCreat_by_nm());
				relation.setUpdatedByNm(lookupByConcatenation.getLast_upd_by_nm());
				relation.setUpdatedDate(SearchPartyUtils
						.convertTimestampToXmlGregorianCalendar(lookupByConcatenation.getLast_upd_dtm()));
				id = lookupByConcatenation.getPrd_id();
				prd_id = lookupByConcatenation.getOrg_prd_id();

				if ((StringUtils.isEmpty(id)) || (StringUtils.isEmpty(prd_id))) {
					relation.setRelatedRefID(lookupByConcatenation.getAgent_org_party_id_no().toString());
					relation.setRelatedRefIDType(ID_REF_TYPE_DEFAULT);
				} else {
					relation.setRelatedRefID(lookupByConcatenation.getOrg_prd_id().toString());
					relation.setRelatedRefIDType(ID_REF_TYPE_OTHER);
				}

				if (lookupByConcatenation.getRole_cd() == null) {
					relation.setRelationRoleCode(BigInteger
							.valueOf(Long.parseLong(DataMappingCrossLookUp.getValue("RELATIONROLECODE", "OTHERWISE"))));
				} else {
					if (lookupByConcatenation.getRole_cd().length() == 0) {
						relation.setRelationRoleCode(BigInteger.valueOf(
								Long.parseLong(DataMappingCrossLookUp.getValue("RELATIONROLECODE", "OTHERWISE"))));

					} else {
						relation.setRelationRoleCode(BigInteger.valueOf(Long.parseLong(DataMappingCrossLookUp
								.getValue("RELATIONROLECODE", lookupByConcatenation.getRole_cd()))));
					}
				}

				final String rep_prd_id = lookupByConcatenation.getOrg_prd_id();

				if ((StringUtils.isEmpty(lookupByConcatenation.getPrd_id())
						|| (StringUtils.isEmpty(lookupByConcatenation.getOrg_prd_id())))) {
					relation.setRelatedRefID(lookupByConcatenation.getAgent_org_party_id_no().toString());
					relation.setIDReferenceType(ID_REF_TYPE_DEFAULT);
					relation.setIDReferenceNo(lookupByConcatenation.getParty_id_no().toString());
				} else {
					relation.setRelatedRefID(rep_prd_id);
					relation.setIDReferenceType(ID_REF_TYPE_OTHER);
					relation.setIDReferenceNo(lookupByConcatenation.getPrd_id());
				}

				relation.setTemporaryRoleInd(false);
				relation.setSequence(DEFAULT_SEQUENCE);
				relation.setBusinessRelationType(BUSINESS_REL);
				relation.setAllocationPercentage(DEFAULT_PERCENT);
			} else if (StringUtils.substringAfter(readPartyRelationshipRequest.getRelationID(), ",")
					.equalsIgnoreCase(lookupByConcatenation.getAgent_org_party_id_no().toString())) {

				relation.setRelationID(lookupByConcatenation.getParty_id_no() + ","
						+ lookupByConcatenation.getAgent_org_party_id_no().toString());
				relation.setStartDate(SearchPartyUtils
						.convertTimestampToXmlGregorianCalendar(lookupByConcatenation.getTransaction_eff_date()));
				relation.setEndDate(SearchPartyUtils
						.convertTimestampToXmlGregorianCalendar(lookupByConcatenation.getTransaction_end_date()));
				relation.setRelationIDRef(RELATIONIDREF.CONCATENATION);
				relation.setCreatedDate(
						SearchPartyUtils.convertTimestampToXmlGregorianCalendar(lookupByConcatenation.getCreat_dtm()));
				relation.setCreatedByNm(lookupByConcatenation.getCreat_by_nm());
				relation.setUpdatedByNm(lookupByConcatenation.getLast_upd_by_nm());
				relation.setUpdatedDate(SearchPartyUtils
						.convertTimestampToXmlGregorianCalendar(lookupByConcatenation.getLast_upd_dtm()));
				id = lookupByConcatenation.getPrd_id();
				prd_id = lookupByConcatenation.getOrg_prd_id();

				if ((StringUtils.isEmpty(id)) || (StringUtils.isEmpty(prd_id))) {
					relation.setRelatedRefID(lookupByConcatenation.getOrg_party_id_no().toString());
					relation.setRelatedRefIDType(ID_REF_TYPE_DEFAULT);
					relation.setIDReferenceNo(lookupByConcatenation.getParty_id_no().toString());
				} else {
					relation.setRelatedRefID(lookupByConcatenation.getOrg_prd_id().toString());
					relation.setRelatedRefIDType(ID_REF_TYPE_OTHER);
					relation.setIDReferenceNo(id);
				}

				if (lookupByConcatenation.getRole_cd() == null) {
					relation.setRelationRoleCode(BigInteger
							.valueOf(Long.parseLong(DataMappingCrossLookUp.getValue("RELATIONROLECODE", "OTHERWISE"))));
				} else {
					if (lookupByConcatenation.getRole_cd().length() == 0) {
						relation.setRelationRoleCode(BigInteger.valueOf(
								Long.parseLong(DataMappingCrossLookUp.getValue("RELATIONROLECODE", "OTHERWISE"))));

					} else {
						relation.setRelationRoleCode(BigInteger.valueOf(Long.parseLong(DataMappingCrossLookUp
								.getValue("RELATIONROLECODE", lookupByConcatenation.getRole_cd()))));
					}
				}

				relation.setTemporaryRoleInd(false);
				relation.setSequence(DEFAULT_SEQUENCE);
				relation.setBusinessRelationType(BUSINESS_REL);
				relation.setAllocationPercentage(DEFAULT_PERCENT);

			} else {

				relation.setRelationID(readPartyRelationshipRequest.getRelationIDRef().value());
				relation.setStartDate(SearchPartyUtils
						.convertTimestampToXmlGregorianCalendar(lookupByConcatenation.getTransaction_eff_date()));
				relation.setEndDate(SearchPartyUtils
						.convertTimestampToXmlGregorianCalendar(lookupByConcatenation.getTransaction_end_date()));
				relation.setRelationIDRef(RELATIONIDREF.CONCATENATION);
				relation.setCreatedDate(
						SearchPartyUtils.convertTimestampToXmlGregorianCalendar(lookupByConcatenation.getCreat_dtm()));
				relation.setCreatedByNm(lookupByConcatenation.getCreat_by_nm());
				relation.setUpdatedByNm(lookupByConcatenation.getLast_upd_by_nm());
				relation.setUpdatedDate(SearchPartyUtils
						.convertTimestampToXmlGregorianCalendar(lookupByConcatenation.getLast_upd_dtm()));
				id = lookupByConcatenation.getPrd_id();
				prd_id = lookupByConcatenation.getOrg_prd_id();

				if ((StringUtils.isEmpty(id)) || (StringUtils.isEmpty(prd_id))) {
					relation.setRelatedRefID(lookupByConcatenation.getOrg_party_id_no().toString());
					relation.setRelatedRefIDType(ID_REF_TYPE_DEFAULT);
				} else {
					relation.setRelatedRefID(lookupByConcatenation.getOrg_prd_id().toString());
					relation.setRelatedRefIDType(ID_REF_TYPE_OTHER);
				}

				if (lookupByConcatenation.getRole_cd() == null) {
					relation.setRelationRoleCode(BigInteger
							.valueOf(Long.parseLong(DataMappingCrossLookUp.getValue("RELATIONROLECODE", "OTHERWISE"))));
				} else {
					if (lookupByConcatenation.getRole_cd().length() == 0) {
						relation.setRelationRoleCode(BigInteger.valueOf(
								Long.parseLong(DataMappingCrossLookUp.getValue("RELATIONROLECODE", "OTHERWISE"))));

					} else {
						relation.setRelationRoleCode(BigInteger.valueOf(Long.parseLong(DataMappingCrossLookUp
								.getValue("RELATIONROLECODE", lookupByConcatenation.getRole_cd()))));
					}
				}

				final String rep_prd_id = lookupByConcatenation.getOrg_prd_id();

				if ((StringUtils.isEmpty(lookupByConcatenation.getPrd_id())
						|| (StringUtils.isEmpty(lookupByConcatenation.getOrg_prd_id())))) {
					relation.setRelatedRefID(lookupByConcatenation.getAgent_org_party_id_no().toString());
					relation.setIDReferenceType(ID_REF_TYPE_DEFAULT);
					relation.setIDReferenceNo(lookupByConcatenation.getParty_id_no().toString());
				} else {
					relation.setRelatedRefID(rep_prd_id);
					relation.setIDReferenceType(ID_REF_TYPE_OTHER);
					relation.setIDReferenceNo(lookupByConcatenation.getPrd_id());
				}

				relation.setTemporaryRoleInd(false);
				relation.setSequence(DEFAULT_SEQUENCE);
				relation.setBusinessRelationType(BUSINESS_REL);
				relation.setAllocationPercentage(DEFAULT_PERCENT);

			}
		}

		readPartyRelationshipReply.setRelation(relation);
		return readPartyRelationshipReply;
	}

}
package com.jh.signator.maintain.relationship.model.data;

import org.apache.commons.lang3.builder.ToStringBuilder;

public class SearchPartyLookupCriteria {

	private String prdId;
	private String prdIdP2p;
	private String prdIdNoP2p;
	private String prdIdNo;
	private String prdIdContract;
	private String prdIdNoContract;
	private String prdIdContractTerm;
	private String prdIdNoContractTerm;
	private String prdIdNoP2pTerm;
	private String prdIdP2pTerm;
	 
	
	public String getPrdId() {
		return prdId;
	}


	public void setPrdId(String prdId) {
		this.prdId = prdId;
	}


	public String getPrdIdP2p() {
		return prdIdP2p;
	}


	public void setPrdIdP2p(String prdIdP2p) {
		this.prdIdP2p = prdIdP2p;
	}


	public String getPrdIdNoP2p() {
		return prdIdNoP2p;
	}


	public void setPrdIdNoP2p(String prdIdNoP2p) {
		this.prdIdNoP2p = prdIdNoP2p;
	}


	public String getPrdIdNo() {
		return prdIdNo;
	}


	public void setPrdIdNo(String prdIdNo) {
		this.prdIdNo = prdIdNo;
	}


	public String getPrdIdContract() {
		return prdIdContract;
	}


	public void setPrdIdContract(String prdIdContract) {
		this.prdIdContract = prdIdContract;
	}


	public String getPrdIdNoContract() {
		return prdIdNoContract;
	}


	public void setPrdIdNoContract(String prdIdNoContract) {
		this.prdIdNoContract = prdIdNoContract;
	}


	public String getPrdIdContractTerm() {
		return prdIdContractTerm;
	}


	public void setPrdIdContractTerm(String prdIdContractTerm) {
		this.prdIdContractTerm = prdIdContractTerm;
	}


	public String getPrdIdNoContractTerm() {
		return prdIdNoContractTerm;
	}


	public void setPrdIdNoContractTerm(String prdIdNoContractTerm) {
		this.prdIdNoContractTerm = prdIdNoContractTerm;
	}


	public String getPrdIdNoP2pTerm() {
		return prdIdNoP2pTerm;
	}


	public void setPrdIdNoP2pTerm(String prdIdNoP2pTerm) {
		this.prdIdNoP2pTerm = prdIdNoP2pTerm;
	}


	public String getPrdIdP2pTerm() {
		return prdIdP2pTerm;
	}


	public void setPrdIdP2pTerm(String prdIdP2pTerm) {
		this.prdIdP2pTerm = prdIdP2pTerm;
	}


	public String toString() {
		return ToStringBuilder.reflectionToString(this);
    }
}

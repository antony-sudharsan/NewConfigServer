package com.jh.signator.maintain.relationship.model.data;

import java.sql.Timestamp;

public class LookupByConcatenation {

	public String transaction_id_no;
	public Double party_id_no;
	public String prd_id;
	public String role_cd;
	public String other_role;
	public Double rep_party_id_no;
	public String agent_prd_id;
	public Double agent_org_party_id_no;
	public String agent_org_prd_id;
	public Double org_party_id_no;
	public String org_prd_id;
	public Double org_agency_cd;
	public Double agency_cd;
	public Double party2_id_no;
	public Timestamp transaction_eff_date;
	public Timestamp transaction_end_date;
	public Timestamp creat_dtm;
	public String creat_by_nm;
	public Timestamp last_upd_dtm;
	public String last_upd_by_nm;

	public String getTransaction_id_no() {
		return transaction_id_no;
	}

	public void setTransaction_id_no(final String transaction_id_no) {
		this.transaction_id_no = transaction_id_no;
	}

	public Double getParty_id_no() {
		return party_id_no;
	}

	public void setParty_id_no(final Double party_id_no) {
		this.party_id_no = party_id_no;
	}

	public String getPrd_id() {
		return prd_id;
	}

	public void setPrd_id(final String prd_id) {
		this.prd_id = prd_id;
	}

	public String getRole_cd() {
		return role_cd;
	}

	public void setRole_cd(final String role_cd) {
		this.role_cd = role_cd;
	}

	public String getOther_role() {
		return other_role;
	}

	public void setOther_role(final String other_role) {
		this.other_role = other_role;
	}

	public Double getRep_party_id_no() {
		return rep_party_id_no;
	}

	public void setRep_party_id_no(final Double rep_party_id_no) {
		this.rep_party_id_no = rep_party_id_no;
	}

	public String getAgent_prd_id() {
		return agent_prd_id;
	}

	public void setAgent_prd_id(final String agent_prd_id) {
		this.agent_prd_id = agent_prd_id;
	}

	public Double getAgent_org_party_id_no() {
		return agent_org_party_id_no;
	}

	public void setAgent_org_party_id_no(final Double agent_org_party_id_no) {
		this.agent_org_party_id_no = agent_org_party_id_no;
	}

	public String getAgent_org_prd_id() {
		return agent_org_prd_id;
	}

	public void setAgent_org_prd_id(final String agent_org_prd_id) {
		this.agent_org_prd_id = agent_org_prd_id;
	}

	public Double getOrg_party_id_no() {
		return org_party_id_no;
	}

	public void setOrg_party_id_no(final Double org_party_id_no) {
		this.org_party_id_no = org_party_id_no;
	}

	public String getOrg_prd_id() {
		return org_prd_id;
	}

	public void setOrg_prd_id(final String org_prd_id) {
		this.org_prd_id = org_prd_id;
	}

	public Double getOrg_agency_cd() {
		return org_agency_cd;
	}

	public void setOrg_agency_cd(final Double org_agency_cd) {
		this.org_agency_cd = org_agency_cd;
	}

	public Double getAgency_cd() {
		return agency_cd;
	}

	public void setAgency_cd(final Double agency_cd) {
		this.agency_cd = agency_cd;
	}

	public Double getParty2_id_no() {
		return party2_id_no;
	}

	public void setParty2_id_no(final Double party2_id_no) {
		this.party2_id_no = party2_id_no;
	}

	public Timestamp getTransaction_eff_date() {
		return transaction_eff_date;
	}

	public void setTransaction_eff_date(final Timestamp transaction_eff_date) {
		this.transaction_eff_date = transaction_eff_date;
	}

	public Timestamp getTransaction_end_date() {
		return transaction_end_date;
	}

	public void setTransaction_end_date(final Timestamp transaction_end_date) {
		this.transaction_end_date = transaction_end_date;
	}

	public Timestamp getCreat_dtm() {
		return creat_dtm;
	}

	public void setCreat_dtm(final Timestamp creat_dtm) {
		this.creat_dtm = creat_dtm;
	}

	public String getCreat_by_nm() {
		return creat_by_nm;
	}

	public void setCreat_by_nm(final String creat_by_nm) {
		this.creat_by_nm = creat_by_nm;
	}

	public Timestamp getLast_upd_dtm() {
		return last_upd_dtm;
	}

	public void setLast_upd_dtm(final Timestamp last_upd_dtm) {
		this.last_upd_dtm = last_upd_dtm;
	}

	public String getLast_upd_by_nm() {
		return last_upd_by_nm;
	}

	public void setLast_upd_by_nm(final String last_upd_by_nm) {
		this.last_upd_by_nm = last_upd_by_nm;
	}

	@Override
	public String toString() {
		return "LookupByConcatenation [transaction_id_no=" + transaction_id_no + ", party_id_no=" + party_id_no + ", prd_id=" + prd_id + ", role_cd=" + role_cd
				+ ", other_role=" + other_role + ", rep_party_id_no=" + rep_party_id_no + ", agent_prd_id=" + agent_prd_id + ", agent_org_party_id_no="
				+ agent_org_party_id_no + ", agent_org_prd_id=" + agent_org_prd_id + ", org_party_id_no=" + org_party_id_no + ", org_prd_id=" + org_prd_id
				+ ", org_agency_cd=" + org_agency_cd + ", agency_cd=" + agency_cd + ", party2_id_no=" + party2_id_no + ", transaction_eff_date="
				+ transaction_eff_date + ", transaction_end_date=" + transaction_end_date + ", creat_dtm=" + creat_dtm + ", creat_by_nm=" + creat_by_nm
				+ ", last_upd_dtm=" + last_upd_dtm + ", last_upd_by_nm=" + last_upd_by_nm + "]";
	}

}

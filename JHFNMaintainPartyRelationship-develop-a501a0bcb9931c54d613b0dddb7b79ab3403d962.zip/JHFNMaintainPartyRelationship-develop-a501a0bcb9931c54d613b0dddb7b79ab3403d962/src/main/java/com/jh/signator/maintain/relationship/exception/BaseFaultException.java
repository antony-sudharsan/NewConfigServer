package com.jh.signator.maintain.relationship.exception;

import org.apache.commons.lang3.builder.ToStringBuilder;

public abstract class BaseFaultException extends RuntimeException {

	private static final long serialVersionUID = 1387749572104551287L;
	private String code;
	private String reason;
	private String details;

	public BaseFaultException(final String code, final String reason, final String details, final String message) {
		super(message);
		this.code = code;
		this.reason = reason;
		this.details = details;
	}

	public BaseFaultException(final String code, final String reason, final String details, final String message,
			final Throwable cause) {
		super(message, cause);
		this.code = code;
		this.reason = reason;
		this.details = details;
	}

	public String getCode() {
		return code;
	}

	public void setCode(final String code) {
		this.code = code;
	}

	public String getReason() {
		return reason;
	}

	public void setReason(final String reason) {
		this.reason = reason;
	}

	public String getDetails() {
		return details;
	}

	public void setDetails(final String details) {
		this.details = details;
	}

	public ExceptionResponse getExceptionResponse() {
		return new ExceptionResponse(this.code, this.reason, this.getDetails());
	}

	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}

}

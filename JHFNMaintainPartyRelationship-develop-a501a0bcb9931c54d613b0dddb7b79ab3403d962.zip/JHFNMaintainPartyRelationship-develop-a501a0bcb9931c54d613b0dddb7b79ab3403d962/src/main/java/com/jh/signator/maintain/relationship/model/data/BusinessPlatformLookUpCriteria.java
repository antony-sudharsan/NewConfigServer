package com.jh.signator.maintain.relationship.model.data;

public class BusinessPlatformLookUpCriteria {

	private String org_agency_cd;
	private String agency_cd;

	public String getOrg_agency_cd() {
		return org_agency_cd;
	}

	public void setOrg_agency_cd(final String org_agency_cd) {
		this.org_agency_cd = org_agency_cd;
	}

	public String getAgency_cd() {
		return agency_cd;
	}

	public void setAgency_cd(final String agency_cd) {
		this.agency_cd = agency_cd;
	}

	@Override
	public String toString() {
		return "BusinessPlatformLookUpCriteria [org_agency_cd=" + org_agency_cd + ", agency_cd=" + agency_cd + "]";
	}

}

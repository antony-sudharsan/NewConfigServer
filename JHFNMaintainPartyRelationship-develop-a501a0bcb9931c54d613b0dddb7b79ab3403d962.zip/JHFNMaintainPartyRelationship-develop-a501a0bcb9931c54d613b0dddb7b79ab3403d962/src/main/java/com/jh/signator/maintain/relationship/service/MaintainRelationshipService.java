package com.jh.signator.maintain.relationship.service;

import java.math.BigInteger;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jh.common.logging.LoggerHandler;
import com.jh.signator.maintain.relationship.bizrule.ReadPartyReplyTransformer;
import com.jh.signator.maintain.relationship.bizrule.SearchPartyReplyActiveOnlyResultTransformer;
import com.jh.signator.maintain.relationship.bizrule.SearchPartyReplyAllResultTransformer;
import com.jh.signator.maintain.relationship.dao.MaintainRelationshipReadDao;
import com.jh.signator.maintain.relationship.dao.MaintainRelationshipSearchDao;
import com.jh.signator.maintain.relationship.exception.RecordNotFoundException;
import com.jh.signator.maintain.relationship.model.data.BusinessPlatformLookUpCriteria;
import com.jh.signator.maintain.relationship.model.data.PartyLookUpResponse;
import com.jh.signator.maintain.relationship.model.data.PartyLookupResult;
import com.jh.signator.maintain.relationship.model.data.SearchBusinessPlatformLookUpResult;
import com.jh.signator.maintain.relationship.model.data.SearchPartyLookupCriteria;
import com.jh.signator.maintain.relationship.utils.LoggerUtils;
import com.jh.signator.maintain.relationship.utils.SearchPartyUtils;
import com.manulife.esb.xsd.distribution.jhfn.partyrelationship.RELATIONIDREF;
import com.manulife.esb.xsd.distribution.jhfn.partyrelationship.ReadPartyRelationshipReply;
import com.manulife.esb.xsd.distribution.jhfn.partyrelationship.ReadPartyRelationshipRequest;
import com.manulife.esb.xsd.distribution.jhfn.partyrelationship.Relation;
import com.manulife.esb.xsd.distribution.jhfn.partyrelationship.SEARCHSTATUS;
import com.manulife.esb.xsd.distribution.jhfn.partyrelationship.SearchPartyRelationshipReply;
import com.manulife.esb.xsd.distribution.jhfn.partyrelationship.SearchPartyRelationshipRequest;

/**
 * Business service for operations related to maintaining party relationships.
 *
 */
@Service
public class MaintainRelationshipService {
	@Autowired
	MaintainRelationshipReadDao maintainRelationshipReadDao;

	@Autowired
	MaintainRelationshipSearchDao maintainRelationshipSearchDao;

	@Autowired
	private LoggerUtils loggerUtils;

	private final ReadPartyReplyTransformer readPartyReplyTransformer = new ReadPartyReplyTransformer();

	private static final String CONTRACT_STATUS_ACTIVE = "active";
	private static final String CONTRACT_STATUS_TERMINATED = "terminated";

	public static final BigInteger ID_REF_TYPE_DEFAULT = new BigInteger("8000");
	public static final BigInteger ID_REF_TYPE_OTHER = new BigInteger("8001");

	public ReadPartyRelationshipReply readPartyRelationship(final String messageUUID, final String sourceSystemName,
			final ReadPartyRelationshipRequest readPartyRelationshipRequest) {
		// operations
		ReadPartyRelationshipReply readPartyRelationshipReplyByID = null;
		PartyLookUpResponse partyLookUpResponse = null;
		LoggerHandler.LogOut("INFO", "2", messageUUID, sourceSystemName, this.getClass().getName(),
				"Entering readPartyRelationship " + loggerUtils.writeAsJson(readPartyRelationshipRequest));

		if (readPartyRelationshipRequest.getRelationIDRef().equals(RELATIONIDREF.BUSINESS_PLATFORM)) {
			LoggerHandler.LogOut("INFO", "2a", messageUUID, sourceSystemName, this.getClass().getName(),
					"Entering readPartyRelationship CASE BUSINESS PLATFORM"
							+ loggerUtils.writeAsJson(readPartyRelationshipRequest));
			readPartyRelationshipReplyByID = populateFinalResponseByID(
					maintainRelationshipReadDao.readPartyRelationshipByID(readPartyRelationshipRequest.getRelationID(),
							messageUUID, sourceSystemName));
			// readPartyRelationshipRequest.get
		} else if (readPartyRelationshipRequest.getRelationIDRef().equals(RELATIONIDREF.CONCATENATION)) {
			LoggerHandler.LogOut("INFO", "2a", messageUUID, sourceSystemName, this.getClass().getName(),
					"Entering readPartyRelationship CASE BUSINESS CONCATENATION"
							+ loggerUtils.writeAsJson(readPartyRelationshipRequest));
			partyLookUpResponse = maintainRelationshipReadDao
					.partyLookUpResponse(readPartyRelationshipRequest.getRelationID(), messageUUID, sourceSystemName);
			LoggerHandler.LogOut("INFO", "2b", messageUUID, sourceSystemName, this.getClass().getName(),
					"Entering readPartyRelationship CASE BUSINESS CONCATENATION Party Lookup Response"
							+ partyLookUpResponse);
			readPartyRelationshipReplyByID = readPartyReplyTransformer.populateFinalResponseByLookUp(
					maintainRelationshipReadDao.readPartyRelationship(partyLookUpResponse.getOrg_agency_cd().toString(),
							partyLookUpResponse.getAgency_cd().toString(), messageUUID, sourceSystemName),
					partyLookUpResponse, readPartyRelationshipRequest);
			LoggerHandler.LogOut("INFO", "2c", messageUUID, sourceSystemName, this.getClass().getName(),
					"Entering readPartyRelationship CASE BUSINESS CONCATENATION Party readPartyRelationshipReplyByID "
							+ readPartyRelationshipReplyByID);
		}

		LoggerHandler.LogOut("INFO", "3", messageUUID, sourceSystemName, this.getClass().getName(),
				"Exiting readPartyRelationship CASE BUSINESS CONCATENATION Party readPartyRelationshipReplyByID ");

		return readPartyRelationshipReplyByID;

	}

	public SearchPartyRelationshipReply searchPartyRelationship(final String messageUUID, final String sourceSystemName,
			final SearchPartyRelationshipRequest searchPartyRelationshipRequest) {
		SearchPartyRelationshipReply searchPartyRelationshipReply = null;

		LoggerHandler.LogOut("INFO", "2", messageUUID, sourceSystemName, this.getClass().getName(),
				"Entering searchPartyRelationship " + loggerUtils.writeAsJson(searchPartyRelationshipRequest));

		// Search status is active only
		if (searchPartyRelationshipRequest.getPartySearchCriteria().getSearchStatus()
				.equals(SEARCHSTATUS.ACTIVE_ONLY)) {
			final SearchPartyLookupCriteria searchPartyLookupCriteria = SearchPartyUtils
					.populateSearchPartyLookupCriteriaForActiveOnly(searchPartyRelationshipRequest);
			LoggerHandler.LogOut("INFO", "2a", messageUUID, sourceSystemName, this.getClass().getName(),
					"Data for searchPartyRelationship query PartyLookup Result Active Only "
							+ searchPartyLookupCriteria);

			final PartyLookupResult partyLookupResult = maintainRelationshipSearchDao
					.getActiveOnlyPartyLookupResult(searchPartyLookupCriteria);

			LoggerHandler.LogOut("INFO", "2b", messageUUID, sourceSystemName, this.getClass().getName(),
					"Data from DB getAllPartyLookupResult for Active Only " + partyLookupResult);

			if (partyLookupResult != null) {
				final BusinessPlatformLookUpCriteria criteria = SearchPartyUtils
						.populateBusinessPlatformLookupCriteria(partyLookupResult);
				final List<SearchBusinessPlatformLookUpResult> searchBusinessPlatformLookUpResults = maintainRelationshipSearchDao
						.getActiveOnlyBusinessPlatformLookupResult(criteria);
				LoggerHandler.LogOut("INFO", "2c", messageUUID, sourceSystemName, this.getClass().getName(),
						"Output of searchPartyRelationship SearchPartyPlatFormLookUpResult Result  Active Only "
								+ searchBusinessPlatformLookUpResults);

				final SearchPartyReplyActiveOnlyResultTransformer transformer = new SearchPartyReplyActiveOnlyResultTransformer();

				searchPartyRelationshipReply = transformer.populateFinalResponse(searchBusinessPlatformLookUpResults,
						partyLookupResult);
				LoggerHandler.LogOut("INFO", "2d", messageUUID, sourceSystemName, this.getClass().getName(),
						"Output of searchPartyRelationship result after transformation "
								+ loggerUtils.writeAsJson(searchPartyRelationshipReply));
			} else {
				throw new RecordNotFoundException();
			}
		}
		// Search ALL
		else {
			final SearchPartyLookupCriteria searchPartyLookupCriteria = SearchPartyUtils
					.populateSearchPartyLookupCriteriaForAll(searchPartyRelationshipRequest);
			LoggerHandler.LogOut("INFO", "2a", messageUUID, sourceSystemName, this.getClass().getName(),
					"Data for searchPartyRelationship query PartyLookup Result criteria ALL ");

			final PartyLookupResult partyLookupResult = maintainRelationshipSearchDao
					.getAllPartyLookupResult(searchPartyLookupCriteria);
			LoggerHandler.LogOut("INFO", "2b", messageUUID, sourceSystemName, this.getClass().getName(),
					"Data from DB getAllPartyLookupResult for ALL" + partyLookupResult);

			if ((partyLookupResult != null) && (partyLookupResult.getFirmCd() != null)) {
				final BusinessPlatformLookUpCriteria criteria = SearchPartyUtils
						.populateBusinessPlatformLookupCriteria(partyLookupResult);
				List<SearchBusinessPlatformLookUpResult> searchBusinessPlatformLookUpResults = null;
				boolean isActive = false;

				if (CONTRACT_STATUS_ACTIVE.equals(partyLookupResult.getContractStatus())) {
					isActive = true;
					searchBusinessPlatformLookUpResults = maintainRelationshipSearchDao
							.getAllContractStatusActiveBusinessPlatformLookupResult(criteria);
					LoggerHandler.LogOut("INFO", "2c", messageUUID, sourceSystemName, this.getClass().getName(),
							"Result Contract Status Active " + searchBusinessPlatformLookUpResults);
				} else if (CONTRACT_STATUS_TERMINATED.equals(partyLookupResult.getContractStatus())) {
					searchBusinessPlatformLookUpResults = maintainRelationshipSearchDao
							.getAllContractStatusTerminatedBusinessPlatformLookupResult(criteria);
					LoggerHandler.LogOut("INFO", "2c", messageUUID, sourceSystemName, this.getClass().getName(),
							"Result from Contract Status Terminated " + searchBusinessPlatformLookUpResults);
				} else {
					throw new RecordNotFoundException();
				}

				final SearchPartyReplyAllResultTransformer transformer = new SearchPartyReplyAllResultTransformer();
				searchPartyRelationshipReply = transformer.populateFinalResponse(searchBusinessPlatformLookUpResults,
						partyLookupResult, isActive);
			} else {
				throw new RecordNotFoundException();
			}
		}

		LoggerHandler.LogOut("INFO", "3", messageUUID, sourceSystemName, this.getClass().getName(),
				"Exiting searchPartyRelationship " + loggerUtils.writeAsJson(searchPartyRelationshipReply));

		return searchPartyRelationshipReply;
	}

	private ReadPartyRelationshipReply populateFinalResponseByID(
			final ReadPartyRelationshipReply readPartyRelationshipReplyByID) {

		final Relation relation = readPartyRelationshipReplyByID.getRelation();
		relation.setTemporaryRoleInd(false);
		relation.setSequence(0);
		relation.setBusinessRelationType(BigInteger.valueOf(9200));
		relation.setAllocationPercentage(0);

		return readPartyRelationshipReplyByID;
	}

}

package com.jh.signator.maintain.relationship.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.jh.common.logging.LoggerHandler;
import com.jh.signator.maintain.relationship.service.MaintainRelationshipService;
import com.jh.signator.maintain.relationship.utils.LoggerUtils;
import com.jh.signator.maintain.relationship.utils.LoggingContextHolder;
import com.jh.signator.maintain.relationship.validator.MaintainRelationshipValidator;
import com.manulife.esb.xsd.distribution.jhfn.partyrelationship.ReadPartyRelationshipReply;
import com.manulife.esb.xsd.distribution.jhfn.partyrelationship.ReadPartyRelationshipRequest;
import com.manulife.esb.xsd.distribution.jhfn.partyrelationship.SearchPartyRelationshipReply;
import com.manulife.esb.xsd.distribution.jhfn.partyrelationship.SearchPartyRelationshipRequest;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

@RestController
@EnableSwagger2
@RequestMapping("/jh/signator/maintainparty/relationship")
public class MaintainRelationshipController {

	@Autowired
	MaintainRelationshipService maintainRelationshipService;

	@Autowired
	private LoggerUtils loggerUtils;

	@ApiOperation(value = "Get Maintain Party Relationship Details", notes = "Service Get Maintain Party Relationship Details", response = ReadPartyRelationshipReply.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Success"),
			@ApiResponse(code = 408, message = "Request Timeout"),
			@ApiResponse(code = 500, message = "Technical Error"),
			@ApiResponse(code = 400, message = "Bad Request or Operation Not Implemented"),
			@ApiResponse(code = 404, message = "Record not found ") })

	@RequestMapping(value = "/read", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ReadPartyRelationshipReply> maintainRelationshipRead(
			@RequestHeader("MessageUUID") final String messageUUID,
			@RequestHeader("SourceSystemName") final String sourceSystemName,
			@Valid @RequestBody final ReadPartyRelationshipRequest readPartyRelationshipRequest) throws Exception {
		ReadPartyRelationshipReply readPartyRelationshipReply = null;

		try {
			LoggingContextHolder.getLoggingContext().setContext(messageUUID, sourceSystemName);
			MaintainRelationshipValidator.validateRequest(messageUUID, sourceSystemName, readPartyRelationshipRequest);

			LoggerHandler.LogOut("INFO", "1", messageUUID, sourceSystemName, this.getClass().getName(),
					"Entering deleteAttachment Controller " + readPartyRelationshipRequest.toString());

			readPartyRelationshipReply = maintainRelationshipService.readPartyRelationship(messageUUID,
					sourceSystemName, readPartyRelationshipRequest);

			LoggerHandler.LogOut("INFO", "4", messageUUID, sourceSystemName, this.getClass().getName(),
					"Exiting deleteAttachment Controller");
			LoggerHandler.LogOut("DEBUG", "4", messageUUID, sourceSystemName, this.getClass().getName(),
					"Controller Create Success");
			LoggingContextHolder.getLoggingContext().clear();

		} catch (final Exception e) {
			LoggerHandler.ErrorOut(e, messageUUID, sourceSystemName, this.getClass().getName(), e.getMessage());
			throw e;
		}

		final HttpHeaders headers = new HttpHeaders();
		return new ResponseEntity<>(readPartyRelationshipReply, headers, HttpStatus.OK);

	}

	@ApiOperation(value = "Maintain Party Relationship Search", notes = "Service to search party relationships", response = ReadPartyRelationshipReply.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Success"),
			@ApiResponse(code = 408, message = "Request Timeout"),
			@ApiResponse(code = 500, message = "Technical Error"), @ApiResponse(code = 400, message = "Bad Request"),
			@ApiResponse(code = 404, message = "Record not found ") })

	@RequestMapping(value = "/search", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<SearchPartyRelationshipReply> maintainRelationshipSearch(
			@RequestHeader("MessageUUID") final String messageUUID,
			@RequestHeader("SourceSystemName") final String sourceSystemName,
			@Valid @RequestBody final SearchPartyRelationshipRequest searchPartyRelationshipRequest) throws Exception {
		SearchPartyRelationshipReply searchPartyRelationshipReply = null;

		try {
			LoggingContextHolder.getLoggingContext().setContext(messageUUID, sourceSystemName);
			MaintainRelationshipValidator.validateRequest(messageUUID, sourceSystemName,
					searchPartyRelationshipRequest);

			LoggerHandler.LogOut("INFO", "1", messageUUID, sourceSystemName, this.getClass().getName(),
					"Entering maintainRelationshipSearch Controller "
							+ loggerUtils.writeAsJson(searchPartyRelationshipRequest));

			searchPartyRelationshipReply = maintainRelationshipService.searchPartyRelationship(messageUUID,
					sourceSystemName, searchPartyRelationshipRequest);

			LoggerHandler.LogOut("INFO", "4", messageUUID, sourceSystemName, this.getClass().getName(),
					"Exiting maintainRelationshipSearch Controller");
			LoggerHandler.LogOut("DEBUG", "4", messageUUID, sourceSystemName, this.getClass().getName(),
					"Controller Search Success");
			LoggingContextHolder.getLoggingContext().clear();

		} catch (final Exception e) {
			LoggerHandler.ErrorOut(e, messageUUID, sourceSystemName, this.getClass().getName(), e.getMessage());
			throw e;
		}

		final HttpHeaders headers = new HttpHeaders();
		return new ResponseEntity<>(searchPartyRelationshipReply, headers, HttpStatus.OK);

	}

}

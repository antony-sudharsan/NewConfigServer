package com.jh.signator.maintain.relationship.bizrule;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import org.apache.commons.lang3.StringUtils;

import com.jh.signator.maintain.relationship.model.data.InterimDataResult;
import com.jh.signator.maintain.relationship.model.data.PartyLookupResult;
import com.jh.signator.maintain.relationship.model.data.SearchBusinessPlatformLookUpResult;
import com.manulife.esb.xsd.distribution.jhfn.partyrelationship.RELATIONIDREF;
import com.manulife.esb.xsd.distribution.jhfn.partyrelationship.SearchPartyRelationshipReply;

/**
 * Handles transforming Active Only Results into a SearchPartyRelationshipReply.
 *
 */
public class SearchPartyReplyActiveOnlyResultTransformer extends SearchPartyReplyTransformer {

	public SearchPartyRelationshipReply populateFinalResponse(
			final List<SearchBusinessPlatformLookUpResult> searchBusinessPlatformLookUpResults,
			final PartyLookupResult partyLookupResult) {
		final List<InterimDataResult> interimResults = new ArrayList<>();
		final InterimDataResult interimResult = interimTransformDefault(searchBusinessPlatformLookUpResults,
				partyLookupResult);
		interimResults.add(interimResult);
		interimResults.addAll(interimTransform(searchBusinessPlatformLookUpResults, partyLookupResult));

		return finalTransform(interimResults);
	}

	private List<InterimDataResult> interimTransform(
			final List<SearchBusinessPlatformLookUpResult> searchBusinessPlatformLookUpResults,
			final PartyLookupResult partyLookupResult) {
		final List<InterimDataResult> interimResults = new ArrayList<>();

		// When MP
		if (searchBusinessPlatformLookUpResults.stream().anyMatch(s -> {
			return (s.getPartyIdNo().equals(partyLookupResult.getPartyIdNo()) && ROLE_CD_MP.equals(s.getRoleCd()));
		})) {
			interimResults.addAll(processMpResults(searchBusinessPlatformLookUpResults, partyLookupResult));
		}
		// When ACS
		else if (searchBusinessPlatformLookUpResults.stream().anyMatch(s -> {
			return (s.getPartyIdNo().equals(partyLookupResult.getPartyIdNo()) && ROLE_CD_ACS.equals(s.getRoleCd()));
		})) {
			interimResults.addAll(processAcsResults(searchBusinessPlatformLookUpResults, partyLookupResult));
		}
		// When Other Role FIRM STAFF
		else if (searchBusinessPlatformLookUpResults.stream().anyMatch(s -> {
			return (s.getPartyIdNo().equals(partyLookupResult.getPartyIdNo())
					&& OTHER_ROLE_CD_FIRM_STAFF.equals(s.getOtherRole()));
		})) {
			interimResults.addAll(processFirmStaffResults(searchBusinessPlatformLookUpResults, partyLookupResult));
		}
		// When REPWT
		else if (searchBusinessPlatformLookUpResults.stream().anyMatch(s -> {
			return (s.getPartyIdNo().equals(partyLookupResult.getPartyIdNo()) && ROLE_CD_REPWT.equals(s.getRoleCd()));
		})) {
			interimResults.addAll(processRepwtResults(searchBusinessPlatformLookUpResults, partyLookupResult));
		}
		// Otherwise
		else {
			interimResults.addAll(processOtherwiseResults(searchBusinessPlatformLookUpResults, partyLookupResult));
		}

		return interimResults;
	}

	private List<InterimDataResult> processMpResults(
			final List<SearchBusinessPlatformLookUpResult> searchBusinessPlatformLookUpResults,
			final PartyLookupResult partyLookupResult) {

		final List<InterimDataResult> interimResults = new ArrayList<>();
		InterimDataResult interimResult = null;
		final Set<BigDecimal> processedPartyIdNos = new HashSet<>();

		for (final SearchBusinessPlatformLookUpResult searchResult : searchBusinessPlatformLookUpResults) {

			if ((searchResult.getRepPartyIdNo() != null)
					&& searchResult.getRepPartyIdNo().equals(partyLookupResult.getPartyIdNo())) {
				interimResult = getDefaultInterimDataResult(searchResult);
				interimResult.setPartyIdNo(searchResult.getPartyIdNo().toString());
				interimResult.setPrdId(searchResult.getPrdId());
				interimResult.setRoleCd(searchResult.getOtherRole());
				interimResult.setRepPartyIdNo(searchResult.getRepPartyIdNo().toString());
				interimResult.setRepPrdId(searchResult.getAgentPrdId());
				interimResult.setRelationId(searchResult.getTransactionIdNo());
				interimResult.setRelationIdRef(RELATIONIDREF.BUSINESS_PLATFORM);
				interimResults.add(interimResult);
			}

			// If the party ids do not match only create a record for each unique party id
			// no that does not match.
			if (!searchResult.getPartyIdNo().equals(partyLookupResult.getPartyIdNo())
					&& !processedPartyIdNos.contains(searchResult.getPartyIdNo())) {
				processedPartyIdNos.add(searchResult.getPartyIdNo());
				interimResult = getDefaultInterimDataResult(searchResult);
				interimResult.setPartyIdNo(partyLookupResult.getPartyIdNo().toString());
				interimResult.setPrdId(partyLookupResult.getPrdId());
				interimResult.setRoleCd(ROLE_CD_MP);
				if (searchResult.getRepPartyIdNo() != null) {
					interimResult.setRepPartyIdNo(searchResult.getRepPartyIdNo().toString());
				}
				interimResult.setRepPrdId(searchResult.getAgentPrdId());
				interimResult.setRelationId(partyLookupResult.getPartyIdNo() + "," + searchResult.getPartyIdNo());
				interimResult.setRelationIdRef(RELATIONIDREF.CONCATENATION);
				interimResults.add(interimResult);
			}
		}
		return interimResults;

	}

	private List<InterimDataResult> processAcsResults(
			final List<SearchBusinessPlatformLookUpResult> searchBusinessPlatformLookUpResults,
			final PartyLookupResult partyLookupResult) {

		final List<InterimDataResult> interimResults = new ArrayList<>();
		InterimDataResult interimResult = null;

		final Set<BigDecimal> processedPartyIdNos = new HashSet<>();
		final Set<String> processedOtherRoles = new HashSet<>();
		for (final SearchBusinessPlatformLookUpResult searchResult : searchBusinessPlatformLookUpResults) {

			// group by party id no, so only create a record for each unique party id no
			// that does not match
			if (!searchResult.getPartyIdNo().equals(partyLookupResult.getPartyIdNo())
					&& !processedPartyIdNos.contains(searchResult.getPartyIdNo())) {
				processedPartyIdNos.add(searchResult.getPartyIdNo());
				interimResult = getDefaultInterimDataResult(searchResult);
				interimResult.setPartyIdNo(partyLookupResult.getPartyIdNo().toString());
				interimResult.setPrdId(partyLookupResult.getPrdId());
				interimResult.setRoleCd(ROLE_CD_ACS);
				interimResult.setRepPartyIdNo(searchResult.getPartyIdNo().toString());
				interimResult.setRepPrdId(searchResult.getPrdId());

				if ((searchResult.getRepPartyIdNo() == null)
						|| !(searchResult.getRepPartyIdNo().equals(partyLookupResult.getPartyIdNo()))) {
					interimResult.setRelationId(partyLookupResult.getPartyIdNo() + "," + searchResult.getPartyIdNo());
					interimResult.setRelationIdRef(RELATIONIDREF.CONCATENATION);
				} else {
					interimResult.setRelationId(searchResult.getTransactionIdNo());
					interimResult.setRelationIdRef(RELATIONIDREF.BUSINESS_PLATFORM);
				}
				interimResults.add(interimResult);
			}

			// group by other role, so only create a record for each unique other role
			if (searchResult.getPartyIdNo().equals(partyLookupResult.getPartyIdNo())
					&& (StringUtils.isNotEmpty(searchResult.getOtherRole()))
					&& !processedOtherRoles.contains(searchResult.getOtherRole())) {
				processedOtherRoles.add(searchResult.getOtherRole());
				interimResult = getDefaultInterimDataResult(searchResult);
				interimResult.setPartyIdNo(partyLookupResult.getPartyIdNo().toString());
				interimResult.setPrdId(partyLookupResult.getPrdId());
				interimResult.setRoleCd(searchResult.getOtherRole());
				if (searchResult.getRepPartyIdNo() != null) {
					interimResult.setRepPartyIdNo(searchResult.getRepPartyIdNo().toString());
				}
				interimResult.setRepPrdId(searchResult.getAgentPrdId());
				interimResult.setRelationId(searchResult.getTransactionIdNo());
				interimResult.setRelationIdRef(RELATIONIDREF.BUSINESS_PLATFORM);
				interimResults.add(interimResult);
			}
		}

		return interimResults;
	}

	private List<InterimDataResult> processRepwtResults(
			final List<SearchBusinessPlatformLookUpResult> searchBusinessPlatformLookUpResults,
			final PartyLookupResult partyLookupResult) {

		final List<InterimDataResult> interimResults = new ArrayList<>();
		InterimDataResult interimResult = null;

		for (final SearchBusinessPlatformLookUpResult searchResult : searchBusinessPlatformLookUpResults) {

			if (ROLE_CD_MP.equals(searchResult.getRoleCd())) {
				// Don't think if being true path can happen as would hit MP when condition
				if (searchResult.getPartyIdNo().equals(partyLookupResult.getPartyIdNo())) {
					if ((searchResult.getRepPartyIdNo() == null)
							|| !searchResult.getRepPartyIdNo().equals(searchResult.getPartyIdNo())) {

						interimResult = getDefaultInterimDataResult(searchResult);
						interimResult.setPartyIdNo(partyLookupResult.getPartyIdNo().toString());
						interimResult.setPrdId(partyLookupResult.getPrdId());
						interimResult.setRoleCd(ROLE_CD_REPWT);
						interimResult.setRepPartyIdNo(searchResult.getPartyIdNo().toString());
						interimResult.setRepPrdId(searchResult.getPrdId());
						interimResult
								.setRelationId(partyLookupResult.getPartyIdNo() + "," + searchResult.getPartyIdNo());
						interimResult.setRelationIdRef(RELATIONIDREF.CONCATENATION);
						interimResults.add(interimResult);
					}
				} else if (searchResult.getRepPartyIdNo() == null) {
					interimResult = getDefaultInterimDataResult(searchResult);
					interimResult.setPartyIdNo(partyLookupResult.getPartyIdNo().toString());
					interimResult.setPrdId(partyLookupResult.getPrdId());
					interimResult.setRoleCd(ROLE_CD_REPWT);
					interimResult.setRepPartyIdNo(searchResult.getPartyIdNo().toString());
					interimResult.setRepPrdId(searchResult.getPrdId());
					interimResult.setRelationId(partyLookupResult.getPartyIdNo() + "," + searchResult.getPartyIdNo());
					interimResult.setRelationIdRef(RELATIONIDREF.CONCATENATION);
					interimResults.add(interimResult);
				}
			}
			if ((searchResult.getRepPartyIdNo() != null)
					&& searchResult.getRepPartyIdNo().equals(partyLookupResult.getPartyIdNo())) {
				interimResult = getDefaultInterimDataResult(searchResult);
				interimResult.setPartyIdNo(searchResult.getPartyIdNo().toString());
				interimResult.setPrdId(searchResult.getPrdId());
				interimResult.setRoleCd(searchResult.getOtherRole());
				interimResult.setRepPartyIdNo(searchResult.getRepPartyIdNo().toString());
				interimResult.setRepPrdId(searchResult.getAgentPrdId());
				interimResult.setRelationId(searchResult.getTransactionIdNo());
				interimResult.setRelationIdRef(RELATIONIDREF.BUSINESS_PLATFORM);
				interimResults.add(interimResult);
			}
			if (searchResult.getPartyIdNo().equals(partyLookupResult.getPartyIdNo())
					&& (OTHER_ROLE_CD_SALES_ASSISTANT.equals(searchResult.getOtherRole()))) {
				interimResult = getDefaultInterimDataResult(searchResult);
				interimResult.setPartyIdNo(searchResult.getPartyIdNo().toString());
				interimResult.setPrdId(searchResult.getPrdId());
				interimResult.setRoleCd(searchResult.getOtherRole());
				if (searchResult.getRepPartyIdNo() != null) {
					interimResult.setRepPartyIdNo(searchResult.getRepPartyIdNo().toString());
				}
				interimResult.setRepPrdId(searchResult.getAgentPrdId());
				interimResult.setRelationId(searchResult.getTransactionIdNo());
				interimResult.setRelationIdRef(RELATIONIDREF.BUSINESS_PLATFORM);
				interimResults.add(interimResult);
			}
		}

		return interimResults;
	}

	private List<InterimDataResult> processFirmStaffResults(
			final List<SearchBusinessPlatformLookUpResult> searchBusinessPlatformLookUpResults,
			final PartyLookupResult partyLookupResult) {

		final List<InterimDataResult> interimResults = new ArrayList<>();
		InterimDataResult interimResult = null;

		final Set<BigDecimal> processedPartyIdNos = new HashSet<>();
		for (final SearchBusinessPlatformLookUpResult searchResult : searchBusinessPlatformLookUpResults) {

			// group by party id no, so only create a record for each unique party id no
			// that does not match
			if (!searchResult.getPartyIdNo().equals(partyLookupResult.getPartyIdNo())
					&& !processedPartyIdNos.contains(searchResult.getPartyIdNo())) {
				processedPartyIdNos.add(searchResult.getPartyIdNo());
				interimResult = getDefaultInterimDataResult(searchResult);
				interimResult.setPartyIdNo(partyLookupResult.getPartyIdNo().toString());
				interimResult.setPrdId(partyLookupResult.getPrdId());
				interimResult.setRoleCd(OTHER_ROLE_CD_FIRM_STAFF);
				interimResult.setRepPartyIdNo(searchResult.getPartyIdNo().toString());
				interimResult.setRepPrdId(searchResult.getPrdId());
				interimResult.setRelationId(partyLookupResult.getPartyIdNo() + "," + searchResult.getPartyIdNo());
				interimResult.setRelationIdRef(RELATIONIDREF.CONCATENATION);

				interimResults.add(interimResult);
			}
		}
		return interimResults;
	}

	private List<InterimDataResult> processOtherwiseResults(
			final List<SearchBusinessPlatformLookUpResult> searchBusinessPlatformLookUpResults,
			final PartyLookupResult partyLookupResult) {

		final List<InterimDataResult> interimResults = new ArrayList<>();
		InterimDataResult interimResult = null;

		for (final SearchBusinessPlatformLookUpResult searchResult : searchBusinessPlatformLookUpResults) {

			if (searchResult.getPartyIdNo().equals(partyLookupResult.getPartyIdNo())
					&& (searchResult.getRepPartyIdNo() != null)) {
				interimResult = getDefaultInterimDataResult(searchResult);
				interimResult.setPartyIdNo(searchResult.getPartyIdNo().toString());
				interimResult.setPrdId(searchResult.getPrdId());
				interimResult.setRoleCd(searchResult.getOtherRole());
				interimResult.setRepPartyIdNo(searchResult.getRepPartyIdNo().toString());
				interimResult.setRepPrdId(searchResult.getAgentPrdId());
				interimResult.setRelationId(searchResult.getTransactionIdNo());
				interimResult.setRelationIdRef(RELATIONIDREF.BUSINESS_PLATFORM);
				interimResults.add(interimResult);
			}
		}

		return interimResults;
	}

	private InterimDataResult interimTransformDefault(
			final List<SearchBusinessPlatformLookUpResult> searchBusinessPlatformLookUpResults,
			final PartyLookupResult partyLookupResult) {
		final InterimDataResult interimResult = new InterimDataResult();

		interimResult.setPartyIdNo(partyLookupResult.getPartyIdNo().toString());
		interimResult.setPrdId(partyLookupResult.getPrdId());
		if (partyLookupResult.getContractOrgPartyIdNo() != null) {
			interimResult.setRepPartyIdNo(partyLookupResult.getContractOrgPartyIdNo().toString());
		}
		interimResult.setRelationEffDate(partyLookupResult.getContractDate());
		interimResult.setRelationEndDate(partyLookupResult.getTermDate());
		interimResult
				.setRelationId(partyLookupResult.getPartyIdNo() + "," + partyLookupResult.getContractOrgPartyIdNo());
		interimResult.setRelationIdRef(RELATIONIDREF.CONCATENATION);
		interimResult.setSequence(DEFAULT_SEQUENCE);
		interimResult.setTemporaryRoleInd(TEMPORARY_ROLE_IND);
		interimResult.setBusinessRelationType(BUSINESS_REL);
		interimResult.setPercentage(DEFAULT_PERCENT);
		interimResult.setCreatByNm(DEFAULT_CREATED_BY);
		interimResult.setCreatDtm(partyLookupResult.getContractDate());

		interimResult.setLastUpdByNm(DEFAULT_CREATED_BY);
		interimResult.setLastUpdDtm(partyLookupResult.getContractDate());
		interimResult.setRoleCd(DEFAULT_ROLE);

		final Optional<SearchBusinessPlatformLookUpResult> match = searchBusinessPlatformLookUpResults.stream()
				.filter(s -> s.getPartyIdNo().equals(partyLookupResult.getPartyIdNo())).findFirst();
		if (match.isPresent()) {
			final SearchBusinessPlatformLookUpResult searchResult = match.get();
			// ROLE CODE
			if (StringUtils.isNotEmpty(searchResult.getRoleCd())) {
				interimResult.setRoleCd(searchResult.getRoleCd());
			}
			// REP PRD ID
			if (StringUtils.isEmpty(searchResult.getAgentOrgPrdId())) {
				interimResult.setRepPrdId(searchResult.getOrgPrdId());
			} else {
				interimResult.setRepPrdId(searchResult.getAgentOrgPrdId());
			}

			// CREAT DTM
			if (searchResult.getCreatDtm() != null) {
				interimResult.setCreatDtm(searchResult.getCreatDtm());
			}

			// CREAT BY NM
			if (StringUtils.isNotEmpty(searchResult.getCreatByNm())) {
				interimResult.setCreatByNm(searchResult.getCreatByNm());
			}

			// LAST UPD DTM
			if (searchResult.getLastUpdDtm() != null) {
				interimResult.setLastUpdDtm(searchResult.getLastUpdDtm());
			}

			// UPDATED BY NM
			if (StringUtils.isNotEmpty(searchResult.getLastUpdByNm())) {
				interimResult.setLastUpdByNm(searchResult.getLastUpdByNm());
			}
		}

		return interimResult;
	}

}

package com.jh.signator.maintain.relationship.mapper;

import java.math.BigInteger;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import com.jh.common.utility.DataMappingCrossLookUp;
import com.jh.signator.maintain.relationship.utils.SearchPartyUtils;
import com.manulife.esb.xsd.distribution.jhfn.partyrelationship.RELATIONIDREF;
import com.manulife.esb.xsd.distribution.jhfn.partyrelationship.Relation;
import com.microsoft.sqlserver.jdbc.StringUtils;

@Component
public class MaintainRelationshipRowMapper implements RowMapper<Relation> {
	// ReadPartyRelationshipReply readPartyRelationshipReply = new
	// ReadPartyRelationshipReply();
	@Override
	public Relation mapRow(final ResultSet rs, final int rowNum) throws SQLException {

		final BigInteger ID_REF_TYPE_DEFAULT = new BigInteger("8000");
		final BigInteger ID_REF_TYPE_OTHER = new BigInteger("8001");
		final Relation relation = new Relation();

		final List<String> keyList = new ArrayList<>();
		keyList.add("ACS");
		keyList.add("Firm Staff");
		keyList.add("MP");
		keyList.add("REPWT");
		keyList.add("Sales Assistant");

		relation.setRelationID(rs.getString("transaction_id_no"));

		relation.setStartDate(SearchPartyUtils.convertTimestampToXmlGregorianCalendar(rs.getTimestamp("transaction_eff_date")));
		relation.setEndDate(SearchPartyUtils.convertTimestampToXmlGregorianCalendar(rs.getTimestamp("transaction_end_date")));
		relation.setRelationIDRef(RELATIONIDREF.BUSINESS_PLATFORM);
		relation.setCreatedDate(SearchPartyUtils.convertTimestampToXmlGregorianCalendar(rs.getTimestamp("creat_dtm")));
		relation.setCreatedByNm(rs.getString("creat_by_nm"));
		relation.setUpdatedByNm(rs.getString("last_upd_by_nm"));
		relation.setUpdatedDate(SearchPartyUtils.convertTimestampToXmlGregorianCalendar(rs.getTimestamp("last_upd_dtm")));
		final String id = rs.getString("prd_id");
		final String prd_id = rs.getString("rep_prd_id");

		if (id.isEmpty() || prd_id.isEmpty()) {
			relation.setRelatedRefID(rs.getString("rep_party_id_no"));
			relation.setIDReferenceType(ID_REF_TYPE_DEFAULT);
			relation.setRelatedRefIDType(ID_REF_TYPE_DEFAULT);
		} else {
			relation.setRelatedRefID(prd_id);
			relation.setIDReferenceType(ID_REF_TYPE_OTHER);
			relation.setRelatedRefIDType(ID_REF_TYPE_OTHER);
		}

		relation.setRelationIDRef(RELATIONIDREF.BUSINESS_PLATFORM);

		if (StringUtils.isEmpty(rs.getString("other_role"))) {
			if (rs.getString("role_cd") != null || !rs.getString("role_cd").equals("")) {

				if (keyList.contains(rs.getString("role_cd"))) {
					relation.setRelationRoleCode(
							BigInteger.valueOf(Long.parseLong(DataMappingCrossLookUp.getValue("RELATIONROLECODE", rs.getString("role_cd")))));
				} else
					relation.setRelationRoleCode(BigInteger.valueOf(Long.parseLong(DataMappingCrossLookUp.getValue("RELATIONROLECODE", "OTHERWISE"))));

			}

		} else {
			relation.setRelationRoleCode(BigInteger.valueOf(Long.parseLong(DataMappingCrossLookUp.getValue("RELATIONROLECODE", rs.getString("other_role")))));
		}

		if ((id.length() == 0) || (prd_id.length() == 0)) {
			relation.setIDReferenceNo(rs.getString("party_id_no"));
		} else {

			relation.setIDReferenceNo(rs.getString("prd_id"));
		}

		return relation;
	}
}
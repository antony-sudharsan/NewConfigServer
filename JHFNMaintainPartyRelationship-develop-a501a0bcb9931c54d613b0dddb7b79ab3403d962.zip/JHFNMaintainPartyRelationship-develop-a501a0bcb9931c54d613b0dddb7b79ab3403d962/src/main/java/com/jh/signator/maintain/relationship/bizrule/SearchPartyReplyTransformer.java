package com.jh.signator.maintain.relationship.bizrule;

import java.math.BigInteger;
import java.util.List;

import org.apache.commons.lang3.StringUtils;

import com.jh.common.utility.DataMappingCrossLookUp;
import com.jh.signator.maintain.relationship.model.data.InterimDataResult;
import com.jh.signator.maintain.relationship.model.data.SearchBusinessPlatformLookUpResult;
import com.jh.signator.maintain.relationship.utils.SearchPartyUtils;
import com.manulife.esb.xsd.distribution.jhfn.partyrelationship.Relation;
import com.manulife.esb.xsd.distribution.jhfn.partyrelationship.SearchPartyRelationshipReply;

/**
 * Base class for transforming db query results into a
 * SearchPartyRelationshipReply.
 *
 */
public class SearchPartyReplyTransformer {

	protected static final String DEFAULT_SEQUENCE = "0";
	protected static final String TEMPORARY_ROLE_IND = "0";
	protected static final String BUSINESS_REL = "9200";
	protected static final String ROLE_CD_MP = "MP";
	protected static final String ROLE_CD_ACS = "ACS";
	protected static final String ROLE_CD_REPWT = "REPWT";
	protected static final String ROLE_CD_STAFF = "STAFF";
	protected static final String OTHER_ROLE_CD_FIRM_STAFF = "Firm Staff";
	protected static final String OTHER_ROLE_CD_SALES_ASSISTANT = "Sales Assistant";
	protected static final String DEFAULT_ROLE = "Other";
	protected static final Double DEFAULT_PERCENT = 0d;
	protected static final String DEFAULT_CREATED_BY = "JHFF";
	protected static final String DEFAULT_UPDATED_BY = "JHFF";
	protected static final BigInteger ID_REF_TYPE_DEFAULT = new BigInteger("8000");
	protected static final BigInteger ID_REF_TYPE_OTHER = new BigInteger("8001");
	protected static final String TRANSACTION_STATUS_ACTIVE = "active";
	protected static final String TRANSACTION_STATUS_TERMINATED = "terminated";
	protected static final String RELATION_ROLE_CODE = "RELATIONROLECODE";
	protected static final String OTHERWISE = "OTHERWISE";

	protected InterimDataResult getDefaultInterimDataResult(final SearchBusinessPlatformLookUpResult searchResult) {

		final InterimDataResult interimResult = new InterimDataResult();
		interimResult.setRelationEffDate(searchResult.getTransactionEffDate());
		interimResult.setRelationEndDate(searchResult.getTransactionEndDate());

		interimResult.setCreatDtm(searchResult.getCreatDtm());
		interimResult.setCreatByNm(searchResult.getCreatByNm());

		interimResult.setLastUpdDtm(searchResult.getLastUpdDtm());
		interimResult.setLastUpdByNm(searchResult.getLastUpdByNm());
		interimResult.setSequence(DEFAULT_SEQUENCE);
		interimResult.setTemporaryRoleInd(TEMPORARY_ROLE_IND);
		interimResult.setBusinessRelationType(BUSINESS_REL);
		interimResult.setPercentage(DEFAULT_PERCENT);

		return interimResult;
	}

	protected SearchPartyRelationshipReply finalTransform(final List<InterimDataResult> interimResults) {

		final SearchPartyRelationshipReply searchPartyRelationshipReply = new SearchPartyRelationshipReply();

		for (final InterimDataResult interimResult : interimResults) {
			final Relation relation = new Relation();
			relation.setRelationID(interimResult.getRelationId());
			relation.setRelationIDRef(interimResult.getRelationIdRef());

			if (StringUtils.isEmpty(interimResult.getPrdId()) || StringUtils.isEmpty(interimResult.getRepPrdId())) {
				relation.setIDReferenceNo(interimResult.getPartyIdNo());
				relation.setIDReferenceType(ID_REF_TYPE_DEFAULT);
				relation.setRelatedRefID(interimResult.getRepPartyIdNo());
				relation.setRelatedRefIDType(ID_REF_TYPE_DEFAULT);
			} else {
				relation.setIDReferenceNo(interimResult.getPrdId());
				relation.setIDReferenceType(ID_REF_TYPE_OTHER);
				relation.setRelatedRefID(interimResult.getRepPrdId());
				relation.setRelatedRefIDType(ID_REF_TYPE_OTHER);
			}

			if (StringUtils.isEmpty(interimResult.getRoleCd())) {
				relation.setRelationRoleCode(BigInteger
						.valueOf(Long.parseLong(DataMappingCrossLookUp.getValue(RELATION_ROLE_CODE, OTHERWISE))));
			} else {

				relation.setRelationRoleCode(BigInteger.valueOf(Long
						.parseLong(DataMappingCrossLookUp.getValue(RELATION_ROLE_CODE, interimResult.getRoleCd()))));
			}

			relation.setStartDate(
					SearchPartyUtils.convertTimestampToXmlGregorianCalendar(interimResult.getRelationEffDate()));
			relation.setEndDate(
					SearchPartyUtils.convertTimestampToXmlGregorianCalendar(interimResult.getRelationEndDate()));
			if (interimResult.getTemporaryRoleInd() != null) {
				relation.setTemporaryRoleInd(Boolean.parseBoolean(interimResult.getTemporaryRoleInd()));
			}
			if (interimResult.getSequence() != null) {
				relation.setSequence(Integer.parseInt(interimResult.getSequence()));
			}
			if (interimResult.getBusinessRelationType() != null) {
				relation.setBusinessRelationType(
						BigInteger.valueOf(Long.parseLong(interimResult.getBusinessRelationType())));
			}
			relation.setAllocationPercentage(interimResult.getPercentage());
			relation.setCreatedDate(
					SearchPartyUtils.convertTimestampToXmlGregorianCalendar(interimResult.getCreatDtm()));
			relation.setUpdatedDate(
					SearchPartyUtils.convertTimestampToXmlGregorianCalendar(interimResult.getLastUpdDtm()));
			relation.setCreatedByNm(interimResult.getCreatByNm());
			relation.setUpdatedByNm(interimResult.getLastUpdByNm());

			// Adding it to final response
			searchPartyRelationshipReply.getRelation().add(relation);
		}

		return searchPartyRelationshipReply;
	}

}

/**
 *
 */
package com.jh.signator.maintain.relationship.dao;

import java.util.List;

import com.jh.signator.maintain.relationship.model.data.LookupByConcatenation;
import com.jh.signator.maintain.relationship.model.data.PartyLookUpResponse;
import com.manulife.esb.xsd.distribution.jhfn.partyrelationship.ReadPartyRelationshipReply;

/**
 * Inteface for Dao handling queries related to the read operation.
 */
public interface MaintainRelationshipReadDao {

	PartyLookUpResponse partyLookUpResponse(final String relationId, final String messageUUID,
			final String sourceSystemName);

	ReadPartyRelationshipReply readPartyRelationshipByID(final String relationID, final String messageUUID,
			final String sourceSystemName);

	List<LookupByConcatenation> readPartyRelationship(final String orgAgencyCode, final String agencyCode,
			final String messageUUID, final String sourceSystemName);
}

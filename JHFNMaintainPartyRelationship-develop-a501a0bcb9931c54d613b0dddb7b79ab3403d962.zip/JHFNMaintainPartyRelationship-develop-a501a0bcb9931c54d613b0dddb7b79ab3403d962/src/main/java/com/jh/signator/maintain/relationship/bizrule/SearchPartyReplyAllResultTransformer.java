package com.jh.signator.maintain.relationship.bizrule;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;

import com.jh.signator.maintain.relationship.model.data.InterimDataResult;
import com.jh.signator.maintain.relationship.model.data.PartyLookupResult;
import com.jh.signator.maintain.relationship.model.data.SearchBusinessPlatformLookUpResult;
import com.manulife.esb.xsd.distribution.jhfn.partyrelationship.RELATIONIDREF;
import com.manulife.esb.xsd.distribution.jhfn.partyrelationship.SearchPartyRelationshipReply;

/**
 * Handles transforming All Results into a SearchPartyRelationshipReply.
 *
 */
public class SearchPartyReplyAllResultTransformer extends SearchPartyReplyTransformer {

	public SearchPartyRelationshipReply populateFinalResponse(
			final List<SearchBusinessPlatformLookUpResult> searchBusinessPlatformLookUpResults,
			final PartyLookupResult partyLookupResult, final boolean checkActive) {

		final List<InterimDataResult> interimResults = new ArrayList<>();
		InterimDataResult interimResult = null;

		if (searchBusinessPlatformLookUpResults.stream().anyMatch(s -> {
			return (s.getPartyIdNo().equals(partyLookupResult.getPartyIdNo()));
		})) {
			interimResult = interimTransformDefaultMatch(searchBusinessPlatformLookUpResults, partyLookupResult);
			interimResults.add(interimResult);
		} else {
			interimResult = interimTransformDefaultNoMatch(searchBusinessPlatformLookUpResults, partyLookupResult);
			interimResults.add(interimResult);
		}

		interimResults.addAll(interimTransform(searchBusinessPlatformLookUpResults, partyLookupResult, checkActive));
		return finalTransform(interimResults);
	}

	private List<InterimDataResult> interimTransform(
			final List<SearchBusinessPlatformLookUpResult> searchBusinessPlatformLookUpResults,
			final PartyLookupResult partyLookupResult, final boolean checkActive) {
		final List<InterimDataResult> interimResults = new ArrayList<>();

		final String transactionStatus = checkActive ? TRANSACTION_STATUS_ACTIVE : TRANSACTION_STATUS_TERMINATED;
		final List<SearchBusinessPlatformLookUpResult> filteredResults = searchBusinessPlatformLookUpResults.stream()
				.filter(s -> s.getPartyIdNo().equals(partyLookupResult.getPartyIdNo())
						&& transactionStatus.equals(s.getTxnStatus()))
				.collect(Collectors.toList());
		for (final SearchBusinessPlatformLookUpResult searchResult : filteredResults) {

			// When MP
			if (ROLE_CD_MP.equals(searchResult.getRoleCd())) {
				if ((searchResult.getRepPartyIdNo() != null)
						&& searchResult.getRepPartyIdNo().equals(partyLookupResult.getPartyIdNo())) {
					addInterimDataResult(interimResults, searchResult, searchResult.getPartyIdNo().toString(),
							searchResult.getPrdId());
				}
			}
			// When ACS and no other role code
			else if (ROLE_CD_ACS.equals(searchResult.getRoleCd()) && StringUtils.isEmpty(searchResult.getOtherRole())) {
				// no op
			}
			// when Other role is FIRM_STAFF and Role cd is STAFF or REPWT
			else if (OTHER_ROLE_CD_FIRM_STAFF.equals(searchResult.getOtherRole())
					&& (ROLE_CD_STAFF.equals(searchResult.getRoleCd())
							|| ROLE_CD_REPWT.equals(searchResult.getRoleCd()))) {
				// no op
			}
			// When REPWT and no Other role cd
			else if (ROLE_CD_REPWT.equals(searchResult.getRoleCd())
					&& StringUtils.isEmpty(searchResult.getOtherRole())) {
				if ((searchResult.getRepPartyIdNo() != null)
						&& searchResult.getRepPartyIdNo().equals(partyLookupResult.getPartyIdNo())) {
					addInterimDataResult(interimResults, searchResult, searchResult.getPartyIdNo().toString(),
							searchResult.getPrdId());
				}
			}
			// When STAFF and Sales Assistant
			else if (ROLE_CD_STAFF.equals(searchResult.getRoleCd())
					&& OTHER_ROLE_CD_SALES_ASSISTANT.equals(searchResult.getOtherRole())) {
				addInterimDataResult(interimResults, searchResult, partyLookupResult.getPartyIdNo().toString(),
						partyLookupResult.getPrdId());
			}
			// When REPWT and Sales Assistant
			else if (ROLE_CD_REPWT.equals(searchResult.getRoleCd())
					&& OTHER_ROLE_CD_SALES_ASSISTANT.equals(searchResult.getOtherRole())) {
				addInterimDataResult(interimResults, searchResult, partyLookupResult.getPartyIdNo().toString(),
						partyLookupResult.getPrdId());

				addInterimDataResult(interimResults, searchResult, searchResult.getPartyIdNo().toString(),
						searchResult.getPrdId());
			}
		}

		return interimResults;
	}

	private InterimDataResult interimTransformDefaultNoMatch(
			final List<SearchBusinessPlatformLookUpResult> searchBusinessPlatformLookUpResults,
			final PartyLookupResult partyLookupResult) {
		final InterimDataResult interimResult = new InterimDataResult();

		interimResult.setPartyIdNo(partyLookupResult.getPartyIdNo().toString());
		interimResult.setPrdId(partyLookupResult.getPrdId());
		if (partyLookupResult.getContractOrgPartyIdNo() != null) {
			interimResult.setRepPartyIdNo(partyLookupResult.getContractOrgPartyIdNo().toString());
		}
		interimResult.setRelationEffDate(partyLookupResult.getContractDate());
		interimResult.setRelationEndDate(partyLookupResult.getTermDate());
		interimResult
				.setRelationId(partyLookupResult.getPartyIdNo() + "," + partyLookupResult.getContractOrgPartyIdNo());
		interimResult.setRelationIdRef(RELATIONIDREF.CONCATENATION);
		interimResult.setSequence(DEFAULT_SEQUENCE);
		interimResult.setTemporaryRoleInd(TEMPORARY_ROLE_IND);
		interimResult.setBusinessRelationType(BUSINESS_REL);
		interimResult.setPercentage(DEFAULT_PERCENT);
		interimResult.setCreatByNm(DEFAULT_CREATED_BY);
		interimResult.setCreatDtm(partyLookupResult.getContractDate());

		interimResult.setLastUpdByNm(DEFAULT_CREATED_BY);
		interimResult.setLastUpdDtm(partyLookupResult.getContractDate());
		interimResult.setRoleCd(DEFAULT_ROLE);
		interimResult.setRepPrdId("");

		return interimResult;
	}

	private InterimDataResult interimTransformDefaultMatch(
			final List<SearchBusinessPlatformLookUpResult> searchBusinessPlatformLookUpResults,
			final PartyLookupResult partyLookupResult) {

		final InterimDataResult interimResult = new InterimDataResult();
		final Optional<SearchBusinessPlatformLookUpResult> match = searchBusinessPlatformLookUpResults.stream()
				.filter(s -> s.getPartyIdNo().equals(partyLookupResult.getPartyIdNo())).findFirst();

		final SearchBusinessPlatformLookUpResult searchResult = match.get();
		interimResult.setPartyIdNo(searchResult.getPartyIdNo().toString());
		interimResult.setPrdId(searchResult.getPrdId());
		if (partyLookupResult.getContractOrgPartyIdNo() != null) {
			interimResult.setRepPartyIdNo(partyLookupResult.getContractOrgPartyIdNo().toString());
		} else if (searchResult.getAgentOrgPartyIdNo() == null) {
			if (searchResult.getOrgPartyIdNo() != null) {
				interimResult.setRepPartyIdNo(searchResult.getOrgPartyIdNo().toString());
			}
		} else {
			interimResult.setRepPartyIdNo(searchResult.getAgentOrgPartyIdNo().toString());
		}
		interimResult.setRelationEffDate(searchResult.getTransactionEffDate());
		interimResult.setRelationEndDate(searchResult.getTransactionEndDate());
		if (StringUtils.isEmpty(searchResult.getAgentOrgPrdId())) {
			interimResult.setRepPrdId(searchResult.getOrgPrdId());
		} else {
			interimResult.setRepPrdId(searchResult.getAgentOrgPrdId());
		}
		if (searchResult.getAgentOrgPartyIdNo() == null) {
			interimResult.setRelationId(searchResult.getPartyIdNo() + "," + searchResult.getOrgPartyIdNo());
		} else {
			interimResult.setRelationId(searchResult.getPartyIdNo() + "," + searchResult.getAgentOrgPartyIdNo());
		}
		interimResult.setRelationIdRef(RELATIONIDREF.CONCATENATION);
		interimResult.setSequence(DEFAULT_SEQUENCE);
		interimResult.setTemporaryRoleInd(TEMPORARY_ROLE_IND);
		interimResult.setBusinessRelationType(BUSINESS_REL);
		interimResult.setPercentage(DEFAULT_PERCENT);
		interimResult.setCreatByNm(searchResult.getCreatByNm());
		interimResult.setCreatDtm(searchResult.getCreatDtm());

		interimResult.setLastUpdByNm(searchResult.getLastUpdByNm());
		interimResult.setLastUpdDtm(searchResult.getLastUpdDtm());
		interimResult.setRoleCd(searchResult.getRoleCd());

		return interimResult;
	}

	private void addInterimDataResult(final List<InterimDataResult> interimResults,
			final SearchBusinessPlatformLookUpResult searchResult, final String partyIdNo, final String prdId) {
		InterimDataResult interimResult = new InterimDataResult();
		interimResult = getDefaultInterimDataResult(searchResult);
		interimResult.setPartyIdNo(partyIdNo);
		interimResult.setPrdId(prdId);
		interimResult.setRoleCd(searchResult.getOtherRole());
		if (searchResult.getRepPartyIdNo() != null) {
			interimResult.setRepPartyIdNo(searchResult.getRepPartyIdNo().toString());
		}
		interimResult.setRepPrdId(searchResult.getAgentPrdId());
		interimResult.setRelationId(searchResult.getTransactionIdNo());
		interimResult.setRelationIdRef(RELATIONIDREF.BUSINESS_PLATFORM);
		interimResults.add(interimResult);
	}
}

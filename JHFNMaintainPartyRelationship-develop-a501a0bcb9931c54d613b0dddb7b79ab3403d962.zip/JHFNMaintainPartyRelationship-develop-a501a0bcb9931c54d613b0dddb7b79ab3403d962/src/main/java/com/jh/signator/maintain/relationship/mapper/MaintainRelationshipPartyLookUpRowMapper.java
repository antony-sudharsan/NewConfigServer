package com.jh.signator.maintain.relationship.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import com.jh.signator.maintain.relationship.model.data.PartyLookUpResponse;

@Component
public class MaintainRelationshipPartyLookUpRowMapper implements RowMapper<PartyLookUpResponse> {

	@Override
	public PartyLookUpResponse mapRow(final ResultSet rs, final int rowNum) throws SQLException {

		final PartyLookUpResponse partyLookUpResponse = new PartyLookUpResponse();
		partyLookUpResponse.setParty_id_no(rs.getDouble("party_id_no"));
		partyLookUpResponse.setPrd_id(rs.getString("prd_id"));

		partyLookUpResponse.setAgency_cd(rs.getDouble("agency_cd"));
		partyLookUpResponse.setOrg_agency_cd(rs.getDouble("org_agency_cd"));

		return partyLookUpResponse;
	}
}
package com.jh.signator.maintain.relationship.model.data;

import java.sql.Timestamp;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.manulife.esb.xsd.distribution.jhfn.partyrelationship.RELATIONIDREF;

public class InterimDataResult {

	private String partyIdNo;
	private String prdId;
	private String roleCd;
	private String repPartyIdNo;
	private Timestamp relationEffDate;
	private Timestamp relationEndDate;
	private String repPrdId;
	private String relationId;
	private RELATIONIDREF relationIdRef;
	private Timestamp creatDtm;
	private String creatByNm;
	private Timestamp lastUpdDtm;
	private String lastUpdByNm;
	private String sequence;
	private String temporaryRoleInd;
	private String businessRelationType;
	private Double percentage;
	private String roleDescription;

	public String getPartyIdNo() {
		return partyIdNo;
	}

	public void setPartyIdNo(final String partyIdNo) {
		this.partyIdNo = partyIdNo;
	}

	public String getPrdId() {
		return prdId;
	}

	public void setPrdId(final String prdId) {
		this.prdId = prdId;
	}

	public String getRoleCd() {
		return roleCd;
	}

	public void setRoleCd(final String roleCd) {
		this.roleCd = roleCd;
	}

	public String getRepPartyIdNo() {
		return repPartyIdNo;
	}

	public void setRepPartyIdNo(final String repPartyIdNo) {
		this.repPartyIdNo = repPartyIdNo;
	}

	public Timestamp getRelationEffDate() {
		return relationEffDate;
	}

	public void setRelationEffDate(final Timestamp relationEffDate) {
		this.relationEffDate = relationEffDate;
	}

	public Timestamp getRelationEndDate() {
		return relationEndDate;
	}

	public void setRelationEndDate(final Timestamp relationEndDate) {
		this.relationEndDate = relationEndDate;
	}

	public String getRepPrdId() {
		return repPrdId;
	}

	public void setRepPrdId(final String repPrdId) {
		this.repPrdId = repPrdId;
	}

	public String getRelationId() {
		return relationId;
	}

	public void setRelationId(final String relationId) {
		this.relationId = relationId;
	}

	public RELATIONIDREF getRelationIdRef() {
		return relationIdRef;
	}

	public void setRelationIdRef(final RELATIONIDREF relationIdRef) {
		this.relationIdRef = relationIdRef;
	}

	public Timestamp getCreatDtm() {
		return creatDtm;
	}

	public void setCreatDtm(final Timestamp creatDtm) {
		this.creatDtm = creatDtm;
	}

	public String getCreatByNm() {
		return creatByNm;
	}

	public void setCreatByNm(final String creatByNm) {
		this.creatByNm = creatByNm;
	}

	public Timestamp getLastUpdDtm() {
		return lastUpdDtm;
	}

	public void setLastUpdDtm(final Timestamp lastUpdDtm) {
		this.lastUpdDtm = lastUpdDtm;
	}

	public String getLastUpdByNm() {
		return lastUpdByNm;
	}

	public void setLastUpdByNm(final String lastUpdByNm) {
		this.lastUpdByNm = lastUpdByNm;
	}

	public String getSequence() {
		return sequence;
	}

	public void setSequence(final String sequence) {
		this.sequence = sequence;
	}

	public String getTemporaryRoleInd() {
		return temporaryRoleInd;
	}

	public void setTemporaryRoleInd(final String temporaryRoleInd) {
		this.temporaryRoleInd = temporaryRoleInd;
	}

	public String getBusinessRelationType() {
		return businessRelationType;
	}

	public void setBusinessRelationType(final String businessRelationType) {
		this.businessRelationType = businessRelationType;
	}

	public Double getPercentage() {
		return percentage;
	}

	public void setPercentage(final Double percentage) {
		this.percentage = percentage;
	}

	public String getRoleDescription() {
		return roleDescription;
	}

	public void setRoleDescription(final String roleDescription) {
		this.roleDescription = roleDescription;
	}

	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}

}

package com.jh.signator.maintain.relationship.utils;

import java.sql.Timestamp;
import java.util.GregorianCalendar;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.jh.signator.maintain.relationship.model.data.BusinessPlatformLookUpCriteria;
import com.jh.signator.maintain.relationship.model.data.PartyLookupResult;
import com.jh.signator.maintain.relationship.model.data.SearchPartyLookupCriteria;
import com.manulife.esb.xsd.distribution.jhfn.partyrelationship.DATAFIELD;
import com.manulife.esb.xsd.distribution.jhfn.partyrelationship.SearchPartyRelationshipRequest;

/**
 * Utility class for search utils.
 *
 */
public class SearchPartyUtils {

	private static final Logger logger = LoggerFactory.getLogger(SearchPartyUtils.class);
	protected static final String EMPTY_STRING = "";

	public static SearchPartyLookupCriteria populateSearchPartyLookupCriteriaForActiveOnly(
			final SearchPartyRelationshipRequest request) {
		// exact match is only possibility based on schema
		final SearchPartyLookupCriteria criteria = new SearchPartyLookupCriteria();
		if (request.getPartySearchCriteria().getDataField().equals(DATAFIELD.PRD_ID)) {
			criteria.setPrdId(request.getPartySearchCriteria().getValue());
			criteria.setPrdIdNo(EMPTY_STRING);
			criteria.setPrdIdP2p(request.getPartySearchCriteria().getValue());
			criteria.setPrdIdNoP2p(EMPTY_STRING);
		} else {
			criteria.setPrdId(EMPTY_STRING);
			criteria.setPrdIdNo(request.getPartySearchCriteria().getValue());
			criteria.setPrdIdP2p(EMPTY_STRING);
			criteria.setPrdIdNoP2p(request.getPartySearchCriteria().getValue());
		}

		return criteria;
	}

	/// LookUp criteria For Not Active

	public static SearchPartyLookupCriteria populateSearchPartyLookupCriteriaForAll(
			final SearchPartyRelationshipRequest request) {
		// exact match is only possibility based on schema
		final SearchPartyLookupCriteria criteria = new SearchPartyLookupCriteria();
		if (request.getPartySearchCriteria().getDataField().equals(DATAFIELD.PRD_ID)) {
			criteria.setPrdIdContract(request.getPartySearchCriteria().getValue());
			criteria.setPrdIdNoContract(EMPTY_STRING);
			criteria.setPrdIdP2p(request.getPartySearchCriteria().getValue());
			criteria.setPrdIdNoP2p(EMPTY_STRING);
			criteria.setPrdIdContractTerm(request.getPartySearchCriteria().getValue());
			criteria.setPrdIdNoContractTerm(EMPTY_STRING);
			criteria.setPrdIdP2pTerm(request.getPartySearchCriteria().getValue());
			criteria.setPrdIdNoP2pTerm(EMPTY_STRING);
		} else {
			criteria.setPrdIdContract(EMPTY_STRING);
			criteria.setPrdIdNoContract(request.getPartySearchCriteria().getValue());
			criteria.setPrdIdP2p(EMPTY_STRING);
			criteria.setPrdIdNoP2p(request.getPartySearchCriteria().getValue());
			criteria.setPrdIdContractTerm(EMPTY_STRING);
			criteria.setPrdIdNoContractTerm(request.getPartySearchCriteria().getValue());
			criteria.setPrdIdP2pTerm(EMPTY_STRING);
			criteria.setPrdIdNoP2pTerm(request.getPartySearchCriteria().getValue());
		}
		return criteria;
	}

	public static BusinessPlatformLookUpCriteria populateBusinessPlatformLookupCriteria(
			final PartyLookupResult result) {
		// exact match is only possibility based on schema
		final BusinessPlatformLookUpCriteria businessCriteria = new BusinessPlatformLookUpCriteria();

		if (result.getFirmCd() != null) {
			businessCriteria.setOrg_agency_cd(result.getFirmCd().toString());
			businessCriteria.setAgency_cd(result.getFirmCd().toString());
		} else {
			businessCriteria.setOrg_agency_cd(EMPTY_STRING);
			businessCriteria.setAgency_cd(EMPTY_STRING);
		}

		return businessCriteria;
	}

	/**
	 * Method to convert Timestamp to XMLGregorianCalendar
	 *
	 * @param inputDate
	 * @return
	 */
	public static XMLGregorianCalendar convertTimestampToXmlGregorianCalendar(final Timestamp inputDate) {
		XMLGregorianCalendar xmlGregorianCalendar = null;
		if (inputDate != null) {
			final GregorianCalendar gregorianCalendar = new GregorianCalendar();

			gregorianCalendar.setTime(inputDate);
			try {
				xmlGregorianCalendar = DatatypeFactory.newInstance().newXMLGregorianCalendar(gregorianCalendar);
			} catch (final DatatypeConfigurationException e) {
				logger.error("Failed converting date to XMLGregorianCalendar", e);
			}
		}
		return xmlGregorianCalendar;
	}

}

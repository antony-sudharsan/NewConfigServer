package com.jh.tools.xjc;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

import java.time.LocalDate;
import java.time.format.DateTimeParseException;

import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;

import com.jh.tools.xjc.LocalDateAdapter;

public class LocalDateAdapterTest {

	private static final String VALID_XSDATE_STR = "1980-10-16";
	private static final String INVALID_XSDATE_STR = "AAAA-10-16";
	private static final LocalDate EXPECTED_DATE = LocalDate.of(1980,  10, 16);
	
	private LocalDateAdapter localDateAdapter = new LocalDateAdapter();
	
	@Rule
	public ExpectedException exception = ExpectedException.none();
	
	@Test
	public void testValidateXsDateUnmarshall() throws Exception {
		assertEquals(EXPECTED_DATE, localDateAdapter.unmarshal(VALID_XSDATE_STR));
	}

	@Test
	public void testInvalidXsDateCauseException() throws Exception {
		exception.expect(DateTimeParseException.class);
		localDateAdapter.unmarshal(INVALID_XSDATE_STR);
	}
	
	@Test
	public void testBlankXsDateCauseException() throws Exception {
		exception.expect(DateTimeParseException.class);
		localDateAdapter.unmarshal("  ");
	}
	
	
	@Test 
	public void testValidDateMarshall() throws Exception {
		assertEquals(VALID_XSDATE_STR, localDateAdapter.marshal(EXPECTED_DATE));
	}
	
	@Test 
	public void testNullDateHandled() throws Exception {	
		assertNull(localDateAdapter.marshal(null));
	}
	
}



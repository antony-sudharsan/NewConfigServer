package com.jh.signator.maintain.relationship.endpoint;

import com.manulife.esb.xsd.common.jh.header.JHHeader;
import com.manulife.esb.xsd.distribution.jhfn.partyrelationship.ReadPartyRelationshipReply;

public class ReadPartyRelationshipReplyWrapper {

	private final ReadPartyRelationshipReply readPartyRelationshipReply;

	private final JHHeader header;

	public ReadPartyRelationshipReplyWrapper(final ReadPartyRelationshipReply readPartyRelationshipReply,
			final JHHeader header) {
		this.readPartyRelationshipReply = readPartyRelationshipReply;
		this.header = header;
	}

	public ReadPartyRelationshipReply getReadPartyRelationshipReply() {
		return readPartyRelationshipReply;
	}

	public JHHeader getHeader() {
		return header;
	}

}

package com.jh.signator.maintain.relationship.endpoint;

import com.manulife.esb.xsd.common.jh.header.JHHeader;
import com.manulife.esb.xsd.distribution.jhfn.partyrelationship.SearchPartyRelationshipReply;

public class SearchPartyRelationshipReplyWrapper {

	private final SearchPartyRelationshipReply searchPartyRelationshipReply;

	private final JHHeader header;

	public SearchPartyRelationshipReplyWrapper(final SearchPartyRelationshipReply searchPartyRelationshipReply,
			final JHHeader header) {
		this.searchPartyRelationshipReply = searchPartyRelationshipReply;
		this.header = header;
	}

	public SearchPartyRelationshipReply getSearchPartyRelationshipReply() {
		return searchPartyRelationshipReply;
	}

	public JHHeader getHeader() {
		return header;
	}

}

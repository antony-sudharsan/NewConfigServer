package com.jh.signator.maintain.relationship.controller;

import static org.hamcrest.CoreMatchers.is;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyString;
//import static org.mockito.Mockito.;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;

import com.jh.signator.maintain.relationship.service.MaintainRelationshipService;
import com.jh.signator.maintain.relationship.test.data.SearchPartyRelationshipTestDataUtils;
import com.jh.signator.maintain.relationship.utils.LoggerUtils;
import com.jh.signator.maintain.relationship.validator.MaintainRelationshipValidator;
import com.manulife.esb.xsd.distribution.jhfn.partyrelationship.RELATIONIDREF;
import com.manulife.esb.xsd.distribution.jhfn.partyrelationship.ReadPartyRelationshipReply;
import com.manulife.esb.xsd.distribution.jhfn.partyrelationship.ReadPartyRelationshipRequest;
import com.manulife.esb.xsd.distribution.jhfn.partyrelationship.Relation;

@ActiveProfiles("test")
@RunWith(SpringRunner.class)
/**
 * @WebMvcTest. It will auto-configure the Spring MVC infrastructure for our
 * unit tests. Setting up WebMvc Context for the Controller which is under
 * test("MaintainRelationshipController")
 */
@WebMvcTest(MaintainRelationshipController.class)
public class MaintainRelationshipControllerTest {

	/**
	 * Initializing MockMvc
	 */
	@Autowired
	private MockMvc mvc;

	/**
	 * @MockBean The class is included in the spring-boot-test library. It allows to
	 *           add Mockito mocks in a Spring ApplicationContext. If a bean,
	 *           compatible with the declared class exists in the context, it
	 *           replaces it by the mock. If it is not the case, it adds the mock in
	 *           the context as a bean.
	 */
	@MockBean
	private MaintainRelationshipService maintainRelationshipService;

	private ReadPartyRelationshipReply readPartyRelationshipReply = new ReadPartyRelationshipReply();

	private final List<ReadPartyRelationshipReply> readPartyRelationshipReplyList = new ArrayList<>();

	public static final String SAMPLE_JSON_STRING_BUINESS_PLATFORM = "{" + "  \"keyedValue\": [" + "    {"
			+ "      \"keyName\": \"1222\"," + "      \"keyValue\": \"11\"," + "      \"vendorCode\": \"222\"" + "    }"
			+ "  ]," + "  \"relationID\": \"1234\"," + "  \"relationIDRef\": \"BUSINESS_PLATFORM\"" + "}";

	public static final String SAMPLE_JSON_STRING_CONCATENATION = "{" + "  \"keyedValue\": [" + "    {"
			+ "      \"keyName\": \"1222\"," + "      \"keyValue\": \"11\"," + "      \"vendorCode\": \"222\"" + "    }"
			+ "  ]," + "  \"relationID\": \"1234\"," + "  \"relationIDRef\": \"CONCATENATION\"" + "}";

	public static final String SAMPLE_JSON_STRING_RELATION_ID = "{" + "  \"keyedValue\": [" + "    {"
			+ "      \"keyName\": \"1222\"," + "      \"keyValue\": \"11\"," + "      \"vendorCode\": \"222\"" + "    }"
			+ "  ]," + "  \"relationID\": \"1234\"," + "  \"relationIDRef\": \"RELATION_ID\"" + "}";

	public static final String SAMPLE_JSON_SEARCH_REQUEST_STRING = "{\n" + "    \"maxRecords\": 100,\n"
			+ "    \"partySearchCriteria\": {\n" + "      \"dataField\": \"PARTY_ID_NO\",\n"
			+ "      \"value\": \"61845\",\n" + "      \"operation\": \"EXACT_MATCH\",\n"
			+ "      \"logic\": \"AND\",\n" + "      \"searchStatus\": \"ALL\",\n" + "      \"weighting\": 0\n"
			+ "    }\n" + "  }";
	private final ReadPartyRelationshipRequest readPartyRelationshipRequest = new ReadPartyRelationshipRequest();
	@MockBean
	private MaintainRelationshipValidator maintainAttachmentValidator;

	@MockBean
	private LoggerUtils loggerUtils;

	private final SearchPartyRelationshipTestDataUtils searchTestUtils = new SearchPartyRelationshipTestDataUtils();

	/**
	 * @Before Method will be called before each test case execution
	 */

	@Before
	public void setup() throws Exception {
		// INPUT REQUEST//
		readPartyRelationshipRequest.setRelationID("1234");
		readPartyRelationshipRequest.setRelationIDRef(RELATIONIDREF.BUSINESS_PLATFORM);

		readPartyRelationshipReply = new ReadPartyRelationshipReply();
		final Relation relation = new Relation();
		relation.setCreatedByNm("test");
		relation.setUpdatedByNm("test");
		readPartyRelationshipReply.setRelation(relation);

		readPartyRelationshipReplyList.add(readPartyRelationshipReply);
	}

	@Test
	public void readRelationshipsTest() throws Exception {

		when(maintainRelationshipService.readPartyRelationship(anyString(), anyString(), any()))
				.thenReturn(readPartyRelationshipReply);

		mvc.perform(post("/jh/signator/maintainparty/relationship/read").header("MessageUUID", "1234")
				.header("SourceSystemName", "1234").content(SAMPLE_JSON_STRING_BUINESS_PLATFORM)
				.contentType(MediaType.APPLICATION_JSON_UTF8_VALUE)).andDo(print())
				.andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE)).andExpect(status().isOk())
				.andExpect(jsonPath("$.relation.createdByNm", is("test")))
				.andExpect(jsonPath("$.relation.updatedByNm", is("test")));

		verify(maintainRelationshipService, times(1)).readPartyRelationship(anyString(), anyString(), any());
		verifyNoMoreInteractions(maintainRelationshipService);
	}

	// BAD REQUEST
	@Test
	public void policyBadRequest() throws Exception {
		mvc.perform(post("/jh/signator/maintainparty/relationship/read").header("MessageUUID", "1234")
				.header("SourceSystemName", "1234").content(SAMPLE_JSON_STRING_BUINESS_PLATFORM)
				.contentType(MediaType.APPLICATION_JSON_UTF8_VALUE)).andExpect(status().isOk());
	}

	@Test
	// CONCAT BAD REQUEST
	public void policyValidRequestConcat() throws Exception {
		mvc.perform(post("/jh/signator/maintainparty/relationship/read").header("MessageUUID", "1234")
				.header("SourceSystemName", "1234").content(SAMPLE_JSON_STRING_RELATION_ID)
				.contentType(MediaType.APPLICATION_JSON_UTF8_VALUE)).andExpect(status().isBadRequest());
	}

	@Test
	public void searchRelationshipsTest() throws Exception {

		when(maintainRelationshipService.searchPartyRelationship(anyString(), anyString(), any()))
				.thenReturn(searchTestUtils.getAllContractStatusTerminatedSearchPartyRelationshipReplyExpected());

		mvc.perform(post("/jh/signator/maintainparty/relationship/search").header("MessageUUID", "1234")
				.header("SourceSystemName", "1234").content(SAMPLE_JSON_SEARCH_REQUEST_STRING)
				.contentType(MediaType.APPLICATION_JSON_UTF8_VALUE)).andDo(print())
				.andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE)).andExpect(status().isOk())
				.andExpect(jsonPath("$.relation[0].createdByNm", is("JHFF")))
				.andExpect(jsonPath("$.relation[0].updatedByNm", is("JHFF")));

		verify(maintainRelationshipService, times(1)).searchPartyRelationship(anyString(), anyString(), any());
		verifyNoMoreInteractions(maintainRelationshipService);
	}

}
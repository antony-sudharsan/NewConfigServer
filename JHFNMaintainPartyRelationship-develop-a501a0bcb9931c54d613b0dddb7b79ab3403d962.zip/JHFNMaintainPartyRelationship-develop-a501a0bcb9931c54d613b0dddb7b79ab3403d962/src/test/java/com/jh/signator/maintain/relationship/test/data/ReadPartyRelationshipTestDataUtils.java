package com.jh.signator.maintain.relationship.test.data;

import java.math.BigInteger;
import java.sql.Timestamp;

import com.jh.signator.maintain.relationship.utils.SearchPartyUtils;
import com.manulife.esb.xsd.distribution.jhfn.partyrelationship.RELATIONIDREF;
import com.manulife.esb.xsd.distribution.jhfn.partyrelationship.ReadPartyRelationshipReply;
import com.manulife.esb.xsd.distribution.jhfn.partyrelationship.ReadPartyRelationshipRequest;
import com.manulife.esb.xsd.distribution.jhfn.partyrelationship.Relation;

/**
 * Utility class for test data related to read.
 */
public class ReadPartyRelationshipTestDataUtils {

	public static final String VALID_BUS_PLATFORM_READ_PARTY_RELATIONSHIP_BY_ID = "E79315F3-5279-4052-9312-087B1ACEC081";

	public ReadPartyRelationshipRequest getBusinessPlatformReadPartyRelationshipRequest() {
		final ReadPartyRelationshipRequest request = new ReadPartyRelationshipRequest();
		request.setRelationID(VALID_BUS_PLATFORM_READ_PARTY_RELATIONSHIP_BY_ID);
		request.setRelationIDRef(RELATIONIDREF.BUSINESS_PLATFORM);
		final ReadPartyRelationshipRequest.KeyedValue keyValue = new ReadPartyRelationshipRequest.KeyedValue();
		request.getKeyedValue().add(keyValue);
		keyValue.setKeyName("1122");
		keyValue.setKeyValue("11");
		keyValue.setVendorCode("222");
		return request;
	}

	public ReadPartyRelationshipReply getBusinessPlatformReadPartyRelationshipExpectedReply() {
		final ReadPartyRelationshipReply reply = new ReadPartyRelationshipReply();
		final Relation relation = new Relation();
		reply.setRelation(relation);
		relation.setRelationID(VALID_BUS_PLATFORM_READ_PARTY_RELATIONSHIP_BY_ID);
		relation.setRelationIDRef(RELATIONIDREF.BUSINESS_PLATFORM);
		relation.setRelatedRefID("a002mcc");
		relation.setRelatedRefIDType(BigInteger.valueOf(8001));
		relation.setRelationRoleCode(BigInteger.valueOf(9004));
		relation.setStartDate(
				SearchPartyUtils.convertTimestampToXmlGregorianCalendar(Timestamp.valueOf("2011-10-10 11:05:46.970")));
		relation.setEndDate(
				SearchPartyUtils.convertTimestampToXmlGregorianCalendar(Timestamp.valueOf("2014-12-18 10:51:42.057")));
		relation.setTemporaryRoleInd(false);
		relation.setSequence(0);
		relation.setBusinessRelationType(BigInteger.valueOf(9200));
		relation.setAllocationPercentage(0.0d);
		relation.setCreatedDate(
				SearchPartyUtils.convertTimestampToXmlGregorianCalendar(Timestamp.valueOf("2011-10-10 11:05:46.970")));
		relation.setCreatedByNm("a002mcc");
		relation.setUpdatedDate(
				SearchPartyUtils.convertTimestampToXmlGregorianCalendar(Timestamp.valueOf("2014-10-21 14:09:52.350")));
		relation.setUpdatedByNm("Role update");
		relation.setIDReferenceNo("a165jam");
		relation.setIDReferenceType(BigInteger.valueOf(8000));
		return reply;
	}

	public ReadPartyRelationshipReply getReadPartyRelationshipByIDReply() {
		final ReadPartyRelationshipReply reply = new ReadPartyRelationshipReply();
		final Relation relation = new Relation();
		reply.setRelation(relation);
		relation.setRelationID(VALID_BUS_PLATFORM_READ_PARTY_RELATIONSHIP_BY_ID);
		relation.setRelationIDRef(RELATIONIDREF.BUSINESS_PLATFORM);
		relation.setRelatedRefID("a002mcc");
		relation.setRelatedRefIDType(BigInteger.valueOf(8001));
		relation.setRelationRoleCode(BigInteger.valueOf(9004));
		relation.setStartDate(
				SearchPartyUtils.convertTimestampToXmlGregorianCalendar(Timestamp.valueOf("2011-10-10 11:05:46.970")));
		relation.setEndDate(
				SearchPartyUtils.convertTimestampToXmlGregorianCalendar(Timestamp.valueOf("2014-12-18 10:51:42.057")));
		relation.setCreatedDate(
				SearchPartyUtils.convertTimestampToXmlGregorianCalendar(Timestamp.valueOf("2011-10-10 11:05:46.970")));
		relation.setCreatedByNm("a002mcc");
		relation.setUpdatedDate(
				SearchPartyUtils.convertTimestampToXmlGregorianCalendar(Timestamp.valueOf("2014-10-21 14:09:52.350")));
		relation.setUpdatedByNm("Role update");
		relation.setIDReferenceNo("a165jam");
		relation.setIDReferenceType(BigInteger.valueOf(8000));
		return reply;
	}
}

package com.jh.signator.maintain.relationship.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.when;

import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import com.jh.signator.maintain.relationship.MaintainRelationshipApplication;
import com.jh.signator.maintain.relationship.dao.MaintainRelationshipReadDaoImpl;
import com.jh.signator.maintain.relationship.dao.MaintainRelationshipSearchDaoImpl;
import com.jh.signator.maintain.relationship.exception.RecordNotFoundException;
import com.jh.signator.maintain.relationship.model.data.BusinessPlatformLookUpCriteria;
import com.jh.signator.maintain.relationship.model.data.PartyLookupResult;
import com.jh.signator.maintain.relationship.model.data.SearchPartyLookupCriteria;
import com.jh.signator.maintain.relationship.test.data.SearchPartyRelationshipTestDataUtils;
import com.jh.signator.maintain.relationship.utils.LoggerUtils;
import com.manulife.esb.xsd.distribution.jhfn.partyrelationship.SearchPartyRelationshipReply;
import com.manulife.esb.xsd.distribution.jhfn.partyrelationship.SearchPartyRelationshipRequest;

/**
 * Test class for MaintainRelationshipService
 */
// TODO: Remove @RunWith and @SpringBootTest when can determine what
// DataMappingCrossLookUp is doing and how to modify so don't need to load
// spring context to use. Which slows the test down needlessly.
@ActiveProfiles("test")
@RunWith(SpringRunner.class)
@SpringBootTest(classes = MaintainRelationshipApplication.class, webEnvironment = WebEnvironment.MOCK)
public class MaintainRelationshipServiceTest {

	private static final String MESSAGE_UUID = "OEE_1234567_RPS";
	private static final String SOURCE_SYSTEM = "ESB";
	@Mock
	private MaintainRelationshipSearchDaoImpl maintainRelationshipSearchDao;

	@Mock
	MaintainRelationshipReadDaoImpl maintainRelationshipDAO;

	@Mock
	private LoggerUtils loggerUtils;

	@InjectMocks
	private MaintainRelationshipService maintainRelationshipService;

	@Rule
	public final ExpectedException exception = ExpectedException.none();

	private final SearchPartyRelationshipTestDataUtils testUtils = new SearchPartyRelationshipTestDataUtils();

	@Before
	public void setup() throws Exception {
		MockitoAnnotations.initMocks(this);
		when(loggerUtils.writeAsJson(any())).thenReturn("");
		// maintainRelationshipService = new
		// MaintainRelationshipService(maintainRelationshipDAO,
		// maintainRelationshipSearchDao, loggerUtils);
	}

	@Test
	public void givenSearchAllWithActiveContractStatusThenExpectedDaoMethodsInvoked() {
		when(maintainRelationshipSearchDao.getAllPartyLookupResult(any(SearchPartyLookupCriteria.class)))
				.thenReturn(testUtils.getAllContractStatusActivePartyLookupResult());
		when(maintainRelationshipSearchDao
				.getAllContractStatusActiveBusinessPlatformLookupResult(any(BusinessPlatformLookUpCriteria.class)))
						.thenReturn(testUtils.getAllContractStatusActiveBusinessPlatformLookupResult());

		final SearchPartyRelationshipRequest request = testUtils.getAllSearchPartyRelationshipRequest(
				SearchPartyRelationshipTestDataUtils.ALL_CONTRACT_STATUS_ACTIVE_TEST_ID);

		maintainRelationshipService.searchPartyRelationship(MESSAGE_UUID, SOURCE_SYSTEM, request);

		verify(maintainRelationshipSearchDao, times(1)).getAllPartyLookupResult(any(SearchPartyLookupCriteria.class));
		verify(maintainRelationshipSearchDao, times(1))
				.getAllContractStatusActiveBusinessPlatformLookupResult(any(BusinessPlatformLookUpCriteria.class));
		verifyNoMoreInteractions(maintainRelationshipSearchDao);
	}

	@Test
	public void givenSearchAllWithTerminatedContractStatusThenExpectedDaoMethodsInvoked() {
		when(maintainRelationshipSearchDao.getAllPartyLookupResult(any(SearchPartyLookupCriteria.class)))
				.thenReturn(testUtils.getAllContractStatusTerminatedPartyLookupResult());
		when(maintainRelationshipSearchDao
				.getAllContractStatusActiveBusinessPlatformLookupResult(any(BusinessPlatformLookUpCriteria.class)))
						.thenReturn(testUtils.getAllContractStatusTerminatedBusinessPlatformLookupResult());

		final SearchPartyRelationshipRequest request = testUtils.getAllSearchPartyRelationshipRequest(
				SearchPartyRelationshipTestDataUtils.ALL_CONTRACT_STATUS_TERMINATED_TEST_ID);

		maintainRelationshipService.searchPartyRelationship(MESSAGE_UUID, SOURCE_SYSTEM, request);

		verify(maintainRelationshipSearchDao, times(1)).getAllPartyLookupResult(any(SearchPartyLookupCriteria.class));
		verify(maintainRelationshipSearchDao, times(1))
				.getAllContractStatusTerminatedBusinessPlatformLookupResult(any(BusinessPlatformLookUpCriteria.class));
		verifyNoMoreInteractions(maintainRelationshipSearchDao);
	}

	@Test
	public void givenSearchActiveOnlyThenExpectedDaoMethodsInvoked() {
		when(maintainRelationshipSearchDao.getActiveOnlyPartyLookupResult(any(SearchPartyLookupCriteria.class)))
				.thenReturn(testUtils.getActiveOnlyPartyLookupResult());
		when(maintainRelationshipSearchDao
				.getActiveOnlyBusinessPlatformLookupResult(any(BusinessPlatformLookUpCriteria.class)))
						.thenReturn(testUtils.getActiveOnlyBusinessPlatformLookupResult());

		final SearchPartyRelationshipRequest request = testUtils.getActiveOnlySearchPartyRelationshipRequest();

		maintainRelationshipService.searchPartyRelationship(MESSAGE_UUID, SOURCE_SYSTEM, request);

		verify(maintainRelationshipSearchDao, times(1))
				.getActiveOnlyPartyLookupResult(any(SearchPartyLookupCriteria.class));
		verify(maintainRelationshipSearchDao, times(1))
				.getActiveOnlyBusinessPlatformLookupResult(any(BusinessPlatformLookUpCriteria.class));
		verifyNoMoreInteractions(maintainRelationshipSearchDao);
	}

	@Test
	public void givenSearchActiveOnlyThenThenExpectedReplyReturned() {
		when(maintainRelationshipSearchDao.getActiveOnlyPartyLookupResult(any(SearchPartyLookupCriteria.class)))
				.thenReturn(testUtils.getActiveOnlyPartyLookupResult());
		when(maintainRelationshipSearchDao
				.getActiveOnlyBusinessPlatformLookupResult(any(BusinessPlatformLookUpCriteria.class)))
						.thenReturn(testUtils.getActiveOnlyBusinessPlatformLookupResult());

		final SearchPartyRelationshipRequest request = testUtils.getActiveOnlySearchPartyRelationshipRequest();

		final SearchPartyRelationshipReply actualReply = maintainRelationshipService
				.searchPartyRelationship(MESSAGE_UUID, SOURCE_SYSTEM, request);

		assertThat(actualReply).isEqualToComparingFieldByFieldRecursively(
				testUtils.getActiveOnlySearchPartyRelationshipReplyExpected());
	}

	@Test
	public void givenSearchAllWithActiveContractStatusThenExpectedReplyReturned() {
		when(maintainRelationshipSearchDao.getAllPartyLookupResult(any(SearchPartyLookupCriteria.class)))
				.thenReturn(testUtils.getAllContractStatusActivePartyLookupResult());
		when(maintainRelationshipSearchDao
				.getAllContractStatusActiveBusinessPlatformLookupResult(any(BusinessPlatformLookUpCriteria.class)))
						.thenReturn(testUtils.getAllContractStatusActiveBusinessPlatformLookupResult());

		final SearchPartyRelationshipRequest request = testUtils.getAllSearchPartyRelationshipRequest(
				SearchPartyRelationshipTestDataUtils.ALL_CONTRACT_STATUS_ACTIVE_TEST_ID);

		final SearchPartyRelationshipReply actualReply = maintainRelationshipService
				.searchPartyRelationship(MESSAGE_UUID, SOURCE_SYSTEM, request);

		assertThat(actualReply).isEqualToComparingFieldByFieldRecursively(
				testUtils.getAllContractStatusActiveSearchPartyRelationshipReplyExpected());

	}

	@Test
	public void givenSearchAllWithTerminatedContractStatusThenExpectedReplyReturned() {
		when(maintainRelationshipSearchDao.getAllPartyLookupResult(any(SearchPartyLookupCriteria.class)))
				.thenReturn(testUtils.getAllContractStatusTerminatedPartyLookupResult());
		when(maintainRelationshipSearchDao
				.getAllContractStatusActiveBusinessPlatformLookupResult(any(BusinessPlatformLookUpCriteria.class)))
						.thenReturn(testUtils.getAllContractStatusTerminatedBusinessPlatformLookupResult());

		final SearchPartyRelationshipRequest request = testUtils.getAllSearchPartyRelationshipRequest(
				SearchPartyRelationshipTestDataUtils.ALL_CONTRACT_STATUS_TERMINATED_TEST_ID);

		final SearchPartyRelationshipReply actualReply = maintainRelationshipService
				.searchPartyRelationship(MESSAGE_UUID, SOURCE_SYSTEM, request);

		assertThat(actualReply).isEqualToComparingFieldByFieldRecursively(
				testUtils.getAllContractStatusTerminatedSearchPartyRelationshipReplyExpected());

	}

	@Test
	public void givenSearchAllWhenNoFirmCdInPartyResultLookupReturnedThenRecordNotFoundExceptionThrown() {
		final PartyLookupResult partyLookupResult = testUtils.getAllContractStatusActivePartyLookupResult();
		partyLookupResult.setFirmCd(null);
		when(maintainRelationshipSearchDao.getAllPartyLookupResult(any(SearchPartyLookupCriteria.class)))
				.thenReturn(partyLookupResult);

		final SearchPartyRelationshipRequest request = testUtils.getAllSearchPartyRelationshipRequest(
				SearchPartyRelationshipTestDataUtils.ALL_CONTRACT_STATUS_ACTIVE_TEST_ID);

		exception.expect(RecordNotFoundException.class);
		maintainRelationshipService.searchPartyRelationship(MESSAGE_UUID, SOURCE_SYSTEM, request);
	}

	@Test
	public void givenSearchAllWhenNoPartyResultLookupReturnedThenRecordNotFoundExceptionThrown() {
		when(maintainRelationshipSearchDao.getAllPartyLookupResult(any(SearchPartyLookupCriteria.class)))
				.thenReturn(null);
		final SearchPartyRelationshipRequest request = testUtils.getAllSearchPartyRelationshipRequest(
				SearchPartyRelationshipTestDataUtils.ALL_CONTRACT_STATUS_ACTIVE_TEST_ID);

		exception.expect(RecordNotFoundException.class);
		maintainRelationshipService.searchPartyRelationship(MESSAGE_UUID, SOURCE_SYSTEM, request);
	}

	@Test
	public void givenSearchActiveOnlyWhenNoPartyResultLookupReturnedThenRecordNotFoundExceptionThrown() {
		when(maintainRelationshipSearchDao.getAllPartyLookupResult(any(SearchPartyLookupCriteria.class)))
				.thenReturn(null);
		final SearchPartyRelationshipRequest request = testUtils.getActiveOnlySearchPartyRelationshipRequest();

		exception.expect(RecordNotFoundException.class);
		maintainRelationshipService.searchPartyRelationship(MESSAGE_UUID, SOURCE_SYSTEM, request);
	}

}

package com.jh.signator.maintain.relationship.test.data;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import com.jh.signator.maintain.relationship.model.data.PartyLookupResult;
import com.jh.signator.maintain.relationship.model.data.SearchBusinessPlatformLookUpResult;
import com.jh.signator.maintain.relationship.utils.SearchPartyUtils;
import com.manulife.esb.xsd.distribution.jhfn.partyrelationship.CONDITIONALLOGIC;
import com.manulife.esb.xsd.distribution.jhfn.partyrelationship.DATAFIELD;
import com.manulife.esb.xsd.distribution.jhfn.partyrelationship.OPERATION;
import com.manulife.esb.xsd.distribution.jhfn.partyrelationship.PartySearchCriteria;
import com.manulife.esb.xsd.distribution.jhfn.partyrelationship.RELATIONIDREF;
import com.manulife.esb.xsd.distribution.jhfn.partyrelationship.Relation;
import com.manulife.esb.xsd.distribution.jhfn.partyrelationship.SEARCHSTATUS;
import com.manulife.esb.xsd.distribution.jhfn.partyrelationship.SearchPartyRelationshipReply;
import com.manulife.esb.xsd.distribution.jhfn.partyrelationship.SearchPartyRelationshipRequest;

/**
 * Utility class for test data related to search.
 */
public class SearchPartyRelationshipTestDataUtils {
	public static final String ACTIVE_ONLY_TEST_ID = "68457";
	public static final String ALL_CONTRACT_STATUS_ACTIVE_TEST_ID = "68145";
	public static final String ALL_CONTRACT_STATUS_TERMINATED_TEST_ID = "61845";

	public SearchPartyRelationshipRequest getAllSearchPartyRelationshipRequest(final String id) {
		final SearchPartyRelationshipRequest request = new SearchPartyRelationshipRequest();
		final PartySearchCriteria partySearchCriteria = new PartySearchCriteria();
		request.setMaxRecords(100);
		request.setPartySearchCriteria(partySearchCriteria);
		partySearchCriteria.setDataField(DATAFIELD.PARTY_ID_NO);
		partySearchCriteria.setValue(id);
		partySearchCriteria.setOperation(OPERATION.EXACT_MATCH);
		partySearchCriteria.setLogic(CONDITIONALLOGIC.AND);
		partySearchCriteria.setSearchStatus(SEARCHSTATUS.ALL);
		partySearchCriteria.setWeighting(0d);
		return request;
	}

	public SearchPartyRelationshipRequest getActiveOnlySearchPartyRelationshipRequest() {
		final SearchPartyRelationshipRequest request = new SearchPartyRelationshipRequest();
		final PartySearchCriteria partySearchCriteria = new PartySearchCriteria();
		request.setMaxRecords(100);
		request.setPartySearchCriteria(partySearchCriteria);
		partySearchCriteria.setDataField(DATAFIELD.PARTY_ID_NO);
		partySearchCriteria.setValue(ACTIVE_ONLY_TEST_ID);
		partySearchCriteria.setOperation(OPERATION.EXACT_MATCH);
		partySearchCriteria.setLogic(CONDITIONALLOGIC.AND);
		partySearchCriteria.setSearchStatus(SEARCHSTATUS.ACTIVE_ONLY);
		partySearchCriteria.setWeighting(0d);
		return request;
	}

	public PartyLookupResult getActiveOnlyPartyLookupResult() {
		final PartyLookupResult result = new PartyLookupResult();
		result.setPartyIdNo(new BigDecimal(ACTIVE_ONLY_TEST_ID));
		result.setPrdId("a026moo");
		result.setFirmCd(new BigDecimal("26"));
		result.setContractStatus("active");
		result.setContractDate(Timestamp.valueOf("2018-03-01 00:00:00.0"));
		result.setContractOrgPartyIdNo(new BigDecimal("27"));
		return result;
	}

	public PartyLookupResult getAllContractStatusActivePartyLookupResult() {
		final PartyLookupResult result = new PartyLookupResult();
		result.setPartyIdNo(new BigDecimal(ALL_CONTRACT_STATUS_ACTIVE_TEST_ID));
		result.setPrdId("a026kmc");
		result.setFirmCd(new BigDecimal("26"));
		result.setContractStatus("active");
		result.setContractDate(Timestamp.valueOf("2018-03-01 00:00:00.0"));
		result.setContractOrgPartyIdNo(new BigDecimal("27"));
		return result;
	}

	public PartyLookupResult getAllContractStatusTerminatedPartyLookupResult() {
		final PartyLookupResult result = new PartyLookupResult();
		result.setPartyIdNo(new BigDecimal(ALL_CONTRACT_STATUS_TERMINATED_TEST_ID));
		result.setPrdId("a026kmc");
		result.setFirmCd(new BigDecimal("149"));
		result.setContractStatus("terminated");
		result.setContractDate(Timestamp.valueOf("2003-01-15 00:00:00.0"));
		result.setContractOrgPartyIdNo(new BigDecimal("149"));
		result.setTermDate(Timestamp.valueOf("2012-04-24 00:00:00.0"));
		return result;
	}

	public List<SearchBusinessPlatformLookUpResult> getActiveOnlyBusinessPlatformLookupResult() {
		final List<SearchBusinessPlatformLookUpResult> results = new ArrayList<>();
		SearchBusinessPlatformLookUpResult result = new SearchBusinessPlatformLookUpResult();
		results.add(result);
		result.setTransactionIdNo("8A16E495-0A05-42EB-BC6F-6C7DB5B30385");
		result.setPartyIdNo(new BigDecimal("71424"));
		result.setPrdId("a026kyl");
		result.setRoleCd("STAFF");
		result.setAgentOrgPartyIdNo(new BigDecimal("27"));
		result.setOrgPartyIdNo(new BigDecimal("27"));
		result.setOrgAgencyCd(new BigDecimal("26"));
		result.setAgencyCd(new BigDecimal("26"));
		result.setParty2IdNo(new BigDecimal("27"));
		result.setTransactionEffDate(Timestamp.valueOf("2015-05-21 11:05:09.88"));
		result.setCreatDtm(Timestamp.valueOf("2015-05-21 11:05:09.88"));
		result.setCreatByNm("a026kyl");
		result.setLastUpdDtm(Timestamp.valueOf("2015-05-21 11:05:09.88"));
		result.setLastUpdByNm("a026kyl");
		result = new SearchBusinessPlatformLookUpResult();
		results.add(result);
		result.setTransactionIdNo("46F7C26F-0384-4808-9C5D-2F3006FBB628");
		result.setPartyIdNo(new BigDecimal("68457"));
		result.setPrdId("a026moo");
		result.setRoleCd("REPWT");
		result.setAgentOrgPartyIdNo(new BigDecimal("27"));
		result.setOrgPartyIdNo(new BigDecimal("27"));
		result.setOrgAgencyCd(new BigDecimal("26"));
		result.setAgencyCd(new BigDecimal("26"));
		result.setParty2IdNo(new BigDecimal("27"));
		result.setTransactionEffDate(Timestamp.valueOf("2014-10-21 14:09:52.35"));
		result.setCreatDtm(Timestamp.valueOf("2014-10-21 14:09:52.35"));
		result.setCreatByNm("a026moo");
		result.setLastUpdDtm(Timestamp.valueOf("2014-10-21 14:09:52.35"));
		result.setLastUpdByNm("a026moo");
		result = new SearchBusinessPlatformLookUpResult();
		results.add(result);
		result.setTransactionIdNo("48116C44-1BF2-49AE-9A2C-346AB921B391");
		result.setPartyIdNo(new BigDecimal("2094"));
		result.setPrdId("a026jan");
		result.setRoleCd("MP");
		result.setAgentOrgPartyIdNo(new BigDecimal("27"));
		result.setOrgPartyIdNo(new BigDecimal("27"));
		result.setOrgAgencyCd(new BigDecimal("26"));
		result.setAgencyCd(new BigDecimal("26"));
		result.setParty2IdNo(new BigDecimal("27"));
		result.setTransactionEffDate(Timestamp.valueOf("2016-12-12 08:08:12.493"));
		result.setCreatDtm(Timestamp.valueOf("2016-12-12 08:08:12.493"));
		result.setCreatByNm("jhdrhin");
		result.setLastUpdDtm(Timestamp.valueOf("2016-12-12 08:08:12.493"));
		result.setLastUpdByNm("jhdrhin");
		result = new SearchBusinessPlatformLookUpResult();
		results.add(result);
		result.setTransactionIdNo("C793BC3C-4D1A-493F-B07F-248C30FDFDA4");
		result.setPartyIdNo(new BigDecimal("68145"));
		result.setPrdId("a026kmc");
		result.setRoleCd("STAFF");
		result.setOtherRole("Sales Assistant");
		result.setRepPartyIdNo(new BigDecimal("68457"));
		result.setAgentPrdId("a026moo");
		result.setOrgPartyIdNo(new BigDecimal("27"));
		result.setOrgAgencyCd(new BigDecimal("26"));
		result.setParty2IdNo(new BigDecimal("27"));
		result.setTransactionEffDate(Timestamp.valueOf("2014-10-21 14:09:52.377"));
		result.setCreatDtm(Timestamp.valueOf("2014-10-21 14:09:52.377"));
		result.setCreatByNm("a026moo");
		result.setLastUpdDtm(Timestamp.valueOf("2014-10-21 14:09:52.377"));
		result.setLastUpdByNm("a026moo");
		result = new SearchBusinessPlatformLookUpResult();
		results.add(result);
		result.setTransactionIdNo("46F7C26F-0384-4808-9C5D-2F3006FBB628");
		result.setPartyIdNo(new BigDecimal("68457"));
		result.setPrdId("a026moo");
		result.setRoleCd("REPWT");
		result.setAgentOrgPartyIdNo(new BigDecimal("27"));
		result.setOrgPartyIdNo(new BigDecimal("27"));
		result.setParty2IdNo(new BigDecimal("27"));
		result.setTransactionEffDate(Timestamp.valueOf("2014-10-21 14:09:52.35"));
		result.setCreatDtm(Timestamp.valueOf("2014-10-21 14:09:52.35"));
		result.setCreatByNm("a026moo");
		result.setLastUpdDtm(Timestamp.valueOf("2014-10-21 14:09:52.35"));
		result.setLastUpdByNm("a026moo");

		return results;
	}

	public List<SearchBusinessPlatformLookUpResult> getActiveOnlyMpBusinessPlatformLookupResult() {
		final List<SearchBusinessPlatformLookUpResult> results = new ArrayList<>();
		SearchBusinessPlatformLookUpResult result = new SearchBusinessPlatformLookUpResult();
		results.add(result);
		result.setTransactionIdNo("8A16E495-0A05-42EB-BC6F-6C7DB5B30385");
		result.setPartyIdNo(new BigDecimal(ACTIVE_ONLY_TEST_ID));
		result.setRepPartyIdNo(new BigDecimal(ACTIVE_ONLY_TEST_ID));
		result.setPrdId("a026kyl");
		result.setRoleCd("MP");
		result.setAgentOrgPartyIdNo(new BigDecimal("27"));
		result.setOrgPartyIdNo(new BigDecimal("27"));
		result.setOrgAgencyCd(new BigDecimal("26"));
		result.setAgencyCd(new BigDecimal("26"));
		result.setParty2IdNo(new BigDecimal("27"));
		result.setTransactionEffDate(Timestamp.valueOf("2015-05-21 11:05:09.88"));
		result.setCreatDtm(Timestamp.valueOf("2015-05-21 11:05:09.88"));
		result.setCreatByNm("a026kyl");
		result.setLastUpdDtm(Timestamp.valueOf("2015-05-21 11:05:09.88"));
		result.setLastUpdByNm("a026kyl");
		result = new SearchBusinessPlatformLookUpResult();
		results.add(result);
		result.setTransactionIdNo("46F7C26F-0384-4808-9C5D-2F3006FBB628");
		result.setPartyIdNo(new BigDecimal("11111"));
		result.setPrdId("a026moo");
		result.setRoleCd("REPWT");
		result.setAgentOrgPartyIdNo(new BigDecimal("27"));
		result.setOrgPartyIdNo(new BigDecimal("27"));
		result.setOrgAgencyCd(new BigDecimal("26"));
		result.setAgencyCd(new BigDecimal("26"));
		result.setParty2IdNo(new BigDecimal("27"));
		result.setTransactionEffDate(Timestamp.valueOf("2014-10-21 14:09:52.35"));
		result.setCreatDtm(Timestamp.valueOf("2014-10-21 14:09:52.35"));
		result.setCreatByNm("a026moo");
		result.setLastUpdDtm(Timestamp.valueOf("2014-10-21 14:09:52.35"));
		result.setLastUpdByNm("a026moo");
		result = new SearchBusinessPlatformLookUpResult();
		results.add(result);
		result.setTransactionIdNo("48116C44-1BF2-49AE-9A2C-346AB921B391");
		result.setPartyIdNo(new BigDecimal("11111"));
		result.setPrdId("a026jan");
		result.setRoleCd("MP");
		result.setAgentOrgPartyIdNo(new BigDecimal("27"));
		result.setOrgPartyIdNo(new BigDecimal("27"));
		result.setOrgAgencyCd(new BigDecimal("26"));
		result.setAgencyCd(new BigDecimal("26"));
		result.setParty2IdNo(new BigDecimal("27"));
		result.setTransactionEffDate(Timestamp.valueOf("2016-12-12 08:08:12.493"));
		result.setCreatDtm(Timestamp.valueOf("2016-12-12 08:08:12.493"));
		result.setCreatByNm("jhdrhin");
		result.setLastUpdDtm(Timestamp.valueOf("2016-12-12 08:08:12.493"));
		result.setLastUpdByNm("jhdrhin");

		return results;
	}

	public List<SearchBusinessPlatformLookUpResult> getActiveOnlyAcsBusinessPlatformLookupResult() {
		final List<SearchBusinessPlatformLookUpResult> results = new ArrayList<>();
		SearchBusinessPlatformLookUpResult result = new SearchBusinessPlatformLookUpResult();
		results.add(result);
		result.setTransactionIdNo("8A16E495-0A05-42EB-BC6F-6C7DB5B30385");
		result.setPartyIdNo(new BigDecimal(ACTIVE_ONLY_TEST_ID));
		result.setRepPartyIdNo(new BigDecimal(ACTIVE_ONLY_TEST_ID));
		result.setPrdId("a026kyl");
		result.setRoleCd("ACS");
		result.setOtherRole("Sales Assistant");
		result.setAgentOrgPartyIdNo(new BigDecimal("27"));
		result.setOrgPartyIdNo(new BigDecimal("27"));
		result.setOrgAgencyCd(new BigDecimal("26"));
		result.setAgencyCd(new BigDecimal("26"));
		result.setParty2IdNo(new BigDecimal("27"));
		result.setTransactionEffDate(Timestamp.valueOf("2015-05-21 11:05:09.88"));
		result.setCreatDtm(Timestamp.valueOf("2015-05-21 11:05:09.88"));
		result.setCreatByNm("a026kyl");
		result.setLastUpdDtm(Timestamp.valueOf("2015-05-21 11:05:09.88"));
		result.setLastUpdByNm("a026kyl");
		result = new SearchBusinessPlatformLookUpResult();
		results.add(result);
		result.setTransactionIdNo("8A16E495-0A05-42EB-BC6F-6C7DB5B30385");
		result.setPartyIdNo(new BigDecimal(ACTIVE_ONLY_TEST_ID));
		result.setRepPartyIdNo(new BigDecimal(ACTIVE_ONLY_TEST_ID));
		result.setPrdId("a026kyl");
		result.setRoleCd("REPWT");
		result.setOtherRole("Sales Assistant");
		result.setAgentOrgPartyIdNo(new BigDecimal("27"));
		result.setOrgPartyIdNo(new BigDecimal("27"));
		result.setOrgAgencyCd(new BigDecimal("26"));
		result.setAgencyCd(new BigDecimal("26"));
		result.setParty2IdNo(new BigDecimal("27"));
		result.setTransactionEffDate(Timestamp.valueOf("2015-05-21 11:05:09.88"));
		result.setCreatDtm(Timestamp.valueOf("2015-05-21 11:05:09.88"));
		result.setCreatByNm("a026kyl");
		result.setLastUpdDtm(Timestamp.valueOf("2015-05-21 11:05:09.88"));
		result.setLastUpdByNm("a026kyl");
		result = new SearchBusinessPlatformLookUpResult();
		results.add(result);
		result.setTransactionIdNo("46F7C26F-0384-4808-9C5D-2F3006FBB628");
		result.setPartyIdNo(new BigDecimal("11111"));
		result.setPrdId("a026moo");
		result.setRoleCd("REPWT");
		result.setAgentOrgPartyIdNo(new BigDecimal("27"));
		result.setOrgPartyIdNo(new BigDecimal("27"));
		result.setOrgAgencyCd(new BigDecimal("26"));
		result.setAgencyCd(new BigDecimal("26"));
		result.setParty2IdNo(new BigDecimal("27"));
		result.setTransactionEffDate(Timestamp.valueOf("2014-10-21 14:09:52.35"));
		result.setCreatDtm(Timestamp.valueOf("2014-10-21 14:09:52.35"));
		result.setCreatByNm("a026moo");
		result.setLastUpdDtm(Timestamp.valueOf("2014-10-21 14:09:52.35"));
		result.setLastUpdByNm("a026moo");
		result = new SearchBusinessPlatformLookUpResult();
		results.add(result);
		result.setTransactionIdNo("48116C44-1BF2-49AE-9A2C-346AB921B391");
		result.setPartyIdNo(new BigDecimal("11111"));
		result.setPrdId("a026jan");
		result.setRoleCd("MP");
		result.setAgentOrgPartyIdNo(new BigDecimal("27"));
		result.setOrgPartyIdNo(new BigDecimal("27"));
		result.setOrgAgencyCd(new BigDecimal("26"));
		result.setAgencyCd(new BigDecimal("26"));
		result.setParty2IdNo(new BigDecimal("27"));
		result.setTransactionEffDate(Timestamp.valueOf("2016-12-12 08:08:12.493"));
		result.setCreatDtm(Timestamp.valueOf("2016-12-12 08:08:12.493"));
		result.setCreatByNm("jhdrhin");
		result.setLastUpdDtm(Timestamp.valueOf("2016-12-12 08:08:12.493"));
		result.setLastUpdByNm("jhdrhin");

		return results;
	}

	public List<SearchBusinessPlatformLookUpResult> getActiveOnlyFirmStaffBusinessPlatformLookupResult() {
		final List<SearchBusinessPlatformLookUpResult> results = new ArrayList<>();
		SearchBusinessPlatformLookUpResult result = new SearchBusinessPlatformLookUpResult();
		results.add(result);
		result.setTransactionIdNo("8A16E495-0A05-42EB-BC6F-6C7DB5B30385");
		result.setPartyIdNo(new BigDecimal(ACTIVE_ONLY_TEST_ID));
		result.setRepPartyIdNo(new BigDecimal(ACTIVE_ONLY_TEST_ID));
		result.setPrdId("a026kyl");
		result.setRoleCd("REPWT");
		result.setOtherRole("Firm Staff");
		result.setAgentOrgPartyIdNo(new BigDecimal("27"));
		result.setOrgPartyIdNo(new BigDecimal("27"));
		result.setOrgAgencyCd(new BigDecimal("26"));
		result.setAgencyCd(new BigDecimal("26"));
		result.setParty2IdNo(new BigDecimal("27"));
		result.setTransactionEffDate(Timestamp.valueOf("2015-05-21 11:05:09.88"));
		result.setCreatDtm(Timestamp.valueOf("2015-05-21 11:05:09.88"));
		result.setCreatByNm("a026kyl");
		result.setLastUpdDtm(Timestamp.valueOf("2015-05-21 11:05:09.88"));
		result.setLastUpdByNm("a026kyl");
		result = new SearchBusinessPlatformLookUpResult();
		results.add(result);
		result.setTransactionIdNo("46F7C26F-0384-4808-9C5D-2F3006FBB628");
		result.setPartyIdNo(new BigDecimal("11111"));
		result.setPrdId("a026moo");
		result.setRoleCd("REPWT");
		result.setAgentOrgPartyIdNo(new BigDecimal("27"));
		result.setOrgPartyIdNo(new BigDecimal("27"));
		result.setOrgAgencyCd(new BigDecimal("26"));
		result.setAgencyCd(new BigDecimal("26"));
		result.setParty2IdNo(new BigDecimal("27"));
		result.setTransactionEffDate(Timestamp.valueOf("2014-10-21 14:09:52.35"));
		result.setCreatDtm(Timestamp.valueOf("2014-10-21 14:09:52.35"));
		result.setCreatByNm("a026moo");
		result.setLastUpdDtm(Timestamp.valueOf("2014-10-21 14:09:52.35"));
		result.setLastUpdByNm("a026moo");
		result = new SearchBusinessPlatformLookUpResult();
		results.add(result);
		result.setTransactionIdNo("48116C44-1BF2-49AE-9A2C-346AB921B391");
		result.setPartyIdNo(new BigDecimal("11111"));
		result.setPrdId("a026jan");
		result.setRoleCd("MP");
		result.setAgentOrgPartyIdNo(new BigDecimal("27"));
		result.setOrgPartyIdNo(new BigDecimal("27"));
		result.setOrgAgencyCd(new BigDecimal("26"));
		result.setAgencyCd(new BigDecimal("26"));
		result.setParty2IdNo(new BigDecimal("27"));
		result.setTransactionEffDate(Timestamp.valueOf("2016-12-12 08:08:12.493"));
		result.setCreatDtm(Timestamp.valueOf("2016-12-12 08:08:12.493"));
		result.setCreatByNm("jhdrhin");
		result.setLastUpdDtm(Timestamp.valueOf("2016-12-12 08:08:12.493"));
		result.setLastUpdByNm("jhdrhin");

		return results;
	}

	public List<SearchBusinessPlatformLookUpResult> getActiveOnlyOtherwiseBusinessPlatformLookupResult() {
		final List<SearchBusinessPlatformLookUpResult> results = new ArrayList<>();
		SearchBusinessPlatformLookUpResult result = new SearchBusinessPlatformLookUpResult();
		results.add(result);
		result.setTransactionIdNo("8A16E495-0A05-42EB-BC6F-6C7DB5B30385");
		result.setPartyIdNo(new BigDecimal(ACTIVE_ONLY_TEST_ID));
		result.setRepPartyIdNo(new BigDecimal(ACTIVE_ONLY_TEST_ID));
		result.setPrdId("a026kyl");
		result.setRoleCd("STAFF");
		result.setAgentOrgPartyIdNo(new BigDecimal("27"));
		result.setOrgPartyIdNo(new BigDecimal("27"));
		result.setOrgAgencyCd(new BigDecimal("26"));
		result.setAgencyCd(new BigDecimal("26"));
		result.setParty2IdNo(new BigDecimal("27"));
		result.setTransactionEffDate(Timestamp.valueOf("2015-05-21 11:05:09.88"));
		result.setCreatDtm(Timestamp.valueOf("2015-05-21 11:05:09.88"));
		result.setCreatByNm("a026kyl");
		result.setLastUpdDtm(Timestamp.valueOf("2015-05-21 11:05:09.88"));
		result.setLastUpdByNm("a026kyl");

		result = new SearchBusinessPlatformLookUpResult();
		results.add(result);
		result.setTransactionIdNo("46F7C26F-0384-4808-9C5D-2F3006FBB628");
		result.setPartyIdNo(new BigDecimal("11111"));
		result.setPrdId("a026moo");
		result.setRoleCd("REPWT");
		result.setAgentOrgPartyIdNo(new BigDecimal("27"));
		result.setOrgPartyIdNo(new BigDecimal("27"));
		result.setOrgAgencyCd(new BigDecimal("26"));
		result.setAgencyCd(new BigDecimal("26"));
		result.setParty2IdNo(new BigDecimal("27"));
		result.setTransactionEffDate(Timestamp.valueOf("2014-10-21 14:09:52.35"));
		result.setCreatDtm(Timestamp.valueOf("2014-10-21 14:09:52.35"));
		result.setCreatByNm("a026moo");
		result.setLastUpdDtm(Timestamp.valueOf("2014-10-21 14:09:52.35"));
		result.setLastUpdByNm("a026moo");
		result = new SearchBusinessPlatformLookUpResult();
		results.add(result);
		result.setTransactionIdNo("48116C44-1BF2-49AE-9A2C-346AB921B391");
		result.setPartyIdNo(new BigDecimal("11111"));
		result.setPrdId("a026jan");
		result.setRoleCd("MP");
		result.setAgentOrgPartyIdNo(new BigDecimal("27"));
		result.setOrgPartyIdNo(new BigDecimal("27"));
		result.setOrgAgencyCd(new BigDecimal("26"));
		result.setAgencyCd(new BigDecimal("26"));
		result.setParty2IdNo(new BigDecimal("27"));
		result.setTransactionEffDate(Timestamp.valueOf("2016-12-12 08:08:12.493"));
		result.setCreatDtm(Timestamp.valueOf("2016-12-12 08:08:12.493"));
		result.setCreatByNm("jhdrhin");
		result.setLastUpdDtm(Timestamp.valueOf("2016-12-12 08:08:12.493"));
		result.setLastUpdByNm("jhdrhin");

		return results;
	}

	public List<SearchBusinessPlatformLookUpResult> getAllContractStatusActiveBusinessPlatformLookupResult() {
		final List<SearchBusinessPlatformLookUpResult> results = new ArrayList<>();
		SearchBusinessPlatformLookUpResult result = new SearchBusinessPlatformLookUpResult();
		results.add(result);
		result.setTransactionIdNo("D88B2FC0-3C61-4E25-B8D0-33471739D0C7");
		result.setPartyIdNo(new BigDecimal("70495"));
		result.setPrdId("a026kof");
		result.setRoleCd("STAFF");
		result.setAgentOrgPartyIdNo(new BigDecimal("103"));
		result.setOrgPartyIdNo(new BigDecimal("27"));
		result.setFirmCd(new BigDecimal("26"));
		result.setParty2IdNo(new BigDecimal("27"));
		result.setTransactionEffDate(Timestamp.valueOf("2017-02-23 11:53:52.22"));
		result.setCreatDtm(Timestamp.valueOf("2017-02-23 11:53:52.22"));
		result.setCreatByNm("wimarke");
		result.setLastUpdDtm(Timestamp.valueOf("2017-02-23 11:53:52.22"));
		result.setLastUpdByNm("wimarke");
		result.setTxnStatus("active");
		result = new SearchBusinessPlatformLookUpResult();
		results.add(result);
		result.setTransactionIdNo("C793BC3C-4D1A-493F-B07F-248C30FDFDA4");
		result.setPartyIdNo(new BigDecimal("68145"));
		result.setPrdId("a026kmc");
		result.setRoleCd("STAFF");
		result.setOtherRole("Sales Assistant");
		result.setRepPartyIdNo(new BigDecimal("68457"));
		result.setAgentPrdId("a026moo");
		result.setOrgPartyIdNo(new BigDecimal("27"));
		result.setFirmCd(new BigDecimal("26"));
		result.setParty2IdNo(new BigDecimal("27"));
		result.setTransactionEffDate(Timestamp.valueOf("2014-10-21 14:09:52.377"));
		result.setCreatDtm(Timestamp.valueOf("2014-10-21 14:09:52.377"));
		result.setCreatByNm("a026moo");
		result.setLastUpdDtm(Timestamp.valueOf("2014-10-21 14:09:52.377"));
		result.setLastUpdByNm("a026moo");
		result.setTxnStatus("active");
		result = new SearchBusinessPlatformLookUpResult();
		results.add(result);
		result.setTransactionIdNo("254B2B87-6B60-4C6B-90B2-B86D498E8A83");
		result.setPartyIdNo(new BigDecimal("68145"));
		result.setPrdId("a026kmc");
		result.setRoleCd("STAFF");
		result.setOtherRole("Sales Assistant");
		result.setRepPartyIdNo(new BigDecimal("2500"));
		result.setAgentPrdId("a026gar");
		result.setOrgPartyIdNo(new BigDecimal("27"));
		result.setFirmCd(new BigDecimal("26"));
		result.setParty2IdNo(new BigDecimal("27"));
		result.setTransactionEffDate(Timestamp.valueOf("2012-09-20 16:15:22.727"));
		result.setCreatDtm(Timestamp.valueOf("2012-09-20 16:15:22.727"));
		result.setCreatByNm("a026gar");
		result.setLastUpdDtm(Timestamp.valueOf("2012-09-20 16:15:22.727"));
		result.setLastUpdByNm("a026gar");
		result.setTxnStatus("active");
		result = new SearchBusinessPlatformLookUpResult();
		results.add(result);
		result.setTransactionIdNo("254B2B87-6B60-4C6B-90B2-B86D498E8A83");
		result.setPartyIdNo(new BigDecimal("68145"));
		result.setPrdId("a026kmc");
		result.setRoleCd("STAFF");
		result.setOrgPartyIdNo(new BigDecimal("27"));
		result.setFirmCd(new BigDecimal("26"));
		result.setParty2IdNo(new BigDecimal("27"));
		result.setTransactionEffDate(Timestamp.valueOf("2012-05-21 13:06:27.613"));
		result.setCreatDtm(Timestamp.valueOf("2012-05-21 13:06:27.613"));
		result.setCreatByNm("a026kmc");
		result.setLastUpdDtm(Timestamp.valueOf("2012-05-21 13:06:27.613"));
		result.setLastUpdByNm("a026kmc");
		result.setTxnStatus("active");
		result = new SearchBusinessPlatformLookUpResult();
		results.add(result);
		result.setTransactionIdNo("D88B2FC0-3C61-4E25-B8D0-33471739D0C7");
		result.setPartyIdNo(new BigDecimal("12345"));
		result.setPrdId("a026kof");
		result.setRoleCd("STAFF");
		result.setAgentOrgPartyIdNo(new BigDecimal("103"));
		result.setOrgPartyIdNo(new BigDecimal("27"));
		result.setFirmCd(new BigDecimal("26"));
		result.setParty2IdNo(new BigDecimal("27"));
		result.setTransactionEffDate(Timestamp.valueOf("2017-02-23 11:53:52.22"));
		result.setCreatDtm(Timestamp.valueOf("2017-02-23 11:53:52.22"));
		result.setCreatByNm("wimarke");
		result.setLastUpdDtm(Timestamp.valueOf("2017-02-23 11:53:52.22"));
		result.setLastUpdByNm("wimarke");
		result.setTxnStatus("active");

		return results;
	}

	public List<SearchBusinessPlatformLookUpResult> getAllContractStatusActiveWithEachConditionBusinessPlatformLookupResult() {
		final List<SearchBusinessPlatformLookUpResult> results = new ArrayList<>();
		SearchBusinessPlatformLookUpResult result = new SearchBusinessPlatformLookUpResult();
		results.add(result);
		result.setTransactionIdNo("D88B2FC0-3C61-4E25-B8D0-33471739D0C7");
		result.setPartyIdNo(new BigDecimal(ALL_CONTRACT_STATUS_ACTIVE_TEST_ID));
		result.setRepPartyIdNo(new BigDecimal(ALL_CONTRACT_STATUS_ACTIVE_TEST_ID));
		result.setPrdId("a026kof");
		result.setRoleCd("MP");
		result.setAgentOrgPartyIdNo(new BigDecimal("103"));
		result.setOrgPartyIdNo(new BigDecimal("27"));
		result.setFirmCd(new BigDecimal("26"));
		result.setParty2IdNo(new BigDecimal("27"));
		result.setTransactionEffDate(Timestamp.valueOf("2017-02-23 11:53:52.22"));
		result.setCreatDtm(Timestamp.valueOf("2017-02-23 11:53:52.22"));
		result.setCreatByNm("wimarke");
		result.setLastUpdDtm(Timestamp.valueOf("2017-02-23 11:53:52.22"));
		result.setLastUpdByNm("wimarke");
		result.setTxnStatus("active");
		result = new SearchBusinessPlatformLookUpResult();
		results.add(result);
		result.setTransactionIdNo("C793BC3C-4D1A-493F-B07F-248C30FDFDA4");
		result.setPartyIdNo(new BigDecimal(ALL_CONTRACT_STATUS_ACTIVE_TEST_ID));
		result.setRepPartyIdNo(new BigDecimal(ALL_CONTRACT_STATUS_ACTIVE_TEST_ID));
		result.setPrdId("a026kmc");
		result.setRoleCd("ACS");
		result.setRepPartyIdNo(new BigDecimal("68457"));
		result.setAgentPrdId("a026moo");
		result.setOrgPartyIdNo(new BigDecimal("27"));
		result.setFirmCd(new BigDecimal("26"));
		result.setParty2IdNo(new BigDecimal("27"));
		result.setTransactionEffDate(Timestamp.valueOf("2014-10-21 14:09:52.377"));
		result.setCreatDtm(Timestamp.valueOf("2014-10-21 14:09:52.377"));
		result.setCreatByNm("a026moo");
		result.setLastUpdDtm(Timestamp.valueOf("2014-10-21 14:09:52.377"));
		result.setLastUpdByNm("a026moo");
		result.setTxnStatus("active");
		result = new SearchBusinessPlatformLookUpResult();
		results.add(result);
		result.setTransactionIdNo("254B2B87-6B60-4C6B-90B2-B86D498E8A83");
		result.setPartyIdNo(new BigDecimal(ALL_CONTRACT_STATUS_ACTIVE_TEST_ID));
		result.setPrdId("a026kmc");
		result.setRoleCd("STAFF");
		result.setOtherRole("Firm Staff");
		result.setRepPartyIdNo(new BigDecimal("2500"));
		result.setAgentPrdId("a026gar");
		result.setOrgPartyIdNo(new BigDecimal("27"));
		result.setFirmCd(new BigDecimal("26"));
		result.setParty2IdNo(new BigDecimal("27"));
		result.setTransactionEffDate(Timestamp.valueOf("2012-09-20 16:15:22.727"));
		result.setCreatDtm(Timestamp.valueOf("2012-09-20 16:15:22.727"));
		result.setCreatByNm("a026gar");
		result.setLastUpdDtm(Timestamp.valueOf("2012-09-20 16:15:22.727"));
		result.setLastUpdByNm("a026gar");
		result.setTxnStatus("active");
		result = new SearchBusinessPlatformLookUpResult();
		results.add(result);
		result.setTransactionIdNo("254B2B87-6B60-4C6B-90B2-B86D498E8A83");
		result.setPartyIdNo(new BigDecimal(ALL_CONTRACT_STATUS_ACTIVE_TEST_ID));
		result.setRepPartyIdNo(new BigDecimal(ALL_CONTRACT_STATUS_ACTIVE_TEST_ID));
		result.setPrdId("a026kmc");
		result.setRoleCd("REPWT");
		result.setOrgPartyIdNo(new BigDecimal("27"));
		result.setFirmCd(new BigDecimal("26"));
		result.setParty2IdNo(new BigDecimal("27"));
		result.setTransactionEffDate(Timestamp.valueOf("2012-05-21 13:06:27.613"));
		result.setCreatDtm(Timestamp.valueOf("2012-05-21 13:06:27.613"));
		result.setCreatByNm("a026kmc");
		result.setLastUpdDtm(Timestamp.valueOf("2012-05-21 13:06:27.613"));
		result.setLastUpdByNm("a026kmc");
		result.setTxnStatus("active");
		result = new SearchBusinessPlatformLookUpResult();
		results.add(result);
		result.setTransactionIdNo("D88B2FC0-3C61-4E25-B8D0-33471739D0C7");
		result.setPartyIdNo(new BigDecimal(ALL_CONTRACT_STATUS_ACTIVE_TEST_ID));
		result.setRepPartyIdNo(new BigDecimal(ALL_CONTRACT_STATUS_ACTIVE_TEST_ID));
		result.setPrdId("a026kof");
		result.setRoleCd("STAFF");
		result.setOtherRole("Sales Assistant");
		result.setAgentOrgPartyIdNo(new BigDecimal("103"));
		result.setOrgPartyIdNo(new BigDecimal("27"));
		result.setFirmCd(new BigDecimal("26"));
		result.setParty2IdNo(new BigDecimal("27"));
		result.setTransactionEffDate(Timestamp.valueOf("2017-02-23 11:53:52.22"));
		result.setCreatDtm(Timestamp.valueOf("2017-02-23 11:53:52.22"));
		result.setCreatByNm("wimarke");
		result.setLastUpdDtm(Timestamp.valueOf("2017-02-23 11:53:52.22"));
		result.setLastUpdByNm("wimarke");
		result.setTxnStatus("active");
		result = new SearchBusinessPlatformLookUpResult();
		results.add(result);
		result.setTransactionIdNo("D88B2FC0-3C61-4E25-B8D0-33471739D0C7");
		result.setPartyIdNo(new BigDecimal(ALL_CONTRACT_STATUS_ACTIVE_TEST_ID));
		result.setRepPartyIdNo(new BigDecimal(ALL_CONTRACT_STATUS_ACTIVE_TEST_ID));
		result.setPrdId("a026kof");
		result.setRoleCd("REPWT");
		result.setOtherRole("Sales Assistant");
		result.setAgentOrgPartyIdNo(new BigDecimal("103"));
		result.setOrgPartyIdNo(new BigDecimal("27"));
		result.setFirmCd(new BigDecimal("26"));
		result.setParty2IdNo(new BigDecimal("27"));
		result.setTransactionEffDate(Timestamp.valueOf("2017-02-23 11:53:52.22"));
		result.setCreatDtm(Timestamp.valueOf("2017-02-23 11:53:52.22"));
		result.setCreatByNm("wimarke");
		result.setLastUpdDtm(Timestamp.valueOf("2017-02-23 11:53:52.22"));
		result.setLastUpdByNm("wimarke");
		result.setTxnStatus("active");

		return results;
	}

	public List<SearchBusinessPlatformLookUpResult> getAllContractStatusTerminatedBusinessPlatformLookupResult() {
		final List<SearchBusinessPlatformLookUpResult> results = new ArrayList<>();
		SearchBusinessPlatformLookUpResult result = new SearchBusinessPlatformLookUpResult();
		results.add(result);
		result.setTransactionIdNo("102305E2-FC8D-4672-ABEF-5D326B008932");
		result.setPartyIdNo(new BigDecimal("70234"));
		result.setPrdId("a149veg");
		result.setRoleCd("STAFF");
		result.setOtherRole("Sales Assistant");
		result.setRepPartyIdNo(new BigDecimal("62064"));
		result.setAgentPrdId("a577cru");
		result.setOrgPartyIdNo(new BigDecimal("149"));
		result.setFirmCd(new BigDecimal("149"));
		result.setParty2IdNo(new BigDecimal("149"));
		result.setTransactionEffDate(Timestamp.valueOf("2015-04-27 12:02:32.613"));
		result.setTransactionEndDate(Timestamp.valueOf("2017-02-15 10:49:51.92"));
		result.setCreatDtm(Timestamp.valueOf("2015-04-27 12:02:32.613"));
		result.setCreatByNm("crabtra");
		result.setLastUpdDtm(Timestamp.valueOf("2017-02-15 10:49:51.92"));
		result.setLastUpdByNm("Role update");
		result.setTxnStatus("terminated");
		result = new SearchBusinessPlatformLookUpResult();
		results.add(result);
		result.setTransactionIdNo("762F14C3-0682-4F99-BFFD-5EAAD9F7AEB7");
		result.setPartyIdNo(new BigDecimal("65811"));
		result.setPrdId("a788nun");
		result.setRoleCd("STAFF");
		result.setOtherRole("Firm Staff");
		result.setRepPartyIdNo(new BigDecimal("61743"));
		result.setAgentPrdId("a149toe");
		result.setOrgPartyIdNo(new BigDecimal("149"));
		result.setFirmCd(new BigDecimal("149"));
		result.setParty2IdNo(new BigDecimal("149"));
		result.setTransactionEffDate(Timestamp.valueOf("2011-10-31 10:56:30.29"));
		result.setTransactionEndDate(Timestamp.valueOf("2017-02-15 10:49:51.92"));
		result.setCreatDtm(Timestamp.valueOf("2011-10-31 10:56:30.29"));
		result.setCreatByNm("a149toe");
		result.setLastUpdDtm(Timestamp.valueOf("2017-02-15 10:49:51.92"));
		result.setLastUpdByNm("Role update");
		result.setTxnStatus("terminated");

		return results;
	}

	public SearchPartyRelationshipReply getActiveOnlySearchPartyRelationshipReplyExpected() {
		final SearchPartyRelationshipReply reply = new SearchPartyRelationshipReply();

		Relation relation = new Relation();
		reply.getRelation().add(relation);
		relation.setRelationID("68457,27");
		relation.setRelationIDRef(RELATIONIDREF.CONCATENATION);
		relation.setRelatedRefID("27");
		relation.setRelatedRefIDType(BigInteger.valueOf(8000));
		relation.setRelationRoleCode(BigInteger.valueOf(9003));
		relation.setStartDate(
				SearchPartyUtils.convertTimestampToXmlGregorianCalendar(Timestamp.valueOf("2018-03-01 00:00:00.0")));
		relation.setTemporaryRoleInd(false);
		relation.setSequence(0);
		relation.setBusinessRelationType(BigInteger.valueOf(9200));
		relation.setAllocationPercentage(0.0d);
		relation.setCreatedDate(
				SearchPartyUtils.convertTimestampToXmlGregorianCalendar(Timestamp.valueOf("2014-10-21 14:09:52.350")));
		relation.setCreatedByNm("a026moo");
		relation.setUpdatedDate(
				SearchPartyUtils.convertTimestampToXmlGregorianCalendar(Timestamp.valueOf("2014-10-21 14:09:52.350")));
		relation.setUpdatedByNm("a026moo");
		relation.setIDReferenceNo("68457");
		relation.setIDReferenceType(BigInteger.valueOf(8000));

		relation = new Relation();
		reply.getRelation().add(relation);
		relation.setRelationID("68457,2094");
		relation.setRelationIDRef(RELATIONIDREF.CONCATENATION);
		relation.setRelatedRefID("a026jan");
		relation.setRelatedRefIDType(BigInteger.valueOf(8001));
		relation.setRelationRoleCode(BigInteger.valueOf(9003));
		relation.setStartDate(
				SearchPartyUtils.convertTimestampToXmlGregorianCalendar(Timestamp.valueOf("2016-12-12 08:08:12.493")));
		relation.setTemporaryRoleInd(false);
		relation.setSequence(0);
		relation.setBusinessRelationType(BigInteger.valueOf(9200));
		relation.setAllocationPercentage(0.0d);
		relation.setCreatedDate(
				SearchPartyUtils.convertTimestampToXmlGregorianCalendar(Timestamp.valueOf("2016-12-12 08:08:12.493")));
		relation.setCreatedByNm("jhdrhin");
		relation.setUpdatedDate(
				SearchPartyUtils.convertTimestampToXmlGregorianCalendar(Timestamp.valueOf("2016-12-12 08:08:12.493")));
		relation.setUpdatedByNm("jhdrhin");
		relation.setIDReferenceNo("a026moo");
		relation.setIDReferenceType(BigInteger.valueOf(8001));

		relation = new Relation();
		reply.getRelation().add(relation);
		relation.setRelationID("C793BC3C-4D1A-493F-B07F-248C30FDFDA4");
		relation.setRelationIDRef(RELATIONIDREF.BUSINESS_PLATFORM);
		relation.setRelatedRefID("a026moo");
		relation.setRelatedRefIDType(BigInteger.valueOf(8001));
		relation.setRelationRoleCode(BigInteger.valueOf(9004));
		relation.setStartDate(
				SearchPartyUtils.convertTimestampToXmlGregorianCalendar(Timestamp.valueOf("2014-10-21 14:09:52.377")));
		relation.setTemporaryRoleInd(false);
		relation.setSequence(0);
		relation.setBusinessRelationType(BigInteger.valueOf(9200));
		relation.setAllocationPercentage(0.0d);
		relation.setCreatedDate(
				SearchPartyUtils.convertTimestampToXmlGregorianCalendar(Timestamp.valueOf("2014-10-21 14:09:52.377")));
		relation.setCreatedByNm("a026moo");
		relation.setUpdatedDate(
				SearchPartyUtils.convertTimestampToXmlGregorianCalendar(Timestamp.valueOf("2014-10-21 14:09:52.377")));
		relation.setUpdatedByNm("a026moo");
		relation.setIDReferenceNo("a026kmc");
		relation.setIDReferenceType(BigInteger.valueOf(8001));

		return reply;
	}

	public SearchPartyRelationshipReply getActiveOnlyMpSearchPartyRelationshipReplyExpected() {
		final SearchPartyRelationshipReply reply = new SearchPartyRelationshipReply();

		Relation relation = new Relation();
		reply.getRelation().add(relation);
		relation.setRelationID("68457,27");
		relation.setRelationIDRef(RELATIONIDREF.CONCATENATION);
		relation.setRelatedRefID("27");
		relation.setRelatedRefIDType(BigInteger.valueOf(8000));
		relation.setRelationRoleCode(BigInteger.valueOf(9002));
		relation.setStartDate(
				SearchPartyUtils.convertTimestampToXmlGregorianCalendar(Timestamp.valueOf("2018-03-01 00:00:00.0")));
		relation.setTemporaryRoleInd(false);
		relation.setSequence(0);
		relation.setBusinessRelationType(BigInteger.valueOf(9200));
		relation.setAllocationPercentage(0.0d);
		relation.setCreatedDate(
				SearchPartyUtils.convertTimestampToXmlGregorianCalendar(Timestamp.valueOf("2015-05-21 11:05:09.88")));
		relation.setCreatedByNm("a026kyl");
		relation.setUpdatedDate(
				SearchPartyUtils.convertTimestampToXmlGregorianCalendar(Timestamp.valueOf("2015-05-21 11:05:09.88")));
		relation.setUpdatedByNm("a026kyl");
		relation.setIDReferenceNo("68457");
		relation.setIDReferenceType(BigInteger.valueOf(8000));

		relation = new Relation();
		reply.getRelation().add(relation);
		relation.setRelationID("8A16E495-0A05-42EB-BC6F-6C7DB5B30385");
		relation.setRelationIDRef(RELATIONIDREF.BUSINESS_PLATFORM);
		relation.setRelatedRefID("68457");
		relation.setRelatedRefIDType(BigInteger.valueOf(8000));
		relation.setRelationRoleCode(BigInteger.valueOf(9006));
		relation.setStartDate(
				SearchPartyUtils.convertTimestampToXmlGregorianCalendar(Timestamp.valueOf("2015-05-21 11:05:09.88")));
		relation.setTemporaryRoleInd(false);
		relation.setSequence(0);
		relation.setBusinessRelationType(BigInteger.valueOf(9200));
		relation.setAllocationPercentage(0.0d);
		relation.setCreatedDate(
				SearchPartyUtils.convertTimestampToXmlGregorianCalendar(Timestamp.valueOf("2015-05-21 11:05:09.88")));
		relation.setCreatedByNm("a026kyl");
		relation.setUpdatedDate(
				SearchPartyUtils.convertTimestampToXmlGregorianCalendar(Timestamp.valueOf("2015-05-21 11:05:09.88")));
		relation.setUpdatedByNm("a026kyl");
		relation.setIDReferenceNo("68457");
		relation.setIDReferenceType(BigInteger.valueOf(8000));

		relation = new Relation();
		reply.getRelation().add(relation);
		relation.setRelationID("68457,11111");
		relation.setRelationIDRef(RELATIONIDREF.CONCATENATION);
		relation.setRelatedRefIDType(BigInteger.valueOf(8000));
		relation.setRelationRoleCode(BigInteger.valueOf(9002));
		relation.setStartDate(
				SearchPartyUtils.convertTimestampToXmlGregorianCalendar(Timestamp.valueOf("2014-10-21 14:09:52.35")));
		relation.setTemporaryRoleInd(false);
		relation.setSequence(0);
		relation.setBusinessRelationType(BigInteger.valueOf(9200));
		relation.setAllocationPercentage(0.0d);
		relation.setCreatedDate(
				SearchPartyUtils.convertTimestampToXmlGregorianCalendar(Timestamp.valueOf("2014-10-21 14:09:52.35")));
		relation.setCreatedByNm("a026moo");
		relation.setUpdatedDate(
				SearchPartyUtils.convertTimestampToXmlGregorianCalendar(Timestamp.valueOf("2014-10-21 14:09:52.35")));
		relation.setUpdatedByNm("a026moo");
		relation.setIDReferenceNo("68457");
		relation.setIDReferenceType(BigInteger.valueOf(8000));

		return reply;
	}

	public SearchPartyRelationshipReply getActiveOnlyAcsSearchPartyRelationshipReplyExpected() {
		final SearchPartyRelationshipReply reply = new SearchPartyRelationshipReply();

		Relation relation = new Relation();
		reply.getRelation().add(relation);
		relation.setRelationID("68457,27");
		relation.setRelationIDRef(RELATIONIDREF.CONCATENATION);
		relation.setRelatedRefID("27");
		relation.setRelatedRefIDType(BigInteger.valueOf(8000));
		relation.setRelationRoleCode(BigInteger.valueOf(9000));
		relation.setStartDate(
				SearchPartyUtils.convertTimestampToXmlGregorianCalendar(Timestamp.valueOf("2018-03-01 00:00:00.0")));
		relation.setTemporaryRoleInd(false);
		relation.setSequence(0);
		relation.setBusinessRelationType(BigInteger.valueOf(9200));
		relation.setAllocationPercentage(0.0d);
		relation.setCreatedDate(
				SearchPartyUtils.convertTimestampToXmlGregorianCalendar(Timestamp.valueOf("2015-05-21 11:05:09.88")));
		relation.setCreatedByNm("a026kyl");
		relation.setUpdatedDate(
				SearchPartyUtils.convertTimestampToXmlGregorianCalendar(Timestamp.valueOf("2015-05-21 11:05:09.88")));
		relation.setUpdatedByNm("a026kyl");
		relation.setIDReferenceNo("68457");
		relation.setIDReferenceType(BigInteger.valueOf(8000));

		relation = new Relation();
		reply.getRelation().add(relation);
		relation.setRelationID("8A16E495-0A05-42EB-BC6F-6C7DB5B30385");
		relation.setRelationIDRef(RELATIONIDREF.BUSINESS_PLATFORM);
		relation.setRelatedRefID("68457");
		relation.setRelatedRefIDType(BigInteger.valueOf(8000));
		relation.setRelationRoleCode(BigInteger.valueOf(9004));
		relation.setStartDate(
				SearchPartyUtils.convertTimestampToXmlGregorianCalendar(Timestamp.valueOf("2015-05-21 11:05:09.88")));
		relation.setTemporaryRoleInd(false);
		relation.setSequence(0);
		relation.setBusinessRelationType(BigInteger.valueOf(9200));
		relation.setAllocationPercentage(0.0d);
		relation.setCreatedDate(
				SearchPartyUtils.convertTimestampToXmlGregorianCalendar(Timestamp.valueOf("2015-05-21 11:05:09.88")));
		relation.setCreatedByNm("a026kyl");
		relation.setUpdatedDate(
				SearchPartyUtils.convertTimestampToXmlGregorianCalendar(Timestamp.valueOf("2015-05-21 11:05:09.88")));
		relation.setUpdatedByNm("a026kyl");
		relation.setIDReferenceNo("68457");
		relation.setIDReferenceType(BigInteger.valueOf(8000));

		relation = new Relation();
		reply.getRelation().add(relation);
		relation.setRelationID("68457,11111");
		relation.setRelationIDRef(RELATIONIDREF.CONCATENATION);
		relation.setRelatedRefID("a026moo");
		relation.setRelatedRefIDType(BigInteger.valueOf(8001));
		relation.setRelationRoleCode(BigInteger.valueOf(9000));
		relation.setStartDate(
				SearchPartyUtils.convertTimestampToXmlGregorianCalendar(Timestamp.valueOf("2014-10-21 14:09:52.35")));
		relation.setTemporaryRoleInd(false);
		relation.setSequence(0);
		relation.setBusinessRelationType(BigInteger.valueOf(9200));
		relation.setAllocationPercentage(0.0d);
		relation.setCreatedDate(
				SearchPartyUtils.convertTimestampToXmlGregorianCalendar(Timestamp.valueOf("2014-10-21 14:09:52.35")));
		relation.setCreatedByNm("a026moo");
		relation.setUpdatedDate(
				SearchPartyUtils.convertTimestampToXmlGregorianCalendar(Timestamp.valueOf("2014-10-21 14:09:52.35")));
		relation.setUpdatedByNm("a026moo");
		relation.setIDReferenceNo("a026moo");
		relation.setIDReferenceType(BigInteger.valueOf(8001));

		return reply;
	}

	public SearchPartyRelationshipReply getActiveOnlyFirmStaffSearchPartyRelationshipReplyExpected() {
		final SearchPartyRelationshipReply reply = new SearchPartyRelationshipReply();

		Relation relation = new Relation();
		reply.getRelation().add(relation);
		relation.setRelationID("68457,27");
		relation.setRelationIDRef(RELATIONIDREF.CONCATENATION);
		relation.setRelatedRefID("27");
		relation.setRelatedRefIDType(BigInteger.valueOf(8000));
		relation.setRelationRoleCode(BigInteger.valueOf(9003));
		relation.setStartDate(
				SearchPartyUtils.convertTimestampToXmlGregorianCalendar(Timestamp.valueOf("2018-03-01 00:00:00.0")));
		relation.setTemporaryRoleInd(false);
		relation.setSequence(0);
		relation.setBusinessRelationType(BigInteger.valueOf(9200));
		relation.setAllocationPercentage(0.0d);
		relation.setCreatedDate(
				SearchPartyUtils.convertTimestampToXmlGregorianCalendar(Timestamp.valueOf("2015-05-21 11:05:09.88")));
		relation.setCreatedByNm("a026kyl");
		relation.setUpdatedDate(
				SearchPartyUtils.convertTimestampToXmlGregorianCalendar(Timestamp.valueOf("2015-05-21 11:05:09.88")));
		relation.setUpdatedByNm("a026kyl");
		relation.setIDReferenceNo("68457");
		relation.setIDReferenceType(BigInteger.valueOf(8000));

		relation = new Relation();
		reply.getRelation().add(relation);
		relation.setRelationID("68457,11111");
		relation.setRelationIDRef(RELATIONIDREF.CONCATENATION);
		relation.setRelatedRefID("a026moo");
		relation.setRelatedRefIDType(BigInteger.valueOf(8001));
		relation.setRelationRoleCode(BigInteger.valueOf(9001));
		relation.setStartDate(
				SearchPartyUtils.convertTimestampToXmlGregorianCalendar(Timestamp.valueOf("2014-10-21 14:09:52.35")));
		relation.setTemporaryRoleInd(false);
		relation.setSequence(0);
		relation.setBusinessRelationType(BigInteger.valueOf(9200));
		relation.setAllocationPercentage(0.0d);
		relation.setCreatedDate(
				SearchPartyUtils.convertTimestampToXmlGregorianCalendar(Timestamp.valueOf("2014-10-21 14:09:52.35")));
		relation.setCreatedByNm("a026moo");
		relation.setUpdatedDate(
				SearchPartyUtils.convertTimestampToXmlGregorianCalendar(Timestamp.valueOf("2014-10-21 14:09:52.35")));
		relation.setUpdatedByNm("a026moo");
		relation.setIDReferenceNo("a026moo");
		relation.setIDReferenceType(BigInteger.valueOf(8001));

		return reply;
	}

	public SearchPartyRelationshipReply getActiveOnlyOtherwiseSearchPartyRelationshipReplyExpected() {
		final SearchPartyRelationshipReply reply = new SearchPartyRelationshipReply();

		Relation relation = new Relation();
		reply.getRelation().add(relation);
		relation.setRelationID("68457,27");
		relation.setRelationIDRef(RELATIONIDREF.CONCATENATION);
		relation.setRelatedRefID("27");
		relation.setRelatedRefIDType(BigInteger.valueOf(8000));
		relation.setRelationRoleCode(BigInteger.valueOf(9005));
		relation.setStartDate(
				SearchPartyUtils.convertTimestampToXmlGregorianCalendar(Timestamp.valueOf("2018-03-01 00:00:00.0")));
		relation.setTemporaryRoleInd(false);
		relation.setSequence(0);
		relation.setBusinessRelationType(BigInteger.valueOf(9200));
		relation.setAllocationPercentage(0.0d);
		relation.setCreatedDate(
				SearchPartyUtils.convertTimestampToXmlGregorianCalendar(Timestamp.valueOf("2015-05-21 11:05:09.88")));
		relation.setCreatedByNm("a026kyl");
		relation.setUpdatedDate(
				SearchPartyUtils.convertTimestampToXmlGregorianCalendar(Timestamp.valueOf("2015-05-21 11:05:09.88")));
		relation.setUpdatedByNm("a026kyl");
		relation.setIDReferenceNo("68457");
		relation.setIDReferenceType(BigInteger.valueOf(8000));

		relation = new Relation();
		reply.getRelation().add(relation);
		relation.setRelationID("8A16E495-0A05-42EB-BC6F-6C7DB5B30385");
		relation.setRelationIDRef(RELATIONIDREF.BUSINESS_PLATFORM);
		relation.setRelatedRefID("68457");
		relation.setRelatedRefIDType(BigInteger.valueOf(8000));
		relation.setRelationRoleCode(BigInteger.valueOf(9006));
		relation.setStartDate(
				SearchPartyUtils.convertTimestampToXmlGregorianCalendar(Timestamp.valueOf("2015-05-21 11:05:09.88")));
		relation.setTemporaryRoleInd(false);
		relation.setSequence(0);
		relation.setBusinessRelationType(BigInteger.valueOf(9200));
		relation.setAllocationPercentage(0.0d);
		relation.setCreatedDate(
				SearchPartyUtils.convertTimestampToXmlGregorianCalendar(Timestamp.valueOf("2015-05-21 11:05:09.88")));
		relation.setCreatedByNm("a026kyl");
		relation.setUpdatedDate(
				SearchPartyUtils.convertTimestampToXmlGregorianCalendar(Timestamp.valueOf("2015-05-21 11:05:09.88")));
		relation.setUpdatedByNm("a026kyl");
		relation.setIDReferenceNo("68457");
		relation.setIDReferenceType(BigInteger.valueOf(8000));

		return reply;
	}

	public SearchPartyRelationshipReply getAllContractStatusActiveSearchPartyRelationshipReplyExpected() {
		final SearchPartyRelationshipReply reply = new SearchPartyRelationshipReply();

		Relation relation = new Relation();
		reply.getRelation().add(relation);
		relation.setRelationID("68145,27");
		relation.setRelationIDRef(RELATIONIDREF.CONCATENATION);
		relation.setRelatedRefID("27");
		relation.setRelatedRefIDType(BigInteger.valueOf(8000));
		relation.setRelationRoleCode(BigInteger.valueOf(9005));
		relation.setStartDate(
				SearchPartyUtils.convertTimestampToXmlGregorianCalendar(Timestamp.valueOf("2014-10-21 14:09:52.377")));
		relation.setTemporaryRoleInd(false);
		relation.setSequence(0);
		relation.setBusinessRelationType(BigInteger.valueOf(9200));
		relation.setAllocationPercentage(0.0d);
		relation.setCreatedDate(
				SearchPartyUtils.convertTimestampToXmlGregorianCalendar(Timestamp.valueOf("2014-10-21 14:09:52.377")));
		relation.setCreatedByNm("a026moo");
		relation.setUpdatedDate(
				SearchPartyUtils.convertTimestampToXmlGregorianCalendar(Timestamp.valueOf("2014-10-21 14:09:52.377")));
		relation.setUpdatedByNm("a026moo");
		relation.setIDReferenceNo("68145");
		relation.setIDReferenceType(BigInteger.valueOf(8000));

		relation = new Relation();
		reply.getRelation().add(relation);
		relation.setRelationID("C793BC3C-4D1A-493F-B07F-248C30FDFDA4");
		relation.setRelationIDRef(RELATIONIDREF.BUSINESS_PLATFORM);
		relation.setRelatedRefID("a026moo");
		relation.setRelatedRefIDType(BigInteger.valueOf(8001));
		relation.setRelationRoleCode(BigInteger.valueOf(9004));
		relation.setStartDate(
				SearchPartyUtils.convertTimestampToXmlGregorianCalendar(Timestamp.valueOf("2014-10-21 14:09:52.377")));
		relation.setTemporaryRoleInd(false);
		relation.setSequence(0);
		relation.setBusinessRelationType(BigInteger.valueOf(9200));
		relation.setAllocationPercentage(0.0d);
		relation.setCreatedDate(
				SearchPartyUtils.convertTimestampToXmlGregorianCalendar(Timestamp.valueOf("2014-10-21 14:09:52.377")));
		relation.setCreatedByNm("a026moo");
		relation.setUpdatedDate(
				SearchPartyUtils.convertTimestampToXmlGregorianCalendar(Timestamp.valueOf("2014-10-21 14:09:52.377")));
		relation.setUpdatedByNm("a026moo");
		relation.setIDReferenceNo("a026kmc");
		relation.setIDReferenceType(BigInteger.valueOf(8001));

		relation = new Relation();
		reply.getRelation().add(relation);
		relation.setRelationID("254B2B87-6B60-4C6B-90B2-B86D498E8A83");
		relation.setRelationIDRef(RELATIONIDREF.BUSINESS_PLATFORM);
		relation.setRelatedRefID("a026gar");
		relation.setRelatedRefIDType(BigInteger.valueOf(8001));
		relation.setRelationRoleCode(BigInteger.valueOf(9004));
		relation.setStartDate(
				SearchPartyUtils.convertTimestampToXmlGregorianCalendar(Timestamp.valueOf("2012-09-20 16:15:22.727")));
		relation.setTemporaryRoleInd(false);
		relation.setSequence(0);
		relation.setBusinessRelationType(BigInteger.valueOf(9200));
		relation.setAllocationPercentage(0.0d);
		relation.setCreatedDate(
				SearchPartyUtils.convertTimestampToXmlGregorianCalendar(Timestamp.valueOf("2012-09-20 16:15:22.727")));
		relation.setCreatedByNm("a026gar");
		relation.setUpdatedDate(
				SearchPartyUtils.convertTimestampToXmlGregorianCalendar(Timestamp.valueOf("2012-09-20 16:15:22.727")));
		relation.setUpdatedByNm("a026gar");
		relation.setIDReferenceNo("a026kmc");
		relation.setIDReferenceType(BigInteger.valueOf(8001));

		return reply;
	}

	public SearchPartyRelationshipReply getAllContractStatusActiveWithEachConditionSearchPartyRelationshipReplyExpected() {
		final SearchPartyRelationshipReply reply = new SearchPartyRelationshipReply();

		Relation relation = new Relation();
		reply.getRelation().add(relation);
		relation.setRelationID("68145,103");
		relation.setRelationIDRef(RELATIONIDREF.CONCATENATION);
		relation.setRelatedRefID("27");
		relation.setRelatedRefIDType(BigInteger.valueOf(8000));
		relation.setRelationRoleCode(BigInteger.valueOf(9002));
		relation.setStartDate(
				SearchPartyUtils.convertTimestampToXmlGregorianCalendar(Timestamp.valueOf("2017-02-23 11:53:52.220")));
		relation.setTemporaryRoleInd(false);
		relation.setSequence(0);
		relation.setBusinessRelationType(BigInteger.valueOf(9200));
		relation.setAllocationPercentage(0.0d);
		relation.setCreatedDate(
				SearchPartyUtils.convertTimestampToXmlGregorianCalendar(Timestamp.valueOf("2017-02-23 11:53:52.220")));
		relation.setCreatedByNm("wimarke");
		relation.setUpdatedDate(
				SearchPartyUtils.convertTimestampToXmlGregorianCalendar(Timestamp.valueOf("2017-02-23 11:53:52.220")));
		relation.setUpdatedByNm("wimarke");
		relation.setIDReferenceNo("68145");
		relation.setIDReferenceType(BigInteger.valueOf(8000));

		relation = new Relation();
		reply.getRelation().add(relation);
		relation.setRelationID("D88B2FC0-3C61-4E25-B8D0-33471739D0C7");
		relation.setRelationIDRef(RELATIONIDREF.BUSINESS_PLATFORM);
		relation.setRelatedRefID("68145");
		relation.setRelatedRefIDType(BigInteger.valueOf(8000));
		relation.setRelationRoleCode(BigInteger.valueOf(9006));
		relation.setStartDate(
				SearchPartyUtils.convertTimestampToXmlGregorianCalendar(Timestamp.valueOf("2017-02-23 11:53:52.220")));
		relation.setTemporaryRoleInd(false);
		relation.setSequence(0);
		relation.setBusinessRelationType(BigInteger.valueOf(9200));
		relation.setAllocationPercentage(0.0d);
		relation.setCreatedDate(
				SearchPartyUtils.convertTimestampToXmlGregorianCalendar(Timestamp.valueOf("2017-02-23 11:53:52.220")));
		relation.setCreatedByNm("wimarke");
		relation.setUpdatedDate(
				SearchPartyUtils.convertTimestampToXmlGregorianCalendar(Timestamp.valueOf("2017-02-23 11:53:52.220")));
		relation.setUpdatedByNm("wimarke");
		relation.setIDReferenceNo("68145");
		relation.setIDReferenceType(BigInteger.valueOf(8000));

		relation = new Relation();
		reply.getRelation().add(relation);
		relation.setRelationID("254B2B87-6B60-4C6B-90B2-B86D498E8A83");
		relation.setRelationIDRef(RELATIONIDREF.BUSINESS_PLATFORM);
		relation.setRelatedRefID("68145");
		relation.setRelatedRefIDType(BigInteger.valueOf(8000));
		relation.setRelationRoleCode(BigInteger.valueOf(9006));
		relation.setStartDate(
				SearchPartyUtils.convertTimestampToXmlGregorianCalendar(Timestamp.valueOf("2012-05-21 13:06:27.613")));
		relation.setTemporaryRoleInd(false);
		relation.setSequence(0);
		relation.setBusinessRelationType(BigInteger.valueOf(9200));
		relation.setAllocationPercentage(0.0d);
		relation.setCreatedDate(
				SearchPartyUtils.convertTimestampToXmlGregorianCalendar(Timestamp.valueOf("2012-05-21 13:06:27.613")));
		relation.setCreatedByNm("a026kmc");
		relation.setUpdatedDate(
				SearchPartyUtils.convertTimestampToXmlGregorianCalendar(Timestamp.valueOf("2012-05-21 13:06:27.613")));
		relation.setUpdatedByNm("a026kmc");
		relation.setIDReferenceNo("68145");
		relation.setIDReferenceType(BigInteger.valueOf(8000));

		relation = new Relation();
		reply.getRelation().add(relation);
		relation.setRelationID("D88B2FC0-3C61-4E25-B8D0-33471739D0C7");
		relation.setRelationIDRef(RELATIONIDREF.BUSINESS_PLATFORM);
		relation.setRelatedRefID("68145");
		relation.setRelatedRefIDType(BigInteger.valueOf(8000));
		relation.setRelationRoleCode(BigInteger.valueOf(9004));
		relation.setStartDate(
				SearchPartyUtils.convertTimestampToXmlGregorianCalendar(Timestamp.valueOf("2017-02-23 11:53:52.220")));
		relation.setTemporaryRoleInd(false);
		relation.setSequence(0);
		relation.setBusinessRelationType(BigInteger.valueOf(9200));
		relation.setAllocationPercentage(0.0d);
		relation.setCreatedDate(
				SearchPartyUtils.convertTimestampToXmlGregorianCalendar(Timestamp.valueOf("2017-02-23 11:53:52.220")));
		relation.setCreatedByNm("wimarke");
		relation.setUpdatedDate(
				SearchPartyUtils.convertTimestampToXmlGregorianCalendar(Timestamp.valueOf("2017-02-23 11:53:52.220")));
		relation.setUpdatedByNm("wimarke");
		relation.setIDReferenceNo("68145");
		relation.setIDReferenceType(BigInteger.valueOf(8000));

		relation = new Relation();
		reply.getRelation().add(relation);
		relation.setRelationID("D88B2FC0-3C61-4E25-B8D0-33471739D0C7");
		relation.setRelationIDRef(RELATIONIDREF.BUSINESS_PLATFORM);
		relation.setRelatedRefID("68145");
		relation.setRelatedRefIDType(BigInteger.valueOf(8000));
		relation.setRelationRoleCode(BigInteger.valueOf(9004));
		relation.setStartDate(
				SearchPartyUtils.convertTimestampToXmlGregorianCalendar(Timestamp.valueOf("2017-02-23 11:53:52.220")));
		relation.setTemporaryRoleInd(false);
		relation.setSequence(0);
		relation.setBusinessRelationType(BigInteger.valueOf(9200));
		relation.setAllocationPercentage(0.0d);
		relation.setCreatedDate(
				SearchPartyUtils.convertTimestampToXmlGregorianCalendar(Timestamp.valueOf("2017-02-23 11:53:52.220")));
		relation.setCreatedByNm("wimarke");
		relation.setUpdatedDate(
				SearchPartyUtils.convertTimestampToXmlGregorianCalendar(Timestamp.valueOf("2017-02-23 11:53:52.220")));
		relation.setUpdatedByNm("wimarke");
		relation.setIDReferenceNo("68145");
		relation.setIDReferenceType(BigInteger.valueOf(8000));

		relation = new Relation();
		reply.getRelation().add(relation);
		relation.setRelationID("D88B2FC0-3C61-4E25-B8D0-33471739D0C7");
		relation.setRelationIDRef(RELATIONIDREF.BUSINESS_PLATFORM);
		relation.setRelatedRefID("68145");
		relation.setRelatedRefIDType(BigInteger.valueOf(8000));
		relation.setRelationRoleCode(BigInteger.valueOf(9004));
		relation.setStartDate(
				SearchPartyUtils.convertTimestampToXmlGregorianCalendar(Timestamp.valueOf("2017-02-23 11:53:52.220")));
		relation.setTemporaryRoleInd(false);
		relation.setSequence(0);
		relation.setBusinessRelationType(BigInteger.valueOf(9200));
		relation.setAllocationPercentage(0.0d);
		relation.setCreatedDate(
				SearchPartyUtils.convertTimestampToXmlGregorianCalendar(Timestamp.valueOf("2017-02-23 11:53:52.220")));
		relation.setCreatedByNm("wimarke");
		relation.setUpdatedDate(
				SearchPartyUtils.convertTimestampToXmlGregorianCalendar(Timestamp.valueOf("2017-02-23 11:53:52.220")));
		relation.setUpdatedByNm("wimarke");
		relation.setIDReferenceNo("68145");
		relation.setIDReferenceType(BigInteger.valueOf(8000));

		return reply;
	}

	public SearchPartyRelationshipReply getAllContractStatusTerminatedSearchPartyRelationshipReplyExpected() {
		final SearchPartyRelationshipReply reply = new SearchPartyRelationshipReply();

		final Relation relation = new Relation();
		reply.getRelation().add(relation);
		relation.setRelationID("61845,149");
		relation.setRelationIDRef(RELATIONIDREF.CONCATENATION);
		relation.setRelatedRefID("149");
		relation.setRelatedRefIDType(BigInteger.valueOf(8000));
		relation.setRelationRoleCode(BigInteger.valueOf(9006));
		relation.setStartDate(
				SearchPartyUtils.convertTimestampToXmlGregorianCalendar(Timestamp.valueOf("2003-01-15 00:00:00.0")));
		relation.setEndDate(
				SearchPartyUtils.convertTimestampToXmlGregorianCalendar(Timestamp.valueOf("2012-04-24 00:00:00.0")));
		relation.setTemporaryRoleInd(false);
		relation.setSequence(0);
		relation.setBusinessRelationType(BigInteger.valueOf(9200));
		relation.setAllocationPercentage(0.0d);
		relation.setCreatedDate(
				SearchPartyUtils.convertTimestampToXmlGregorianCalendar(Timestamp.valueOf("2003-01-15 00:00:00.0")));
		relation.setCreatedByNm("JHFF");
		relation.setUpdatedDate(
				SearchPartyUtils.convertTimestampToXmlGregorianCalendar(Timestamp.valueOf("2003-01-15 00:00:00.0")));
		relation.setUpdatedByNm("JHFF");
		relation.setIDReferenceNo("61845");
		relation.setIDReferenceType(BigInteger.valueOf(8000));

		return reply;
	}
}

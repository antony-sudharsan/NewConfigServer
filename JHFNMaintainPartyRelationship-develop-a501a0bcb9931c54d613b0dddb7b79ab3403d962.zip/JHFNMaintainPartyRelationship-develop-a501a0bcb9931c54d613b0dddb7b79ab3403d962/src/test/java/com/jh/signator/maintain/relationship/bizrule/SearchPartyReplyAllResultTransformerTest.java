package com.jh.signator.maintain.relationship.bizrule;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import com.jh.signator.maintain.relationship.MaintainRelationshipApplication;
import com.jh.signator.maintain.relationship.test.data.SearchPartyRelationshipTestDataUtils;
import com.manulife.esb.xsd.distribution.jhfn.partyrelationship.SearchPartyRelationshipReply;

//TODO: @RunWith and @SpringBootTest when can determine what
//DataMappingCrossLookUp is doing and how to modify so don't need to load
//spring context to use. Which slows the test down needlessly.
@ActiveProfiles("test")
@RunWith(SpringRunner.class)
@SpringBootTest(classes = MaintainRelationshipApplication.class, webEnvironment = WebEnvironment.MOCK)
public class SearchPartyReplyAllResultTransformerTest {

	private final SearchPartyRelationshipTestDataUtils testUtils = new SearchPartyRelationshipTestDataUtils();

	@Test
	public void givenSearchAllWithActiveContractStatusThenExpectedReplyReturned() {
		final SearchPartyReplyAllResultTransformer transformer = new SearchPartyReplyAllResultTransformer();
		final SearchPartyRelationshipReply actualReply = transformer.populateFinalResponse(
				testUtils.getAllContractStatusActiveBusinessPlatformLookupResult(),
				testUtils.getAllContractStatusActivePartyLookupResult(), true);

		assertThat(actualReply).isEqualToComparingFieldByFieldRecursively(
				testUtils.getAllContractStatusActiveSearchPartyRelationshipReplyExpected());
	}

	@Test
	public void givenSearchAllWithActiveContractStatusWithEachConditionThenExpectedReplyReturned() {
		final SearchPartyReplyAllResultTransformer transformer = new SearchPartyReplyAllResultTransformer();
		final SearchPartyRelationshipReply actualReply = transformer.populateFinalResponse(
				testUtils.getAllContractStatusActiveWithEachConditionBusinessPlatformLookupResult(),
				testUtils.getAllContractStatusActivePartyLookupResult(), true);

		assertThat(actualReply).isEqualToComparingFieldByFieldRecursively(
				testUtils.getAllContractStatusActiveWithEachConditionSearchPartyRelationshipReplyExpected());
	}

	@Test
	public void givenSearchAllWithTerminatedContractStatusThenExpectedReplyReturned() {
		final SearchPartyReplyAllResultTransformer transformer = new SearchPartyReplyAllResultTransformer();
		final SearchPartyRelationshipReply actualReply = transformer.populateFinalResponse(
				testUtils.getAllContractStatusTerminatedBusinessPlatformLookupResult(),
				testUtils.getAllContractStatusTerminatedPartyLookupResult(), false);

		assertThat(actualReply).isEqualToComparingFieldByFieldRecursively(
				testUtils.getAllContractStatusTerminatedSearchPartyRelationshipReplyExpected());
	}
}

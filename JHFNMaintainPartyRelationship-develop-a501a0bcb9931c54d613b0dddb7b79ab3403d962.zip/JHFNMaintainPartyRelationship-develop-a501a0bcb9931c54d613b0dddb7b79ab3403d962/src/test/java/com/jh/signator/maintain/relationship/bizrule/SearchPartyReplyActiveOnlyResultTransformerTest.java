/**
 *
 */
package com.jh.signator.maintain.relationship.bizrule;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import com.jh.signator.maintain.relationship.MaintainRelationshipApplication;
import com.jh.signator.maintain.relationship.test.data.SearchPartyRelationshipTestDataUtils;
import com.manulife.esb.xsd.distribution.jhfn.partyrelationship.SearchPartyRelationshipReply;

/**
 * Test Class for SearchPartyReplyActiveOnlyResultTransformer.
 */
// TODO: @RunWith and @SpringBootTest when can determine what
// DataMappingCrossLookUp is doing and how to modify so don't need to load
// spring context to use. Which slows the test down needlessly.
@ActiveProfiles("test")
@RunWith(SpringRunner.class)
@SpringBootTest(classes = MaintainRelationshipApplication.class, webEnvironment = WebEnvironment.MOCK)
public class SearchPartyReplyActiveOnlyResultTransformerTest {
	private final SearchPartyRelationshipTestDataUtils testUtils = new SearchPartyRelationshipTestDataUtils();

	@Test
	public void givenActiveOnlyRepwtCaseThenExpectedReplyReturned() {
		final SearchPartyReplyActiveOnlyResultTransformer transformer = new SearchPartyReplyActiveOnlyResultTransformer();
		final SearchPartyRelationshipReply actualReply = transformer.populateFinalResponse(
				testUtils.getActiveOnlyBusinessPlatformLookupResult(), testUtils.getActiveOnlyPartyLookupResult());
		assertThat(actualReply).isEqualToComparingFieldByFieldRecursively(
				testUtils.getActiveOnlySearchPartyRelationshipReplyExpected());
	}

	@Test
	public void givenActiveOnlyMpCaseThenExpectedReplyReturned() {
		final SearchPartyReplyActiveOnlyResultTransformer transformer = new SearchPartyReplyActiveOnlyResultTransformer();
		final SearchPartyRelationshipReply actualReply = transformer.populateFinalResponse(
				testUtils.getActiveOnlyMpBusinessPlatformLookupResult(), testUtils.getActiveOnlyPartyLookupResult());

		final SearchPartyRelationshipReply reply = testUtils.getActiveOnlyMpSearchPartyRelationshipReplyExpected();
		assertThat(actualReply).isEqualToComparingFieldByFieldRecursively(reply);
	}

	@Test
	public void givenActiveOnlyAcsCaseThenExpectedReplyReturned() {
		final SearchPartyReplyActiveOnlyResultTransformer transformer = new SearchPartyReplyActiveOnlyResultTransformer();
		final SearchPartyRelationshipReply actualReply = transformer.populateFinalResponse(
				testUtils.getActiveOnlyAcsBusinessPlatformLookupResult(), testUtils.getActiveOnlyPartyLookupResult());

		final SearchPartyRelationshipReply reply = testUtils.getActiveOnlyAcsSearchPartyRelationshipReplyExpected();
		assertThat(actualReply).isEqualToComparingFieldByFieldRecursively(reply);
	}

	@Test
	public void givenActiveOnlyFirmStaffCaseThenExpectedReplyReturned() {
		final SearchPartyReplyActiveOnlyResultTransformer transformer = new SearchPartyReplyActiveOnlyResultTransformer();
		final SearchPartyRelationshipReply actualReply = transformer.populateFinalResponse(
				testUtils.getActiveOnlyFirmStaffBusinessPlatformLookupResult(),
				testUtils.getActiveOnlyPartyLookupResult());

		final SearchPartyRelationshipReply reply = testUtils
				.getActiveOnlyFirmStaffSearchPartyRelationshipReplyExpected();
		assertThat(actualReply).isEqualToComparingFieldByFieldRecursively(reply);
	}

	@Test
	public void givenActiveOnlyOtherwiseCaseThenExpectedReplyReturned() {
		final SearchPartyReplyActiveOnlyResultTransformer transformer = new SearchPartyReplyActiveOnlyResultTransformer();
		final SearchPartyRelationshipReply actualReply = transformer.populateFinalResponse(
				testUtils.getActiveOnlyOtherwiseBusinessPlatformLookupResult(),
				testUtils.getActiveOnlyPartyLookupResult());

		final SearchPartyRelationshipReply reply = testUtils
				.getActiveOnlyOtherwiseSearchPartyRelationshipReplyExpected();

		assertThat(actualReply).isEqualToComparingFieldByFieldRecursively(reply);
	}

}

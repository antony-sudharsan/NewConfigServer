package com.jh.signator.maintain.relationship.dao;

import static junit.framework.TestCase.assertTrue;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import com.jh.signator.maintain.relationship.exception.RecordNotFoundException;
import com.jh.signator.maintain.relationship.model.data.LookupByConcatenation;
import com.jh.signator.maintain.relationship.model.data.PartyLookUpResponse;

@ActiveProfiles("test")
@RunWith(SpringRunner.class)
public class MaintainRelationshipReadDaoImplTest {

	@Mock
	JdbcTemplate template = mock(JdbcTemplate.class);

	List<LookupByConcatenation> readPartyRelationship = new ArrayList<>();
	LookupByConcatenation lookupByConcatenation = new LookupByConcatenation();

	@InjectMocks
	private MaintainRelationshipReadDaoImpl maintainRelationshipDAO;

	@Before
	public void setup() throws Exception {
		lookupByConcatenation.setAgency_cd(10.0);
		lookupByConcatenation.setAgent_org_prd_id("TEST");
		lookupByConcatenation.setAgent_prd_id("TEST12");
		lookupByConcatenation.setCreat_by_nm("TEST1");
		lookupByConcatenation.setLast_upd_by_nm("TEST12");
		readPartyRelationship.add(lookupByConcatenation);
		final PartyLookUpResponse partyLookUpResponse = new PartyLookUpResponse();
		partyLookUpResponse.setAgency_cd(10.0);
		partyLookUpResponse.setOrg_agency_cd(10.0);
		partyLookUpResponse.setParty_id_no(10.0);

	}

	@Test
	public void readPartyRelationshipTest() throws Exception {
		List<LookupByConcatenation> actualLookupByConcatenation = new ArrayList<>();
		when(template.query(anyString(), any(Object[].class), any(RowMapper.class))).thenReturn(readPartyRelationship);
		actualLookupByConcatenation = maintainRelationshipDAO.readPartyRelationship("test", "test", "1234", "1234");
		assertTrue(actualLookupByConcatenation.get(0).getAgency_cd() == readPartyRelationship.get(0).getAgency_cd());
		assertTrue(actualLookupByConcatenation.get(0).getAgent_org_prd_id() == readPartyRelationship.get(0)
				.getAgent_org_prd_id());
		assertTrue(
				actualLookupByConcatenation.get(0).getCreat_by_nm() == readPartyRelationship.get(0).getCreat_by_nm());
		assertTrue(actualLookupByConcatenation.get(0).getLast_upd_by_nm() == readPartyRelationship.get(0)
				.getLast_upd_by_nm());
	}

	@Test(expected = RecordNotFoundException.class)
	public void expectReadPartyRelationshipNotFoundTest() throws Exception {
		// ReadPartyRelationshipRequest readPartyRelationshipRequest=null;
		when(maintainRelationshipDAO.partyLookUpResponse("1234", "1234", "1234"))
				.thenThrow(new RecordNotFoundException("Record Not found"));
		maintainRelationshipDAO.partyLookUpResponse("1234", "1234", "1234");
	}

}

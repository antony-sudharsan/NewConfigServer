package com.jh.signator.maintain.relationship.endpoint;

import static org.assertj.core.api.Assertions.assertThat;

import java.io.IOException;
import java.util.Iterator;

import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.springframework.boot.context.embedded.LocalServerPort;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.util.ClassUtils;
import org.springframework.ws.WebServiceMessage;
import org.springframework.ws.client.core.WebServiceMessageCallback;
import org.springframework.ws.client.core.WebServiceMessageExtractor;
import org.springframework.ws.client.core.WebServiceTemplate;
import org.springframework.ws.client.support.interceptor.ClientInterceptor;
import org.springframework.ws.soap.SoapHeader;
import org.springframework.ws.soap.SoapHeaderElement;
import org.springframework.ws.soap.SoapMessage;
import org.springframework.ws.soap.client.SoapFaultClientException;
import org.springframework.ws.support.MarshallingUtils;

import com.jh.signator.maintain.relationship.test.data.ReadPartyRelationshipTestDataUtils;
import com.jh.signator.maintain.relationship.test.data.SearchPartyRelationshipTestDataUtils;
import com.manulife.esb.xsd.common.jh.header.JHHeader;
import com.manulife.esb.xsd.distribution.jhfn.partyrelationship.ReadPartyRelationshipReply;
import com.manulife.esb.xsd.distribution.jhfn.partyrelationship.ReadPartyRelationshipRequest;
import com.manulife.esb.xsd.distribution.jhfn.partyrelationship.SearchPartyRelationshipReply;
import com.manulife.esb.xsd.distribution.jhfn.partyrelationship.SearchPartyRelationshipRequest;

@ActiveProfiles("test,test-fake")
@RunWith(SpringRunner.class)
// @ContextConfiguration(classes = { TestConfig.class,
// MaintainRelationshipApplication.class })
@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT)
public class MaintainPartyRelationshipEndpointIntegrationTest {

	private final Jaxb2Marshaller marshaller = new Jaxb2Marshaller();

	@LocalServerPort
	private int port;

	@Rule
	public ExpectedException exception = ExpectedException.none();

	private final SearchPartyRelationshipTestDataUtils searchTestUtils = new SearchPartyRelationshipTestDataUtils();
	private final ReadPartyRelationshipTestDataUtils readTestUtils = new ReadPartyRelationshipTestDataUtils();

	private String endPointURI;

	@Before
	public void init() throws Exception {
		marshaller.setPackagesToScan(ClassUtils.getPackageName(SearchPartyRelationshipRequest.class),
				ClassUtils.getPackageName(ReadPartyRelationshipRequest.class),
				ClassUtils.getPackageName(JHHeader.class));
		marshaller.afterPropertiesSet();
		endPointURI = "http://localhost:" + port + "/MaintainPartyRelationship_1.0/";
	}

	@Test
	public void testValidSearchPartyRelationshipRequestReturnsResponse() {

		final WebServiceTemplate ws = new WebServiceTemplate(marshaller);
		// client interceptor will set the sample request JH Header
		ws.setInterceptors(new ClientInterceptor[] { new TestClientInterceptor() });

		assertThat(ws.marshalSendAndReceive(endPointURI, searchTestUtils.getAllSearchPartyRelationshipRequest(
				SearchPartyRelationshipTestDataUtils.ALL_CONTRACT_STATUS_ACTIVE_TEST_ID))).isNotNull();
	}

	@Test
	public void givenSearchAllWithActiveContractStatusThenExpectedReplyReturned() {

		final WebServiceTemplate ws = new WebServiceTemplate(marshaller);
		ws.setDefaultUri(endPointURI);
		// client interceptor will set the sample request JH Header
		ws.setInterceptors(new ClientInterceptor[] { new TestClientInterceptor() });

		final SearchPartyRelationshipRequest request = searchTestUtils.getAllSearchPartyRelationshipRequest(
				SearchPartyRelationshipTestDataUtils.ALL_CONTRACT_STATUS_ACTIVE_TEST_ID);

		// Use WebServiceMessageExtractor to get Body and Header
		final SearchPartyRelationshipReplyWrapper responseAndHeader = ws
				.sendAndReceive(new WebServiceMessageCallback() {
					@Override
					public void doWithMessage(final WebServiceMessage message) throws IOException {
						MarshallingUtils.marshal(marshaller, request, message);
					}
				}, new WebServiceMessageExtractor<SearchPartyRelationshipReplyWrapper>() {
					@Override
					public SearchPartyRelationshipReplyWrapper extractData(final WebServiceMessage message)
							throws IOException {
						final SoapHeader header = ((SoapMessage) message).getSoapHeader();
						JHHeader responseJhHeader = null;
						// should be at most one header returned
						final Iterator<SoapHeaderElement> it = header.examineAllHeaderElements();
						if (it.hasNext()) {
							responseJhHeader = (JHHeader) marshaller.unmarshal(it.next().getSource());
						}
						final SearchPartyRelationshipReply responseBody = (SearchPartyRelationshipReply) MarshallingUtils
								.unmarshal(marshaller, message);
						return new SearchPartyRelationshipReplyWrapper(responseBody, responseJhHeader);
					}
				});

		assertThat(responseAndHeader).isNotNull();
		assertThat(responseAndHeader.getSearchPartyRelationshipReply()).isNotNull();
		assertThat(responseAndHeader.getHeader()).isNotNull();
		assertThat(responseAndHeader.getSearchPartyRelationshipReply()).isEqualToComparingFieldByFieldRecursively(
				searchTestUtils.getAllContractStatusActiveSearchPartyRelationshipReplyExpected());
	}

	@Test
	public void givenSearchAllWhenNoPartyResultLookupReturnedThenRecordNotFoundSoapFaultReturned() {

		final WebServiceTemplate ws = new WebServiceTemplate(marshaller);
		// client interceptor will set the sample request JH Header
		ws.setInterceptors(new ClientInterceptor[] { new TestClientInterceptor() });
		final SearchPartyRelationshipRequest request = searchTestUtils.getAllSearchPartyRelationshipRequest(
				SearchPartyRelationshipTestDataUtils.ALL_CONTRACT_STATUS_ACTIVE_TEST_ID);
		// modify value to return no result
		request.getPartySearchCriteria().setValue("1111");

		exception.expect(SoapFaultClientException.class);
		ws.marshalSendAndReceive(endPointURI, request);
	}

	@Test
	public void testValidReadPartyRelationshipRequestReturnsResponse() {

		final WebServiceTemplate ws = new WebServiceTemplate(marshaller);
		// client interceptor will set the sample request JH Header
		ws.setInterceptors(new ClientInterceptor[] { new TestClientInterceptor() });

		assertThat(
				ws.marshalSendAndReceive(endPointURI, readTestUtils.getBusinessPlatformReadPartyRelationshipRequest()))
						.isNotNull();
	}

	@Test
	public void givenBusinessPlatformReadRequestThenExpectedReplyReturned() {

		final WebServiceTemplate ws = new WebServiceTemplate(marshaller);
		ws.setDefaultUri(endPointURI);
		// client interceptor will set the sample request JH Header
		ws.setInterceptors(new ClientInterceptor[] { new TestClientInterceptor() });

		final ReadPartyRelationshipRequest request = readTestUtils.getBusinessPlatformReadPartyRelationshipRequest();

		// Use WebServiceMessageExtractor to get Body and Header
		final ReadPartyRelationshipReplyWrapper responseAndHeader = ws.sendAndReceive(new WebServiceMessageCallback() {
			@Override
			public void doWithMessage(final WebServiceMessage message) throws IOException {
				MarshallingUtils.marshal(marshaller, request, message);
			}
		}, new WebServiceMessageExtractor<ReadPartyRelationshipReplyWrapper>() {
			@Override
			public ReadPartyRelationshipReplyWrapper extractData(final WebServiceMessage message) throws IOException {
				final SoapHeader header = ((SoapMessage) message).getSoapHeader();
				JHHeader responseJhHeader = null;
				// should be at most one header returned
				final Iterator<SoapHeaderElement> it = header.examineAllHeaderElements();
				if (it.hasNext()) {
					responseJhHeader = (JHHeader) marshaller.unmarshal(it.next().getSource());
				}
				final ReadPartyRelationshipReply responseBody = (ReadPartyRelationshipReply) MarshallingUtils
						.unmarshal(marshaller, message);
				return new ReadPartyRelationshipReplyWrapper(responseBody, responseJhHeader);
			}
		});

		assertThat(responseAndHeader).isNotNull();
		assertThat(responseAndHeader.getReadPartyRelationshipReply()).isNotNull();
		assertThat(responseAndHeader.getHeader()).isNotNull();
		assertThat(responseAndHeader.getReadPartyRelationshipReply()).isEqualToComparingFieldByFieldRecursively(
				readTestUtils.getBusinessPlatformReadPartyRelationshipExpectedReply());
	}

	@Test
	public void givenReadPartyRelationshipByIDWhenNoRecordFoundThenRecordNotFoundSoapFaultReturned() {

		final WebServiceTemplate ws = new WebServiceTemplate(marshaller);
		// client interceptor will set the sample request JH Header
		ws.setInterceptors(new ClientInterceptor[] { new TestClientInterceptor() });
		final ReadPartyRelationshipRequest request = readTestUtils.getBusinessPlatformReadPartyRelationshipRequest();
		// modify value to return no result
		request.setRelationID("14456");

		exception.expect(SoapFaultClientException.class);
		ws.marshalSendAndReceive(endPointURI, request);
	}
}

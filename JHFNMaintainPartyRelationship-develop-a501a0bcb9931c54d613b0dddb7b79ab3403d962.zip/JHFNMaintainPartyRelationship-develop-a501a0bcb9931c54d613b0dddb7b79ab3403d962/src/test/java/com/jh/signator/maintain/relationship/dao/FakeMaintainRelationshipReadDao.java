/**
 *
 */
package com.jh.signator.maintain.relationship.dao;

import java.util.List;

import com.jh.signator.maintain.relationship.model.data.LookupByConcatenation;
import com.jh.signator.maintain.relationship.model.data.PartyLookUpResponse;
import com.jh.signator.maintain.relationship.test.data.ReadPartyRelationshipTestDataUtils;
import com.manulife.esb.xsd.distribution.jhfn.partyrelationship.ReadPartyRelationshipReply;

/**
 * Fake for MaintainRelationshipReadDao.
 *
 */
public class FakeMaintainRelationshipReadDao implements MaintainRelationshipReadDao {

	private final ReadPartyRelationshipTestDataUtils testUtils = new ReadPartyRelationshipTestDataUtils();

	@Override
	public ReadPartyRelationshipReply readPartyRelationshipByID(final String relationID, final String messageUUID,
			final String sourceSystemName) {
		if (ReadPartyRelationshipTestDataUtils.VALID_BUS_PLATFORM_READ_PARTY_RELATIONSHIP_BY_ID.equals(relationID)) {
			return testUtils.getReadPartyRelationshipByIDReply();
		}
		return null;
	}

	@Override
	public List<LookupByConcatenation> readPartyRelationship(final String orgAgencyCode, final String agencyCode,
			final String messageUUID, final String sourceSystemName) {
		// TODO: Note implemented
		return null;
	}

	@Override
	public PartyLookUpResponse partyLookUpResponse(final String relationId, final String messageUUID,
			final String sourceSystemName) {
		// TODO Auto-generated method stub
		return null;
	}

}

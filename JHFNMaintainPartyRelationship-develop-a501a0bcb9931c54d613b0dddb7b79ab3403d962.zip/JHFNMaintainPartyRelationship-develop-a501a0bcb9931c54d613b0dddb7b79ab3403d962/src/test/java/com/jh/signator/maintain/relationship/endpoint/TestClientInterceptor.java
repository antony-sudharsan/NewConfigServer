package com.jh.signator.maintain.relationship.endpoint;

import org.springframework.ws.client.WebServiceClientException;
import org.springframework.ws.client.support.interceptor.ClientInterceptor;
import org.springframework.ws.context.MessageContext;
import org.springframework.ws.soap.SoapHeader;
import org.springframework.ws.soap.SoapMessage;

import com.jh.signator.maintain.relationship.utils.JHHeaderJaxbUtils;
import com.manulife.esb.xsd.common.jh.header.JHHeader;
import com.manulife.esb.xsd.common.jh.header.MessageSource;

public class TestClientInterceptor implements ClientInterceptor {
	private static final String MESSAGE_UUID = "OEE_1234567_RPS";
	private static final String SOURCE_SYSTEM = "ESB";

	private final JHHeaderJaxbUtils jhHeaderJaxbUtils;

	public TestClientInterceptor() {
		this.jhHeaderJaxbUtils = new JHHeaderJaxbUtils();
		;
	}

	@Override
	public boolean handleRequest(final MessageContext messageContext) throws WebServiceClientException {
		final SoapMessage soapMessage = (SoapMessage) messageContext.getRequest();
		final SoapHeader soapHeader = soapMessage.getSoapHeader();
		final JHHeader jhHeader = createSampleJHHeader();
		jhHeaderJaxbUtils.marshallJHHeaderToResult(jhHeader, soapHeader.getResult());
		return true;
	}

	@Override
	public boolean handleResponse(final MessageContext messageContext) throws WebServiceClientException {
		return true;
	}

	@Override
	public boolean handleFault(final MessageContext messageContext) throws WebServiceClientException {
		return true;
	}

	@Override
	public void afterCompletion(final MessageContext messageContext, final Exception ex)
			throws WebServiceClientException {

	}

	private JHHeader createSampleJHHeader() {
		final JHHeader header = new JHHeader();
		header.setMessageUID(MESSAGE_UUID);
		final MessageSource messageSource = new MessageSource();
		messageSource.setApplicationName(SOURCE_SYSTEM);
		header.setMessageSource(messageSource);
		return header;
	}

}

/**
 *
 */
package com.jh.signator.maintain.relationship.utils;

import static org.assertj.core.api.Assertions.assertThat;

import java.math.BigDecimal;

import org.junit.Test;

import com.jh.signator.maintain.relationship.model.data.BusinessPlatformLookUpCriteria;
import com.jh.signator.maintain.relationship.model.data.PartyLookupResult;
import com.jh.signator.maintain.relationship.model.data.SearchPartyLookupCriteria;
import com.manulife.esb.xsd.distribution.jhfn.partyrelationship.DATAFIELD;
import com.manulife.esb.xsd.distribution.jhfn.partyrelationship.PartySearchCriteria;
import com.manulife.esb.xsd.distribution.jhfn.partyrelationship.SEARCHSTATUS;
import com.manulife.esb.xsd.distribution.jhfn.partyrelationship.SearchPartyRelationshipRequest;

/**
 * Test class for SearchPartyUtils.
 *
 */
public class SearchPartyUtilsTest {

	private static final String TEST_VALUE = "12345";
	private static final BigDecimal TEST_FIRM_CD = new BigDecimal("26");

	@Test
	public void givenPartyIdNoAndActiveOnlyThenCriteriaMatchesExpected() {
		final SearchPartyRelationshipRequest request = new SearchPartyRelationshipRequest();
		final PartySearchCriteria criteria = new PartySearchCriteria();
		request.setPartySearchCriteria(criteria);
		criteria.setDataField(DATAFIELD.PARTY_ID_NO);
		criteria.setValue(TEST_VALUE);
		criteria.setSearchStatus(SEARCHSTATUS.ACTIVE_ONLY);

		final SearchPartyLookupCriteria actualSearchCriteria = SearchPartyUtils
				.populateSearchPartyLookupCriteriaForActiveOnly(request);

		final SearchPartyLookupCriteria expectedCriteria = new SearchPartyLookupCriteria();
		expectedCriteria.setPrdId(SearchPartyUtils.EMPTY_STRING);
		expectedCriteria.setPrdIdNo(request.getPartySearchCriteria().getValue());
		expectedCriteria.setPrdIdP2p(SearchPartyUtils.EMPTY_STRING);
		expectedCriteria.setPrdIdNoP2p(request.getPartySearchCriteria().getValue());

		assertThat(actualSearchCriteria).isEqualToComparingFieldByFieldRecursively(expectedCriteria);
	}

	@Test
	public void givenPrdIdAndActiveOnlyThenCriteriaMatchesExpected() {
		final SearchPartyRelationshipRequest request = new SearchPartyRelationshipRequest();
		final PartySearchCriteria criteria = new PartySearchCriteria();
		request.setPartySearchCriteria(criteria);
		criteria.setDataField(DATAFIELD.PRD_ID);
		criteria.setValue(TEST_VALUE);
		criteria.setSearchStatus(SEARCHSTATUS.ACTIVE_ONLY);

		final SearchPartyLookupCriteria actualSearchCriteria = SearchPartyUtils
				.populateSearchPartyLookupCriteriaForActiveOnly(request);

		final SearchPartyLookupCriteria expectedCriteria = new SearchPartyLookupCriteria();
		expectedCriteria.setPrdId(request.getPartySearchCriteria().getValue());
		expectedCriteria.setPrdIdNo(SearchPartyUtils.EMPTY_STRING);
		expectedCriteria.setPrdIdP2p(request.getPartySearchCriteria().getValue());
		expectedCriteria.setPrdIdNoP2p(SearchPartyUtils.EMPTY_STRING);

		assertThat(actualSearchCriteria).isEqualToComparingFieldByFieldRecursively(expectedCriteria);
	}

	@Test
	public void givenPartyIdNoAndAllThenCriteriaMatchesExpected() {
		final SearchPartyRelationshipRequest request = new SearchPartyRelationshipRequest();
		final PartySearchCriteria criteria = new PartySearchCriteria();
		request.setPartySearchCriteria(criteria);
		criteria.setDataField(DATAFIELD.PARTY_ID_NO);
		criteria.setValue(TEST_VALUE);
		criteria.setSearchStatus(SEARCHSTATUS.ALL);

		final SearchPartyLookupCriteria actualSearchCriteria = SearchPartyUtils
				.populateSearchPartyLookupCriteriaForAll(request);

		final SearchPartyLookupCriteria expectedCriteria = new SearchPartyLookupCriteria();
		expectedCriteria.setPrdIdContract(SearchPartyUtils.EMPTY_STRING);
		expectedCriteria.setPrdIdNoContract(request.getPartySearchCriteria().getValue());
		expectedCriteria.setPrdIdP2p(SearchPartyUtils.EMPTY_STRING);
		expectedCriteria.setPrdIdNoP2p(request.getPartySearchCriteria().getValue());
		expectedCriteria.setPrdIdContractTerm(SearchPartyUtils.EMPTY_STRING);
		expectedCriteria.setPrdIdNoContractTerm(request.getPartySearchCriteria().getValue());
		expectedCriteria.setPrdIdP2pTerm(SearchPartyUtils.EMPTY_STRING);
		expectedCriteria.setPrdIdNoP2pTerm(request.getPartySearchCriteria().getValue());

		assertThat(actualSearchCriteria).isEqualToComparingFieldByFieldRecursively(expectedCriteria);
	}

	@Test
	public void givenPrdIdNoAndAllThenCriteriaMatchesExpected() {
		final SearchPartyRelationshipRequest request = new SearchPartyRelationshipRequest();
		final PartySearchCriteria criteria = new PartySearchCriteria();
		request.setPartySearchCriteria(criteria);
		criteria.setDataField(DATAFIELD.PRD_ID);
		criteria.setValue(TEST_VALUE);
		criteria.setSearchStatus(SEARCHSTATUS.ALL);

		final SearchPartyLookupCriteria actualSearchCriteria = SearchPartyUtils
				.populateSearchPartyLookupCriteriaForAll(request);

		final SearchPartyLookupCriteria expectedCriteria = new SearchPartyLookupCriteria();
		expectedCriteria.setPrdIdContract(request.getPartySearchCriteria().getValue());
		expectedCriteria.setPrdIdNoContract(SearchPartyUtils.EMPTY_STRING);
		expectedCriteria.setPrdIdP2p(request.getPartySearchCriteria().getValue());
		expectedCriteria.setPrdIdNoP2p(SearchPartyUtils.EMPTY_STRING);
		expectedCriteria.setPrdIdContractTerm(request.getPartySearchCriteria().getValue());
		expectedCriteria.setPrdIdNoContractTerm(SearchPartyUtils.EMPTY_STRING);
		expectedCriteria.setPrdIdP2pTerm(request.getPartySearchCriteria().getValue());
		expectedCriteria.setPrdIdNoP2pTerm(SearchPartyUtils.EMPTY_STRING);

		assertThat(actualSearchCriteria).isEqualToComparingFieldByFieldRecursively(expectedCriteria);
	}

	@Test
	public void givenFirmCdThenBusinessPlatformLookupCriteriaMatchesExpected() {
		final PartyLookupResult result = new PartyLookupResult();
		result.setFirmCd(TEST_FIRM_CD);

		final BusinessPlatformLookUpCriteria actualBusinessCriteria = SearchPartyUtils
				.populateBusinessPlatformLookupCriteria(result);

		final BusinessPlatformLookUpCriteria expectedBusinessCriteria = new BusinessPlatformLookUpCriteria();
		expectedBusinessCriteria.setAgency_cd(TEST_FIRM_CD.toString());
		expectedBusinessCriteria.setOrg_agency_cd(TEST_FIRM_CD.toString());

		assertThat(actualBusinessCriteria).isEqualToComparingFieldByFieldRecursively(expectedBusinessCriteria);
	}

	@Test
	public void givenNoFirmCdThenBusinessPlatformLookupCriteriaMatchesExpected() {
		final PartyLookupResult result = new PartyLookupResult();

		final BusinessPlatformLookUpCriteria actualBusinessCriteria = SearchPartyUtils
				.populateBusinessPlatformLookupCriteria(result);

		final BusinessPlatformLookUpCriteria expectedBusinessCriteria = new BusinessPlatformLookUpCriteria();
		expectedBusinessCriteria.setAgency_cd(SearchPartyUtils.EMPTY_STRING);
		expectedBusinessCriteria.setOrg_agency_cd(SearchPartyUtils.EMPTY_STRING);

		assertThat(actualBusinessCriteria).isEqualToComparingFieldByFieldRecursively(expectedBusinessCriteria);
	}
}

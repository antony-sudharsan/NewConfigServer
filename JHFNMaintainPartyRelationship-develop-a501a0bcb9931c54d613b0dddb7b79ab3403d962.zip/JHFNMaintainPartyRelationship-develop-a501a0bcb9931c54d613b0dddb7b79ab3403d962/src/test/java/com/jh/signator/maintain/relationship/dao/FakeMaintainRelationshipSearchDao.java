package com.jh.signator.maintain.relationship.dao;

import java.util.ArrayList;
import java.util.List;

import com.jh.signator.maintain.relationship.model.data.BusinessPlatformLookUpCriteria;
import com.jh.signator.maintain.relationship.model.data.PartyLookupResult;
import com.jh.signator.maintain.relationship.model.data.SearchBusinessPlatformLookUpResult;
import com.jh.signator.maintain.relationship.model.data.SearchPartyLookupCriteria;
import com.jh.signator.maintain.relationship.test.data.SearchPartyRelationshipTestDataUtils;

public class FakeMaintainRelationshipSearchDao implements MaintainRelationshipSearchDao {

	private final SearchPartyRelationshipTestDataUtils testUtils = new SearchPartyRelationshipTestDataUtils();

	@Override
	public PartyLookupResult getActiveOnlyPartyLookupResult(final SearchPartyLookupCriteria searchPartyLookupCriteria) {
		// TODO: implement
		return null;
	}

	@Override
	public List<SearchBusinessPlatformLookUpResult> getActiveOnlyBusinessPlatformLookupResult(
			final BusinessPlatformLookUpCriteria criteria) {
		// TODO: implement
		return new ArrayList<>();
	}

	@Override
	public PartyLookupResult getAllPartyLookupResult(final SearchPartyLookupCriteria searchPartyLookupCriteria) {
		// if it is the expected test value, return result, else treat as record not
		// found.
		if (searchPartyLookupCriteria.getPrdIdNoContractTerm()
				.equals(SearchPartyRelationshipTestDataUtils.ALL_CONTRACT_STATUS_ACTIVE_TEST_ID)) {
			return testUtils.getAllContractStatusActivePartyLookupResult();
		} else if (searchPartyLookupCriteria.getPrdIdNoContractTerm()
				.equals(SearchPartyRelationshipTestDataUtils.ALL_CONTRACT_STATUS_TERMINATED_TEST_ID)) {
			return testUtils.getAllContractStatusTerminatedPartyLookupResult();
		} else {
			return null;
		}
	}

	@Override
	public List<SearchBusinessPlatformLookUpResult> getAllContractStatusActiveBusinessPlatformLookupResult(
			final BusinessPlatformLookUpCriteria criteria) {
		return testUtils.getAllContractStatusActiveBusinessPlatformLookupResult();
	}

	@Override
	public List<SearchBusinessPlatformLookUpResult> getAllContractStatusTerminatedBusinessPlatformLookupResult(
			final BusinessPlatformLookUpCriteria criteria) {
		// TODO: implement
		return new ArrayList<>();
	}
}
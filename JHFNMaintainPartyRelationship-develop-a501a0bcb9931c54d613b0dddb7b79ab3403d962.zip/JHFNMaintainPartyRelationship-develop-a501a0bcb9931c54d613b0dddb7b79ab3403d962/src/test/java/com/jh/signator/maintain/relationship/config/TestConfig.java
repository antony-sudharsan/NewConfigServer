package com.jh.signator.maintain.relationship.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.context.annotation.Profile;

import com.jh.signator.maintain.relationship.dao.FakeMaintainRelationshipReadDao;
import com.jh.signator.maintain.relationship.dao.FakeMaintainRelationshipSearchDao;
import com.jh.signator.maintain.relationship.dao.MaintainRelationshipReadDao;
import com.jh.signator.maintain.relationship.dao.MaintainRelationshipSearchDao;

@Profile("test-fake")
@Configuration
public class TestConfig {

	@Bean
	@Primary
	public MaintainRelationshipSearchDao getMaintainRelationshipSearchDao() {
		return new FakeMaintainRelationshipSearchDao();
	}

	@Bean
	@Primary
	public MaintainRelationshipReadDao getMaintainRelationshipReadDao() {
		return new FakeMaintainRelationshipReadDao();
	}
}
